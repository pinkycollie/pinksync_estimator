#!/usr/bin/env node

/**
 * Script to run the Yeoman generator from the command line
 */
const path = require('path');
const { spawnSync } = require('child_process');
const chalk = require('chalk');

// Define generator path
const generatorPath = path.resolve(__dirname, '../generators/app');

console.log(chalk.cyan('🧙‍♂️ Pinky\'s AI OS Generator 🧙‍♂️'));
console.log(chalk.yellow('Scaffolding a new component...\n'));

// Run the generator
const result = spawnSync('node', [
  require.resolve('yo/lib/cli.js'),
  '--no-insight',
  '--no-update-notifier',
  generatorPath
], {
  stdio: 'inherit',
  cwd: process.cwd()
});

if (result.error) {
  console.error(chalk.red('Failed to run generator:'), result.error);
  process.exit(1);
}

if (result.status !== 0) {
  console.error(chalk.red(`Generator exited with status code: ${result.status}`));
  process.exit(result.status);
}

console.log(chalk.green('\n✨ Component generated successfully! ✨'));