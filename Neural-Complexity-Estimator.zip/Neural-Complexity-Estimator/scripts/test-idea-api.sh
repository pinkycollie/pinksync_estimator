#!/bin/bash

# PinkSync API Test Script
# This script tests the Idea Ingestor API endpoints

# Base URL - change this to match your environment
BASE_URL="http://localhost:5000/api/ideas"

# Test authentication and session cookie
# You must be logged in via the web UI before running this script
SESSION_COOKIE=""

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}PinkSync Idea Ingestor API Test${NC}"
echo "================================="
echo ""

# Function to make API requests
make_request() {
  local method=$1
  local endpoint=$2
  local data=$3
  local expected_status=$4
  
  echo -e "${YELLOW}Testing: ${method} ${endpoint}${NC}"
  
  # Make the request
  if [ -z "$data" ]; then
    # GET or DELETE request
    response=$(curl -s -X "${method}" \
      -w "%{http_code}" \
      -b "$SESSION_COOKIE" \
      "${BASE_URL}${endpoint}")
  else
    # POST or PUT with data
    response=$(curl -s -X "${method}" \
      -w "%{http_code}" \
      -H "Content-Type: application/json" \
      -b "$SESSION_COOKIE" \
      -d "${data}" \
      "${BASE_URL}${endpoint}")
  fi
  
  # Extract status code (last 3 characters)
  status_code=${response: -3}
  # Extract response body (everything except last 3 characters)
  body=${response:0:${#response}-3}
  
  # Check status code
  if [ "$status_code" = "$expected_status" ]; then
    echo -e "${GREEN}✓ Status: ${status_code} (Expected: ${expected_status})${NC}"
  else
    echo -e "${RED}✗ Status: ${status_code} (Expected: ${expected_status})${NC}"
  fi
  
  # Pretty print the JSON response
  echo "Response:"
  echo "$body" | python -m json.tool || echo "$body"
  echo ""
}

# 1. Test get all ideas
test_get_all_ideas() {
  echo -e "${YELLOW}Test: Get All Ideas${NC}"
  make_request "GET" "" "" "200"
}

# 2. Test idea ingestion
test_ingest_idea() {
  echo -e "${YELLOW}Test: Ingest Idea from Text${NC}"
  local data='{
    "content": "I think there should be an app that helps people find parking spaces in busy urban areas. It could use a combination of user reports, IoT sensors, and predictive algorithms to guide drivers to available spots, reducing congestion and frustration.",
    "source": "brainstorming",
    "format": "text"
  }'
  make_request "POST" "/ingest" "$data" "200"
}

# 3. Test manually creating an idea
test_create_idea() {
  echo -e "${YELLOW}Test: Create Idea Manually${NC}"
  local data='{
    "title": "E-commerce Return Reduction AI",
    "description": "An AI system that helps online retailers reduce return rates by analyzing product images, descriptions, and reviews to identify discrepancies and potential sources of customer disappointment.",
    "category": "retail",
    "status": "draft",
    "priority": 6,
    "tags": "ai, ecommerce, retail, returns"
  }'
  make_request "POST" "" "$data" "201"
  # Save the ID for later tests
  IDEA_ID=$(echo "$body" | python -c "import sys, json; print(json.load(sys.stdin)['id'])" 2>/dev/null)
  echo "Created idea with ID: $IDEA_ID"
}

# 4. Test getting a specific idea
test_get_idea() {
  if [ -z "$IDEA_ID" ]; then
    echo -e "${RED}No idea ID available for testing. Run create idea test first.${NC}"
    return
  fi
  echo -e "${YELLOW}Test: Get Idea by ID${NC}"
  make_request "GET" "/$IDEA_ID" "" "200"
}

# 5. Test updating an idea
test_update_idea() {
  if [ -z "$IDEA_ID" ]; then
    echo -e "${RED}No idea ID available for testing. Run create idea test first.${NC}"
    return
  fi
  echo -e "${YELLOW}Test: Update Idea${NC}"
  local data='{
    "title": "AI Returns Prevention Platform",
    "priority": 8
  }'
  make_request "PUT" "/$IDEA_ID" "$data" "200"
}

# 6. Test analyzing an idea
test_analyze_idea() {
  if [ -z "$IDEA_ID" ]; then
    echo -e "${RED}No idea ID available for testing. Run create idea test first.${NC}"
    return
  fi
  echo -e "${YELLOW}Test: Analyze Idea${NC}"
  make_request "POST" "/$IDEA_ID/analyze" "" "200"
}

# 7. Test deleting an idea
test_delete_idea() {
  if [ -z "$IDEA_ID" ]; then
    echo -e "${RED}No idea ID available for testing. Run create idea test first.${NC}"
    return
  fi
  echo -e "${YELLOW}Test: Delete Idea${NC}"
  make_request "DELETE" "/$IDEA_ID" "" "200"
}

# Run tests in sequence
run_all_tests() {
  test_get_all_ideas
  test_ingest_idea
  test_create_idea
  test_get_idea
  test_update_idea
  test_analyze_idea
  test_delete_idea
}

# Execute all tests
if [ "$1" = "all" ]; then
  run_all_tests
else
  echo "Available tests:"
  echo "1. Get all ideas"
  echo "2. Ingest idea from text"
  echo "3. Create idea manually"
  echo "4. Get idea by ID"
  echo "5. Update idea"
  echo "6. Analyze idea"
  echo "7. Delete idea"
  echo "all. Run all tests in sequence"
  echo ""
  read -p "Enter test number to run (or 'all'): " test_number
  
  case $test_number in
    1) test_get_all_ideas ;;
    2) test_ingest_idea ;;
    3) test_create_idea ;;
    4) test_get_idea ;;
    5) test_update_idea ;;
    6) test_analyze_idea ;;
    7) test_delete_idea ;;
    "all") run_all_tests ;;
    *) echo -e "${RED}Invalid test number.${NC}" ;;
  esac
fi

echo -e "${YELLOW}API Testing Completed${NC}"