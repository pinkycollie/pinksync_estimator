#!/usr/bin/env python3
"""
Chat History Extractor - For collecting conversations from various AI platforms

This module provides functionality to:
1. Extract conversations from Claude, ChatGPT, and other AI platforms
2. Process and organize the content for analysis
3. Export the data in formats suitable for technical specification development
"""

import json
import csv
import os
import re
import datetime
import argparse
from pathlib import Path
import pandas as pd
from typing import List, Dict, Any, Optional


class ChatHistoryExtractor:
    """Base class for extracting chat history from AI platforms"""
    
    def __init__(self, output_dir: str = "chat_exports"):
        """Initialize with output directory"""
        self.output_dir = output_dir
        Path(output_dir).mkdir(exist_ok=True, parents=True)
        
    def extract(self) -> List[Dict[str, Any]]:
        """Extract chat history - to be implemented by subclasses"""
        raise NotImplementedError("Subclasses must implement extract()")
    
    def save_as_json(self, data: List[Dict[str, Any]], filename: str) -> str:
        """Save chat history as JSON"""
        filepath = os.path.join(self.output_dir, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return filepath
    
    def save_as_csv(self, data: List[Dict[str, Any]], filename: str) -> str:
        """Save chat history as CSV"""
        filepath = os.path.join(self.output_dir, filename)
        
        if not data:
            return ""
            
        # Get all possible keys for headers
        headers = set()
        for item in data:
            headers.update(item.keys())
        
        with open(filepath, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=sorted(headers))
            writer.writeheader()
            writer.writerows(data)
        return filepath
    
    def process_conversations(self, data: List[Dict[str, Any]]) -> pd.DataFrame:
        """Process conversations into a dataframe for analysis"""
        df = pd.DataFrame(data)
        return df


class ClaudeHistoryExtractor(ChatHistoryExtractor):
    """Extractor for Claude chat history"""
    
    def __init__(self, data_path: str, output_dir: str = "chat_exports"):
        """Initialize with path to Claude data export"""
        super().__init__(output_dir)
        self.data_path = data_path
    
    def extract(self) -> List[Dict[str, Any]]:
        """Extract chat history from Claude data export"""
        try:
            with open(self.data_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            conversations = []
            
            # Process based on Claude's export format
            # This is a placeholder structure - adjust based on actual Claude export format
            for conversation in data.get('conversations', []):
                convo_id = conversation.get('id', 'unknown')
                
                for message in conversation.get('messages', []):
                    conversations.append({
                        'conversation_id': convo_id,
                        'timestamp': message.get('timestamp'),
                        'role': message.get('role', 'unknown'),
                        'content': message.get('content', ''),
                        'platform': 'Claude'
                    })
                    
            return conversations
        except Exception as e:
            print(f"Error extracting Claude history: {e}")
            return []


class ChatGPTHistoryExtractor(ChatHistoryExtractor):
    """Extractor for ChatGPT chat history"""
    
    def __init__(self, data_path: str, output_dir: str = "chat_exports"):
        """Initialize with path to ChatGPT data export"""
        super().__init__(output_dir)
        self.data_path = data_path
    
    def extract(self) -> List[Dict[str, Any]]:
        """Extract chat history from ChatGPT data export"""
        try:
            with open(self.data_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            conversations = []
            
            # Process based on ChatGPT's export format
            # This is a placeholder structure - adjust based on actual ChatGPT export format
            for conversation in data:
                convo_id = conversation.get('id', 'unknown')
                title = conversation.get('title', 'Untitled')
                
                for message in conversation.get('mapping', {}).values():
                    if 'message' in message:
                        msg = message['message']
                        conversations.append({
                            'conversation_id': convo_id,
                            'conversation_title': title,
                            'timestamp': msg.get('create_time'),
                            'role': msg.get('author', {}).get('role', 'unknown'),
                            'content': msg.get('content', {}).get('parts', [''])[0],
                            'platform': 'ChatGPT'
                        })
                    
            return conversations
        except Exception as e:
            print(f"Error extracting ChatGPT history: {e}")
            return []


class GenericChatExtractor(ChatHistoryExtractor):
    """Extractor for other chat platforms with custom format parsing"""
    
    def __init__(self, data_path: str, output_dir: str = "chat_exports", 
                 format_type: str = "json"):
        """Initialize with path to data export and format type"""
        super().__init__(output_dir)
        self.data_path = data_path
        self.format_type = format_type.lower()
    
    def extract(self) -> List[Dict[str, Any]]:
        """Extract chat history from specified format"""
        if self.format_type == "json":
            return self._extract_from_json()
        elif self.format_type == "csv":
            return self._extract_from_csv()
        elif self.format_type == "txt":
            return self._extract_from_txt()
        else:
            print(f"Unsupported format: {self.format_type}")
            return []
    
    def _extract_from_json(self) -> List[Dict[str, Any]]:
        """Extract from JSON format"""
        try:
            with open(self.data_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Handle both array and object formats
            if isinstance(data, list):
                return data
            elif isinstance(data, dict):
                # Try to find conversations/messages in the data structure
                if 'conversations' in data:
                    return data['conversations']
                elif 'messages' in data:
                    return data['messages']
                else:
                    # Return the dict wrapped in a list
                    return [data]
            else:
                print(f"Unexpected JSON structure: {type(data)}")
                return []
        except Exception as e:
            print(f"Error extracting from JSON: {e}")
            return []
    
    def _extract_from_csv(self) -> List[Dict[str, Any]]:
        """Extract from CSV format"""
        try:
            df = pd.read_csv(self.data_path)
            return df.to_dict('records')
        except Exception as e:
            print(f"Error extracting from CSV: {e}")
            return []
    
    def _extract_from_txt(self) -> List[Dict[str, Any]]:
        """Extract from text format using pattern matching"""
        try:
            with open(self.data_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            conversations = []
            
            # Try to detect conversation patterns
            # Pattern: "Role: Message" or "[Timestamp] Role: Message"
            # This is a simple example - adjust regex for your specific format
            timestamp_pattern = r'(?:\[([^\]]+)\])?\s*([^:]+):\s*((?:.+?)(?=\n\s*(?:\[\d|[A-Za-z]+:)|$))'
            matches = re.findall(timestamp_pattern, content, re.DOTALL)
            
            for i, (timestamp, role, message) in enumerate(matches):
                conversations.append({
                    'conversation_id': 'txt_export',
                    'index': i,
                    'timestamp': timestamp.strip() if timestamp else '',
                    'role': role.strip(),
                    'content': message.strip(),
                    'platform': 'Unknown'
                })
                
            return conversations
        except Exception as e:
            print(f"Error extracting from text: {e}")
            return []


class ChatHistoryAnalyzer:
    """Analyzes extracted chat history for insights"""
    
    def __init__(self, chats: List[Dict[str, Any]]):
        """Initialize with chat data"""
        self.chats = chats
        self.df = pd.DataFrame(chats)
    
    def get_conversation_stats(self) -> Dict[str, Any]:
        """Get basic statistics about conversations"""
        stats = {
            'total_messages': len(self.df),
            'conversations': len(self.df['conversation_id'].unique()) if 'conversation_id' in self.df.columns else 0,
            'avg_message_length': self.df['content'].str.len().mean() if 'content' in self.df.columns else 0,
            'platform_distribution': self.df['platform'].value_counts().to_dict() if 'platform' in self.df.columns else {}
        }
        
        # Get role distributions if available
        if 'role' in self.df.columns:
            stats['role_distribution'] = self.df['role'].value_counts().to_dict()
            
        return stats
    
    def extract_key_topics(self) -> Dict[str, int]:
        """Extract and count key topics from conversations"""
        # This is a simple implementation - could be enhanced with NLP techniques
        topics = {}
        
        if 'content' not in self.df.columns:
            return topics
            
        # Define some keywords for your deaf-first infrastructure platform
        keywords = [
            'deaf', 'accessibility', 'api', 'infrastructure', 'platform',
            'tax', 'insurance', 'real estate', 'business', 'modular',
            'integration', 'processor', 'digital space'
        ]
        
        # Count occurrences
        for keyword in keywords:
            count = sum(self.df['content'].str.lower().str.contains(keyword, na=False))
            if count > 0:
                topics[keyword] = count
                
        return dict(sorted(topics.items(), key=lambda x: x[1], reverse=True))
    
    def extract_requirements(self) -> List[str]:
        """Extract potential requirements from conversations"""
        requirements = []
        
        if 'content' not in self.df.columns:
            return requirements
            
        # Look for common requirement patterns
        requirement_patterns = [
            r'(?:need|must|should|could|would require) to (\w+\s.+?)(?:\.|\n|$)',
            r'(?:necessary|important) to (\w+\s.+?)(?:\.|\n|$)',
            r'requirement(?:s)? (?:is|are|include|for) (\w+\s.+?)(?:\.|\n|$)'
        ]
        
        for pattern in requirement_patterns:
            for content in self.df['content'].dropna():
                matches = re.findall(pattern, content, re.IGNORECASE)
                requirements.extend(matches)
                
        # Remove duplicates and clean up
        clean_requirements = []
        for req in requirements:
            cleaned = req.strip()
            if cleaned and cleaned not in clean_requirements:
                clean_requirements.append(cleaned)
                
        return clean_requirements


def main():
    """Main function to run the chat history extraction"""
    parser = argparse.ArgumentParser(description='Extract chat history from AI platforms')
    parser.add_argument('--claude', help='Path to Claude chat history export')
    parser.add_argument('--chatgpt', help='Path to ChatGPT chat history export')
    parser.add_argument('--generic', help='Path to generic chat history file')
    parser.add_argument('--format', default='json', help='Format of generic file (json, csv, txt)')
    parser.add_argument('--output', default='chat_exports', help='Output directory')
    args = parser.parse_args()
    
    all_chats = []
    
    # Process Claude chats if provided
    if args.claude:
        extractor = ClaudeHistoryExtractor(args.claude, args.output)
        claude_chats = extractor.extract()
        all_chats.extend(claude_chats)
        extractor.save_as_json(claude_chats, 'claude_history.json')
        extractor.save_as_csv(claude_chats, 'claude_history.csv')
        print(f"Extracted {len(claude_chats)} messages from Claude")
    
    # Process ChatGPT chats if provided
    if args.chatgpt:
        extractor = ChatGPTHistoryExtractor(args.chatgpt, args.output)
        chatgpt_chats = extractor.extract()
        all_chats.extend(chatgpt_chats)
        extractor.save_as_json(chatgpt_chats, 'chatgpt_history.json')
        extractor.save_as_csv(chatgpt_chats, 'chatgpt_history.csv')
        print(f"Extracted {len(chatgpt_chats)} messages from ChatGPT")
    
    # Process generic chats if provided
    if args.generic:
        extractor = GenericChatExtractor(args.generic, args.output, args.format)
        generic_chats = extractor.extract()
        all_chats.extend(generic_chats)
        extractor.save_as_json(generic_chats, 'generic_history.json')
        extractor.save_as_csv(generic_chats, 'generic_history.csv')
        print(f"Extracted {len(generic_chats)} messages from generic source")
    
    # Analyze all chats if any were extracted
    if all_chats:
        analyzer = ChatHistoryAnalyzer(all_chats)
        
        # Get basic stats
        stats = analyzer.get_conversation_stats()
        print(f"\nExtracted {stats['total_messages']} messages from {stats['conversations']} conversations")
        
        # Extract key topics
        topics = analyzer.extract_key_topics()
        print("\nKey topics:")
        for topic, count in topics.items():
            print(f"- {topic}: {count}")
        
        # Extract requirements
        requirements = analyzer.extract_requirements()
        if requirements:
            print("\nPotential requirements:")
            for i, req in enumerate(requirements[:10], 1):  # Show top 10
                print(f"{i}. {req}")
        
        # Save combined results
        combined_output = os.path.join(args.output, 'combined_history.json')
        with open(combined_output, 'w', encoding='utf-8') as f:
            json.dump(all_chats, f, indent=2, ensure_ascii=False)
        
        print(f"\nCombined chat history saved to {combined_output}")
    else:
        print("No chat data was extracted. Please provide valid input files.")


if __name__ == "__main__":
    main()