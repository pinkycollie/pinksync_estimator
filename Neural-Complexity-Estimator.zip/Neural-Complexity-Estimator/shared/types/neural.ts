/**
 * Neural Network Types
 * 
 * This module defines the core data structures for the neural network system.
 */

/**
 * Modality types for neural signals
 */
export type NeuralModality = 
  | 'text'
  | 'asl_video'
  | 'vr_gesture'
  | 'voice'
  | 'image'
  | 'combined';

/**
 * Context data type based on modality
 */
export type ModalityContext = {
  // Text modality context
  content?: string;
  language?: string;
  
  // Video modality context
  resolution?: string;
  frameRate?: number;
  duration?: number;
  format?: string;
  contentType?: string;
  
  // VR gesture context
  gestureType?: string;
  handPosition?: { x: number; y: number; z: number };
  fingerPositions?: Array<{ id: string; position: { x: number; y: number; z: number } }>;
  
  // Voice modality context
  audioFormat?: string;
  sampleRate?: number;
  channels?: number;
  transcript?: string;
  
  // Image modality context
  width?: number;
  height?: number;
  imageFormat?: string;
  
  // Combined modality can include any of the above
  [key: string]: any;
};

/**
 * Metadata for processing decisions
 */
export type ProcessorMetadata = {
  confidenceThreshold?: number;
  processingPriority?: 'high' | 'normal' | 'low';
  customParams?: Record<string, any>;
};

/**
 * Neural signal main structure
 */
export interface NeuralSignal {
  userId: string;
  modality: NeuralModality;
  context: ModalityContext;
  timestamp?: string;
  sessionId?: string;
  processingPath?: ResponsePath[];
  priority?: number;
  metadata?: Record<string, any>;
}

/**
 * Processing result from neural processors
 */
export interface ProcessingResult {
  type: string;
  timestamp: string;
  processingTime?: number;
  confidence?: number;
  [key: string]: any;
}

/**
 * Response path for tracking signal flow
 */
export interface ResponsePath {
  processorId: string;
  timestamp: string;
  duration: number;
  status: 'success' | 'error' | 'forwarded';
  nextProcessor?: string;
  metadata?: Record<string, any>;
}

/**
 * Neural processor interface
 */
export interface NeuralProcessor {
  process(signal: NeuralSignal, metadata: ProcessorMetadata): Promise<ProcessingResult>;
  getCapabilities(): NeuralProcessorCapabilities;
}

/**
 * Neural processor capabilities
 */
export interface NeuralProcessorCapabilities {
  supportedModalities: NeuralModality[];
  processingSpeed: 'realtime' | 'near-realtime' | 'batch';
  maxConcurrentSignals: number;
  requiresPreprocessing: boolean;
  features: string[];
}

/**
 * Neural processor factory interface
 */
export interface NeuralProcessorFactory {
  createProcessor(config: Record<string, any>): NeuralProcessor;
}

/**
 * Neural signal processing configuration
 */
export interface ProcessingConfig {
  processorMap: Record<string, string[]>;
  defaultPath: Record<NeuralModality, string>;
  fallbackProcessor?: string;
}