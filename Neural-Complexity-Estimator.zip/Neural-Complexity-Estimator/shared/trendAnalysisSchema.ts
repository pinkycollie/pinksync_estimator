/**
 * PinkSync - Trend Analysis Schema
 * 
 * This schema defines the structure for tracking technology trends, market activities,
 * and real-time validation data for startup ideas.
 */

import { pgTable, serial, varchar, text, timestamp, boolean, integer, json, pgEnum } from 'drizzle-orm/pg-core';
import { createInsertSchema } from 'drizzle-zod';
import { z } from 'zod';

/**
 * Enums for trend categories and sources
 */
export const trendCategoryEnum = pgEnum('trend_category', [
  'AR_VR',
  'CYBERSECURITY',
  'WEB3',
  'CLOUD_COMPUTING',
  'QUANTUM_COMPUTING',
  '3D_PRINTING',
  'SUPER_APPS',
  'AI_ML',
  'IOT',
  'FINTECH',
  'HEALTHTECH',
  'OTHER'
]);

export const trendSourceEnum = pgEnum('trend_source', [
  'GITHUB',
  'TWITTER',
  'NEWS',
  'ACADEMIC',
  'PATENTS',
  'VENTURE_CAPITAL',
  'MARKET_RESEARCH',
  'STARTUP_ACTIVITIES',
  'REGULATORS',
  'CONFERENCES',
  'OTHER'
]);

export const validationResultEnum = pgEnum('validation_result', [
  'HIGHLY_PROMISING',
  'PROMISING',
  'NEUTRAL',
  'CONCERNING',
  'HIGHLY_CONCERNING'
]);

/**
 * Technology Trends Table
 * Tracks emerging technology trends across various categories
 */
export const technologyTrends = pgTable('technology_trends', {
  id: serial('id').primaryKey(),
  category: trendCategoryEnum('category').notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  description: text('description'),
  source: trendSourceEnum('source').notNull(),
  sourceUrl: varchar('source_url', { length: 1024 }),
  mentionCount: integer('mention_count').default(1),
  growthRate: integer('growth_rate'), // Percentage growth over past period
  firstDetectedAt: timestamp('first_detected_at').defaultNow().notNull(),
  lastMentionedAt: timestamp('last_mentioned_at').defaultNow().notNull(),
  metadata: json('metadata').$type<Record<string, any>>(),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

/**
 * GitHub Repository Trends Table
 * Tracks trending GitHub repositories that might signal emerging technology
 */
export const githubTrends = pgTable('github_trends', {
  id: serial('id').primaryKey(),
  repositoryName: varchar('repository_name', { length: 255 }).notNull(),
  ownerName: varchar('owner_name', { length: 255 }).notNull(),
  url: varchar('url', { length: 1024 }).notNull(),
  description: text('description'),
  category: trendCategoryEnum('category'),
  language: varchar('language', { length: 100 }),
  starCount: integer('star_count').notNull(),
  forkCount: integer('fork_count'),
  issueCount: integer('issue_count'),
  contributorCount: integer('contributor_count'),
  growthRate: integer('growth_rate'), // Star growth percentage in last period
  relatedTrendId: integer('related_trend_id'), // Linked to technology_trends
  firstDetectedAt: timestamp('first_detected_at').defaultNow().notNull(),
  lastUpdatedAt: timestamp('last_updated_at').defaultNow().notNull(),
  metadata: json('metadata').$type<Record<string, any>>(),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

/**
 * Economic News Table
 * Tracks economic and market news that could impact startup viability
 */
export const economicNews = pgTable('economic_news', {
  id: serial('id').primaryKey(),
  title: varchar('title', { length: 255 }).notNull(),
  summary: text('summary').notNull(),
  source: varchar('source', { length: 255 }).notNull(),
  url: varchar('url', { length: 1024 }),
  category: varchar('category', { length: 100 }), // economy, market, industry, etc.
  sector: varchar('sector', { length: 100 }), // tech, healthcare, finance, etc.
  sentimentScore: integer('sentiment_score'), // -100 to 100
  impactLevel: integer('impact_level'), // 1-10
  relatedTrendIds: json('related_trend_ids').$type<number[]>(),
  publishedAt: timestamp('published_at').notNull(),
  detectedAt: timestamp('detected_at').defaultNow().notNull(),
  metadata: json('metadata').$type<Record<string, any>>(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

/**
 * Idea Validation Results Table
 * Stores multi-dimensional validation data for startup ideas
 */
export const ideaValidations = pgTable('idea_validations', {
  id: serial('id').primaryKey(),
  ideaId: integer('idea_id').notNull(),
  analysisId: varchar('analysis_id', { length: 255 }),
  marketValidation: json('market_validation').$type<{
    totalAddressableMarket: number;
    targetMarketSize: number;
    growthRate: number;
    competitorCount: number;
    marketSaturation: number;
    entryBarriers: string[];
    validationSources: string[];
    result: string;
  }>(),
  technicalValidation: json('technical_validation').$type<{
    feasibilityScore: number;
    implementationComplexity: number;
    resourceRequirements: string[];
    timeToMarket: number;
    scalabilityScore: number;
    technicalRisks: string[];
    validationSources: string[];
    result: string;
  }>(),
  economicValidation: json('economic_validation').$type<{
    initialInvestment: number;
    estimatedBreakEven: number;
    projectedROI: number;
    financingOptions: string[];
    economicRisks: string[];
    validationSources: string[];
    result: string;
  }>(),
  competitiveValidation: json('competitive_validation').$type<{
    directCompetitors: string[];
    indirectCompetitors: string[];
    competitiveAdvantages: string[];
    uniquenessScore: number;
    defensibilityScore: number;
    validationSources: string[];
    result: string;
  }>(),
  overallResult: validationResultEnum('overall_result').notNull(),
  validationDate: timestamp('validation_date').defaultNow().notNull(),
  validatedBy: varchar('validated_by', { length: 255 }),
  metadata: json('metadata').$type<Record<string, any>>(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

/**
 * User Trend Subscription Table
 * Tracks which trends a user wants to monitor
 */
export const userTrendSubscriptions = pgTable('user_trend_subscriptions', {
  id: serial('id').primaryKey(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  trendCategory: trendCategoryEnum('trend_category'),
  specificTrendId: integer('specific_trend_id'),
  notificationEnabled: boolean('notification_enabled').default(true),
  notificationFrequency: varchar('notification_frequency', { length: 50 }).default('daily'),
  lastNotifiedAt: timestamp('last_notified_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

/**
 * Zod Schemas for Insert Operations
 */
export const insertTechnologyTrendSchema = createInsertSchema(technologyTrends)
  .omit({ id: true, createdAt: true, updatedAt: true });

export const insertGithubTrendSchema = createInsertSchema(githubTrends)
  .omit({ id: true, createdAt: true, updatedAt: true });

export const insertEconomicNewsSchema = createInsertSchema(economicNews)
  .omit({ id: true, createdAt: true, updatedAt: true });

export const insertIdeaValidationSchema = createInsertSchema(ideaValidations)
  .omit({ id: true, createdAt: true, updatedAt: true });

export const insertUserTrendSubscriptionSchema = createInsertSchema(userTrendSubscriptions)
  .omit({ id: true, createdAt: true, updatedAt: true });

/**
 * TypeScript Types for Insert Operations
 */
export type InsertTechnologyTrend = z.infer<typeof insertTechnologyTrendSchema>;
export type InsertGithubTrend = z.infer<typeof insertGithubTrendSchema>;
export type InsertEconomicNews = z.infer<typeof insertEconomicNewsSchema>;
export type InsertIdeaValidation = z.infer<typeof insertIdeaValidationSchema>;
export type InsertUserTrendSubscription = z.infer<typeof insertUserTrendSubscriptionSchema>;

/**
 * TypeScript Types for Select Operations
 */
export type TechnologyTrend = typeof technologyTrends.$inferSelect;
export type GithubTrend = typeof githubTrends.$inferSelect;
export type EconomicNews = typeof economicNews.$inferSelect;
export type IdeaValidation = typeof ideaValidations.$inferSelect;
export type UserTrendSubscription = typeof userTrendSubscriptions.$inferSelect;