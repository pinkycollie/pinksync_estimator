/**
 * PinkSync - Checkpoint Database Schema
 * 
 * This schema defines the structure for tracking development and deployment checkpoints
 * across multiple platforms and services integrated with PinkSync.
 */

import { pgTable, serial, varchar, text, timestamp, boolean, integer, json, pgEnum } from 'drizzle-orm/pg-core';
import { createInsertSchema } from 'drizzle-zod';
import { z } from 'zod';

/**
 * Enums for the various statuses
 */
export const checkpointStatusEnum = pgEnum('checkpoint_status', [
  'pending', 
  'in_progress', 
  'completed', 
  'failed', 
  'skipped'
]);

export const platformTypeEnum = pgEnum('platform_type', [
  'cursor_ai',
  'vercel',
  'github',
  'replit',
  'railway',
  'other'
]);

export const checkpointCategoryEnum = pgEnum('checkpoint_category', [
  'development',
  'deployment',
  'quality_assurance'
]);

/**
 * Web Hooks Table
 * Stores webhook configurations for various platforms
 */
export const webhooks = pgTable('webhooks', {
  id: serial('id').primaryKey(),
  platform: platformTypeEnum('platform').notNull(),
  endpoint: varchar('endpoint', { length: 255 }).notNull(),
  events: json('events').notNull().$type<string[]>(),
  secretKey: varchar('secret_key', { length: 255 }),
  isActive: boolean('is_active').default(true).notNull(),
  lastTriggered: timestamp('last_triggered'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

/**
 * Checkpoints Table
 * Tracks development and deployment checkpoints across platforms
 */
export const checkpoints = pgTable('checkpoints', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  description: text('description'),
  category: checkpointCategoryEnum('category').notNull(),
  status: checkpointStatusEnum('status').default('pending').notNull(),
  platformType: platformTypeEnum('platform_type'),
  platformId: varchar('platform_id', { length: 255 }),
  projectId: integer('project_id').notNull(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  metadata: json('metadata').$type<Record<string, any>>(),
  completedAt: timestamp('completed_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

/**
 * Development Status Table
 * Tracks status of development-related checkpoints
 */
export const developmentStatus = pgTable('development_status', {
  id: serial('id').primaryKey(),
  checkpointId: integer('checkpoint_id').notNull(),
  environmentSetup: checkpointStatusEnum('environment_setup').default('pending').notNull(),
  versionControl: checkpointStatusEnum('version_control').default('pending').notNull(),
  ciCdPipeline: checkpointStatusEnum('ci_cd_pipeline').default('pending').notNull(),
  codeReview: checkpointStatusEnum('code_review').default('pending').notNull(),
  dependencyUpdates: checkpointStatusEnum('dependency_updates').default('pending').notNull(),
  securityScanning: checkpointStatusEnum('security_scanning').default('pending').notNull(),
  metadata: json('metadata').$type<Record<string, any>>(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

/**
 * Deployment Status Table
 * Tracks status of deployment-related checkpoints
 */
export const deploymentStatus = pgTable('deployment_status', {
  id: serial('id').primaryKey(),
  checkpointId: integer('checkpoint_id').notNull(),
  stagingEnvironment: checkpointStatusEnum('staging_environment').default('pending').notNull(),
  productionEnvironment: checkpointStatusEnum('production_environment').default('pending').notNull(),
  rollbackStatus: checkpointStatusEnum('rollback_status').default('pending').notNull(),
  monitoringAlerts: checkpointStatusEnum('monitoring_alerts').default('pending').notNull(),
  backupStatus: checkpointStatusEnum('backup_status').default('pending').notNull(),
  metadata: json('metadata').$type<Record<string, any>>(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

/**
 * Quality Assurance Table
 * Tracks status of QA-related checkpoints
 */
export const qualityAssurance = pgTable('quality_assurance', {
  id: serial('id').primaryKey(),
  checkpointId: integer('checkpoint_id').notNull(),
  automatedTests: checkpointStatusEnum('automated_tests').default('pending').notNull(),
  humanVerification: checkpointStatusEnum('human_verification').default('pending').notNull(),
  performanceMetrics: checkpointStatusEnum('performance_metrics').default('pending').notNull(),
  securityScans: checkpointStatusEnum('security_scans').default('pending').notNull(),
  metadata: json('metadata').$type<Record<string, any>>(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

/**
 * Webhook Event Logs Table
 * Stores history of webhook events
 */
export const webhookEventLogs = pgTable('webhook_event_logs', {
  id: serial('id').primaryKey(),
  webhookId: integer('webhook_id').notNull(),
  event: varchar('event', { length: 255 }).notNull(),
  requestBody: json('request_body'),
  responseBody: json('response_body'),
  statusCode: integer('status_code'),
  processedAt: timestamp('processed_at').defaultNow().notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull()
});

/**
 * Zod Schemas for Insert Operations
 */
export const insertWebhookSchema = createInsertSchema(webhooks)
  .omit({ id: true, createdAt: true, updatedAt: true });

export const insertCheckpointSchema = createInsertSchema(checkpoints)
  .omit({ id: true, createdAt: true, updatedAt: true });

export const insertDevelopmentStatusSchema = createInsertSchema(developmentStatus)
  .omit({ id: true, createdAt: true, updatedAt: true });

export const insertDeploymentStatusSchema = createInsertSchema(deploymentStatus)
  .omit({ id: true, createdAt: true, updatedAt: true });

export const insertQualityAssuranceSchema = createInsertSchema(qualityAssurance)
  .omit({ id: true, createdAt: true, updatedAt: true });

export const insertWebhookEventLogSchema = createInsertSchema(webhookEventLogs)
  .omit({ id: true, createdAt: true });

/**
 * TypeScript Types for Insert Operations
 */
export type InsertWebhook = z.infer<typeof insertWebhookSchema>;
export type InsertCheckpoint = z.infer<typeof insertCheckpointSchema>;
export type InsertDevelopmentStatus = z.infer<typeof insertDevelopmentStatusSchema>;
export type InsertDeploymentStatus = z.infer<typeof insertDeploymentStatusSchema>;
export type InsertQualityAssurance = z.infer<typeof insertQualityAssuranceSchema>;
export type InsertWebhookEventLog = z.infer<typeof insertWebhookEventLogSchema>;

/**
 * TypeScript Types for Select Operations
 */
export type Webhook = typeof webhooks.$inferSelect;
export type Checkpoint = typeof checkpoints.$inferSelect;
export type DevelopmentStatus = typeof developmentStatus.$inferSelect;
export type DeploymentStatus = typeof deploymentStatus.$inferSelect;
export type QualityAssurance = typeof qualityAssurance.$inferSelect;
export type WebhookEventLog = typeof webhookEventLogs.$inferSelect;