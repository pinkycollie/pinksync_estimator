/**
 * PinkSync - Notion Integration Schema
 * 
 * This file defines the database schema for Notion integration in PinkSync,
 * following Pinky's "idea, build, grow, manage" collaborative workflow with AI.
 */

import { z } from 'zod';
import { createInsertSchema } from 'drizzle-zod';
import { relations } from 'drizzle-orm';
import { 
  pgTable, 
  serial, 
  varchar, 
  text, 
  timestamp, 
  boolean, 
  integer, 
  json
} from 'drizzle-orm/pg-core';
import { entrepreneurIdeas } from './schema';

/**
 * Notion connection table
 * Stores configurations for connecting to Notion workspaces
 */
export const notionConnections = pgTable('notion_connections', {
  id: varchar('id').primaryKey(),
  name: varchar('name').notNull(),
  authToken: text('auth_token').notNull(),
  workspaceId: varchar('workspace_id'),
  databases: json('databases').default([]).notNull(),
  defaultDatabase: varchar('default_database'),
  webhookUrl: text('webhook_url'),
  lastSync: timestamp('last_sync'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  isActive: boolean('is_active').default(true).notNull()
});

/**
 * Notion integration table
 * Maps PinkSync ideas to Notion pages
 */
export const notionIntegrations = pgTable('notion_integrations', {
  id: serial('id').primaryKey(),
  ideaId: integer('idea_id').references(() => entrepreneurIdeas.id).notNull(),
  connectionId: varchar('connection_id').references(() => notionConnections.id).notNull(),
  notionPageId: varchar('notion_page_id').notNull(),
  notionDatabaseId: varchar('notion_database_id').notNull(),
  syncedAt: timestamp('synced_at').defaultNow().notNull(),
  lastSyncedAt: timestamp('last_synced_at').defaultNow().notNull(),
  syncStatus: varchar('sync_status').default('synced').notNull(),
  metadata: json('metadata')
});

/**
 * Relations
 */
export const notionConnectionsRelations = relations(notionConnections, ({ many }) => ({
  integrations: many(notionIntegrations)
}));

export const notionIntegrationsRelations = relations(notionIntegrations, ({ one }) => ({
  idea: one(entrepreneurIdeas, {
    fields: [notionIntegrations.ideaId],
    references: [entrepreneurIdeas.id]
  }),
  connection: one(notionConnections, {
    fields: [notionIntegrations.connectionId],
    references: [notionConnections.id]
  })
}));

/**
 * Zod schemas for validation
 */
// Notion Connection
export const insertNotionConnectionSchema = createInsertSchema(notionConnections).omit({
  createdAt: true,
  updatedAt: true
});
export type InsertNotionConnection = z.infer<typeof insertNotionConnectionSchema>;
export type NotionConnection = typeof notionConnections.$inferSelect;

// Notion Integration
export const insertNotionIntegrationSchema = createInsertSchema(notionIntegrations).omit({
  id: true,
  syncedAt: true,
  lastSyncedAt: true
});
export type InsertNotionIntegration = z.infer<typeof insertNotionIntegrationSchema>;
export type NotionIntegration = typeof notionIntegrations.$inferSelect;

// Notion Database Type enum
export enum NotionDatabaseType {
  IDEAS = 'ideas',
  PROJECTS = 'projects',
  TASKS = 'tasks',
  DOCUMENTATION = 'documentation',
  TRENDS = 'trends',
  VALIDATIONS = 'validations',
  CHECKPOINTS = 'checkpoints',
  CUSTOM = 'custom'
}

// Notion Database Config schema
export const notionDatabaseConfigSchema = z.object({
  id: z.string(),
  type: z.nativeEnum(NotionDatabaseType),
  name: z.string(),
  description: z.string().optional(),
  schema: z.record(z.any()).optional(),
  customMapping: z.record(z.string()).optional()
});

export type NotionDatabaseConfig = z.infer<typeof notionDatabaseConfigSchema>;