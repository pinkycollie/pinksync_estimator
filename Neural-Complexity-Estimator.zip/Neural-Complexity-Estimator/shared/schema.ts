import { pgTable, text, serial, integer, boolean, timestamp, jsonb, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Original PinkSync User Schema - Simplified for Neural Complexity Estimator
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").unique(),
  fullName: text("full_name"),
  preferences: jsonb("preferences"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastLogin: timestamp("last_login"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastLogin: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Project Complexity Analysis
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  name: text("name").notNull(),
  description: text("description"),
  status: text("status").notNull().default('planning'), // planning, in_progress, completed, cancelled
  complexityScore: integer("complexity_score"), // 1-100 calculated by neural estimator
  estimatedHours: integer("estimated_hours"),
  actualHours: integer("actual_hours"),
  technologies: jsonb("technologies").default('[]'), // Array of tech stack
  requirements: text("requirements"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  complexityScore: true, // This will be calculated by AI
});

export const updateProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
}).partial();

export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type UpdateProject = z.infer<typeof updateProjectSchema>;

// Neural Analysis Results
export const complexityAnalyses = pgTable("complexity_analyses", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id, { onDelete: 'cascade' }),
  analysisType: text("analysis_type").notNull(), // 'initial', 'updated', 'final'
  inputData: jsonb("input_data").notNull(), // The data fed to neural analyzer
  complexityBreakdown: jsonb("complexity_breakdown").notNull(), // Detailed breakdown by category
  estimatedTimeBreakdown: jsonb("estimated_time_breakdown").notNull(),
  riskFactors: jsonb("risk_factors").default('[]'),
  recommendations: jsonb("recommendations").default('[]'),
  confidence: integer("confidence").notNull(), // 0-100 confidence in analysis
  modelVersion: text("model_version").notNull().default('1.0'),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertComplexityAnalysisSchema = createInsertSchema(complexityAnalyses).omit({
  id: true,
  createdAt: true,
});

export type ComplexityAnalysis = typeof complexityAnalyses.$inferSelect;
export type InsertComplexityAnalysis = z.infer<typeof insertComplexityAnalysisSchema>;

// Task Breakdown from Neural Analysis
export const projectTasks = pgTable("project_tasks", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id, { onDelete: 'cascade' }),
  analysisId: integer("analysis_id").references(() => complexityAnalyses.id),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category"), // frontend, backend, database, testing, etc.
  estimatedHours: integer("estimated_hours"),
  actualHours: integer("actual_hours"),
  complexity: integer("complexity").notNull(), // 1-10 task complexity
  dependencies: jsonb("dependencies").default('[]'), // Array of task IDs this depends on
  status: text("status").notNull().default('pending'), // pending, in_progress, completed
  assignedTo: text("assigned_to"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertProjectTaskSchema = createInsertSchema(projectTasks).omit({
  id: true,
  createdAt: true,
});

export type ProjectTask = typeof projectTasks.$inferSelect;
export type InsertProjectTask = z.infer<typeof insertProjectTaskSchema>;

// Learning Data for Neural Network Improvement
export const learningData = pgTable("learning_data", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id),
  actualComplexity: integer("actual_complexity").notNull(), // Final assessed complexity
  actualTimeSpent: integer("actual_time_spent").notNull(),
  projectFeatures: jsonb("project_features").notNull(), // Features used for training
  outcomeData: jsonb("outcome_data").notNull(), // Success metrics, challenges faced
  feedbackScore: integer("feedback_score"), // User satisfaction 1-10
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertLearningDataSchema = createInsertSchema(learningData).omit({
  id: true,
  createdAt: true,
});

export type LearningData = typeof learningData.$inferSelect;
export type InsertLearningData = z.infer<typeof insertLearningDataSchema>;

// Templates for common project types
export const projectTemplates = pgTable("project_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(), // web_app, mobile_app, api, etc.
  baseComplexity: integer("base_complexity").notNull(),
  defaultTechnologies: jsonb("default_technologies").default('[]'),
  commonTasks: jsonb("common_tasks").default('[]'),
  typicalTimeRange: jsonb("typical_time_range"), // {min: hours, max: hours}
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertProjectTemplateSchema = createInsertSchema(projectTemplates).omit({
  id: true,
  createdAt: true,
});

export type ProjectTemplate = typeof projectTemplates.$inferSelect;
export type InsertProjectTemplate = z.infer<typeof insertProjectTemplateSchema>;