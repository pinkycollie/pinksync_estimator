#!/bin/bash

# PinkSync Git Repository Setup Script
# This script initializes a git repository and pushes it to GitHub

echo "🚀 PinkSync Git Repository Setup"
echo "================================"

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "❌ Git is not installed. Please install git first."
    exit 1
fi

# Prompt for GitHub username
read -p "Enter your GitHub username: " GITHUB_USERNAME

# Prompt for repository name
read -p "Enter repository name (default: pinksync): " REPO_NAME
REPO_NAME=${REPO_NAME:-pinksync}

# Confirm repository creation
echo ""
echo "Will create repository: https://github.com/$GITHUB_USERNAME/$REPO_NAME"
read -p "Continue? (y/n): " CONFIRM
if [[ $CONFIRM != "y" && $CONFIRM != "Y" ]]; then
    echo "Aborted."
    exit 0
fi

# Initialize git repository (if not already done)
if [ ! -d ".git" ]; then
    echo "Initializing git repository..."
    git init
else
    echo "Git repository already initialized."
fi

# Create .gitignore file
echo "Creating .gitignore file..."
cat > .gitignore << EOL
# Dependencies
node_modules/
__pycache__/
.venv/
venv/
*.pyc

# Environment variables
.env
.env.local

# Build outputs
dist/
build/

# Logs
*.log
npm-debug.log*

# OS-specific files
.DS_Store
Thumbs.db

# Editor directories and files
.idea/
.vscode/
*.swp
*.swo
EOL

# Add all files
echo "Adding files to git..."
git add .

# Initial commit
echo "Creating initial commit..."
git commit -m "Initial PinkSync deployment configuration"

# Check if remote origin already exists
if git remote | grep -q "origin"; then
    echo "Remote 'origin' already exists. Updating URL..."
    git remote set-url origin "https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"
else
    echo "Adding remote origin..."
    git remote add origin "https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"
fi

# Instructions for pushing
echo ""
echo "✅ Repository setup complete!"
echo ""
echo "NEXT STEPS:"
echo "1. Create a repository named '$REPO_NAME' on GitHub:"
echo "   https://github.com/new"
echo ""
echo "2. Push your code with:"
echo "   git push -u origin main"
echo ""
echo "3. Connect the repository to Render.com as described in:"
echo "   RENDER_DEPLOYMENT_GUIDE.md"
echo ""
echo "Happy coding! 🎉"