/**
 * In-process Neural API Test (ESM Version)
 * 
 * This script directly tests the neural processors without going through HTTP.
 */

import fetch from 'node-fetch';

async function runTest() {
  console.log('Neural API Test');
  console.log('==============');

  try {
    const replitDomain = '1256edaf-1598-4f87-9afa-76255db49f60-00-3l2pncga6f8u8.janeway.replit.dev';
    const baseUrl = `https://${replitDomain}`;
    
    // Test basic API access first
    console.log('Testing API health endpoint...');
    console.log(`Using URL: ${baseUrl}/api/health`);
    const healthResponse = await fetch(`${baseUrl}/api/health`);
    
    if (healthResponse.ok) {
      const healthData = await healthResponse.json();
      console.log('✅ API health endpoint successful:');
      console.log(JSON.stringify(healthData, null, 2));
    } else {
      console.error(`❌ API health endpoint failed: ${healthResponse.status}`);
    }
    
    // Test neural endpoints
    console.log('\nTesting neural API health endpoint...');
    console.log(`Using URL: ${baseUrl}/api/neural/health`);
    const neuralResponse = await fetch(`${baseUrl}/api/neural/health`);
    
    if (neuralResponse.ok) {
      const neuralData = await neuralResponse.json();
      console.log('✅ Neural API health endpoint successful:');
      console.log(JSON.stringify(neuralData, null, 2));
    } else {
      console.error(`❌ Neural API health endpoint failed: ${neuralResponse.status}`);
    }
    
    console.log('\nTesting neural text processing endpoint...');
    console.log(`Using URL: ${baseUrl}/api/neural/test/text`);
    const textResponse = await fetch(`${baseUrl}/api/neural/test/text`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        userId: 'test-user',
        text: 'This is a test message for the neural text processor.'
      })
    });
    
    if (textResponse.ok) {
      const textData = await textResponse.json();
      console.log('✅ Text processing endpoint successful:');
      console.log(JSON.stringify(textData, null, 2));
    } else {
      console.error(`❌ Text processing endpoint failed: ${textResponse.status}`);
    }
    
  } catch (error) {
    console.error('❌ Error running test:', error);
  }
}

// Run the test
runTest();