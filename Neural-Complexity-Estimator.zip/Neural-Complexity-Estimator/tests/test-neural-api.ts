/**
 * Neural API Test Script
 * 
 * This script tests the neural API endpoints.
 */

import fetch from 'node-fetch';

async function testNeuralAPI() {
  const baseUrl = 'http://0.0.0.0:5000/api/neural';
  
  console.log('Neural API Test Script');
  console.log('======================');
  
  try {
    // Test health endpoint
    console.log('\nTesting Health Endpoint:');
    const healthResponse = await fetch(`${baseUrl}/health`);
    
    if (healthResponse.ok) {
      const healthData = await healthResponse.json();
      console.log('✅ Health endpoint responded successfully:');
      console.log(JSON.stringify(healthData, null, 2));
    } else {
      console.error(`❌ Health endpoint failed with status: ${healthResponse.status}`);
    }
    
    // Test text processing endpoint
    console.log('\nTesting Text Processing Endpoint:');
    const textResponse = await fetch(`${baseUrl}/test/text`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        userId: 'test-user',
        text: 'This is a test message for the neural text processor. I really love this system!'
      })
    });
    
    if (textResponse.ok) {
      const textData = await textResponse.json();
      console.log('✅ Text processing endpoint responded successfully:');
      console.log(JSON.stringify(textData, null, 2));
    } else {
      console.error(`❌ Text processing endpoint failed with status: ${textResponse.status}`);
    }
    
    // Test ASL processing endpoint
    console.log('\nTesting ASL Processing Endpoint:');
    const aslResponse = await fetch(`${baseUrl}/test/asl`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        userId: 'test-user',
        videoMetadata: {
          resolution: '720p',
          frameRate: 30,
          duration: 15,
          format: 'mp4',
          contentType: 'greeting'
        }
      })
    });
    
    if (aslResponse.ok) {
      const aslData = await aslResponse.json();
      console.log('✅ ASL processing endpoint responded successfully:');
      console.log(JSON.stringify(aslData, null, 2));
    } else {
      console.error(`❌ ASL processing endpoint failed with status: ${aslResponse.status}`);
    }
    
    console.log('\nTest Complete');
    
  } catch (error) {
    console.error('❌ Error testing neural API:', error);
  }
}

// Run the test
testNeuralAPI();