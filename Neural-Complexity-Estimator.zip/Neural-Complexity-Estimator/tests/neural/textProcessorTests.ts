/**
 * Neural Text Processor Tests
 * 
 * This module contains automated tests for the neural text processor.
 */

import { SynapseTest, synapseTest } from './synapseTest';
import { NeuralSignal, NeuralModality } from '../../shared/types/neural';

// Text processor test suite
const textProcessorSuite = {
  name: 'Text Processor Suite',
  description: 'Tests for the neural text processor capabilities',
  
  tests: [
    // Basic text processing test
    {
      name: 'Basic Text Processing',
      signal: {
        userId: 'test-user-1',
        modality: 'text' as NeuralModality,
        context: {
          content: 'This is a test message.'
        }
      },
      validator: (result: any) => {
        // Validate basic result structure
        if (!result || result.type !== 'text-processed') {
          return { 
            valid: false, 
            message: `Invalid result type: ${result?.type}` 
          };
        }
        
        // Validate that content was processed
        if (result.content !== 'This is a test message.') {
          return { 
            valid: false, 
            message: `Content mismatch: ${result.content}` 
          };
        }
        
        return { valid: true };
      }
    },
    
    // Sentiment analysis test
    {
      name: 'Sentiment Analysis',
      signal: {
        userId: 'test-user-2',
        modality: 'text' as NeuralModality,
        context: {
          content: 'I really love this new feature, it works great!'
        }
      },
      validator: (result: any) => {
        // Check that sentiment analysis was performed
        if (!result.sentiment) {
          return { 
            valid: false, 
            message: 'Sentiment analysis missing from result' 
          };
        }
        
        // Check sentiment is positive (because the text is positive)
        if (result.sentiment.label !== 'positive') {
          return { 
            valid: false, 
            message: `Expected positive sentiment, got: ${result.sentiment.label}` 
          };
        }
        
        return { valid: true };
      }
    },
    
    // Keyword extraction test
    {
      name: 'Keyword Extraction',
      signal: {
        userId: 'test-user-3',
        modality: 'text' as NeuralModality,
        context: {
          content: 'Machine learning models can process natural language texts and extract important information efficiently.'
        }
      },
      validator: (result: any) => {
        // Check that keywords were extracted
        if (!result.keywords || !Array.isArray(result.keywords)) {
          return { 
            valid: false, 
            message: 'Keywords missing or not an array' 
          };
        }
        
        // Check that we have some keywords
        if (result.keywords.length === 0) {
          return { 
            valid: false, 
            message: 'No keywords extracted' 
          };
        }
        
        // Some of these keywords should be present
        const expectedKeywords = ['machine', 'learning', 'language', 'natural', 'process', 'extract'];
        const foundKeywords = expectedKeywords.filter(k => 
          result.keywords.some((rk: string) => rk.includes(k))
        );
        
        if (foundKeywords.length < 2) {
          return { 
            valid: false, 
            message: `Expected at least 2 matching keywords, found: ${foundKeywords.join(', ')}` 
          };
        }
        
        return { valid: true };
      }
    },
    
    // Intent recognition test
    {
      name: 'Intent Recognition',
      signal: {
        userId: 'test-user-4',
        modality: 'text' as NeuralModality,
        context: {
          content: 'What is the status of my account?'
        }
      },
      validator: (result: any) => {
        // Check that intent was recognized
        if (!result.intent) {
          return { 
            valid: false, 
            message: 'Intent recognition missing from result' 
          };
        }
        
        // Check primary intent (this should be a question)
        if (result.intent.primary !== 'question') {
          return { 
            valid: false, 
            message: `Expected question intent, got: ${result.intent.primary}` 
          };
        }
        
        return { valid: true };
      }
    },
    
    // Long text truncation test
    {
      name: 'Long Text Truncation',
      signal: {
        userId: 'test-user-5',
        modality: 'text' as NeuralModality,
        context: {
          content: 'A'.repeat(15000) // Very long text
        }
      },
      validator: (result: any) => {
        // Check that text was truncated
        if (!result.truncated) {
          return { 
            valid: false, 
            message: 'Long text was not marked as truncated' 
          };
        }
        
        // Check original length
        if (result.originalLength !== 15000) {
          return { 
            valid: false, 
            message: `Original length incorrect: ${result.originalLength}` 
          };
        }
        
        // Check truncated length
        if (result.content.length > 10000) {
          return { 
            valid: false, 
            message: `Content not properly truncated: ${result.content.length}` 
          };
        }
        
        return { valid: true };
      }
    }
  ]
};

// Add the suite to the test system
synapseTest.addSuite(textProcessorSuite);

// Export for direct import
export { textProcessorSuite };
export default textProcessorSuite;