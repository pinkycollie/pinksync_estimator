/**
 * Neural ASL Processor Tests
 * 
 * This module contains automated tests for the neural ASL video processor.
 */

import { SynapseTest, synapseTest } from './synapseTest';
import { NeuralSignal, NeuralModality } from '../../shared/types/neural';

// ASL processor test suite
const aslProcessorSuite = {
  name: 'ASL Processor Suite',
  description: 'Tests for the neural ASL processor capabilities',
  
  tests: [
    // Basic ASL processing test
    {
      name: 'Basic ASL Processing',
      signal: {
        userId: 'test-user-1',
        modality: 'asl_video' as NeuralModality,
        context: {
          resolution: '720p',
          frameRate: 30,
          duration: 15,
          format: 'mp4',
          contentType: 'greeting'
        }
      },
      validator: (result: any) => {
        // Validate basic result structure
        if (!result || result.type !== 'asl-processed') {
          return { 
            valid: false, 
            message: `Invalid result type: ${result?.type}` 
          };
        }
        
        // Validate video metadata was processed
        if (!result.videoMetadata) {
          return { 
            valid: false, 
            message: 'Video metadata missing from result' 
          };
        }
        
        // Validate video metadata content
        if (result.videoMetadata.resolution !== '720p' || 
            result.videoMetadata.frameRate !== 30) {
          return { 
            valid: false, 
            message: `Video metadata mismatch: ${JSON.stringify(result.videoMetadata)}` 
          };
        }
        
        return { valid: true };
      }
    },
    
    // Gesture recognition test
    {
      name: 'Gesture Recognition',
      signal: {
        userId: 'test-user-2',
        modality: 'asl_video' as NeuralModality,
        context: {
          resolution: '1080p',
          frameRate: 60,
          duration: 30,
          format: 'mp4',
          contentType: 'question'
        }
      },
      validator: (result: any) => {
        // Check that gestures were recognized
        if (!result.gestures || !Array.isArray(result.gestures)) {
          return { 
            valid: false, 
            message: 'Gestures missing or not an array' 
          };
        }
        
        // Check that we have some gestures
        if (result.gestures.length === 0) {
          return { 
            valid: false, 
            message: 'No gestures recognized' 
          };
        }
        
        // Check that gesture objects have the right structure
        const firstGesture = result.gestures[0];
        if (!firstGesture.gesture || !firstGesture.confidence || !firstGesture.timestamp) {
          return { 
            valid: false, 
            message: `Gesture object missing required properties: ${JSON.stringify(firstGesture)}` 
          };
        }
        
        return { valid: true };
      }
    },
    
    // Facial expression analysis test
    {
      name: 'Facial Expression Analysis',
      signal: {
        userId: 'test-user-3',
        modality: 'asl_video' as NeuralModality,
        context: {
          resolution: '720p',
          frameRate: 30,
          duration: 20,
          format: 'mp4',
          contentType: 'statement'
        }
      },
      validator: (result: any) => {
        // Check that facial expressions were analyzed
        if (!result.facialExpressions || !Array.isArray(result.facialExpressions)) {
          return { 
            valid: false, 
            message: 'Facial expressions missing or not an array' 
          };
        }
        
        // Check that we have some expressions
        if (result.facialExpressions.length === 0) {
          return { 
            valid: false, 
            message: 'No facial expressions analyzed' 
          };
        }
        
        // Check that expression objects have the right structure
        const firstExpression = result.facialExpressions[0];
        if (!firstExpression.expression || 
            typeof firstExpression.intensity !== 'number' || 
            !firstExpression.timestamp) {
          return { 
            valid: false, 
            message: `Expression object missing required properties: ${JSON.stringify(firstExpression)}` 
          };
        }
        
        return { valid: true };
      }
    },
    
    // Translation test
    {
      name: 'ASL-to-Text Translation',
      signal: {
        userId: 'test-user-4',
        modality: 'asl_video' as NeuralModality,
        context: {
          resolution: '480p',
          frameRate: 24,
          duration: 10,
          format: 'mp4',
          contentType: 'greeting'
        }
      },
      validator: (result: any) => {
        // Check that translation was performed
        if (!result.translation) {
          return { 
            valid: false, 
            message: 'Translation missing from result' 
          };
        }
        
        // Check translation text
        if (!result.translation.text || typeof result.translation.text !== 'string' || 
            result.translation.text.length === 0) {
          return { 
            valid: false, 
            message: `Invalid translation text: ${result.translation.text}` 
          };
        }
        
        // Check confidence score
        if (typeof result.translation.confidence !== 'number' || 
            result.translation.confidence < 0 || 
            result.translation.confidence > 1) {
          return { 
            valid: false, 
            message: `Invalid confidence score: ${result.translation.confidence}` 
          };
        }
        
        return { valid: true };
      }
    },
    
    // Video parameter validation test
    {
      name: 'Video Parameter Validation',
      signal: {
        userId: 'test-user-5',
        modality: 'asl_video' as NeuralModality,
        context: {
          resolution: '240p', // Low resolution
          frameRate: 10,      // Low frame rate
          duration: 5,
          format: 'mp4',
          contentType: 'emergency'
        }
      },
      validator: (result: any) => {
        // Check if validation failed as expected (low frame rate should trigger validation failure)
        if (result.type !== 'asl-validation-failed') {
          return { 
            valid: false, 
            message: `Expected validation failure, got result type: ${result.type}` 
          };
        }
        
        // Check error message
        if (!result.error || !result.error.includes('frame rate')) {
          return { 
            valid: false, 
            message: `Expected frame rate error, got: ${result.error}` 
          };
        }
        
        // Check recommendations
        if (!result.recommendations || !Array.isArray(result.recommendations) || 
            result.recommendations.length === 0) {
          return { 
            valid: false, 
            message: 'Missing or invalid recommendations' 
          };
        }
        
        return { valid: true };
      }
    }
  ]
};

// Add the suite to the test system
synapseTest.addSuite(aslProcessorSuite);

// Export for direct import
export { aslProcessorSuite };
export default aslProcessorSuite;