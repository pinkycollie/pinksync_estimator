/**
 * Neural Test Runner
 * 
 * This script runs all neural processor tests and outputs the results.
 */

import { synapseTest } from './synapseTest';
import './textProcessorTests';
import './aslProcessorTests';

/**
 * Main function to run all tests
 */
async function runAllTests() {
  console.log('======================================');
  console.log('   PinkSync Neural Testing System     ');
  console.log('======================================');
  
  try {
    // Initialize test environment
    await synapseTest.initialize();
    
    // Run all registered test suites
    const results = await synapseTest.runAll();
    
    // Analyze results
    const passedCount = results.filter(r => r.passed).length;
    const totalCount = results.length;
    const successRate = Math.round((passedCount / totalCount) * 100);
    
    console.log('\n======================================');
    console.log(` TEST COMPLETE: ${successRate}% PASSED`);
    console.log('======================================');
    
    // Set exit code based on test success
    if (passedCount === totalCount) {
      process.exit(0); // All tests passed
    } else {
      process.exit(1); // Some tests failed
    }
  } catch (error) {
    console.error('Error running tests:', error);
    process.exit(2); // Error in test runner
  }
}

// Run the tests
runAllTests();