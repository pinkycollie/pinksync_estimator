/**
 * SynapseTest - Automated Neural Signal Testing Utility
 * 
 * This utility provides automated testing capabilities for the neural signal processing system.
 * It simulates real-world usage patterns and validates the responses from the neural processors.
 */

import { NeuralSignal, ResponsePath } from '../../shared/types/neural';
import { neuralProcessor } from '../../server/services/neural/neuralProcessor';
import { createTextProcessor } from '../../server/services/neural/processors/textProcessor';
import { createASLProcessor } from '../../server/services/neural/processors/aslProcessor';

/**
 * Test case definition
 */
interface TestCase {
  name: string;
  signal: NeuralSignal;
  expectedDestination?: string;
  validator: (result: any) => { valid: boolean; message?: string };
}

/**
 * Test suite definition
 */
interface TestSuite {
  name: string;
  description: string;
  setup?: () => Promise<void>;
  teardown?: () => Promise<void>;
  tests: TestCase[];
}

/**
 * Test result
 */
interface TestResult {
  suiteName: string;
  testName: string;
  passed: boolean;
  message?: string;
  processingTime: number;
  result?: any;
}

/**
 * SynapseTest - Neural Signal Testing Utility
 */
export class SynapseTest {
  private suites: TestSuite[] = [];
  private results: TestResult[] = [];
  private initialized: boolean = false;
  
  constructor() {}
  
  /**
   * Initialize the test environment
   */
  async initialize(): Promise<void> {
    if (this.initialized) {
      return;
    }
    
    // Initialize processors
    const textProcessor = createTextProcessor();
    const aslProcessor = createASLProcessor();
    
    // Register processors with neural processor
    neuralProcessor.registerProcessor('text-processor', async (signal, metadata) => {
      return await textProcessor.process(signal, metadata);
    });
    
    neuralProcessor.registerProcessor('asl-processor', async (signal, metadata) => {
      return await aslProcessor.process(signal, metadata);
    });
    
    // Initialize neural processor
    await neuralProcessor.initialize();
    
    this.initialized = true;
    console.log('SynapseTest initialized');
  }
  
  /**
   * Add a test suite
   */
  addSuite(suite: TestSuite): void {
    this.suites.push(suite);
  }
  
  /**
   * Run all test suites
   */
  async runAll(): Promise<TestResult[]> {
    // Initialize if not already done
    if (!this.initialized) {
      await this.initialize();
    }
    
    this.results = [];
    
    // Run each suite
    for (const suite of this.suites) {
      console.log(`\nRunning test suite: ${suite.name}`);
      console.log(suite.description);
      
      // Run setup if defined
      if (suite.setup) {
        await suite.setup();
      }
      
      // Run tests in suite
      for (const test of suite.tests) {
        await this.runTest(suite, test);
      }
      
      // Run teardown if defined
      if (suite.teardown) {
        await suite.teardown();
      }
    }
    
    // Print summary
    this.printSummary();
    
    return this.results;
  }
  
  /**
   * Run a single test
   */
  private async runTest(suite: TestSuite, test: TestCase): Promise<void> {
    console.log(`  Testing: ${test.name}`);
    
    const startTime = Date.now();
    let result: any;
    
    try {
      // Process the signal
      result = await neuralProcessor.processSignal(test.signal);
      
      // Validate the result
      const validation = test.validator(result);
      
      const endTime = Date.now();
      const processingTime = endTime - startTime;
      
      // Store result
      this.results.push({
        suiteName: suite.name,
        testName: test.name,
        passed: validation.valid,
        message: validation.message,
        processingTime,
        result
      });
      
      // Print result
      if (validation.valid) {
        console.log(`    ✅ PASSED (${processingTime}ms)`);
      } else {
        console.log(`    ❌ FAILED: ${validation.message} (${processingTime}ms)`);
      }
    } catch (error: any) {
      const endTime = Date.now();
      const processingTime = endTime - startTime;
      
      // Store error result
      this.results.push({
        suiteName: suite.name,
        testName: test.name,
        passed: false,
        message: `Error: ${error.message}`,
        processingTime,
        result
      });
      
      // Print error
      console.log(`    ❌ ERROR: ${error.message} (${processingTime}ms)`);
    }
  }
  
  /**
   * Print test summary
   */
  private printSummary(): void {
    const totalTests = this.results.length;
    const passedTests = this.results.filter(r => r.passed).length;
    const failedTests = totalTests - passedTests;
    
    console.log('\n===== SYNAPSE TEST SUMMARY =====');
    console.log(`Total Test Suites: ${this.suites.length}`);
    console.log(`Total Tests: ${totalTests}`);
    console.log(`Passed: ${passedTests} (${Math.round(passedTests / totalTests * 100)}%)`);
    console.log(`Failed: ${failedTests} (${Math.round(failedTests / totalTests * 100)}%)`);
    
    if (failedTests > 0) {
      console.log('\nFailed Tests:');
      this.results
        .filter(r => !r.passed)
        .forEach(r => {
          console.log(`  - [${r.suiteName}] ${r.testName}: ${r.message}`);
        });
    }
    
    console.log('\nAverage Processing Time: ' + 
      Math.round(
        this.results.reduce((acc, r) => acc + r.processingTime, 0) / totalTests
      ) + 'ms'
    );
  }
}

// Export singleton instance
export const synapseTest = new SynapseTest();
export default synapseTest;