/**
 * Neural Controller
 * 
 * Registers neural routes with the Express application.
 */

import { Express } from 'express';
import neuralRoutes from '../api/neural-routes';
import { logger } from '../utils/logger';

/**
 * Configure neural routes
 */
export function configureNeuralRoutes(app: Express): void {
  logger.info('Configuring neural routes');
  
  // Mount neural routes under /api/neural
  app.use('/api/neural', neuralRoutes);
}

export default configureNeuralRoutes;