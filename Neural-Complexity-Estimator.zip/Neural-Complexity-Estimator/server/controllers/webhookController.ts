/**
 * Webhook Controller
 * 
 * Registers webhook routes with the Express application.
 */

import { Express } from 'express';
import webhookRoutes from '../api/webhook-routes';
import { logger } from '../utils/logger';

/**
 * Configure webhook routes
 */
export function configureWebhookRoutes(app: Express): void {
  logger.info('Configuring webhook routes');
  
  // Mount webhook routes under /api
  app.use('/api', webhookRoutes);
}

export default configureWebhookRoutes;