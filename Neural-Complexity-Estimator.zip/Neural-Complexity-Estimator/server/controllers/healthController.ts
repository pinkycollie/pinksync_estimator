/**
 * Health Controller
 * 
 * Registers health check routes with the Express application.
 */

import { Express } from 'express';
import healthRoutes from '../api/health-routes';
import { logger } from '../utils/logger';

/**
 * Configure health check routes
 */
export function configureHealthRoutes(app: Express): void {
  logger.info('Configuring health check routes');
  
  // Mount health routes under /api
  app.use('/api', healthRoutes);
}

export default configureHealthRoutes;