/**
 * PinkSync Webhook API Routes
 * 
 * Endpoints for managing and receiving webhooks
 */

import { Router, Request, Response } from 'express';
import { webhookManager } from '../services/webhooks/webhookManager';
import { logger } from '../utils/logger';
import { isAuthenticated } from '../replitAuth';

// Initialize router
const router = Router();

/**
 * Get all webhooks (authenticated)
 */
router.get('/webhooks', isAuthenticated, (req: any, res: Response) => {
  try {
    const userId = req.user?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'User not authenticated'
      });
    }
    
    const webhooks = webhookManager.getWebhooksByOwner(userId);
    
    // Remove secrets from response
    const safeWebhooks = webhooks.map(webhook => {
      const { secret, ...safeWebhook } = webhook;
      return safeWebhook;
    });
    
    return res.json({
      success: true,
      webhooks: safeWebhooks
    });
  } catch (error: any) {
    logger.error('Error getting webhooks:', error);
    
    return res.status(500).json({
      success: false,
      error: error.message || 'Unknown error'
    });
  }
});

/**
 * Create a new webhook (authenticated)
 */
router.post('/webhooks', isAuthenticated, (req: any, res: Response) => {
  try {
    const userId = req.user?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'User not authenticated'
      });
    }
    
    const { name, signalMapping } = req.body;
    
    if (!name) {
      return res.status(400).json({
        success: false,
        error: 'Name is required'
      });
    }
    
    const webhook = webhookManager.createWebhook(name, userId, signalMapping);
    
    return res.status(201).json({
      success: true,
      webhook: {
        id: webhook.id,
        name: webhook.name,
        url: webhook.url,
        secret: webhook.secret, // Include secret in creation response only
        owner: webhook.owner,
        enabled: webhook.enabled,
        createdAt: webhook.createdAt,
        signalMapping: webhook.signalMapping
      }
    });
  } catch (error: any) {
    logger.error('Error creating webhook:', error);
    
    return res.status(500).json({
      success: false,
      error: error.message || 'Unknown error'
    });
  }
});

/**
 * Get webhook by ID (authenticated)
 */
router.get('/webhooks/:id', isAuthenticated, (req: any, res: Response) => {
  try {
    const userId = req.user?.claims?.sub;
    const webhookId = req.params.id;
    
    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'User not authenticated'
      });
    }
    
    const webhook = webhookManager.getWebhook(webhookId);
    
    if (!webhook) {
      return res.status(404).json({
        success: false,
        error: 'Webhook not found'
      });
    }
    
    // Verify ownership
    if (webhook.owner !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Not authorized to access this webhook'
      });
    }
    
    // Remove secret from response
    const { secret, ...safeWebhook } = webhook;
    
    return res.json({
      success: true,
      webhook: safeWebhook
    });
  } catch (error: any) {
    logger.error('Error getting webhook:', error);
    
    return res.status(500).json({
      success: false,
      error: error.message || 'Unknown error'
    });
  }
});

/**
 * Update webhook (authenticated)
 */
router.patch('/webhooks/:id', isAuthenticated, (req: any, res: Response) => {
  try {
    const userId = req.user?.claims?.sub;
    const webhookId = req.params.id;
    
    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'User not authenticated'
      });
    }
    
    const webhook = webhookManager.getWebhook(webhookId);
    
    if (!webhook) {
      return res.status(404).json({
        success: false,
        error: 'Webhook not found'
      });
    }
    
    // Verify ownership
    if (webhook.owner !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Not authorized to update this webhook'
      });
    }
    
    // Update webhook
    const { name, enabled, signalMapping } = req.body;
    
    const updates: any = {};
    
    if (name !== undefined) updates.name = name;
    if (enabled !== undefined) updates.enabled = enabled;
    if (signalMapping !== undefined) updates.signalMapping = signalMapping;
    
    const updatedWebhook = webhookManager.updateWebhook(webhookId, updates);
    
    if (!updatedWebhook) {
      return res.status(404).json({
        success: false,
        error: 'Failed to update webhook'
      });
    }
    
    // Remove secret from response
    const { secret, ...safeWebhook } = updatedWebhook;
    
    return res.json({
      success: true,
      webhook: safeWebhook
    });
  } catch (error: any) {
    logger.error('Error updating webhook:', error);
    
    return res.status(500).json({
      success: false,
      error: error.message || 'Unknown error'
    });
  }
});

/**
 * Delete webhook (authenticated)
 */
router.delete('/webhooks/:id', isAuthenticated, (req: any, res: Response) => {
  try {
    const userId = req.user?.claims?.sub;
    const webhookId = req.params.id;
    
    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'User not authenticated'
      });
    }
    
    const webhook = webhookManager.getWebhook(webhookId);
    
    if (!webhook) {
      return res.status(404).json({
        success: false,
        error: 'Webhook not found'
      });
    }
    
    // Verify ownership
    if (webhook.owner !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Not authorized to delete this webhook'
      });
    }
    
    // Delete webhook
    const deleted = webhookManager.deleteWebhook(webhookId);
    
    if (!deleted) {
      return res.status(500).json({
        success: false,
        error: 'Failed to delete webhook'
      });
    }
    
    return res.json({
      success: true,
      message: 'Webhook deleted'
    });
  } catch (error: any) {
    logger.error('Error deleting webhook:', error);
    
    return res.status(500).json({
      success: false,
      error: error.message || 'Unknown error'
    });
  }
});

/**
 * Rotate webhook secret (authenticated)
 */
router.post('/webhooks/:id/rotate-secret', isAuthenticated, (req: any, res: Response) => {
  try {
    const userId = req.user?.claims?.sub;
    const webhookId = req.params.id;
    
    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'User not authenticated'
      });
    }
    
    const webhook = webhookManager.getWebhook(webhookId);
    
    if (!webhook) {
      return res.status(404).json({
        success: false,
        error: 'Webhook not found'
      });
    }
    
    // Verify ownership
    if (webhook.owner !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Not authorized to rotate secret for this webhook'
      });
    }
    
    // Rotate secret
    const newSecret = webhookManager.rotateWebhookSecret(webhookId);
    
    if (!newSecret) {
      return res.status(500).json({
        success: false,
        error: 'Failed to rotate webhook secret'
      });
    }
    
    return res.json({
      success: true,
      secret: newSecret
    });
  } catch (error: any) {
    logger.error('Error rotating webhook secret:', error);
    
    return res.status(500).json({
      success: false,
      error: error.message || 'Unknown error'
    });
  }
});

/**
 * Receive webhook request
 * This endpoint is public and validates using the webhook signature
 */
router.post('/webhooks/:id', (req: Request, res: Response) => {
  try {
    const webhookId = req.params.id;
    const signature = req.headers['x-pinksync-signature'] as string;
    
    if (!signature) {
      return res.status(401).json({
        success: false,
        error: 'Missing signature'
      });
    }
    
    // Get raw body from request
    const payload = JSON.stringify(req.body);
    
    // Verify signature
    const verification = webhookManager.verifyWebhookSignature(webhookId, payload, signature);
    
    if (!verification.valid) {
      return res.status(401).json({
        success: false,
        error: verification.error || 'Invalid signature'
      });
    }
    
    // Process webhook
    webhookManager.processWebhookToNeuralSignal(webhookId, {
      event: req.headers['x-pinksync-event'] as string || 'webhook',
      timestamp: new Date().toISOString(),
      data: req.body
    }).then(result => {
      logger.info(`Webhook ${webhookId} processed successfully`);
    }).catch(error => {
      logger.error(`Error processing webhook ${webhookId}:`, error);
    });
    
    // Respond immediately to avoid timeouts
    return res.status(202).json({
      success: true,
      message: 'Webhook received and processing'
    });
  } catch (error: any) {
    logger.error('Error receiving webhook:', error);
    
    return res.status(500).json({
      success: false,
      error: error.message || 'Unknown error'
    });
  }
});

export default router;