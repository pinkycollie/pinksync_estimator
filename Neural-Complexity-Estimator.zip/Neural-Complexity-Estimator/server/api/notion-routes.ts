/**
 * PinkSync - Notion Integration API Routes
 * 
 * These routes provide access to Notion integration capabilities of PinkSync,
 * allowing ideas to be synced with Notion databases following the "idea, build, grow, manage" workflow.
 */

import express from 'express';
import { isAuthenticated } from '../replitAuth';
import { storage } from '../storage';
import notionService, { NotionDatabaseType } from '../services/integration/notionService';

const router = express.Router();

/**
 * Get Notion connections
 * GET /api/notion/connections
 */
router.get('/connections', isAuthenticated, async (_req, res) => {
  try {
    const connections = await notionService.getConnections();
    
    // Mask auth tokens for security
    const secureConnections = connections.map(conn => ({
      ...conn,
      authToken: '••••••••••••' // Mask the token
    }));
    
    return res.json({
      success: true,
      connections: secureConnections
    });
  } catch (error: any) {
    console.error('Error fetching Notion connections:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch Notion connections'
    });
  }
});

/**
 * Get a specific Notion connection
 * GET /api/notion/connections/:id
 */
router.get('/connections/:id', isAuthenticated, async (req, res) => {
  try {
    const connectionId = req.params.id;
    
    const connection = await notionService.getConnection(connectionId);
    
    if (!connection) {
      return res.status(404).json({
        success: false,
        error: `Notion connection not found: ${connectionId}`
      });
    }
    
    // Mask auth token for security
    const secureConnection = {
      ...connection,
      authToken: '••••••••••••' // Mask the token
    };
    
    return res.json({
      success: true,
      connection: secureConnection
    });
  } catch (error: any) {
    console.error('Error fetching Notion connection:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch Notion connection'
    });
  }
});

/**
 * Add a new Notion connection
 * POST /api/notion/connections
 */
router.post('/connections', isAuthenticated, async (req, res) => {
  try {
    const { name, authToken, workspaceId, databases, defaultDatabase, webhookUrl } = req.body;
    
    if (!name || !authToken) {
      return res.status(400).json({
        success: false,
        error: 'Name and authentication token are required'
      });
    }
    
    const connection = await notionService.addConnection({
      name,
      authToken,
      workspaceId,
      databases: databases || [],
      defaultDatabase,
      webhookUrl,
      isActive: true
    });
    
    // Mask auth token for security
    const secureConnection = {
      ...connection,
      authToken: '••••••••••••' // Mask the token
    };
    
    return res.status(201).json({
      success: true,
      message: 'Notion connection created successfully',
      connection: secureConnection
    });
  } catch (error: any) {
    console.error('Error creating Notion connection:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to create Notion connection'
    });
  }
});

/**
 * Update a Notion connection
 * PATCH /api/notion/connections/:id
 */
router.patch('/connections/:id', isAuthenticated, async (req, res) => {
  try {
    const connectionId = req.params.id;
    const { name, authToken, workspaceId, defaultDatabase, webhookUrl, isActive } = req.body;
    
    const updates: Record<string, any> = {};
    
    if (name !== undefined) updates.name = name;
    if (authToken !== undefined) updates.authToken = authToken;
    if (workspaceId !== undefined) updates.workspaceId = workspaceId;
    if (defaultDatabase !== undefined) updates.defaultDatabase = defaultDatabase;
    if (webhookUrl !== undefined) updates.webhookUrl = webhookUrl;
    if (isActive !== undefined) updates.isActive = isActive;
    
    const connection = await notionService.updateConnection(connectionId, updates);
    
    // Mask auth token for security
    const secureConnection = {
      ...connection,
      authToken: '••••••••••••' // Mask the token
    };
    
    return res.json({
      success: true,
      message: 'Notion connection updated successfully',
      connection: secureConnection
    });
  } catch (error: any) {
    console.error('Error updating Notion connection:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to update Notion connection'
    });
  }
});

/**
 * Remove a Notion connection
 * DELETE /api/notion/connections/:id
 */
router.delete('/connections/:id', isAuthenticated, async (req, res) => {
  try {
    const connectionId = req.params.id;
    
    await notionService.removeConnection(connectionId);
    
    return res.json({
      success: true,
      message: 'Notion connection removed successfully'
    });
  } catch (error: any) {
    console.error('Error removing Notion connection:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to remove Notion connection'
    });
  }
});

/**
 * Get available Notion databases for a connection
 * GET /api/notion/connections/:id/databases
 */
router.get('/connections/:id/databases', isAuthenticated, async (req, res) => {
  try {
    const connectionId = req.params.id;
    
    const result = await notionService.getAvailableDatabases(connectionId);
    
    if (!result.success) {
      return res.status(400).json(result);
    }
    
    return res.json(result);
  } catch (error: any) {
    console.error('Error fetching Notion databases:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch Notion databases'
    });
  }
});

/**
 * Add a database to a Notion connection
 * POST /api/notion/connections/:id/databases
 */
router.post('/connections/:id/databases', isAuthenticated, async (req, res) => {
  try {
    const connectionId = req.params.id;
    const { type, name, description, schema, customMapping } = req.body;
    
    if (!type || !name) {
      return res.status(400).json({
        success: false,
        error: 'Database type and name are required'
      });
    }
    
    const database = await notionService.addDatabase(connectionId, {
      type,
      name,
      description,
      schema,
      customMapping
    });
    
    return res.status(201).json({
      success: true,
      message: 'Database added to Notion connection successfully',
      database
    });
  } catch (error: any) {
    console.error('Error adding database to Notion connection:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to add database to Notion connection'
    });
  }
});

/**
 * Create a new database in Notion
 * POST /api/notion/connections/:id/create-database
 */
router.post('/connections/:id/create-database', isAuthenticated, async (req, res) => {
  try {
    const connectionId = req.params.id;
    const { title, parentPageId, type } = req.body;
    
    if (!title || !parentPageId) {
      return res.status(400).json({
        success: false,
        error: 'Title and parent page ID are required'
      });
    }
    
    const result = await notionService.createDatabase(
      connectionId,
      title,
      parentPageId,
      type || NotionDatabaseType.IDEAS
    );
    
    if (!result.success) {
      return res.status(400).json(result);
    }
    
    return res.status(201).json(result);
  } catch (error: any) {
    console.error('Error creating database in Notion:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to create database in Notion'
    });
  }
});

/**
 * Update a database in a Notion connection
 * PATCH /api/notion/connections/:connectionId/databases/:databaseId
 */
router.patch('/connections/:connectionId/databases/:databaseId', isAuthenticated, async (req, res) => {
  try {
    const { connectionId, databaseId } = req.params;
    const { type, name, description, schema, customMapping } = req.body;
    
    const updates: Record<string, any> = {};
    
    if (type !== undefined) updates.type = type;
    if (name !== undefined) updates.name = name;
    if (description !== undefined) updates.description = description;
    if (schema !== undefined) updates.schema = schema;
    if (customMapping !== undefined) updates.customMapping = customMapping;
    
    const database = await notionService.updateDatabase(connectionId, databaseId, updates);
    
    return res.json({
      success: true,
      message: 'Database in Notion connection updated successfully',
      database
    });
  } catch (error: any) {
    console.error('Error updating database in Notion connection:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to update database in Notion connection'
    });
  }
});

/**
 * Remove a database from a Notion connection
 * DELETE /api/notion/connections/:connectionId/databases/:databaseId
 */
router.delete('/connections/:connectionId/databases/:databaseId', isAuthenticated, async (req, res) => {
  try {
    const { connectionId, databaseId } = req.params;
    
    await notionService.removeDatabase(connectionId, databaseId);
    
    return res.json({
      success: true,
      message: 'Database removed from Notion connection successfully'
    });
  } catch (error: any) {
    console.error('Error removing database from Notion connection:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to remove database from Notion connection'
    });
  }
});

/**
 * Sync an idea to Notion
 * POST /api/notion/sync-idea
 */
router.post('/sync-idea', isAuthenticated, async (req, res) => {
  try {
    const {
      ideaId,
      connectionId,
      databaseId,
      includeAnalysis,
      includeValidation,
      includeFiles,
      asTemplate,
      templateType,
      templateProperties
    } = req.body;
    
    if (!ideaId || !connectionId) {
      return res.status(400).json({
        success: false,
        error: 'Idea ID and connection ID are required'
      });
    }
    
    const result = await notionService.syncIdeaToNotion({
      ideaId,
      connectionId,
      databaseId,
      includeAnalysis,
      includeValidation,
      includeFiles,
      asTemplate,
      templateType,
      templateProperties
    });
    
    if (!result.success) {
      return res.status(400).json(result);
    }
    
    // Update the idea with Notion reference
    await storage.updateIdea(ideaId, {
      metadata: {
        notionSync: {
          synced: true,
          syncedAt: new Date().toISOString(),
          notionPageId: result.data?.notionPageId,
          notionUrl: result.data?.notionUrl
        }
      }
    });
    
    return res.json(result);
  } catch (error: any) {
    console.error('Error syncing idea to Notion:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to sync idea to Notion'
    });
  }
});

/**
 * Import content from Notion
 * POST /api/notion/import
 */
router.post('/import', isAuthenticated, async (req, res) => {
  try {
    const {
      connectionId,
      databaseId,
      pageId,
      asIdea,
      categoryMapping,
      statusMapping,
      limit
    } = req.body;
    
    if (!connectionId || !databaseId) {
      return res.status(400).json({
        success: false,
        error: 'Connection ID and database ID are required'
      });
    }
    
    // Get user ID from session
    const userId = (req.session as any)?.passport?.user?.claims?.sub;
    
    if (!userId && asIdea) {
      return res.status(400).json({
        success: false,
        error: 'User ID is required to import as idea'
      });
    }
    
    const result = await notionService.importFromNotion({
      connectionId,
      databaseId,
      pageId,
      asIdea,
      userId,
      categoryMapping,
      statusMapping,
      limit
    });
    
    if (!result.success) {
      return res.status(400).json(result);
    }
    
    return res.json(result);
  } catch (error: any) {
    console.error('Error importing from Notion:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to import from Notion'
    });
  }
});

/**
 * Get database types for Notion
 * GET /api/notion/database-types
 */
router.get('/database-types', isAuthenticated, (_req, res) => {
  try {
    const databaseTypes = Object.values(NotionDatabaseType).map(type => ({
      id: type,
      name: type.charAt(0).toUpperCase() + type.slice(1).toLowerCase(),
      description: getDatabaseTypeDescription(type)
    }));
    
    return res.json({
      success: true,
      databaseTypes
    });
  } catch (error: any) {
    console.error('Error getting Notion database types:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to get Notion database types'
    });
  }
});

/**
 * Get description for a database type
 */
function getDatabaseTypeDescription(type: string): string {
  switch (type) {
    case NotionDatabaseType.IDEAS:
      return 'For storing and managing ideas and concepts';
    case NotionDatabaseType.PROJECTS:
      return 'For tracking and managing projects';
    case NotionDatabaseType.TASKS:
      return 'For tracking individual tasks and to-dos';
    case NotionDatabaseType.DOCUMENTATION:
      return 'For creating and organizing documentation';
    case NotionDatabaseType.TRENDS:
      return 'For tracking technology and market trends';
    case NotionDatabaseType.VALIDATIONS:
      return 'For storing idea validations and analysis results';
    case NotionDatabaseType.CHECKPOINTS:
      return 'For tracking development checkpoints and milestones';
    case NotionDatabaseType.CUSTOM:
      return 'Custom database with user-defined schema';
    default:
      return 'Notion database';
  }
}

export default router;