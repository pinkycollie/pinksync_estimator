import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { v4 as uuidv4 } from 'uuid';
import { astraService } from '../services/astra/astraService';
import { documentUploaderService } from '../services/astra/documentUploaderService';
import { isAuthenticated } from '../replitAuth';
import { z } from 'zod';

const router = express.Router();

// Set up multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(process.cwd(), 'uploads', 'documents');
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1E9)}`;
    const ext = path.extname(file.originalname);
    cb(null, `${path.basename(file.originalname, ext)}-${uniqueSuffix}${ext}`);
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedExtensions = ['.json', '.csv', '.txt'];
    const ext = path.extname(file.originalname).toLowerCase();
    
    if (allowedExtensions.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Only .json, .csv, and .txt files are allowed'));
    }
  }
});

// Define validation schemas
const uploadDocumentSchema = z.object({
  collection: z.string(),
  namespace: z.string().optional(),
  documentId: z.string().optional(),
  tags: z.array(z.string()).optional(),
  metadata: z.record(z.any()).optional()
});

const batchUploadSchema = z.object({
  collection: z.string(),
  namespace: z.string().optional(),
  tags: z.array(z.string()).optional(),
  generateIds: z.boolean().optional().default(true),
  idField: z.string().optional()
});

// List all collections
router.get('/api/astra/collections', isAuthenticated, async (req, res) => {
  try {
    const collections = await astraService.listCollections();
    res.json(collections);
  } catch (error) {
    console.error('Error listing collections:', error);
    res.status(500).json({ error: 'Failed to list collections' });
  }
});

// Create a new collection
router.post('/api/astra/collections', isAuthenticated, express.json(), async (req, res) => {
  try {
    const { collection } = req.body;
    
    if (!collection) {
      return res.status(400).json({ error: 'Collection name is required' });
    }
    
    await documentUploaderService.ensureCollection(collection);
    res.status(201).json({ message: `Collection ${collection} created successfully` });
  } catch (error) {
    console.error('Error creating collection:', error);
    res.status(500).json({ error: 'Failed to create collection' });
  }
});

// Upload a document using JSON body
router.post('/api/astra/documents', isAuthenticated, express.json(), async (req, res) => {
  try {
    // Validate request
    const validationResult = uploadDocumentSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ 
        error: 'Invalid request body',
        details: validationResult.error.format() 
      });
    }
    
    const { collection, documentId, namespace, tags, metadata } = validationResult.data;
    const content = req.body.content || {};
    
    if (!content || typeof content !== 'object' || Array.isArray(content)) {
      return res.status(400).json({ error: 'Content must be a JSON object' });
    }
    
    // Upload document
    const result = await documentUploaderService.uploadDocument({
      collection,
      documentId,
      content,
      namespace,
      tags,
      metadata: {
        ...metadata,
        uploadedBy: req.user.claims.sub
      }
    });
    
    res.status(201).json(result);
  } catch (error) {
    console.error('Error uploading document:', error);
    res.status(500).json({ error: 'Failed to upload document' });
  }
});

// Upload a file (JSON, CSV, TXT)
router.post('/api/astra/upload-file', isAuthenticated, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    // Validate request
    const validationResult = batchUploadSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ 
        error: 'Invalid request body',
        details: validationResult.error.format() 
      });
    }
    
    const { collection, namespace, tags, generateIds, idField } = validationResult.data;
    
    // Determine file format
    const ext = path.extname(req.file.originalname).toLowerCase();
    let format: 'json' | 'csv' | 'txt';
    
    switch (ext) {
      case '.json':
        format = 'json';
        break;
      case '.csv':
        format = 'csv';
        break;
      case '.txt':
        format = 'txt';
        break;
      default:
        return res.status(400).json({ error: 'Unsupported file format' });
    }
    
    // Batch upload
    const result = await documentUploaderService.batchUpload({
      collection,
      namespace,
      tags,
      generateIds,
      files: [{
        path: req.file.path,
        format,
        idField
      }]
    });
    
    res.json({
      ...result,
      file: {
        originalname: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size
      }
    });
  } catch (error) {
    console.error('Error uploading file:', error);
    res.status(500).json({ error: 'Failed to upload file' });
  }
});

// Search documents in a collection
router.post('/api/astra/search', isAuthenticated, express.json(), async (req, res) => {
  try {
    const { collection, query, namespace = 'default', limit = 100 } = req.body;
    
    if (!collection) {
      return res.status(400).json({ error: 'Collection name is required' });
    }
    
    if (!query || typeof query !== 'object') {
      return res.status(400).json({ error: 'Query must be a valid object' });
    }
    
    const results = await astraService.findDocuments(namespace, collection, query, { limit });
    res.json(results);
  } catch (error) {
    console.error('Error searching documents:', error);
    res.status(500).json({ error: 'Failed to search documents' });
  }
});

// Get a document by ID
router.get('/api/astra/documents/:collection/:id', isAuthenticated, async (req, res) => {
  try {
    const { collection, id } = req.params;
    const namespace = req.query.namespace as string || 'default';
    
    const document = await astraService.getDocument(namespace, collection, id);
    
    if (!document) {
      return res.status(404).json({ error: 'Document not found' });
    }
    
    res.json(document);
  } catch (error) {
    console.error('Error fetching document:', error);
    res.status(500).json({ error: 'Failed to fetch document' });
  }
});

// Update a document
router.patch('/api/astra/documents/:collection/:id', isAuthenticated, express.json(), async (req, res) => {
  try {
    const { collection, id } = req.params;
    const namespace = req.query.namespace as string || 'default';
    const updates = req.body;
    
    if (!updates || typeof updates !== 'object' || Array.isArray(updates)) {
      return res.status(400).json({ error: 'Updates must be a JSON object' });
    }
    
    // Check if document exists
    const existingDoc = await astraService.getDocument(namespace, collection, id);
    if (!existingDoc) {
      return res.status(404).json({ error: 'Document not found' });
    }
    
    // Add modification timestamp
    const updatedDocument = {
      ...updates,
      _metadata: {
        ...(existingDoc._metadata || {}),
        ...(updates._metadata || {}),
        updatedAt: new Date().toISOString(),
        updatedBy: req.user.claims.sub
      }
    };
    
    // Update document
    await astraService.updateDocument(namespace, collection, id, updatedDocument);
    
    // Get updated document
    const document = await astraService.getDocument(namespace, collection, id);
    
    res.json(document);
  } catch (error) {
    console.error('Error updating document:', error);
    res.status(500).json({ error: 'Failed to update document' });
  }
});

// Delete a document
router.delete('/api/astra/documents/:collection/:id', isAuthenticated, async (req, res) => {
  try {
    const { collection, id } = req.params;
    const namespace = req.query.namespace as string || 'default';
    
    // Check if document exists
    const document = await astraService.getDocument(namespace, collection, id);
    if (!document) {
      return res.status(404).json({ error: 'Document not found' });
    }
    
    // Delete document
    await astraService.deleteDocument(namespace, collection, id);
    
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting document:', error);
    res.status(500).json({ error: 'Failed to delete document' });
  }
});

export default router;