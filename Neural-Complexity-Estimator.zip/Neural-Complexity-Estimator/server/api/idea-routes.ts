/**
 * PinkSync - Idea Ingestor API Routes
 * Handles ingestion, processing, and management of entrepreneurial ideas
 */

import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { storage } from '../storage';
// Legacy idea schema - will be migrated to new project schema
import openaiService, { ChatMessage } from '../services/openai/chat';
import { isAuthenticated } from '../replitAuth';

const router = express.Router();

// Apply authentication middleware to all routes
router.use(isAuthenticated);

/**
 * GET /api/ideas
 * Get all ideas for the current user
 */
router.get('/', async (req: any, res) => {
  try {
    const userId = req.user?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    const ideas = await storage.getIdeasByUserId(userId);
    res.json(ideas);
  } catch (error: any) {
    console.error('Error fetching ideas:', error);
    res.status(500).json({ error: error.message || 'Failed to fetch ideas' });
  }
});

/**
 * GET /api/ideas/:id
 * Get a specific idea by ID
 */
router.get('/:id', async (req, res) => {
  try {
    const userId = req.user?.claims?.sub;
    const ideaId = parseInt(req.params.id);
    
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    const idea = await storage.getIdeaById(ideaId);
    
    if (!idea) {
      return res.status(404).json({ error: 'Idea not found' });
    }
    
    // Check if the user owns this idea
    if (idea.userId.toString() !== userId) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    
    res.json(idea);
  } catch (error: any) {
    console.error('Error fetching idea:', error);
    res.status(500).json({ error: error.message || 'Failed to fetch idea' });
  }
});

/**
 * POST /api/ideas/ingest
 * Ingest raw text from various sources and generate idea entries
 */
router.post('/ingest', async (req: any, res) => {
  try {
    const userId = req.user?.claims?.sub;
    const { content, source, format } = req.body;
    
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    if (!content) {
      return res.status(400).json({ error: 'Content is required' });
    }
    
    // Process the content using OpenAI to extract ideas
    const messages = [
      {
        role: 'system' as const,
        content: `You are an AI assistant specialized in extracting entrepreneurial ideas from text content. 
        Extract key ideas with the following information for each:
        1. A clear, concise title (max 10 words)
        2. A detailed description that captures the essence of the idea
        3. Suggested category (business, tech, product, service, etc.)
        4. Relevant tags (comma separated)
        5. Priority score (1-10, with 10 being highest priority)
        
        Format each idea as a JSON object with these fields: title, description, category, tags, priority`
      },
      {
        role: 'user' as const,
        content: `Extract entrepreneurial ideas from the following content. The content is from ${source || 'user input'} in ${format || 'text'} format:\n\n${content}`
      }
    ];
    
    // Generate AI analysis of the content
    const completion = await openaiService.chat.generateChatCompletion(
      messages,
      { model: 'gpt-4o', useContext: true, contextId: userId }
    );
    
    // Parse the ideas from the AI response
    // We expect a JSON string or array of idea objects
    let extractedIdeas = [];
    try {
      // First try to parse as a JSON array directly
      const responseText = completion.content.trim();
      
      // Check if the response is wrapped in backticks or has a JSON code block
      const jsonMatch = responseText.match(/```json\n([\s\S]*?)\n```/) || 
                        responseText.match(/```\n([\s\S]*?)\n```/) ||
                        responseText.match(/`([\s\S]*?)`/);
      
      const jsonContent = jsonMatch ? jsonMatch[1] : responseText;
      
      extractedIdeas = JSON.parse(jsonContent);
      
      // Ensure it's an array
      if (!Array.isArray(extractedIdeas)) {
        extractedIdeas = [extractedIdeas];
      }
    } catch (parseError) {
      console.error('Error parsing AI response:', parseError);
      console.log('Raw AI response:', completion.content);
      return res.status(500).json({ 
        error: 'Failed to parse ideas from AI response',
        aiResponse: completion.content
      });
    }
    
    // Convert extracted ideas to database format and save them
    const savedIdeas = [];
    
    for (const idea of extractedIdeas) {
      const newIdea = {
        userId: userId,
        title: idea.title,
        description: idea.description,
        category: idea.category || 'general',
        status: 'draft',
        priority: idea.priority || 5,
        tags: idea.tags || '',
        inspirationSource: source || 'user input',
      };
      
      // Validate the idea using the schema
      const parseResult = insertEntrepreneurIdeaSchema.safeParse(newIdea);
      
      if (!parseResult.success) {
        console.error('Invalid idea data:', parseResult.error);
        continue; // Skip invalid ideas
      }
      
      // Save the idea to the database
      const savedIdea = await storage.createIdea(newIdea);
      savedIdeas.push(savedIdea);
    }
    
    res.json({ 
      message: `Successfully extracted ${savedIdeas.length} ideas`,
      ideas: savedIdeas
    });
  } catch (error: any) {
    console.error('Error ingesting ideas:', error);
    res.status(500).json({ error: error.message || 'Failed to ingest ideas' });
  }
});

/**
 * POST /api/ideas
 * Create a new idea manually
 */
router.post('/', async (req: any, res) => {
  try {
    const userId = req.user?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    const ideaData = {
      ...req.body,
      userId: userId,
    };
    
    // Validate using schema
    const parseResult = insertEntrepreneurIdeaSchema.safeParse(ideaData);
    
    if (!parseResult.success) {
      return res.status(400).json({ 
        error: 'Invalid idea data', 
        details: parseResult.error.format() 
      });
    }
    
    const idea = await storage.createIdea(ideaData);
    res.status(201).json(idea);
  } catch (error: any) {
    console.error('Error creating idea:', error);
    res.status(500).json({ error: error.message || 'Failed to create idea' });
  }
});

/**
 * PUT /api/ideas/:id
 * Update an existing idea
 */
router.put('/:id', async (req: any, res) => {
  try {
    const userId = req.user?.claims?.sub;
    const ideaId = parseInt(req.params.id);
    
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    // Check if the idea exists and belongs to the user
    const existingIdea = await storage.getIdeaById(ideaId);
    
    if (!existingIdea) {
      return res.status(404).json({ error: 'Idea not found' });
    }
    
    if (existingIdea.userId !== userId) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    
    // Update the idea
    const updatedData = {
      ...req.body,
      id: ideaId,
      userId: userId, // Ensure userId doesn't change
    };
    
    const updatedIdea = await storage.updateIdea(ideaId, updatedData);
    res.json(updatedIdea);
  } catch (error: any) {
    console.error('Error updating idea:', error);
    res.status(500).json({ error: error.message || 'Failed to update idea' });
  }
});

/**
 * DELETE /api/ideas/:id
 * Delete an idea
 */
router.delete('/:id', async (req: any, res) => {
  try {
    const userId = req.user?.claims?.sub;
    const ideaId = parseInt(req.params.id);
    
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    // Check if the idea exists and belongs to the user
    const existingIdea = await storage.getIdeaById(ideaId);
    
    if (!existingIdea) {
      return res.status(404).json({ error: 'Idea not found' });
    }
    
    if (existingIdea.userId !== userId) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    
    // Delete the idea
    await storage.deleteIdea(ideaId);
    res.json({ success: true, message: 'Idea deleted successfully' });
  } catch (error: any) {
    console.error('Error deleting idea:', error);
    res.status(500).json({ error: error.message || 'Failed to delete idea' });
  }
});

/**
 * POST /api/ideas/:id/analyze
 * Analyze an idea with AI to suggest improvements, next steps, etc.
 */
router.post('/:id/analyze', async (req: any, res) => {
  try {
    const userId = req.user?.claims?.sub;
    const ideaId = parseInt(req.params.id);
    
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    
    // Check if the idea exists and belongs to the user
    const idea = await storage.getIdeaById(ideaId);
    
    if (!idea) {
      return res.status(404).json({ error: 'Idea not found' });
    }
    
    if (idea.userId !== userId) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    
    // Use AI to analyze the idea
    const messages = [
      {
        role: 'system' as const,
        content: `You are an AI entrepreneurship advisor specialized in analyzing and improving business ideas.
        Analyze the provided idea and provide thoughtful feedback in the following areas:
        1. Strengths - What's strong about this idea?
        2. Weaknesses - What areas need improvement?
        3. Opportunities - What opportunities could be leveraged?
        4. Threats - What potential challenges might arise?
        5. Next Steps - What concrete steps would improve this idea or move it forward?
        6. Resources - What resources would be helpful?
        
        Format your response as a JSON object with these fields.`
      },
      {
        role: 'user' as const,
        content: `Analyze this entrepreneurial idea:\n\nTitle: ${idea.title}\nDescription: ${idea.description}\nCategory: ${idea.category}`
      }
    ];
    
    const completion = await openaiService.chat.generateChatCompletion(
      messages,
      { model: 'gpt-4o', useContext: true, contextId: userId }
    );
    
    // Parse the analysis from the AI response
    let analysis = {};
    try {
      // Extract JSON from the response
      const responseText = completion.content.trim();
      
      // Check if the response is wrapped in backticks or has a JSON code block
      const jsonMatch = responseText.match(/```json\n([\s\S]*?)\n```/) || 
                        responseText.match(/```\n([\s\S]*?)\n```/) ||
                        responseText.match(/`([\s\S]*?)`/);
      
      const jsonContent = jsonMatch ? jsonMatch[1] : responseText;
      
      analysis = JSON.parse(jsonContent);
    } catch (parseError) {
      console.error('Error parsing AI analysis:', parseError);
      // Return the raw analysis if JSON parsing fails
      analysis = { 
        rawAnalysis: completion.content,
        error: 'Failed to parse as structured JSON'
      };
    }
    
    res.json({
      idea: idea,
      analysis: analysis
    });
  } catch (error: any) {
    console.error('Error analyzing idea:', error);
    res.status(500).json({ error: error.message || 'Failed to analyze idea' });
  }
});

export default router;