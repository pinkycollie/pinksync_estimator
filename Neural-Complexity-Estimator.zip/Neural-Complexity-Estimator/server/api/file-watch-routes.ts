import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { isAuthenticated } from '../replitAuth';
import { storage } from '../storage';
import { FileWatchService } from '../services/automation/fileWatchService';
import { hasPermission } from '../middleware/accessControl';

const router = express.Router();

// Interface types - these should match the frontend and FileWatchService interfaces
interface WatchConfig {
  id: string;
  name: string;
  path: string;
  excludePaths: string[];
  isRecursive: boolean;
  watchForPatterns: string[];
  ignorePatterns: string[];
  active: boolean;
  createdAt: string;
  automationRules: AutomationRule[];
}

interface AutomationRule {
  id: string;
  name: string;
  description?: string;
  eventType: 'add' | 'change' | 'unlink' | 'addDir' | 'unlinkDir' | 'all';
  filePattern: string;
  actions: AutomationAction[];
  active: boolean;
}

interface AutomationAction {
  id: string;
  type: 'notify' | 'move' | 'copy' | 'delete' | 'rename' | 'sync' | 'extract' | 'execute' | 'googleSheets';
  config: Record<string, any>;
  active: boolean;
}

interface FileEvent {
  id: string;
  watchId: string;
  eventType: string;
  filePath: string;
  relativePath: string;
  timestamp: string;
  fileStats?: any;
  automationResults?: AutomationResult[];
}

interface AutomationResult {
  id: string;
  ruleId: string;
  ruleName: string;
  successful: boolean;
  actions: {
    id: string;
    type: string;
    successful: boolean;
    message?: string;
    details?: any;
  }[];
  timestamp: string;
}

// Get the FileWatchService instance
const fileWatchService = FileWatchService.getInstance();

// Get all watch configurations
router.get('/configs', isAuthenticated, hasPermission('fileWatcher'), async (req, res) => {
  try {
    const configs = await fileWatchService.getConfigs();
    res.json(configs);
  } catch (error: any) {
    console.error('Error fetching watch configurations:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Get a specific watch configuration
router.get('/configs/:id', isAuthenticated, hasPermission('fileWatcher'), async (req, res) => {
  try {
    const config = await fileWatchService.getConfig(req.params.id);
    if (!config) {
      return res.status(404).json({ error: 'Watch configuration not found' });
    }
    res.json(config);
  } catch (error: any) {
    console.error(`Error fetching watch configuration ${req.params.id}:`, error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Create a new watch configuration
router.post('/configs', isAuthenticated, hasPermission('fileWatcher'), async (req, res) => {
  try {
    const { name, path, excludePaths, isRecursive, watchForPatterns, ignorePatterns, active } = req.body;
    
    if (!name || !path) {
      return res.status(400).json({ error: 'Name and path are required' });
    }
    
    const newConfig: Omit<WatchConfig, 'id' | 'createdAt'> & { id?: string, createdAt?: string } = {
      name,
      path,
      excludePaths: excludePaths || [],
      isRecursive: isRecursive !== undefined ? isRecursive : true,
      watchForPatterns: watchForPatterns || ['*'],
      ignorePatterns: ignorePatterns || [],
      active: active !== undefined ? active : true,
      automationRules: []
    };
    
    const config = await fileWatchService.addConfig(newConfig);
    res.status(201).json(config);
  } catch (error: any) {
    console.error('Error creating watch configuration:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Update a watch configuration
router.patch('/configs/:id', isAuthenticated, hasPermission('fileWatcher'), async (req, res) => {
  try {
    const configId = req.params.id;
    const { name, path, excludePaths, isRecursive, watchForPatterns, ignorePatterns, active } = req.body;
    
    const existingConfig = await fileWatchService.getConfig(configId);
    if (!existingConfig) {
      return res.status(404).json({ error: 'Watch configuration not found' });
    }
    
    const updatedConfig: Partial<WatchConfig> = {
      ...(name !== undefined && { name }),
      ...(path !== undefined && { path }),
      ...(excludePaths !== undefined && { excludePaths }),
      ...(isRecursive !== undefined && { isRecursive }),
      ...(watchForPatterns !== undefined && { watchForPatterns }),
      ...(ignorePatterns !== undefined && { ignorePatterns }),
      ...(active !== undefined && { active })
    };
    
    const config = await fileWatchService.updateConfig(configId, updatedConfig);
    res.json(config);
  } catch (error: any) {
    console.error(`Error updating watch configuration ${req.params.id}:`, error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Delete a watch configuration
router.delete('/configs/:id', isAuthenticated, hasPermission('fileWatcher'), async (req, res) => {
  try {
    const configId = req.params.id;
    
    const existingConfig = await fileWatchService.getConfig(configId);
    if (!existingConfig) {
      return res.status(404).json({ error: 'Watch configuration not found' });
    }
    
    await fileWatchService.removeConfig(configId);
    res.status(204).send();
  } catch (error: any) {
    console.error(`Error deleting watch configuration ${req.params.id}:`, error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Get all rules for a watch configuration
router.get('/configs/:id/rules', isAuthenticated, hasPermission('fileWatcher'), async (req, res) => {
  try {
    const configId = req.params.id;
    
    const config = await fileWatchService.getConfig(configId);
    if (!config) {
      return res.status(404).json({ error: 'Watch configuration not found' });
    }
    
    res.json(config.automationRules || []);
  } catch (error: any) {
    console.error(`Error fetching rules for watch configuration ${req.params.id}:`, error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Add a rule to a watch configuration
router.post('/configs/:id/rules', isAuthenticated, hasPermission('fileAutomation'), async (req, res) => {
  try {
    const configId = req.params.id;
    const { name, description, eventType, filePattern, active } = req.body;
    
    if (!name || !eventType || !filePattern) {
      return res.status(400).json({ error: 'Name, eventType, and filePattern are required' });
    }
    
    const config = await fileWatchService.getConfig(configId);
    if (!config) {
      return res.status(404).json({ error: 'Watch configuration not found' });
    }
    
    const newRule: AutomationRule = {
      id: uuidv4(),
      name,
      description,
      eventType,
      filePattern,
      active: active !== undefined ? active : true,
      actions: []
    };
    
    const updatedConfig = await fileWatchService.addRule(configId, newRule);
    res.status(201).json(newRule);
  } catch (error: any) {
    console.error(`Error adding rule to watch configuration ${req.params.id}:`, error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Update a rule
router.patch('/configs/:id/rules/:ruleId', isAuthenticated, hasPermission('fileAutomation'), async (req, res) => {
  try {
    const configId = req.params.id;
    const ruleId = req.params.ruleId;
    const { name, description, eventType, filePattern, active } = req.body;
    
    const config = await fileWatchService.getConfig(configId);
    if (!config) {
      return res.status(404).json({ error: 'Watch configuration not found' });
    }
    
    const ruleIndex = config.automationRules.findIndex(rule => rule.id === ruleId);
    if (ruleIndex === -1) {
      return res.status(404).json({ error: 'Rule not found' });
    }
    
    const updatedRule: Partial<AutomationRule> = {
      ...(name !== undefined && { name }),
      ...(description !== undefined && { description }),
      ...(eventType !== undefined && { eventType }),
      ...(filePattern !== undefined && { filePattern }),
      ...(active !== undefined && { active })
    };
    
    const result = await fileWatchService.updateRule(configId, ruleId, updatedRule);
    res.json(result);
  } catch (error: any) {
    console.error(`Error updating rule ${req.params.ruleId} for watch configuration ${req.params.id}:`, error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Delete a rule
router.delete('/configs/:id/rules/:ruleId', isAuthenticated, hasPermission('fileAutomation'), async (req, res) => {
  try {
    const configId = req.params.id;
    const ruleId = req.params.ruleId;
    
    const config = await fileWatchService.getConfig(configId);
    if (!config) {
      return res.status(404).json({ error: 'Watch configuration not found' });
    }
    
    const ruleIndex = config.automationRules.findIndex(rule => rule.id === ruleId);
    if (ruleIndex === -1) {
      return res.status(404).json({ error: 'Rule not found' });
    }
    
    await fileWatchService.removeRule(configId, ruleId);
    res.status(204).send();
  } catch (error: any) {
    console.error(`Error deleting rule ${req.params.ruleId} for watch configuration ${req.params.id}:`, error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Add an action to a rule
router.post('/configs/:id/rules/:ruleId/actions', isAuthenticated, hasPermission('fileAutomation'), async (req, res) => {
  try {
    const configId = req.params.id;
    const ruleId = req.params.ruleId;
    const { type, config: actionConfig, active } = req.body;
    
    if (!type) {
      return res.status(400).json({ error: 'Action type is required' });
    }
    
    const watchConfig = await fileWatchService.getConfig(configId);
    if (!watchConfig) {
      return res.status(404).json({ error: 'Watch configuration not found' });
    }
    
    const rule = watchConfig.automationRules.find(rule => rule.id === ruleId);
    if (!rule) {
      return res.status(404).json({ error: 'Rule not found' });
    }
    
    const newAction: AutomationAction = {
      id: uuidv4(),
      type,
      config: actionConfig || {},
      active: active !== undefined ? active : true
    };
    
    const updatedConfig = await fileWatchService.addAction(configId, ruleId, newAction);
    res.status(201).json(newAction);
  } catch (error: any) {
    console.error(`Error adding action to rule ${req.params.ruleId} for watch configuration ${req.params.id}:`, error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Update an action
router.patch('/configs/:id/rules/:ruleId/actions/:actionId', isAuthenticated, hasPermission('fileAutomation'), async (req, res) => {
  try {
    const configId = req.params.id;
    const ruleId = req.params.ruleId;
    const actionId = req.params.actionId;
    const { type, config: actionConfig, active } = req.body;
    
    const watchConfig = await fileWatchService.getConfig(configId);
    if (!watchConfig) {
      return res.status(404).json({ error: 'Watch configuration not found' });
    }
    
    const rule = watchConfig.automationRules.find(rule => rule.id === ruleId);
    if (!rule) {
      return res.status(404).json({ error: 'Rule not found' });
    }
    
    const actionIndex = rule.actions.findIndex(action => action.id === actionId);
    if (actionIndex === -1) {
      return res.status(404).json({ error: 'Action not found' });
    }
    
    const updatedAction: Partial<AutomationAction> = {
      ...(type !== undefined && { type }),
      ...(actionConfig !== undefined && { config: actionConfig }),
      ...(active !== undefined && { active })
    };
    
    const result = await fileWatchService.updateAction(configId, ruleId, actionId, updatedAction);
    res.json(result);
  } catch (error: any) {
    console.error(`Error updating action ${req.params.actionId} for rule ${req.params.ruleId}:`, error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Delete an action
router.delete('/configs/:id/rules/:ruleId/actions/:actionId', isAuthenticated, hasPermission('fileAutomation'), async (req, res) => {
  try {
    const configId = req.params.id;
    const ruleId = req.params.ruleId;
    const actionId = req.params.actionId;
    
    const watchConfig = await fileWatchService.getConfig(configId);
    if (!watchConfig) {
      return res.status(404).json({ error: 'Watch configuration not found' });
    }
    
    const rule = watchConfig.automationRules.find(rule => rule.id === ruleId);
    if (!rule) {
      return res.status(404).json({ error: 'Rule not found' });
    }
    
    const actionIndex = rule.actions.findIndex(action => action.id === actionId);
    if (actionIndex === -1) {
      return res.status(404).json({ error: 'Action not found' });
    }
    
    await fileWatchService.removeAction(configId, ruleId, actionId);
    res.status(204).send();
  } catch (error: any) {
    console.error(`Error deleting action ${req.params.actionId} for rule ${req.params.ruleId}:`, error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Get all file events for a config
router.get('/configs/:id/events', isAuthenticated, hasPermission('fileWatcher'), async (req, res) => {
  try {
    const configId = req.params.id;
    
    const config = await fileWatchService.getConfig(configId);
    if (!config) {
      return res.status(404).json({ error: 'Watch configuration not found' });
    }
    
    const events = await fileWatchService.getEventsByConfig(configId);
    res.json(events);
  } catch (error: any) {
    console.error(`Error fetching events for watch configuration ${req.params.id}:`, error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

// Get recent file events (across all configs)
router.get('/events/recent', isAuthenticated, hasPermission('fileWatcher'), async (req, res) => {
  try {
    const limit = Number(req.query.limit) || 20;
    const events = await fileWatchService.getRecentEvents(limit);
    res.json(events);
  } catch (error: any) {
    console.error('Error fetching recent events:', error);
    res.status(500).json({ error: error.message || 'Internal server error' });
  }
});

export default router;