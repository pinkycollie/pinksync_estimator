import express from 'express';
import { anonymousMindService } from '../services/anonymousMind/anonymousMindService';
import { isAuthenticated } from '../replitAuth';
import { z } from 'zod';

// Extend the Express Request type
declare global {
  namespace Express {
    interface User {
      claims: {
        sub: string;
        [key: string]: any;
      };
      [key: string]: any;
    }
  }
}

const router = express.Router();

// Define validation schemas
const createContentSchema = z.object({
  contentType: z.string(),
  tags: z.array(z.string()),
  content: z.string(),
  source: z.string().optional(),
  metadata: z.record(z.any()).optional(),
  isPrivate: z.boolean().optional().default(true),
});

const updateContentSchema = z.object({
  contentType: z.string().optional(),
  tags: z.array(z.string()).optional(),
  content: z.string().optional(),
  source: z.string().optional(),
  metadata: z.record(z.any()).optional(),
  isPrivate: z.boolean().optional(),
});

const searchContentSchema = z.object({
  query: z.string().optional(),
  tags: z.array(z.string()).optional(),
  contentType: z.string().optional(),
  isPrivate: z.boolean().optional(),
  limit: z.number().optional().default(100),
});

// Create content
router.post('/api/anonymous-mind/content', isAuthenticated, express.json(), async (req, res) => {
  try {
    const userId = req.user.claims.sub;
    
    // Validate request body
    const validationResult = createContentSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ 
        error: 'Invalid request body',
        details: validationResult.error.format() 
      });
    }
    
    const content = validationResult.data;
    
    // Create content in Astra DB
    const result = await anonymousMindService.createContent({
      userId,
      ...content
    });
    
    res.status(201).json(result);
  } catch (error) {
    console.error('Error creating content:', error);
    res.status(500).json({ error: 'Failed to create content' });
  }
});

// Get content by ID
router.get('/api/anonymous-mind/content/:id', isAuthenticated, async (req, res) => {
  try {
    const userId = req.user.claims.sub;
    const contentId = req.params.id;
    
    // Get content from Astra DB
    const content = await anonymousMindService.getContentById(contentId);
    
    // Check if content exists and belongs to user
    if (!content || content.userId !== userId) {
      return res.status(404).json({ error: 'Content not found' });
    }
    
    res.json(content);
  } catch (error) {
    console.error('Error retrieving content:', error);
    res.status(500).json({ error: 'Failed to retrieve content' });
  }
});

// Get user's content
router.get('/api/anonymous-mind/content', isAuthenticated, async (req, res) => {
  try {
    const userId = req.user.claims.sub;
    
    // Parse query params
    const contentType = req.query.contentType as string | undefined;
    const tagsStr = req.query.tags as string | undefined;
    const isPrivate = req.query.isPrivate !== undefined 
      ? req.query.isPrivate === 'true'
      : undefined;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
    
    const tags = tagsStr ? tagsStr.split(',') : undefined;
    
    // Get content from Astra DB
    const contents = await anonymousMindService.getContentByUserId(userId, {
      contentType,
      tags,
      isPrivate,
      limit
    });
    
    res.json(contents);
  } catch (error) {
    console.error('Error retrieving user content:', error);
    res.status(500).json({ error: 'Failed to retrieve content' });
  }
});

// Update content
router.patch('/api/anonymous-mind/content/:id', isAuthenticated, express.json(), async (req, res) => {
  try {
    const userId = req.user.claims.sub;
    const contentId = req.params.id;
    
    // Validate request body
    const validationResult = updateContentSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ 
        error: 'Invalid request body',
        details: validationResult.error.format() 
      });
    }
    
    // Check if content exists and belongs to user
    const content = await anonymousMindService.getContentById(contentId);
    if (!content || content.userId !== userId) {
      return res.status(404).json({ error: 'Content not found' });
    }
    
    const updates = validationResult.data;
    
    // Update content in Astra DB
    const updatedContent = await anonymousMindService.updateContent(contentId, updates);
    
    res.json(updatedContent);
  } catch (error) {
    console.error('Error updating content:', error);
    res.status(500).json({ error: 'Failed to update content' });
  }
});

// Delete content
router.delete('/api/anonymous-mind/content/:id', isAuthenticated, async (req, res) => {
  try {
    const userId = req.user.claims.sub;
    const contentId = req.params.id;
    
    // Check if content exists and belongs to user
    const content = await anonymousMindService.getContentById(contentId);
    if (!content || content.userId !== userId) {
      return res.status(404).json({ error: 'Content not found' });
    }
    
    // Delete content from Astra DB
    await anonymousMindService.deleteContent(contentId);
    
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting content:', error);
    res.status(500).json({ error: 'Failed to delete content' });
  }
});

// Search content
router.post('/api/anonymous-mind/search', isAuthenticated, express.json(), async (req, res) => {
  try {
    const userId = req.user.claims.sub;
    
    // Validate request body
    const validationResult = searchContentSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ 
        error: 'Invalid request body',
        details: validationResult.error.format() 
      });
    }
    
    const searchOptions = validationResult.data;
    
    // Search content in Astra DB
    const results = await anonymousMindService.searchContent(userId, searchOptions);
    
    res.json(results);
  } catch (error) {
    console.error('Error searching content:', error);
    res.status(500).json({ error: 'Failed to search content' });
  }
});

export default router;