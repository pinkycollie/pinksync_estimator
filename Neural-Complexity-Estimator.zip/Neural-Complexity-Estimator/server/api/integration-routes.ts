import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { v4 as uuidv4 } from 'uuid';
import { isAuthenticated } from '../replitAuth';
import { z } from 'zod';
import { chatToAstraService } from '../services/integration/chatToAstraService';
import { fileSyncService } from '../services/integration/fileSyncService';

const router = express.Router();

// Set up multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const fileType = file.originalname.includes('chat') ? 'chat_histories' : 'documents';
    const uploadDir = path.join(process.cwd(), 'uploads', fileType);
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1E9)}`;
    const ext = path.extname(file.originalname);
    cb(null, `${path.basename(file.originalname, ext)}-${uniqueSuffix}${ext}`);
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB limit
});

// Define validation schemas
const extractChatSchema = z.object({
  platformType: z.enum(['claude', 'chatgpt', 'generic']),
  fileFormat: z.enum(['json', 'csv', 'txt']).optional(),
  collectionName: z.string(),
  tags: z.array(z.string()).optional(),
  namespace: z.string().optional()
});

const fileSyncSchema = z.object({
  platforms: z.array(z.string()),
  direction: z.enum(['push', 'pull', 'bidirectional']),
  includePaths: z.array(z.string()).optional(),
  excludePaths: z.array(z.string()).optional(),
  deleteOrphaned: z.boolean().optional()
});

const platformSchema = z.object({
  id: z.string().optional(),
  name: z.string(),
  type: z.enum(['ubuntu', 'windows', 'dropbox', 'local']),
  config: z.record(z.any()),
  rootPath: z.string(),
  active: z.boolean()
});

// Extract chat history and upload to Astra DB
router.post('/api/integration/extract-chat', isAuthenticated, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    // Validate request
    const validationResult = extractChatSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ 
        error: 'Invalid request body',
        details: validationResult.error.format() 
      });
    }
    
    const { platformType, fileFormat, collectionName, tags, namespace } = validationResult.data;
    
    // Extract and upload
    const result = await chatToAstraService.extractAndUpload(
      collectionName,
      platformType,
      req.file.path,
      {
        fileFormat: fileFormat as any,
        tags,
        userId: req.user.claims.sub,
        namespace
      }
    );
    
    if (!result.success) {
      return res.status(500).json({
        error: 'Failed to extract and upload chat history',
        details: result.error
      });
    }
    
    res.json({
      success: true,
      totalExtracted: result.totalExtracted,
      totalUploaded: result.totalUploaded,
      file: {
        originalname: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size
      }
    });
  } catch (error) {
    console.error('Error extracting chat history:', error);
    res.status(500).json({ error: 'Failed to extract chat history' });
  }
});

// Get chat statistics
router.get('/api/integration/chat-stats/:filePath', isAuthenticated, async (req, res) => {
  try {
    const { filePath } = req.params;
    const fullPath = path.join(process.cwd(), 'uploads', 'chat_exports', filePath);
    
    // Validate file exists
    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ error: 'Chat export file not found' });
    }
    
    // Get stats
    const stats = await chatToAstraService.getConversationStats(fullPath);
    
    res.json(stats);
  } catch (error) {
    console.error('Error getting chat statistics:', error);
    res.status(500).json({ error: 'Failed to get chat statistics' });
  }
});

// Add or update a platform connection
router.post('/api/integration/platforms', isAuthenticated, express.json(), async (req, res) => {
  try {
    // Validate request
    const validationResult = platformSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ 
        error: 'Invalid request body',
        details: validationResult.error.format() 
      });
    }
    
    // Ensure platform has an ID (even if undefined in the request)
    const platform = {
      ...validationResult.data,
      id: validationResult.data.id || undefined
    };
    
    // Add platform
    const platformId = fileSyncService.addPlatform(platform as PlatformConnection);
    
    res.json({
      success: true,
      platformId,
      platform: fileSyncService.getPlatform(platformId)
    });
  } catch (error) {
    console.error('Error adding platform:', error);
    res.status(500).json({ error: 'Failed to add platform' });
  }
});

// Get all platforms
router.get('/api/integration/platforms', isAuthenticated, async (req, res) => {
  try {
    const platforms = fileSyncService.getAllPlatforms();
    res.json(platforms);
  } catch (error) {
    console.error('Error getting platforms:', error);
    res.status(500).json({ error: 'Failed to get platforms' });
  }
});

// Remove a platform
router.delete('/api/integration/platforms/:id', isAuthenticated, async (req, res) => {
  try {
    const { id } = req.params;
    
    const success = fileSyncService.removePlatform(id);
    
    if (!success) {
      return res.status(404).json({ error: 'Platform not found' });
    }
    
    res.status(204).send();
  } catch (error) {
    console.error('Error removing platform:', error);
    res.status(500).json({ error: 'Failed to remove platform' });
  }
});

// Sync files
router.post('/api/integration/sync', isAuthenticated, express.json(), async (req, res) => {
  try {
    // Validate request
    const validationResult = fileSyncSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ 
        error: 'Invalid request body',
        details: validationResult.error.format() 
      });
    }
    
    const options = validationResult.data;
    
    // Sync files
    const result = await fileSyncService.syncFiles(options);
    
    res.json(result);
  } catch (error) {
    console.error('Error syncing files:', error);
    res.status(500).json({ error: 'Failed to sync files' });
  }
});

export default router;