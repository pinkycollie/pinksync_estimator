/**
 * PinkSync - Trend Analysis API Routes
 * 
 * These routes provide access to the trend analysis capabilities of PinkSync,
 * allowing collaboration between users and AI in the "idea, build, grow, manage" workflow.
 */

import express from 'express';
import { isAuthenticated } from '../replitAuth';
import { storage } from '../storage';
import trendAnalysisService from '../services/analysis/trendAnalysisService';
import trendSyncService from '../services/sync/trendSyncService';
import { trendCategoryEnum } from '../../shared/trendAnalysisSchema';

const router = express.Router();

/**
 * Get trending technologies
 * GET /api/trends/technologies
 */
router.get('/technologies', isAuthenticated, async (req, res) => {
  try {
    const { 
      category, 
      limit = 10, 
      offset = 0,
      sortBy = 'growthRate',
      sortOrder = 'desc' 
    } = req.query;
    
    const categoryFilter = category ? 
      (Array.isArray(category) ? category : [category]) : 
      undefined;
    
    const trends = await storage.getTechnologyTrends({
      categories: categoryFilter as string[],
      limit: Number(limit),
      offset: Number(offset),
      sortBy: sortBy as string,
      sortOrder: sortOrder as 'asc' | 'desc'
    });
    
    return res.json({
      success: true,
      count: trends.length,
      trends
    });
  } catch (error: any) {
    console.error('Error fetching technology trends:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch technology trends'
    });
  }
});

/**
 * Get trending GitHub repositories
 * GET /api/trends/github
 */
router.get('/github', isAuthenticated, async (req, res) => {
  try {
    const { 
      category, 
      language,
      limit = 10, 
      offset = 0,
      sortBy = 'starCount',
      sortOrder = 'desc' 
    } = req.query;
    
    const categoryFilter = category ? 
      (Array.isArray(category) ? category : [category]) : 
      undefined;
    
    const languageFilter = language ? 
      (Array.isArray(language) ? language : [language]) : 
      undefined;
    
    const repos = await storage.getGithubTrends({
      categories: categoryFilter as string[],
      languages: languageFilter as string[],
      limit: Number(limit),
      offset: Number(offset),
      sortBy: sortBy as string,
      sortOrder: sortOrder as 'asc' | 'desc'
    });
    
    return res.json({
      success: true,
      count: repos.length,
      repositories: repos
    });
  } catch (error: any) {
    console.error('Error fetching GitHub trends:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch GitHub trends'
    });
  }
});

/**
 * Get economic news
 * GET /api/trends/economic-news
 */
router.get('/economic-news', isAuthenticated, async (req, res) => {
  try {
    const { 
      sector, 
      category,
      limit = 10, 
      offset = 0,
      sortBy = 'publishedAt',
      sortOrder = 'desc' 
    } = req.query;
    
    const sectorFilter = sector ? 
      (Array.isArray(sector) ? sector : [sector]) : 
      undefined;
    
    const categoryFilter = category ? 
      (Array.isArray(category) ? category : [category]) : 
      undefined;
    
    const news = await storage.getEconomicNews({
      sectors: sectorFilter as string[],
      categories: categoryFilter as string[],
      limit: Number(limit),
      offset: Number(offset),
      sortBy: sortBy as string,
      sortOrder: sortOrder as 'asc' | 'desc'
    });
    
    return res.json({
      success: true,
      count: news.length,
      news
    });
  } catch (error: any) {
    console.error('Error fetching economic news:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch economic news'
    });
  }
});

/**
 * Get idea validations
 * GET /api/trends/validations/:ideaId
 */
router.get('/validations/:ideaId', isAuthenticated, async (req, res) => {
  try {
    const ideaId = parseInt(req.params.ideaId);
    
    if (isNaN(ideaId)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid idea ID'
      });
    }
    
    const validations = await storage.getIdeaValidationsByIdeaId(ideaId);
    
    return res.json({
      success: true,
      count: validations.length,
      validations
    });
  } catch (error: any) {
    console.error('Error fetching idea validations:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch idea validations'
    });
  }
});

/**
 * Validate an idea against current trends
 * POST /api/trends/validate-idea
 */
router.post('/validate-idea', isAuthenticated, async (req, res) => {
  try {
    const { ideaId } = req.body;
    
    if (!ideaId) {
      return res.status(400).json({
        success: false,
        error: 'Idea ID is required'
      });
    }
    
    // Get user ID from authenticated session
    const userId = (req.session as any)?.passport?.user?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'User not authenticated'
      });
    }
    
    // Validate idea against current trends
    const validation = await trendAnalysisService.validateIdeaAgainstTrends(ideaId);
    
    return res.json({
      success: true,
      validation
    });
  } catch (error: any) {
    console.error('Error validating idea:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to validate idea'
    });
  }
});

/**
 * Monitor GitHub trends
 * POST /api/trends/monitor-github
 */
router.post('/monitor-github', isAuthenticated, async (req, res) => {
  try {
    const { 
      categories, 
      languages, 
      minimumStars,
      excludeKeywords,
      limit
    } = req.body;
    
    // Only allow authorized users to trigger monitoring
    const userId = (req.session as any)?.passport?.user?.claims?.sub;
    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'User not authenticated'
      });
    }
    
    // Check if user has necessary permissions
    const userPermissions = await storage.getUserPermissions(userId);
    if (!userPermissions?.trendAnalysis) {
      return res.status(403).json({
        success: false,
        error: 'Insufficient permissions for trend monitoring'
      });
    }
    
    // Monitor GitHub trends
    const result = await trendAnalysisService.monitorGitHubTrends({
      categories,
      languages,
      minimumStars,
      excludeKeywords,
      limit
    });
    
    return res.json({
      success: result.success,
      result
    });
  } catch (error: any) {
    console.error('Error monitoring GitHub trends:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to monitor GitHub trends'
    });
  }
});

/**
 * Monitor economic news
 * POST /api/trends/monitor-news
 */
router.post('/monitor-news', isAuthenticated, async (req, res) => {
  try {
    const { 
      sectors, 
      countries, 
      sources,
      keywords,
      excludeKeywords,
      limit
    } = req.body;
    
    // Only allow authorized users to trigger monitoring
    const userId = (req.session as any)?.passport?.user?.claims?.sub;
    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'User not authenticated'
      });
    }
    
    // Check if user has necessary permissions
    const userPermissions = await storage.getUserPermissions(userId);
    if (!userPermissions?.trendAnalysis) {
      return res.status(403).json({
        success: false,
        error: 'Insufficient permissions for trend monitoring'
      });
    }
    
    // Monitor economic news
    const result = await trendAnalysisService.monitorEconomicNews({
      sectors,
      countries,
      sources,
      keywords,
      excludeKeywords,
      limit
    });
    
    return res.json({
      success: result.success,
      result
    });
  } catch (error: any) {
    console.error('Error monitoring economic news:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to monitor economic news'
    });
  }
});

/**
 * Subscribe to trend notifications
 * POST /api/trends/subscribe
 */
router.post('/subscribe', isAuthenticated, async (req, res) => {
  try {
    const { 
      trendCategory, 
      specificTrendId,
      notificationFrequency = 'daily' 
    } = req.body;
    
    // Get user ID from authenticated session
    const userId = (req.session as any)?.passport?.user?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'User not authenticated'
      });
    }
    
    // Validate category if provided
    if (trendCategory && !Object.values(trendCategoryEnum.enumValues).includes(trendCategory)) {
      return res.status(400).json({
        success: false,
        error: `Invalid trend category: ${trendCategory}`
      });
    }
    
    // Check if subscription already exists
    const existingSubscription = await storage.getUserTrendSubscription(
      userId, 
      trendCategory, 
      specificTrendId
    );
    
    if (existingSubscription) {
      // Update existing subscription
      await storage.updateUserTrendSubscription(existingSubscription.id, {
        notificationEnabled: true,
        notificationFrequency,
        updatedAt: new Date()
      });
      
      return res.json({
        success: true,
        subscription: await storage.getUserTrendSubscriptionById(existingSubscription.id)
      });
    } else {
      // Create new subscription
      const subscription = await storage.createUserTrendSubscription({
        userId,
        trendCategory,
        specificTrendId,
        notificationEnabled: true,
        notificationFrequency
      });
      
      return res.json({
        success: true,
        subscription
      });
    }
  } catch (error: any) {
    console.error('Error subscribing to trend:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to subscribe to trend'
    });
  }
});

/**
 * Unsubscribe from trend notifications
 * POST /api/trends/unsubscribe
 */
router.post('/unsubscribe', isAuthenticated, async (req, res) => {
  try {
    const { subscriptionId } = req.body;
    
    if (!subscriptionId) {
      return res.status(400).json({
        success: false,
        error: 'Subscription ID is required'
      });
    }
    
    // Get user ID from authenticated session
    const userId = (req.session as any)?.passport?.user?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'User not authenticated'
      });
    }
    
    // Get subscription to verify ownership
    const subscription = await storage.getUserTrendSubscriptionById(subscriptionId);
    
    if (!subscription) {
      return res.status(404).json({
        success: false,
        error: 'Subscription not found'
      });
    }
    
    // Verify that the subscription belongs to the user
    if (subscription.userId !== userId) {
      return res.status(403).json({
        success: false,
        error: 'You do not have permission to unsubscribe from this trend'
      });
    }
    
    // Update subscription to disable notifications
    await storage.updateUserTrendSubscription(subscriptionId, {
      notificationEnabled: false,
      updatedAt: new Date()
    });
    
    return res.json({
      success: true
    });
  } catch (error: any) {
    console.error('Error unsubscribing from trend:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to unsubscribe from trend'
    });
  }
});

/**
 * Sync trend database to a remote platform
 * POST /api/trends/sync
 */
router.post('/sync', isAuthenticated, async (req, res) => {
  try {
    const { 
      connectionId, 
      targetPath,
      syncTechnologyTrends,
      syncGithubTrends,
      syncEconomicNews,
      syncIdeaValidations,
      fullSync
    } = req.body;
    
    if (!connectionId) {
      return res.status(400).json({
        success: false,
        error: 'Connection ID is required'
      });
    }
    
    // Only allow authorized users to trigger sync
    const userId = (req.session as any)?.passport?.user?.claims?.sub;
    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'User not authenticated'
      });
    }
    
    // Check if user has necessary permissions
    const userPermissions = await storage.getUserPermissions(userId);
    if (!userPermissions?.databaseSync) {
      return res.status(403).json({
        success: false,
        error: 'Insufficient permissions for database sync'
      });
    }
    
    // Perform the sync
    const syncResult = await trendSyncService.syncToRemote({
      connectionId,
      targetPath,
      syncTechnologyTrends,
      syncGithubTrends,
      syncEconomicNews,
      syncIdeaValidations,
      fullSync
    });
    
    return res.json({
      success: syncResult.success,
      result: syncResult
    });
  } catch (error: any) {
    console.error('Error syncing trend database:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to sync trend database'
    });
  }
});

/**
 * Get available trend categories
 * GET /api/trends/categories
 */
router.get('/categories', isAuthenticated, (_req, res) => {
  try {
    const categories = Object.values(trendCategoryEnum.enumValues).map(category => ({
      id: category,
      name: category.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase()),
      description: getCategoryDescription(category)
    }));
    
    return res.json({
      success: true,
      categories
    });
  } catch (error: any) {
    console.error('Error getting trend categories:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Failed to get trend categories'
    });
  }
});

/**
 * Get description for a trend category
 */
function getCategoryDescription(category: string): string {
  switch (category) {
    case 'AR_VR':
      return 'Augmented and Virtual Reality technologies';
    case 'CYBERSECURITY':
      return 'Security solutions for protecting systems, networks, and data';
    case 'WEB3':
      return 'Decentralized web technologies including blockchain and cryptocurrencies';
    case 'CLOUD_COMPUTING':
      return 'Services and infrastructure for cloud-based computing';
    case 'QUANTUM_COMPUTING':
      return 'Computing using quantum-mechanical phenomena';
    case '3D_PRINTING':
      return 'Additive manufacturing technologies for creating three-dimensional objects';
    case 'SUPER_APPS':
      return 'All-in-one applications offering multiple services';
    case 'AI_ML':
      return 'Artificial Intelligence and Machine Learning technologies';
    case 'IOT':
      return 'Internet of Things devices and connectivity';
    case 'FINTECH':
      return 'Financial technology innovations';
    case 'HEALTHTECH':
      return 'Technology solutions for healthcare and wellness';
    case 'OTHER':
      return 'Other emerging technology trends';
    default:
      return 'Technology trend category';
  }
}

export default router;