/**
 * PinkSync Neural Network API Routes
 * 
 * These routes handle neural signal processing and related functionality.
 */

import { Router } from 'express';
import { neuralProcessor } from '../services/neural/neuralProcessor';
import { createTextProcessor } from '../services/neural/processors/textProcessor';
import { createASLProcessor } from '../services/neural/processors/aslProcessor';
import { NeuralSignal } from '../../shared/types/neural';
import { logger } from '../utils/logger';

// Initialize router
const router = Router();

// Initialize specialized processors
const textProcessor = createTextProcessor();
const aslProcessor = createASLProcessor();

// Register processors with the neural processor
neuralProcessor.registerProcessor('text-processor', async (signal, metadata) => {
  return await textProcessor.process(signal, metadata);
});

neuralProcessor.registerProcessor('asl-processor', async (signal, metadata) => {
  return await aslProcessor.process(signal, metadata);
});

// Initialize neural processor
neuralProcessor.initialize().catch(err => {
  logger.error('Failed to initialize neural processor:', err);
});

/**
 * Health check endpoint
 */
router.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    service: 'PinkSync Neural Network',
    timestamp: new Date().toISOString(),
    processors: {
      text: true,
      asl: true
    }
  });
});

/**
 * Process a neural signal
 */
router.post('/process', async (req, res) => {
  try {
    const signal: NeuralSignal = req.body;
    
    // Basic validation
    if (!signal || !signal.userId || !signal.modality) {
      return res.status(400).json({
        success: false,
        error: 'Invalid signal format. Required fields: userId, modality'
      });
    }
    
    logger.info(`Processing neural signal of type ${signal.modality} from user ${signal.userId}`);
    
    // Process the signal
    const result = await neuralProcessor.processSignal(signal);
    
    return res.json({
      success: true,
      result
    });
  } catch (error: any) {
    logger.error('Error processing neural signal:', error);
    
    return res.status(500).json({
      success: false,
      error: error.message || 'Unknown error occurred'
    });
  }
});

/**
 * Test endpoint for text processing
 */
router.post('/test/text', async (req, res) => {
  try {
    const { text, userId } = req.body;
    
    if (!text || !userId) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: text, userId'
      });
    }
    
    // Create a neural signal for text
    const signal: NeuralSignal = {
      userId,
      modality: 'text',
      context: {
        content: text
      }
    };
    
    // Process using the text processor directly
    const result = await textProcessor.process(signal, {});
    
    return res.json({
      success: true,
      result
    });
  } catch (error: any) {
    logger.error('Error in text processing test:', error);
    
    return res.status(500).json({
      success: false,
      error: error.message || 'Unknown error occurred'
    });
  }
});

/**
 * Test endpoint for ASL processing
 */
router.post('/test/asl', async (req, res) => {
  try {
    const { videoMetadata, userId } = req.body;
    
    if (!videoMetadata || !userId) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: videoMetadata, userId'
      });
    }
    
    // Create a neural signal for ASL video
    const signal: NeuralSignal = {
      userId,
      modality: 'asl_video',
      context: {
        ...videoMetadata,
        contentType: videoMetadata.contentType || 'greeting'
      }
    };
    
    // Process using the ASL processor directly
    const result = await aslProcessor.process(signal, {});
    
    return res.json({
      success: true,
      result
    });
  } catch (error: any) {
    logger.error('Error in ASL processing test:', error);
    
    return res.status(500).json({
      success: false,
      error: error.message || 'Unknown error occurred'
    });
  }
});

export default router;