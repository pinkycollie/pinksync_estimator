import express from 'express';
import { isAuthenticated } from '../replitAuth';
import { z } from 'zod';
import { googleSheetsService, CreateGoogleSheetsConfig } from '../services/integration/googleSheetsService';

const router = express.Router();

// Define validation schemas
const googleSheetsConfigSchema = z.object({
  name: z.string(),
  sheetId: z.string(),
  tabName: z.string().optional(),
  apiKey: z.string().optional(),
  serviceAccountKey: z.string().optional(),
  events: z.array(z.string()),
  active: z.boolean().optional(),
  mappingFunction: z.string().optional()
});

const eventTriggerSchema = z.object({
  type: z.string(),
  data: z.any()
});

// Get all Google Sheets configs
router.get('/api/google-sheets/configs', isAuthenticated, async (req, res) => {
  try {
    const configs = googleSheetsService.getAllConfigs().map(config => ({
      ...config,
      // Remove sensitive data
      apiKey: config.apiKey ? '[REDACTED]' : undefined,
      serviceAccountKey: config.serviceAccountKey ? '[REDACTED]' : undefined
    }));
    
    res.json(configs);
  } catch (error) {
    console.error('Error getting Google Sheets configs:', error);
    res.status(500).json({ error: 'Failed to get Google Sheets configs' });
  }
});

// Get a specific Google Sheets config
router.get('/api/google-sheets/configs/:id', isAuthenticated, async (req, res) => {
  try {
    const { id } = req.params;
    const config = googleSheetsService.getConfig(id);
    
    if (!config) {
      return res.status(404).json({ error: 'Google Sheets config not found' });
    }
    
    // Remove sensitive data
    const safeConfig = {
      ...config,
      apiKey: config.apiKey ? '[REDACTED]' : undefined,
      serviceAccountKey: config.serviceAccountKey ? '[REDACTED]' : undefined
    };
    
    res.json(safeConfig);
  } catch (error) {
    console.error('Error getting Google Sheets config:', error);
    res.status(500).json({ error: 'Failed to get Google Sheets config' });
  }
});

// Create a new Google Sheets config
router.post('/api/google-sheets/configs', isAuthenticated, express.json(), async (req, res) => {
  try {
    // Validate request
    const validationResult = googleSheetsConfigSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ 
        error: 'Invalid request body',
        details: validationResult.error.format() 
      });
    }
    
    // Ensure active property is a boolean
    const config: CreateGoogleSheetsConfig = {
      ...validationResult.data,
      active: validationResult.data.active !== undefined ? validationResult.data.active : true
    };
    
    // Create config
    const newConfig = googleSheetsService.createConfig(config);
    
    // Remove sensitive data from response
    const safeConfig = {
      ...newConfig,
      apiKey: newConfig.apiKey ? '[REDACTED]' : undefined,
      serviceAccountKey: newConfig.serviceAccountKey ? '[REDACTED]' : undefined
    };
    
    res.status(201).json(safeConfig);
  } catch (error) {
    console.error('Error creating Google Sheets config:', error);
    res.status(500).json({ error: 'Failed to create Google Sheets config' });
  }
});

// Update a Google Sheets config
router.patch('/api/google-sheets/configs/:id', isAuthenticated, express.json(), async (req, res) => {
  try {
    const { id } = req.params;
    
    // Partial validation for update
    const updateSchema = googleSheetsConfigSchema.partial();
    const validationResult = updateSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({ 
        error: 'Invalid request body',
        details: validationResult.error.format() 
      });
    }
    
    const updates = validationResult.data;
    
    // Update config
    const updatedConfig = googleSheetsService.updateConfig(id, updates);
    
    if (!updatedConfig) {
      return res.status(404).json({ error: 'Google Sheets config not found' });
    }
    
    // Remove sensitive data from response
    const safeConfig = {
      ...updatedConfig,
      apiKey: updatedConfig.apiKey ? '[REDACTED]' : undefined,
      serviceAccountKey: updatedConfig.serviceAccountKey ? '[REDACTED]' : undefined
    };
    
    res.json(safeConfig);
  } catch (error) {
    console.error('Error updating Google Sheets config:', error);
    res.status(500).json({ error: 'Failed to update Google Sheets config' });
  }
});

// Delete a Google Sheets config
router.delete('/api/google-sheets/configs/:id', isAuthenticated, async (req, res) => {
  try {
    const { id } = req.params;
    
    const success = googleSheetsService.deleteConfig(id);
    
    if (!success) {
      return res.status(404).json({ error: 'Google Sheets config not found' });
    }
    
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting Google Sheets config:', error);
    res.status(500).json({ error: 'Failed to delete Google Sheets config' });
  }
});

// Get deliveries for a Google Sheets config
router.get('/api/google-sheets/configs/:id/deliveries', isAuthenticated, async (req, res) => {
  try {
    const { id } = req.params;
    const config = googleSheetsService.getConfig(id);
    
    if (!config) {
      return res.status(404).json({ error: 'Google Sheets config not found' });
    }
    
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const deliveries = googleSheetsService.getSheetUpdateDeliveries(id, limit);
    
    res.json(deliveries);
  } catch (error) {
    console.error('Error getting Google Sheets deliveries:', error);
    res.status(500).json({ error: 'Failed to get Google Sheets deliveries' });
  }
});

// Get all events
router.get('/api/google-sheets/events', isAuthenticated, async (req, res) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const events = googleSheetsService.getSheetUpdateEvents(limit);
    
    res.json(events);
  } catch (error) {
    console.error('Error getting Google Sheets events:', error);
    res.status(500).json({ error: 'Failed to get Google Sheets events' });
  }
});

// Manually trigger an event
router.post('/api/google-sheets/trigger', isAuthenticated, express.json(), async (req, res) => {
  try {
    // Validate request
    const validationResult = eventTriggerSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ 
        error: 'Invalid request body',
        details: validationResult.error.format() 
      });
    }
    
    const { type, data } = validationResult.data;
    
    // Trigger event
    const events = await googleSheetsService.triggerEvent(type, data);
    
    res.json({
      success: true,
      eventsTriggered: events.length,
      events
    });
  } catch (error) {
    console.error('Error triggering Google Sheets event:', error);
    res.status(500).json({ error: 'Failed to trigger Google Sheets event' });
  }
});

// Get Google Apps Script template
router.get('/api/google-sheets/script-template', isAuthenticated, async (req, res) => {
  try {
    const { sheetId, tabName } = req.query;
    
    if (!sheetId) {
      return res.status(400).json({ error: 'sheetId is required' });
    }
    
    const template = googleSheetsService.generateAppsScriptTemplate(
      sheetId as string,
      tabName as string
    );
    
    res.json({
      script: template
    });
  } catch (error) {
    console.error('Error generating Google Apps Script template:', error);
    res.status(500).json({ error: 'Failed to generate Google Apps Script template' });
  }
});

export default router;