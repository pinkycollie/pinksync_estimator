/**
 * PinkSync - Notion Test Routes
 * 
 * These routes provide a simple way to test Notion API connectivity
 * and debug integration issues.
 */

import express from 'express';
import { Client } from '@notionhq/client';

const router = express.Router();

/**
 * Check if Notion API key is configured
 * GET /api/notion-test/api-key-status
 */
router.get('/api-key-status', (_req, res) => {
  const apiKey = process.env.NOTION_API_KEY;
  
  return res.json({
    configured: !!apiKey,
    message: apiKey 
      ? 'Notion API key is configured' 
      : 'Notion API key is not configured',
    keyLength: apiKey ? apiKey.length : 0
  });
});

/**
 * Test Notion connection
 * GET /api/notion-test/connection
 */
router.get('/connection', async (_req, res) => {
  try {
    // Create a new Notion client with the API key
    const notion = new Client({
      auth: process.env.NOTION_API_KEY
    });
    
    // Attempt to list users (simple API call that requires minimal permissions)
    const users = await notion.users.list();
    
    return res.json({
      success: true,
      connected: true,
      message: 'Successfully connected to Notion API',
      userCount: users.results.length,
      users: users.results.map(user => ({
        id: user.id,
        name: user.name,
        type: user.type
      }))
    });
  } catch (error: any) {
    console.error('Error connecting to Notion:', error);
    
    return res.status(500).json({
      success: false,
      connected: false,
      message: 'Failed to connect to Notion API',
      error: error.message || 'Unknown error',
      // Include the request ID if available (helpful for Notion API debugging)
      requestId: error.headers?.['x-notion-request-id'] || null
    });
  }
});

/**
 * List available Notion databases
 * GET /api/notion-test/databases
 */
router.get('/databases', async (_req, res) => {
  try {
    // Create a new Notion client with the API key
    const notion = new Client({
      auth: process.env.NOTION_API_KEY
    });
    
    // Search for databases
    const response = await notion.search({
      filter: {
        property: 'object',
        value: 'database'
      }
    });
    
    return res.json({
      success: true,
      count: response.results.length,
      databases: response.results.map((db: any) => ({
        id: db.id,
        title: db.title?.[0]?.plain_text || 'Untitled',
        url: db.url,
        createdTime: db.created_time,
        lastEditedTime: db.last_edited_time
      }))
    });
  } catch (error: any) {
    console.error('Error listing Notion databases:', error);
    
    return res.status(500).json({
      success: false,
      message: 'Failed to list Notion databases',
      error: error.message || 'Unknown error',
      requestId: error.headers?.['x-notion-request-id'] || null
    });
  }
});

export default router;