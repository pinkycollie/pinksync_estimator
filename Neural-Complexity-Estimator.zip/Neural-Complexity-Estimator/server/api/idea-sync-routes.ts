/**
 * PinkSync - Idea Sync API Routes
 * 
 * Routes for integrating the Idea Ingestor with platform synchronization capabilities,
 * allowing ideas to be exported to and imported from various connected platforms.
 */

import express from 'express';
import { ideaSyncService, IdeaFormat } from '../services/integration/ideaSyncService';
import { isAuthenticated } from '../replitAuth';

const router = express.Router();

/**
 * Export ideas to a platform
 * POST /api/idea-sync/export
 */
router.post('/export', isAuthenticated, async (req, res) => {
  try {
    const { 
      connectionId, 
      format = 'json', 
      includeAnalysis = false,
      targetPath,
      ideaIds
    } = req.body;
    
    // Get user ID from authenticated session
    const userId = req.session?.passport?.user?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({ 
        success: false, 
        error: 'User not authenticated' 
      });
    }
    
    if (!connectionId) {
      return res.status(400).json({ 
        success: false, 
        error: 'Connection ID is required' 
      });
    }
    
    // Convert format string to enum
    const formatEnum = format.toUpperCase() as keyof typeof IdeaFormat;
    if (!Object.keys(IdeaFormat).includes(formatEnum)) {
      return res.status(400).json({ 
        success: false, 
        error: `Invalid format: ${format}. Supported formats: json, markdown, csv, text` 
      });
    }
    
    // Export ideas
    const result = await ideaSyncService.exportIdeasToPlatform({
      connectionId,
      format: IdeaFormat[formatEnum],
      includeAnalysis,
      targetPath,
      userId,
      ideaIds
    });
    
    return res.json(result);
  } catch (error: any) {
    console.error('Error in idea export route:', error);
    return res.status(500).json({ 
      success: false, 
      error: error.message || 'Failed to export ideas'
    });
  }
});

/**
 * Import ideas from a platform
 * POST /api/idea-sync/import
 */
router.post('/import', isAuthenticated, async (req, res) => {
  try {
    const { 
      connectionId, 
      filePath, 
      format = 'json' 
    } = req.body;
    
    // Get user ID from authenticated session
    const userId = req.session?.passport?.user?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({ 
        success: false, 
        error: 'User not authenticated' 
      });
    }
    
    if (!connectionId) {
      return res.status(400).json({ 
        success: false, 
        error: 'Connection ID is required' 
      });
    }
    
    if (!filePath) {
      return res.status(400).json({ 
        success: false, 
        error: 'File path is required' 
      });
    }
    
    // Convert format string to enum
    const formatEnum = format.toUpperCase() as keyof typeof IdeaFormat;
    if (!Object.keys(IdeaFormat).includes(formatEnum)) {
      return res.status(400).json({ 
        success: false, 
        error: `Invalid format: ${format}. Supported formats: json, markdown, csv, text` 
      });
    }
    
    // Import ideas
    const result = await ideaSyncService.importIdeasFromPlatform(
      connectionId,
      filePath,
      IdeaFormat[formatEnum],
      userId
    );
    
    return res.json(result);
  } catch (error: any) {
    console.error('Error in idea import route:', error);
    return res.status(500).json({ 
      success: false, 
      error: error.message || 'Failed to import ideas'
    });
  }
});

/**
 * Auto-organize ideas
 * POST /api/idea-sync/organize
 */
router.post('/organize', isAuthenticated, async (req, res) => {
  try {
    const { connectionId } = req.body;
    
    // Get user ID from authenticated session
    const userId = req.session?.passport?.user?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({ 
        success: false, 
        error: 'User not authenticated' 
      });
    }
    
    if (!connectionId) {
      return res.status(400).json({ 
        success: false, 
        error: 'Connection ID is required' 
      });
    }
    
    // Organize ideas
    const result = await ideaSyncService.organizeIdeas(userId, connectionId);
    
    return res.json(result);
  } catch (error: any) {
    console.error('Error in idea organization route:', error);
    return res.status(500).json({ 
      success: false, 
      error: error.message || 'Failed to organize ideas'
    });
  }
});

/**
 * Get supported idea formats
 * GET /api/idea-sync/formats
 */
router.get('/formats', isAuthenticated, (_req, res) => {
  try {
    // Return all available formats with descriptions
    const formats = [
      { 
        id: IdeaFormat.JSON, 
        name: 'JSON', 
        description: 'A structured format for machine-readable data',
        extension: '.json',
        mimeType: 'application/json' 
      },
      { 
        id: IdeaFormat.MARKDOWN, 
        name: 'Markdown', 
        description: 'A human-readable format with formatting',
        extension: '.md',
        mimeType: 'text/markdown' 
      },
      { 
        id: IdeaFormat.CSV, 
        name: 'CSV', 
        description: 'Comma-separated values for spreadsheet compatibility',
        extension: '.csv',
        mimeType: 'text/csv' 
      },
      { 
        id: IdeaFormat.TEXT, 
        name: 'Plain Text', 
        description: 'Simple text format without formatting',
        extension: '.txt',
        mimeType: 'text/plain' 
      }
    ];
    
    return res.json({
      success: true,
      formats
    });
  } catch (error: any) {
    console.error('Error getting formats:', error);
    return res.status(500).json({ 
      success: false, 
      error: error.message || 'Failed to get formats'
    });
  }
});

export default router;