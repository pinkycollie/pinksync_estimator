/**
 * PinkSync Health API Routes
 * 
 * Endpoints for health checks and system status
 */

import { Router, Request, Response } from 'express';
import { logger } from '../utils/logger';

// Initialize router
const router = Router();

/**
 * Health check endpoint
 * Used by Render.com to determine if the service is healthy
 */
router.get('/health', (_req: Request, res: Response) => {
  try {
    // Return a simple 200 OK response
    return res.status(200).json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      version: process.env.npm_package_version || '1.0.0'
    });
  } catch (error: any) {
    logger.error('Error in health check:', error);
    
    // Still return 200 for now; in production you might want to return 500
    // if critical components are unavailable
    return res.status(200).json({
      status: 'degraded',
      timestamp: new Date().toISOString(),
      error: error.message || 'Unknown error'
    });
  }
});

export default router;