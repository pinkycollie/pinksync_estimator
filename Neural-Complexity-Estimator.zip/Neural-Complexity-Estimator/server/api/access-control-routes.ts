import { Router } from 'express';
import { isAuthenticated } from '../replitAuth';
import { hasPermission } from '../middleware/accessControl';

const router = Router();

// Get user's roles
router.get('/roles', isAuthenticated, async (req: any, res) => {
  try {
    // The user's roles should be available from the user info
    const userId = req.user.claims.sub;
    
    // This is a simplified implementation.
    // In a real application, you would fetch roles from your database
    const roles = [
      { id: 'user', description: 'Basic User' }
    ];
    
    // Check for additional roles
    if (req.user.claims?.permissions?.fileWatcher) {
      roles.push({ id: 'file_watcher', description: 'File Watcher' });
    }
    
    if (req.user.claims?.permissions?.fileAutomation) {
      roles.push({ id: 'file_automation', description: 'File Automation' });
    }
    
    if (req.user.claims?.permissions?.accessControl) {
      roles.push({ id: 'access_control_admin', description: 'Access Control Admin' });
    }
    
    res.json(roles);
  } catch (error) {
    console.error('Error fetching roles:', error);
    res.status(500).json({ error: 'Failed to fetch roles' });
  }
});

// Request file watcher role
router.post('/roles/request-file-watcher', isAuthenticated, async (req: any, res) => {
  try {
    const userId = req.user.claims.sub;
    
    // This is a simplified implementation.
    // In a real application, you would update the user's permissions in your database
    // and have an approval workflow.
    
    // For demonstration, we'll just grant the permission immediately
    if (!req.user.claims.permissions) {
      req.user.claims.permissions = {};
    }
    
    req.user.claims.permissions.fileWatcher = true;
    
    res.json({ 
      success: true, 
      message: 'File watcher role has been granted.' 
    });
  } catch (error) {
    console.error('Error requesting file watcher role:', error);
    res.status(500).json({ error: 'Failed to request file watcher role' });
  }
});

// Grant file automation role - Only available to access control admins
router.post('/roles/grant-file-automation', isAuthenticated, hasPermission('accessControl'), async (req: any, res) => {
  try {
    const { userId } = req.body;
    
    if (!userId) {
      return res.status(400).json({ error: 'User ID is required' });
    }
    
    // This is a simplified implementation.
    // In a real application, you would update the specified user's permissions in your database
    
    res.json({ 
      success: true, 
      message: 'File automation role has been granted to the specified user.' 
    });
  } catch (error) {
    console.error('Error granting file automation role:', error);
    res.status(500).json({ error: 'Failed to grant file automation role' });
  }
});

// Revoke roles - Only available to access control admins
router.post('/roles/revoke', isAuthenticated, hasPermission('accessControl'), async (req: any, res) => {
  try {
    const { userId, roleId } = req.body;
    
    if (!userId || !roleId) {
      return res.status(400).json({ error: 'User ID and role ID are required' });
    }
    
    // This is a simplified implementation.
    // In a real application, you would update the specified user's permissions in your database
    
    res.json({ 
      success: true, 
      message: `Role '${roleId}' has been revoked from the specified user.` 
    });
  } catch (error) {
    console.error('Error revoking role:', error);
    res.status(500).json({ error: 'Failed to revoke role' });
  }
});

export default router;