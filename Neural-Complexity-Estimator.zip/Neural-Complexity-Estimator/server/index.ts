import express from "express";
import { createServer } from "http";
import { setupVite, serveStatic } from "./vite";
import complexityRoutes from "./routes/simple-complexity";

const app = express();
app.use(express.json());

// Basic health check
app.get('/api/health', (_req, res) => {
  res.json({ status: 'Neural Complexity Estimator - Ready' });
});

// Use complexity routes
app.use('/api', complexityRoutes);

(async () => {
  const server = createServer(app);

  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = process.env.PORT ? parseInt(process.env.PORT) : 5000;
  server.listen(port, "0.0.0.0", () => {
    console.log(`Neural Complexity Estimator running at http://0.0.0.0:${port}/`);
  });
})();
