import session from 'express-session';
import MemoryStore from 'memorystore';
import {
  User,
  InsertUser,
  Project,
  InsertProject,
  ComplexityAnalysis,
  InsertComplexityAnalysis,
  ProjectTask,
  InsertProjectTask,
  LearningData,
  InsertLearningData,
  ProjectTemplate,
  InsertProjectTemplate
} from '../shared/schema';

// Create memory store for sessions
const MemStoreConstructor = MemoryStore(session);

// Define storage interface for PinkSync Neural Complexity Estimator
export interface IStorage {
  sessionStore: session.Store;
  
  // User management methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<InsertUser>): Promise<User | null>;

  // Project management methods
  getProjectsByUserId(userId: number): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, updates: Partial<InsertProject>): Promise<Project | null>;
  deleteProject(id: number): Promise<boolean>;

  // Complexity analysis methods
  getComplexityAnalysesByProjectId(projectId: number): Promise<ComplexityAnalysis[]>;
  getComplexityAnalysis(id: number): Promise<ComplexityAnalysis | undefined>;
  createComplexityAnalysis(analysis: InsertComplexityAnalysis): Promise<ComplexityAnalysis>;
  updateComplexityAnalysis(id: number, updates: Partial<InsertComplexityAnalysis>): Promise<ComplexityAnalysis | null>;

  // Project task methods
  getTasksByProjectId(projectId: number): Promise<ProjectTask[]>;
  getTask(id: number): Promise<ProjectTask | undefined>;
  createTask(task: InsertProjectTask): Promise<ProjectTask>;
  updateTask(id: number, updates: Partial<InsertProjectTask>): Promise<ProjectTask | null>;
  deleteTask(id: number): Promise<boolean>;

  // Learning data methods
  getLearningDataByProjectId(projectId: number): Promise<LearningData[]>;
  createLearningData(data: InsertLearningData): Promise<LearningData>;

  // Project template methods
  getAllProjectTemplates(): Promise<ProjectTemplate[]>;
  getProjectTemplate(id: number): Promise<ProjectTemplate | undefined>;
  createProjectTemplate(template: InsertProjectTemplate): Promise<ProjectTemplate>;
}

// In-memory storage implementation for PinkSync
export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private projects: Map<number, Project> = new Map();
  private complexityAnalyses: Map<number, ComplexityAnalysis> = new Map();
  private projectTasks: Map<number, ProjectTask> = new Map();
  private learningData: Map<number, LearningData> = new Map();
  private projectTemplates: Map<number, ProjectTemplate> = new Map();
  
  private lastUserId: number = 0;
  private lastProjectId: number = 0;
  private lastAnalysisId: number = 0;
  private lastTaskId: number = 0;
  private lastLearningId: number = 0;
  private lastTemplateId: number = 0;
  
  public sessionStore: session.Store;
  
  constructor() {
    this.sessionStore = new MemStoreConstructor({
      checkPeriod: 86400000 // 24 hours
    });
    
    // Initialize with some project templates
    this.initializeTemplates();
  }
  
  private initializeTemplates() {
    const templates = [
      {
        name: "Simple Web Application",
        description: "Basic web app with frontend and backend",
        category: "web_app",
        baseComplexity: 30,
        defaultTechnologies: ["React", "Node.js", "Express", "PostgreSQL"],
        commonTasks: [
          "Setup project structure",
          "Create database schema",
          "Build REST API",
          "Implement authentication",
          "Create user interface",
          "Add testing",
          "Deploy application"
        ],
        typicalTimeRange: { min: 80, max: 120 }
      },
      {
        name: "Mobile Application",
        description: "Cross-platform mobile app",
        category: "mobile_app",
        baseComplexity: 50,
        defaultTechnologies: ["React Native", "Firebase", "Redux"],
        commonTasks: [
          "Setup development environment",
          "Design UI/UX",
          "Implement navigation",
          "Add state management",
          "Integrate APIs",
          "Handle device features",
          "Testing and deployment"
        ],
        typicalTimeRange: { min: 150, max: 250 }
      },
      {
        name: "RESTful API",
        description: "Backend API service",
        category: "api",
        baseComplexity: 25,
        defaultTechnologies: ["Node.js", "Express", "PostgreSQL", "JWT"],
        commonTasks: [
          "Design API endpoints",
          "Setup database",
          "Implement authentication",
          "Add validation",
          "Write documentation",
          "Add monitoring",
          "Deploy to cloud"
        ],
        typicalTimeRange: { min: 60, max: 100 }
      }
    ];
    
    templates.forEach(async (template) => {
      await this.createProjectTemplate(template);
    });
  }
  
  // User management methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const id = ++this.lastUserId;
    const now = new Date();
    
    const newUser: User = {
      id,
      username: user.username,
      password: user.password,
      email: user.email ?? null,
      fullName: user.fullName ?? null,
      preferences: user.preferences ?? {},
      createdAt: now,
      lastLogin: null
    };
    
    this.users.set(id, newUser);
    return newUser;
  }
  
  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User | null> {
    const user = this.users.get(id);
    if (!user) return null;
    
    const updatedUser: User = {
      ...user,
      ...updates
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Project management methods
  async getProjectsByUserId(userId: number): Promise<Project[]> {
    const projects: Project[] = [];
    
    for (const project of this.projects.values()) {
      if (project.userId === userId) {
        projects.push(project);
      }
    }
    
    return projects.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }
  
  async createProject(project: InsertProject): Promise<Project> {
    const id = ++this.lastProjectId;
    const now = new Date();
    
    const newProject: Project = {
      id,
      name: project.name,
      userId: project.userId,
      description: project.description ?? null,
      status: project.status ?? 'planning',
      estimatedHours: project.estimatedHours ?? null,
      actualHours: project.actualHours ?? null,
      technologies: project.technologies ?? [],
      requirements: project.requirements ?? null,
      createdAt: now,
      updatedAt: now,
      complexityScore: null,
      completedAt: null
    };
    
    this.projects.set(id, newProject);
    return newProject;
  }
  
  async updateProject(id: number, updates: Partial<InsertProject>): Promise<Project | null> {
    const project = this.projects.get(id);
    if (!project) return null;
    
    const updatedProject: Project = {
      ...project,
      ...updates,
      updatedAt: new Date()
    };
    
    this.projects.set(id, updatedProject);
    return updatedProject;
  }
  
  async deleteProject(id: number): Promise<boolean> {
    const deleted = this.projects.delete(id);
    
    if (deleted) {
      // Clean up related data
      for (const [analysisId, analysis] of this.complexityAnalyses.entries()) {
        if (analysis.projectId === id) {
          this.complexityAnalyses.delete(analysisId);
        }
      }
      
      for (const [taskId, task] of this.projectTasks.entries()) {
        if (task.projectId === id) {
          this.projectTasks.delete(taskId);
        }
      }
      
      for (const [learningId, learning] of this.learningData.entries()) {
        if (learning.projectId === id) {
          this.learningData.delete(learningId);
        }
      }
    }
    
    return deleted;
  }
  
  // Complexity analysis methods
  async getComplexityAnalysesByProjectId(projectId: number): Promise<ComplexityAnalysis[]> {
    const analyses: ComplexityAnalysis[] = [];
    
    for (const analysis of this.complexityAnalyses.values()) {
      if (analysis.projectId === projectId) {
        analyses.push(analysis);
      }
    }
    
    return analyses.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async getComplexityAnalysis(id: number): Promise<ComplexityAnalysis | undefined> {
    return this.complexityAnalyses.get(id);
  }
  
  async createComplexityAnalysis(analysis: InsertComplexityAnalysis): Promise<ComplexityAnalysis> {
    const id = ++this.lastAnalysisId;
    const now = new Date();
    
    const newAnalysis: ComplexityAnalysis = {
      ...analysis,
      id,
      createdAt: now
    };
    
    this.complexityAnalyses.set(id, newAnalysis);
    return newAnalysis;
  }
  
  async updateComplexityAnalysis(id: number, updates: Partial<InsertComplexityAnalysis>): Promise<ComplexityAnalysis | null> {
    const analysis = this.complexityAnalyses.get(id);
    if (!analysis) return null;
    
    const updatedAnalysis: ComplexityAnalysis = {
      ...analysis,
      ...updates
    };
    
    this.complexityAnalyses.set(id, updatedAnalysis);
    return updatedAnalysis;
  }
  
  // Project task methods
  async getTasksByProjectId(projectId: number): Promise<ProjectTask[]> {
    const tasks: ProjectTask[] = [];
    
    for (const task of this.projectTasks.values()) {
      if (task.projectId === projectId) {
        tasks.push(task);
      }
    }
    
    return tasks.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }
  
  async getTask(id: number): Promise<ProjectTask | undefined> {
    return this.projectTasks.get(id);
  }
  
  async createTask(task: InsertProjectTask): Promise<ProjectTask> {
    const id = ++this.lastTaskId;
    const now = new Date();
    
    const newTask: ProjectTask = {
      ...task,
      id,
      createdAt: now,
      completedAt: null
    };
    
    this.projectTasks.set(id, newTask);
    return newTask;
  }
  
  async updateTask(id: number, updates: Partial<InsertProjectTask>): Promise<ProjectTask | null> {
    const task = this.projectTasks.get(id);
    if (!task) return null;
    
    const updatedTask: ProjectTask = {
      ...task,
      ...updates
    };
    
    this.projectTasks.set(id, updatedTask);
    return updatedTask;
  }
  
  async deleteTask(id: number): Promise<boolean> {
    return this.projectTasks.delete(id);
  }
  
  // Learning data methods
  async getLearningDataByProjectId(projectId: number): Promise<LearningData[]> {
    const data: LearningData[] = [];
    
    for (const learning of this.learningData.values()) {
      if (learning.projectId === projectId) {
        data.push(learning);
      }
    }
    
    return data.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async createLearningData(data: InsertLearningData): Promise<LearningData> {
    const id = ++this.lastLearningId;
    const now = new Date();
    
    const newLearningData: LearningData = {
      ...data,
      id,
      createdAt: now
    };
    
    this.learningData.set(id, newLearningData);
    return newLearningData;
  }
  
  // Project template methods
  async getAllProjectTemplates(): Promise<ProjectTemplate[]> {
    const templates = Array.from(this.projectTemplates.values());
    return templates.filter(t => t.isActive).sort((a, b) => a.name.localeCompare(b.name));
  }
  
  async getProjectTemplate(id: number): Promise<ProjectTemplate | undefined> {
    return this.projectTemplates.get(id);
  }
  
  async createProjectTemplate(template: InsertProjectTemplate): Promise<ProjectTemplate> {
    const id = ++this.lastTemplateId;
    const now = new Date();
    
    const newTemplate: ProjectTemplate = {
      ...template,
      id,
      createdAt: now
    };
    
    this.projectTemplates.set(id, newTemplate);
    return newTemplate;
  }
}

export const storage = new MemStorage();