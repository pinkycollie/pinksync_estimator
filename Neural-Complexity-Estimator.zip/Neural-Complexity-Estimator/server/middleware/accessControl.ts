import { Response, NextFunction } from 'express';
import accessControlService from '../services/security/accessControl';

/**
 * Middleware to check if a user has the required permission
 * @param permission The permission key to check for
 */
export function hasPermission(permission: string) {
  return (req: any, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized - Please login' });
    }

    const userId = req.user?.claims?.sub;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized - User ID not found' });
    }

    if (accessControlService.hasPermission(userId, permission)) {
      return next();
    }

    return res.status(403).json({ 
      error: 'Access denied',
      message: `You don't have the required permission: ${permission}`
    });
  };
}

/**
 * Middleware to check if a user has any of the specified permissions
 * @param permissions Array of permission keys to check for
 */
export function hasAnyPermission(permissions: string[]) {
  return (req: any, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized - Please login' });
    }

    const userId = req.user?.claims?.sub;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized - User ID not found' });
    }

    for (const permission of permissions) {
      if (accessControlService.hasPermission(userId, permission)) {
        return next();
      }
    }

    return res.status(403).json({ 
      error: 'Access denied',
      message: `You don't have any of the required permissions: ${permissions.join(', ')}` 
    });
  };
}

/**
 * Middleware to check if a user has all of the specified permissions
 * @param permissions Array of permission keys to check for
 */
export function hasAllPermissions(permissions: string[]) {
  return (req: any, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized - Please login' });
    }

    const userId = req.user?.claims?.sub;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized - User ID not found' });
    }

    for (const permission of permissions) {
      if (!accessControlService.hasPermission(userId, permission)) {
        return res.status(403).json({ 
          error: 'Access denied',
          message: `Missing required permission: ${permission}` 
        });
      }
    }

    return next();
  };
}

/**
 * Middleware to check if a user has a specific role
 * @param role The role to check for
 */
export function hasRole(role: string) {
  return (req: any, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized - Please login' });
    }

    const userId = req.user?.claims?.sub;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized - User ID not found' });
    }

    const userAc = accessControlService.getUserAccessControl(userId);
    if (!userAc || !userAc.roles.includes(role)) {
      return res.status(403).json({ 
        error: 'Access denied',
        message: `You don't have the required role: ${role}` 
      });
    }

    return next();
  };
}

/**
 * Middleware to apply access control checks to a route based on resourceType and action
 * @param resourceType The type of resource being accessed
 * @param action The action being performed on the resource
 */
export function checkAccess(resourceType: string, action: string) {
  return (req: any, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: 'Unauthorized - Please login' });
    }

    const userId = req.user?.claims?.sub;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized - User ID not found' });
    }

    const permissionKey = `${resourceType}.${action}`;
    if (!accessControlService.hasPermission(userId, permissionKey)) {
      return res.status(403).json({ 
        error: 'Access denied',
        message: `You don't have permission to ${action} on ${resourceType}` 
      });
    }

    return next();
  };
}