import { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';

// Interface for logging object
export interface LogEntry {
  id: string;
  timestamp: string;
  method: string;
  path: string;
  statusCode: number;
  responseTime: number;
  userId?: string;
  projectId?: string;
  tokenUsage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  error?: string;
}

// In-memory store for logs (would be replaced with database in production)
const logs: LogEntry[] = [];

/**
 * Express middleware to log request and response details
 */
export function requestLogger(req: Request, res: Response, next: NextFunction) {
  // Generate a unique ID for this request
  const requestId = uuidv4();
  
  // Capture the start time
  const startTime = Date.now();
  
  // Store the original end method to intercept it
  const originalEnd = res.end;
  
  // Override the end method to capture the response
  res.end = function(chunk?: any, encoding?: BufferEncoding | undefined, callback?: (() => void) | undefined): Response<any, Record<string, any>> {
    // Calculate response time
    const responseTime = Date.now() - startTime;
    
    // Get user ID if authenticated
    const userId = req.user ? (req.user as any).sub : undefined;
    
    // Get project ID from query params, headers or body
    const projectId = 
      req.query.projectId as string || 
      req.headers['x-project-id'] as string || 
      (req.body && req.body.projectId);
    
    // Create log entry
    const logEntry: LogEntry = {
      id: requestId,
      timestamp: new Date().toISOString(),
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      responseTime,
      userId,
      projectId,
    };
    
    // Add token usage if available (from res.locals set by AI route handlers)
    if (res.locals.tokenUsage) {
      logEntry.tokenUsage = res.locals.tokenUsage;
    }
    
    // Add error if status is 4xx or 5xx
    if (res.statusCode >= 400) {
      logEntry.error = res.statusMessage || 'Unknown error';
    }
    
    // Store the log
    logs.push(logEntry);
    
    // In production, you would save this to a database or logging service
    // For example: await db.insert(aiLogs).values(logEntry);
    
    // Call the original end method
    return originalEnd.call(this, chunk, encoding, callback);
  };
  
  // Continue to the next middleware
  next();
}

/**
 * Get all logs (for admin dashboard)
 */
export function getLogs(): LogEntry[] {
  return [...logs];
}

/**
 * Get logs for a specific user
 */
export function getUserLogs(userId: string): LogEntry[] {
  return logs.filter(log => log.userId === userId);
}

/**
 * Get logs for a specific project
 */
export function getProjectLogs(projectId: string): LogEntry[] {
  return logs.filter(log => log.projectId === projectId);
}

/**
 * Get token usage statistics
 */
export function getTokenUsageStats(): {
  totalPromptTokens: number;
  totalCompletionTokens: number;
  totalTokens: number;
  requestCount: number;
} {
  const stats = logs.reduce((acc, log) => {
    if (log.tokenUsage) {
      acc.totalPromptTokens += log.tokenUsage.promptTokens || 0;
      acc.totalCompletionTokens += log.tokenUsage.completionTokens || 0;
      acc.totalTokens += log.tokenUsage.totalTokens || 0;
      acc.requestCount += 1;
    }
    return acc;
  }, {
    totalPromptTokens: 0,
    totalCompletionTokens: 0,
    totalTokens: 0,
    requestCount: 0,
  });
  
  return stats;
}