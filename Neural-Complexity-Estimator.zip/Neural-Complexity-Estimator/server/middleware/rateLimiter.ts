/**
 * Rate Limiter Middleware
 * 
 * Provides rate limiting functionality for API endpoints to prevent abuse.
 */

import { Request, Response, NextFunction } from 'express';

// Simple in-memory rate limiting implementation
interface RateLimitStore {
  [key: string]: {
    count: number;
    resetTime: number;
  }
}

export interface RateLimitOptions {
  windowMs?: number;       // Milliseconds for the rate limiting window
  maxRequests?: number;    // Maximum number of requests allowed in the window
  message?: string;        // Error message to return when limit is reached
  keyGenerator?: (req: Request) => string; // Function to generate key for rate limiting
}

const defaultOptions: RateLimitOptions = {
  windowMs: 60 * 1000, // 1 minute window
  maxRequests: 10,      // 10 requests per window
  message: 'Too many requests, please try again later.',
  keyGenerator: (req: Request) => {
    // Default to IP-based rate limiting
    return req.ip || req.socket.remoteAddress || 'unknown';
  }
};

// In-memory store for rate limits
// In a production system, this would likely use Redis or similar
const rateLimitStore: RateLimitStore = {};

/**
 * Creates a rate limiter middleware function
 * @param options Rate limiter options
 * @returns Express middleware function
 */
export function createRateLimiter(options: RateLimitOptions = {}) {
  const mergedOptions = { ...defaultOptions, ...options };
  const { windowMs, maxRequests, message, keyGenerator } = mergedOptions;
  
  // Clean up expired rate limits periodically
  setInterval(() => {
    const now = Date.now();
    Object.keys(rateLimitStore).forEach(key => {
      if (rateLimitStore[key].resetTime <= now) {
        delete rateLimitStore[key];
      }
    });
  }, windowMs! / 2); // Clean up halfway through the window
  
  // Return the middleware function
  return (req: Request, res: Response, next: NextFunction) => {
    const key = keyGenerator!(req);
    const now = Date.now();
    
    // Initialize or reset if expired
    if (!rateLimitStore[key] || rateLimitStore[key].resetTime <= now) {
      rateLimitStore[key] = {
        count: 0,
        resetTime: now + windowMs!
      };
    }
    
    // Increment count
    rateLimitStore[key].count++;
    
    // Set rate limit headers
    const currentCount = rateLimitStore[key].count;
    const timeRemaining = Math.max(0, rateLimitStore[key].resetTime - now);
    
    res.setHeader('X-RateLimit-Limit', String(maxRequests));
    res.setHeader('X-RateLimit-Remaining', String(Math.max(0, maxRequests! - currentCount)));
    res.setHeader('X-RateLimit-Reset', String(Math.ceil(timeRemaining / 1000))); // in seconds
    
    // Check if over limit
    if (currentCount > maxRequests!) {
      return res.status(429).json({
        error: 'Rate limit exceeded',
        message,
        retryAfter: Math.ceil(timeRemaining / 1000)
      });
    }
    
    next();
  };
}

// Specialized rate limiters for different services
export const aiRateLimiter = createRateLimiter({
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 20,      // 20 requests per minute
  message: 'Too many AI requests, please try again in a minute.'
});

export const chatRateLimiter = createRateLimiter({
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 10,      // 10 requests per minute
  message: 'Chat rate limit exceeded. Please wait a moment before sending more messages.'
});

export const imageRateLimiter = createRateLimiter({
  windowMs: 5 * 60 * 1000, // 5 minutes
  maxRequests: 15,         // 15 requests per 5 minutes
  message: 'Image generation rate limit exceeded. Please wait a few minutes before trying again.'
});

export default createRateLimiter;