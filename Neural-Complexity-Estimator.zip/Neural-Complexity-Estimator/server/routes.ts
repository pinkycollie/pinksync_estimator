import express, { type Express } from 'express';
import path from 'path';
import session from 'express-session';
import { createServer, type Server } from 'http';
import { WebSocketServer } from 'ws';
import { storage } from './storage';
import { setupAuth, isAuthenticated } from './replitAuth';
import accessControlService from './services/security/accessControl';
import communicationRoutes from './api/communication-routes';
import realEstateRoutes from './api/real-estate-routes';
import insuranceRoutes from './api/insurance-routes';
import syncRoutes from './api/sync-routes';
import anonymousMindRoutes from './api/anonymousMind-routes';
import astraDocumentRoutes from './api/astra-document-routes';
import integrationRoutes from './api/integration-routes';
import googleSheetsRoutes from './api/google-sheets-routes';
import fileWatchRoutes from './api/file-watch-routes';
import accessControlRoutes from './api/access-control-routes';
import aiRouter from './routes/aiRouter';
// import ideaRoutes from './api/idea-routes'; // Temporarily disabled due to schema conflicts
import ideaSyncRoutes from './api/idea-sync-routes';
import trendAnalysisRoutes from './api/trend-analysis-routes';
import notionRoutes from './api/notion-routes';
import notionTestRoutes from './api/notion-test-routes';
import neuralRoutes from './api/neural-routes';
import neuralSecurityRoutes from './api/neural-security-routes';
import healthRoutes from './api/health-routes';
import webhookRoutes from './api/webhook-routes';
import signLanguageAuthRoutes from './routes/signLanguageAuth';
import { requestLogger } from './middleware/logger';

// Import new PinkSync services
import { initializeServices } from './services';
import developmentRoutes from './routes/development';
import complexityRoutes from './routes/complexity';

// Set up WebSocket connections (for real-time communication)
const setupWebSockets = (server: Server) => {
  const wss = new WebSocketServer({ server, path: '/ws' });
  
  wss.on('connection', (ws) => {
    console.log('New client connected');
    
    // Send welcome message
    ws.send(JSON.stringify({
      type: 'welcome',
      message: 'Connected to Pinky\'s AI OS WebSocket server'
    }));
    
    // Handle messages from clients
    ws.on('message', (message) => {
      try {
        const parsedMessage = JSON.parse(message.toString());
        console.log('Received message:', parsedMessage);
        
        // Echo back for now
        if (ws.readyState === 1) { // 1 means OPEN
          ws.send(JSON.stringify({
            type: 'echo',
            data: parsedMessage
          }));
        }
      } catch (error) {
        console.error('Error processing message:', error);
      }
    });
    
    // Handle client disconnect
    ws.on('close', () => {
      console.log('Client disconnected');
    });
  });
  
  return wss;
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up Replit authentication
  await setupAuth(app);
  
  // Initialize PinkSync services
  await initializeServices();
  console.log('PinkSync services initialized');
  
  // Middleware to initialize access control for users
  app.use((req: any, res, next) => {
    if (req.isAuthenticated() && req.user?.claims?.sub) {
      const userId = req.user.claims.sub;
      
      // Ensure user exists in access control system
      if (!accessControlService.getUserAccessControl(userId)) {
        // Set up initial user access control
        accessControlService.setUserAccessControl({
          userId,
          roles: ['user'], // Basic user role
          permissions: {}
        });
        
        console.log(`Initialized access control for user: ${userId}`);
      }
    }
    next();
  });
  
  // Body parser middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  
  // Request logger for analytics
  app.use(requestLogger);
  
  // Static files
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));
  
  // API routes
  app.use('/api/communications', communicationRoutes);
  app.use('/api/real-estate', realEstateRoutes);
  app.use('/api/insurance', insuranceRoutes);
  app.use('/api/sync', syncRoutes);
  app.use(anonymousMindRoutes);
  app.use(astraDocumentRoutes);
  app.use(integrationRoutes);
  app.use(googleSheetsRoutes);
  app.use('/api/file-watch', fileWatchRoutes);
  app.use('/api/access', accessControlRoutes);
  app.use('/api/ai', aiRouter);
  // app.use('/api/ideas', ideaRoutes); // Temporarily disabled
  app.use('/api/idea-sync', ideaSyncRoutes);
  app.use('/api/trends', trendAnalysisRoutes);
  app.use('/api/notion', notionRoutes);
  app.use('/api/notion-test', notionTestRoutes);
  app.use('/api/neural', neuralRoutes);
  app.use('/api', neuralSecurityRoutes);
  app.use('/api', healthRoutes);
  app.use('/api', webhookRoutes);
  
  // Sign Language Authentication routes (temporarily disabled)
  // app.use('/api/v1', signLanguageAuthRoutes);
  
  // Development pipeline routes
  app.use('/api/development', developmentRoutes);
  
  // AI-powered complexity estimator routes
  app.use('/api/complexity', complexityRoutes);
  
  // Check if secrets are set
  app.get('/api/check-secrets', (_req, res) => {
    const secretsStatus = {
      signyapse: process.env.SIGNYAPSE_API_KEY !== undefined,
      openai: process.env.OPENAI_API_KEY !== undefined,
      huggingface: process.env.HUGGINGFACE_API_KEY !== undefined,
      astraDb: process.env.ASTRA_DB_TOKEN !== undefined,
      notion: process.env.NOTION_API_KEY !== undefined,
      xano: process.env.XANO_API_KEY !== undefined,
      xanoMeta: process.env.XANO_META_API_KEY !== undefined,
      civic: process.env.CIVIC_APP_ID !== undefined,
      github: process.env.GITHUB_ACCESS_TOKEN !== undefined,
      vercel: process.env.VERCEL_API_TOKEN !== undefined
    };
    
    res.json(secretsStatus);
  });
  
  // Auth user endpoint with access control information
  app.get('/api/auth/user', (req: any, res) => {
    const user = req.session?.passport?.user || null;
    
    // If user is authenticated, enrich with access control information
    if (user && req.isAuthenticated() && user.claims?.sub) {
      const userId = user.claims.sub;
      
      // Get user's access control information
      const userAc = accessControlService.getUserAccessControl(userId);
      
      // Get user roles
      const roles = userAc?.roles || [];
      const roleDetails = roles.map(roleId => {
        const roleDefinition = accessControlService.getRole(roleId);
        return {
          id: roleId,
          description: roleDefinition?.description || 'Unknown role'
        };
      });
      
      // Get user permissions
      const userPermissions = accessControlService.getUserPermissions(userId);
      
      // Extract common permissions
      const permissions = {
        fileWatcher: !!userPermissions['fileWatcher'],
        fileAutomation: !!userPermissions['fileAutomation'],
        accessControl: !!userPermissions['accessControl']
      };
      
      // Return enriched user object
      return res.json({
        ...user,
        accessControl: {
          roles: roleDetails,
          permissions
        }
      });
    }
    
    // Return basic user info if not authenticated
    res.json(user);
  });
  
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Set up WebSockets
  setupWebSockets(httpServer);
  
  return httpServer;
}