import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';
import { v4 as uuidv4 } from 'uuid';
import { anonymousMindService } from '../anonymousMind/anonymousMindService';

/**
 * Service for extracting and processing chat history from various AI platforms
 * This is a TypeScript wrapper around the Python script for chat history extraction
 */
export class ChatHistoryExtractorService {
  private readonly scriptPath: string;
  private readonly outputDir: string;
  
  constructor() {
    // Set path to Python script and output directory
    this.scriptPath = path.join(process.cwd(), 'scripts', 'chat_history_extractor.py');
    this.outputDir = path.join(process.cwd(), 'uploads', 'chat_exports');
    
    // Create output directory if it doesn't exist
    if (!fs.existsSync(this.outputDir)) {
      fs.mkdirSync(this.outputDir, { recursive: true });
    }
    
    // Create scripts directory if it doesn't exist
    const scriptsDir = path.join(process.cwd(), 'scripts');
    if (!fs.existsSync(scriptsDir)) {
      fs.mkdirSync(scriptsDir, { recursive: true });
    }
  }
  
  /**
   * Extract chat history from various platforms
   */
  async extractChatHistory(
    userId: string,
    platformType: 'claude' | 'chatgpt' | 'generic',
    filePath: string,
    options: {
      fileFormat?: 'json' | 'csv' | 'txt';
      saveToAnonymousMind?: boolean;
      contentType?: string;
      tags?: string[];
    } = {}
  ): Promise<string> {
    return new Promise((resolve, reject) => {
      const outputFileName = `${platformType}_export_${Date.now()}.json`;
      const outputPath = path.join(this.outputDir, outputFileName);
      
      // Build command arguments
      const args = [
        this.scriptPath,
        `--${platformType}`, filePath,
        '--output', this.outputDir
      ];
      
      // Add file format if specified
      if (options.fileFormat && platformType === 'generic') {
        args.push('--format', options.fileFormat);
      }
      
      // Execute Python script
      const pythonProcess = spawn('python', args);
      
      let output = '';
      let errorOutput = '';
      
      pythonProcess.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      pythonProcess.stderr.on('data', (data) => {
        errorOutput += data.toString();
      });
      
      pythonProcess.on('close', async (code) => {
        if (code !== 0) {
          reject(new Error(`Chat history extraction failed: ${errorOutput}`));
          return;
        }
        
        try {
          // If saveToAnonymousMind is true, save to Anonymous Mind
          if (options.saveToAnonymousMind) {
            // Read the exported JSON file
            const jsonContent = fs.readFileSync(outputPath, 'utf8');
            const chatData = JSON.parse(jsonContent);
            
            // Process chat data and save to Anonymous Mind
            await this.saveChatToAnonymousMind(
              userId, 
              chatData, 
              platformType,
              options.contentType || 'chat_history',
              options.tags || ['chat', platformType]
            );
          }
          
          resolve(outputPath);
        } catch (error) {
          reject(error);
        }
      });
    });
  }
  
  /**
   * Save extracted chat to Anonymous Mind
   */
  private async saveChatToAnonymousMind(
    userId: string,
    chatData: any[],
    source: string,
    contentType: string,
    tags: string[]
  ): Promise<void> {
    // Group messages by conversation
    const conversations = this.groupByConversation(chatData);
    
    // Save each conversation as a separate content item
    for (const [conversationId, messages] of Object.entries(conversations)) {
      try {
        // Create content in Anonymous Mind
        await anonymousMindService.createContent({
          userId,
          contentType,
          tags: [...tags, 'conversation', 'extracted'],
          content: JSON.stringify(messages),
          source,
          metadata: {
            conversationId,
            messageCount: messages.length,
            extractedAt: new Date().toISOString(),
            platform: source
          },
          isPrivate: true
        });
      } catch (error) {
        console.error(`Failed to save conversation ${conversationId}:`, error);
      }
    }
  }
  
  /**
   * Group chat messages by conversation
   */
  private groupByConversation(messages: any[]): Record<string, any[]> {
    const conversations: Record<string, any[]> = {};
    
    for (const message of messages) {
      const conversationId = message.conversation_id || 'unknown';
      
      if (!conversations[conversationId]) {
        conversations[conversationId] = [];
      }
      
      conversations[conversationId].push(message);
    }
    
    return conversations;
  }
  
  /**
   * Extract key topics from chat data
   */
  async extractKeyTopics(chatData: any[]): Promise<Record<string, number>> {
    // Simple keyword extraction for demonstration
    // In a real implementation, this would use NLP or the Python script's functionality
    const keywords = [
      'deaf', 'accessibility', 'api', 'infrastructure', 'platform',
      'tax', 'insurance', 'real estate', 'business', 'modular',
      'integration', 'processor', 'digital space'
    ];
    
    const topics: Record<string, number> = {};
    
    for (const message of chatData) {
      const content = message.content?.toLowerCase() || '';
      
      for (const keyword of keywords) {
        if (content.includes(keyword.toLowerCase())) {
          topics[keyword] = (topics[keyword] || 0) + 1;
        }
      }
    }
    
    // Sort topics by frequency
    return Object.fromEntries(
      Object.entries(topics).sort(([, countA], [, countB]) => countB - countA)
    );
  }
  
  /**
   * Extract potential requirements from chat data
   */
  async extractRequirements(chatData: any[]): Promise<string[]> {
    // Simple requirement extraction for demonstration
    // In a real implementation, this would use NLP or the Python script's functionality
    const requirements: string[] = [];
    const patterns = [
      /(?:need|must|should|could|would require) to (\w+\s.+?)(?:\.|\n|$)/i,
      /(?:necessary|important) to (\w+\s.+?)(?:\.|\n|$)/i,
      /requirement(?:s)? (?:is|are|include|for) (\w+\s.+?)(?:\.|\n|$)/i
    ];
    
    for (const message of chatData) {
      const content = message.content || '';
      
      for (const pattern of patterns) {
        const matches = content.match(pattern);
        if (matches && matches[1]) {
          requirements.push(matches[1].trim());
        }
      }
    }
    
    // Remove duplicates
    return [...new Set(requirements)];
  }
}

// Export a singleton instance
export const chatHistoryExtractorService = new ChatHistoryExtractorService();