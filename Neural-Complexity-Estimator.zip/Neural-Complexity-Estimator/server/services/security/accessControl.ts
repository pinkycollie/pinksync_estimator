/**
 * Access Control Service
 * Provides functionality for managing and enforcing access control in the application.
 */

// Type definitions
export interface Permission {
  key: string;
  name: string;
  description: string;
  resourceType?: string;
  action?: string;
}

export interface Role {
  id: string;
  name: string;
  description: string;
  permissions: string[]; // Permission keys
}

export interface UserAccessControl {
  userId: string;
  roles: string[]; // Role IDs
  permissions: Record<string, boolean>; // Direct permission assignments
}

// Available permissions in the system
const availablePermissions: Permission[] = [
  {
    key: 'fileWatcher',
    name: 'File Watcher',
    description: 'Access file watching functionality',
    resourceType: 'file',
    action: 'watch'
  },
  {
    key: 'fileAutomation',
    name: 'File Automation',
    description: 'Create and manage file automation rules',
    resourceType: 'file',
    action: 'automate'
  },
  {
    key: 'accessControl',
    name: 'Access Control Management',
    description: 'Manage access roles and permissions',
    resourceType: 'security',
    action: 'manage'
  },
  {
    key: 'platformSync',
    name: 'Platform Synchronization',
    description: 'Configure platform synchronization',
    resourceType: 'platform',
    action: 'sync'
  },
  {
    key: 'useAI',
    name: 'AI Hub Access',
    description: 'Access and use AI features',
    resourceType: 'ai',
    action: 'use'
  },
  {
    key: 'aiAdmin',
    name: 'AI Administration',
    description: 'Configure AI models and manage prompts',
    resourceType: 'ai',
    action: 'admin'
  },
  {
    key: 'aiAnalytics',
    name: 'AI Analytics',
    description: 'View AI usage analytics and metrics',
    resourceType: 'ai',
    action: 'analyze'
  }
];

// Predefined roles
const predefinedRoles: Role[] = [
  {
    id: 'admin',
    name: 'Administrator',
    description: 'Full system access',
    permissions: availablePermissions.map(p => p.key)
  },
  {
    id: 'file_manager',
    name: 'File Manager',
    description: 'Manage and automate files',
    permissions: ['fileWatcher', 'fileAutomation']
  },
  {
    id: 'security_admin',
    name: 'Security Administrator',
    description: 'Manage security and access control',
    permissions: ['accessControl']
  },
  {
    id: 'ai_user',
    name: 'AI User',
    description: 'Can use AI features',
    permissions: ['useAI']
  },
  {
    id: 'ai_admin',
    name: 'AI Administrator',
    description: 'Can manage AI features and view analytics',
    permissions: ['useAI', 'aiAdmin', 'aiAnalytics']
  },
  {
    id: 'user',
    name: 'Standard User',
    description: 'Basic user access',
    permissions: []
  }
];

/**
 * Class to manage access control for the application
 */
export class AccessControlService {
  // In-memory storage for permissions and roles
  // In a production system, this would be stored in a database
  private permissions: Permission[] = [...availablePermissions];
  private roles: Role[] = [...predefinedRoles];
  private userAccessControl: Map<string, UserAccessControl> = new Map();

  constructor() {
    console.log('AccessControlService initialized');
  }

  /**
   * Get all available permissions
   */
  getPermissions(): Permission[] {
    return this.permissions;
  }

  /**
   * Get permission by key
   */
  getPermission(key: string): Permission | undefined {
    return this.permissions.find(p => p.key === key);
  }

  /**
   * Add a new permission
   */
  addPermission(permission: Permission): Permission {
    if (this.permissions.some(p => p.key === permission.key)) {
      throw new Error(`Permission with key ${permission.key} already exists`);
    }
    this.permissions.push(permission);
    return permission;
  }

  /**
   * Update an existing permission
   */
  updatePermission(key: string, updates: Partial<Permission>): Permission {
    const index = this.permissions.findIndex(p => p.key === key);
    if (index === -1) {
      throw new Error(`Permission with key ${key} not found`);
    }
    this.permissions[index] = { ...this.permissions[index], ...updates };
    return this.permissions[index];
  }

  /**
   * Delete a permission
   */
  deletePermission(key: string): void {
    const index = this.permissions.findIndex(p => p.key === key);
    if (index === -1) {
      throw new Error(`Permission with key ${key} not found`);
    }
    this.permissions.splice(index, 1);
    
    // Also remove this permission from all roles
    this.roles.forEach(role => {
      const permIndex = role.permissions.indexOf(key);
      if (permIndex !== -1) {
        role.permissions.splice(permIndex, 1);
      }
    });
  }

  /**
   * Get all roles
   */
  getRoles(): Role[] {
    return this.roles;
  }

  /**
   * Get role by ID
   */
  getRole(id: string): Role | undefined {
    return this.roles.find(r => r.id === id);
  }

  /**
   * Add a new role
   */
  addRole(role: Role): Role {
    if (this.roles.some(r => r.id === role.id)) {
      throw new Error(`Role with ID ${role.id} already exists`);
    }
    
    // Validate that all permissions exist
    role.permissions.forEach(permKey => {
      if (!this.permissions.some(p => p.key === permKey)) {
        throw new Error(`Permission with key ${permKey} not found`);
      }
    });
    
    this.roles.push(role);
    return role;
  }

  /**
   * Update an existing role
   */
  updateRole(id: string, updates: Partial<Role>): Role {
    const index = this.roles.findIndex(r => r.id === id);
    if (index === -1) {
      throw new Error(`Role with ID ${id} not found`);
    }
    
    // If updating permissions, validate they exist
    if (updates.permissions) {
      updates.permissions.forEach(permKey => {
        if (!this.permissions.some(p => p.key === permKey)) {
          throw new Error(`Permission with key ${permKey} not found`);
        }
      });
    }
    
    this.roles[index] = { ...this.roles[index], ...updates };
    return this.roles[index];
  }

  /**
   * Delete a role
   */
  deleteRole(id: string): void {
    const index = this.roles.findIndex(r => r.id === id);
    if (index === -1) {
      throw new Error(`Role with ID ${id} not found`);
    }
    this.roles.splice(index, 1);
    
    // Remove this role from all users
    this.userAccessControl.forEach((userAc, userId) => {
      const roleIndex = userAc.roles.indexOf(id);
      if (roleIndex !== -1) {
        userAc.roles.splice(roleIndex, 1);
        this.userAccessControl.set(userId, userAc);
      }
    });
  }

  /**
   * Get user access control
   */
  getUserAccessControl(userId: string): UserAccessControl | undefined {
    return this.userAccessControl.get(userId);
  }

  /**
   * Set user access control
   */
  setUserAccessControl(userAc: UserAccessControl): UserAccessControl {
    // Validate roles exist
    userAc.roles.forEach(roleId => {
      if (!this.roles.some(r => r.id === roleId)) {
        throw new Error(`Role with ID ${roleId} not found`);
      }
    });
    
    // Validate permissions exist
    Object.keys(userAc.permissions).forEach(permKey => {
      if (!this.permissions.some(p => p.key === permKey)) {
        throw new Error(`Permission with key ${permKey} not found`);
      }
    });
    
    this.userAccessControl.set(userAc.userId, userAc);
    return userAc;
  }

  /**
   * Add role to user
   */
  addUserRole(userId: string, roleId: string): UserAccessControl {
    // Check if role exists
    if (!this.roles.some(r => r.id === roleId)) {
      throw new Error(`Role with ID ${roleId} not found`);
    }
    
    let userAc = this.userAccessControl.get(userId);
    if (!userAc) {
      userAc = {
        userId,
        roles: [],
        permissions: {}
      };
    }
    
    if (!userAc.roles.includes(roleId)) {
      userAc.roles.push(roleId);
    }
    
    this.userAccessControl.set(userId, userAc);
    return userAc;
  }

  /**
   * Remove role from user
   */
  removeUserRole(userId: string, roleId: string): UserAccessControl | undefined {
    const userAc = this.userAccessControl.get(userId);
    if (!userAc) {
      return undefined;
    }
    
    const roleIndex = userAc.roles.indexOf(roleId);
    if (roleIndex !== -1) {
      userAc.roles.splice(roleIndex, 1);
      this.userAccessControl.set(userId, userAc);
    }
    
    return userAc;
  }

  /**
   * Set direct permission for user
   */
  setUserPermission(userId: string, permissionKey: string, value: boolean): UserAccessControl {
    // Check if permission exists
    if (!this.permissions.some(p => p.key === permissionKey)) {
      throw new Error(`Permission with key ${permissionKey} not found`);
    }
    
    let userAc = this.userAccessControl.get(userId);
    if (!userAc) {
      userAc = {
        userId,
        roles: [],
        permissions: {}
      };
    }
    
    userAc.permissions[permissionKey] = value;
    this.userAccessControl.set(userId, userAc);
    return userAc;
  }

  /**
   * Check if user has a specific permission (from roles or direct permissions)
   */
  hasPermission(userId: string, permissionKey: string): boolean {
    const userAc = this.userAccessControl.get(userId);
    if (!userAc) {
      return false;
    }
    
    // Check direct permissions first
    if (userAc.permissions[permissionKey] === true) {
      return true;
    }
    
    // Check permissions from roles
    return userAc.roles.some(roleId => {
      const role = this.roles.find(r => r.id === roleId);
      return role?.permissions.includes(permissionKey) || false;
    });
  }

  /**
   * Get all permissions that a user has (from roles and direct permissions)
   */
  getUserPermissions(userId: string): Record<string, boolean> {
    const userAc = this.userAccessControl.get(userId);
    if (!userAc) {
      return {};
    }
    
    // Start with direct permissions
    const permissions = { ...userAc.permissions };
    
    // Add permissions from roles
    userAc.roles.forEach(roleId => {
      const role = this.roles.find(r => r.id === roleId);
      if (role) {
        role.permissions.forEach(permKey => {
          permissions[permKey] = true;
        });
      }
    });
    
    return permissions;
  }
}

// Singleton instance
const accessControlService = new AccessControlService();
export default accessControlService;