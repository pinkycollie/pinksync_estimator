import { astraService } from "../astra/astraService";
import { v4 as uuidv4 } from "uuid";

// Define types for content
export interface AnonymousMindContent {
  id: string;
  userId: string;
  contentType: string;
  tags: string[];
  content: string;
  source?: string;
  metadata?: Record<string, any>;
  isPrivate: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateContentOptions {
  userId: string;
  contentType: string;
  tags: string[];
  content: string;
  source?: string;
  metadata?: Record<string, any>;
  isPrivate?: boolean;
}

export interface UpdateContentOptions {
  contentType?: string;
  tags?: string[];
  content?: string;
  source?: string;
  metadata?: Record<string, any>;
  isPrivate?: boolean;
}

export interface SearchContentOptions {
  query?: string;
  tags?: string[];
  contentType?: string;
  isPrivate?: boolean;
  limit?: number;
}

/**
 * Service for managing Anonymous Mind content
 */
export class AnonymousMindService {
  private readonly namespace = "anonymind";
  private readonly contentCollection = "content";

  /**
   * Create new content
   */
  async createContent(options: CreateContentOptions): Promise<AnonymousMindContent> {
    try {
      const now = new Date().toISOString();
      const contentId = uuidv4();
      
      const content: AnonymousMindContent = {
        id: contentId,
        userId: options.userId,
        contentType: options.contentType,
        tags: options.tags,
        content: options.content,
        source: options.source,
        metadata: options.metadata,
        isPrivate: options.isPrivate !== undefined ? options.isPrivate : true,
        createdAt: now,
        updatedAt: now
      };
      
      // Save to Astra DB
      await astraService.createDocument(
        this.namespace,
        this.contentCollection,
        contentId,
        content
      );
      
      return content;
    } catch (error) {
      console.error("Error creating content:", error);
      throw error;
    }
  }

  /**
   * Get content by ID
   */
  async getContentById(contentId: string): Promise<AnonymousMindContent | null> {
    try {
      const content = await astraService.getDocument(
        this.namespace,
        this.contentCollection,
        contentId
      );
      
      return content ? content as AnonymousMindContent : null;
    } catch (error) {
      console.error("Error getting content by ID:", error);
      throw error;
    }
  }

  /**
   * Get content by user ID
   */
  async getContentByUserId(
    userId: string,
    options: {
      contentType?: string;
      tags?: string[];
      isPrivate?: boolean;
      limit?: number;
    } = {}
  ): Promise<AnonymousMindContent[]> {
    try {
      // Build query filter
      const filter: Record<string, any> = { userId };
      
      if (options.contentType) {
        filter.contentType = options.contentType;
      }
      
      if (options.isPrivate !== undefined) {
        filter.isPrivate = options.isPrivate;
      }
      
      // Get results from Astra DB
      const results = await astraService.findDocuments(
        this.namespace,
        this.contentCollection,
        filter,
        { limit: options.limit || 100 }
      );
      
      // Convert results to array and filter by tags if needed
      let contents = Object.values(results || {}) as AnonymousMindContent[];
      
      if (options.tags && options.tags.length > 0) {
        contents = contents.filter(content => {
          return options.tags!.some(tag => content.tags.includes(tag));
        });
      }
      
      return contents;
    } catch (error) {
      console.error("Error getting content by user ID:", error);
      throw error;
    }
  }

  /**
   * Update content
   */
  async updateContent(
    contentId: string,
    options: UpdateContentOptions
  ): Promise<AnonymousMindContent | null> {
    try {
      // Get current content
      const content = await this.getContentById(contentId);
      if (!content) {
        return null;
      }
      
      // Prepare updates
      const updates: Partial<AnonymousMindContent> = {
        ...options,
        updatedAt: new Date().toISOString()
      };
      
      // Update in Astra DB
      await astraService.updateDocument(
        this.namespace,
        this.contentCollection,
        contentId,
        updates
      );
      
      // Return updated content
      return {
        ...content,
        ...updates
      } as AnonymousMindContent;
    } catch (error) {
      console.error("Error updating content:", error);
      throw error;
    }
  }

  /**
   * Delete content
   */
  async deleteContent(contentId: string): Promise<boolean> {
    try {
      await astraService.deleteDocument(
        this.namespace,
        this.contentCollection,
        contentId
      );
      
      return true;
    } catch (error) {
      console.error("Error deleting content:", error);
      throw error;
    }
  }

  /**
   * Search content
   */
  async searchContent(
    userId: string,
    options: SearchContentOptions = {}
  ): Promise<AnonymousMindContent[]> {
    try {
      // Get all user content first (we'll filter client-side)
      const contents = await this.getContentByUserId(userId, {
        contentType: options.contentType,
        isPrivate: options.isPrivate,
        limit: options.limit
      });
      
      // Filter by tags if needed
      let filteredContents = contents;
      if (options.tags && options.tags.length > 0) {
        filteredContents = filteredContents.filter(content => {
          return options.tags!.some(tag => content.tags.includes(tag));
        });
      }
      
      // Filter by search query if provided
      if (options.query) {
        const query = options.query.toLowerCase();
        filteredContents = filteredContents.filter(content => {
          return (
            content.content.toLowerCase().includes(query) ||
            content.contentType.toLowerCase().includes(query) ||
            (content.source && content.source.toLowerCase().includes(query)) ||
            content.tags.some(tag => tag.toLowerCase().includes(query))
          );
        });
      }
      
      return filteredContents;
    } catch (error) {
      console.error("Error searching content:", error);
      throw error;
    }
  }
}

// Export a singleton instance
export const anonymousMindService = new AnonymousMindService();