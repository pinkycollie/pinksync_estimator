/**
 * PinkSync - Idea Analysis Service
 * 
 * This service provides comprehensive analysis of ideas, including:
 * - AI-powered insights
 * - Cost and feasibility assessment
 * - Implementation recommendations
 * - Approval workflow management
 */

import * as fs from 'fs';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { storage } from '../../storage';
import openaiService from '../../services/openai';
import { platformSyncManager } from '../../utils/platformSyncManager';

// Types for analysis results
export interface IdeaAnalysisResult {
  id: string;
  ideaId: number;
  userId: string;
  technicalFeasibility: number; // 1-10 scale
  businessValue: number; // 1-10 scale
  implementationCost: {
    estimatedHours: number;
    hourlyRate?: number;
    totalCost?: number;
    currency?: string;
    components: {
      name: string;
      hours: number;
      cost?: number;
    }[];
  };
  risksAndChallenges: {
    description: string;
    severity: 'low' | 'medium' | 'high';
    mitigationStrategy?: string;
  }[];
  recommendedApproach: string;
  suggestedTechnologies: string[];
  approvalStatus: 'pending' | 'approved' | 'rejected' | 'needs_revision';
  approvalFeedback?: string;
  approvedBy?: string;
  approvedAt?: Date;
  sentToPipeline: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Analysis request options
export interface AnalysisOptions {
  includeCostEstimate: boolean;
  includeRisks: boolean;
  includeTechnologyRecommendations: boolean;
  detailLevel: 'basic' | 'detailed' | 'comprehensive';
  userContext?: string; // Additional context like industry, company size, etc.
}

class IdeaAnalysisService {
  private readonly analysisDir: string;
  
  constructor() {
    this.analysisDir = path.join(process.cwd(), 'data', 'idea_analysis');
    this.ensureDirectoryExists(this.analysisDir);
  }
  
  /**
   * Analyze an idea and generate comprehensive insights
   */
  async analyzeIdea(ideaId: number, options: AnalysisOptions): Promise<IdeaAnalysisResult> {
    try {
      // Get the idea details
      const idea = await storage.getIdeaById(ideaId);
      
      if (!idea) {
        throw new Error(`Idea with ID ${ideaId} not found`);
      }
      
      // Generate analysis using AI
      const analysisResult = await this.generateAnalysis(idea, options);
      
      // Save analysis to database
      const savedAnalysis = await storage.createIdeaAnalysis(analysisResult);
      
      // Also save a JSON copy in the file system for backup
      const filePath = path.join(this.analysisDir, `analysis_${ideaId}_${uuidv4()}.json`);
      fs.writeFileSync(filePath, JSON.stringify(analysisResult, null, 2));
      
      return savedAnalysis;
    } catch (error: any) {
      console.error('Error analyzing idea:', error);
      throw new Error(`Failed to analyze idea: ${error.message || 'Unknown error'}`);
    }
  }
  
  /**
   * Generate AI-powered analysis for an idea
   */
  private async generateAnalysis(idea: any, options: AnalysisOptions): Promise<IdeaAnalysisResult> {
    // Build the analysis prompt
    const detailPrompt = options.detailLevel === 'comprehensive' ? 
      'Provide extremely detailed analysis with specific implementation steps and considerations.' :
      options.detailLevel === 'detailed' ? 
      'Provide detailed analysis with specific recommendations.' :
      'Provide a basic overview analysis.';
    
    const costPrompt = options.includeCostEstimate ?
      'Include a detailed cost breakdown with estimated hours for each component, suggesting a total cost range.' :
      'Do not include cost estimates.';
    
    const risksPrompt = options.includeRisks ?
      'Identify specific risks and challenges, categorizing them as low/medium/high severity, with mitigation strategies.' :
      'Do not include risks assessment.';
    
    const techPrompt = options.includeTechnologyRecommendations ?
      'Recommend specific technologies, frameworks, and tools that would be best suited for implementation.' :
      'Do not provide technology recommendations.';
    
    const contextPrompt = options.userContext ?
      `Consider the following context: ${options.userContext}` :
      '';
    
    const messages = [
      {
        role: 'system' as const,
        content: `You are an expert technology and business analyst specializing in software development feasibility analysis. 
        You will analyze ideas and provide structured feasibility assessments.
        ${detailPrompt}
        ${costPrompt}
        ${risksPrompt}
        ${techPrompt}
        ${contextPrompt}
        
        Format your response as a JSON object with these fields:
        - technicalFeasibility: number from 1-10
        - businessValue: number from 1-10
        - implementationCost: object with estimatedHours, and components array
        - risksAndChallenges: array of objects with description, severity, and mitigationStrategy
        - recommendedApproach: string with implementation approach
        - suggestedTechnologies: array of technology strings`
      },
      {
        role: 'user' as const,
        content: `Please analyze this idea:
        Title: ${idea.title}
        Description: ${idea.description}
        Category: ${idea.category || 'Uncategorized'}
        
        Additional context:
        Status: ${idea.status || 'Unknown'}
        Tags: ${idea.tags || 'None'}
        Priority: ${idea.priority || 'Unspecified'}`
      }
    ];
    
    // Generate analysis using OpenAI
    const completion = await openaiService.chat.generateJsonResponse(
      messages,
      `{
        "technicalFeasibility": "number",
        "businessValue": "number",
        "implementationCost": {
          "estimatedHours": "number",
          "components": [
            {
              "name": "string",
              "hours": "number"
            }
          ]
        },
        "risksAndChallenges": [
          {
            "description": "string",
            "severity": "string",
            "mitigationStrategy": "string"
          }
        ],
        "recommendedApproach": "string",
        "suggestedTechnologies": ["string"]
      }`,
      { model: 'gpt-4o' }
    );
    
    // Format the analysis result
    const analysis = completion as any;
    
    // Calculate cost if hourly rate is provided
    if (options.includeCostEstimate && analysis.implementationCost) {
      // Default hourly rate of $100 if not specified
      const hourlyRate = 100;
      const currency = 'USD';
      
      analysis.implementationCost.hourlyRate = hourlyRate;
      analysis.implementationCost.currency = currency;
      analysis.implementationCost.totalCost = analysis.implementationCost.estimatedHours * hourlyRate;
      
      // Calculate component costs
      if (analysis.implementationCost.components) {
        analysis.implementationCost.components.forEach((component: any) => {
          component.cost = component.hours * hourlyRate;
        });
      }
    }
    
    // Build the full analysis result
    const analysisResult: IdeaAnalysisResult = {
      id: uuidv4(),
      ideaId: idea.id,
      userId: idea.userId,
      technicalFeasibility: analysis.technicalFeasibility,
      businessValue: analysis.businessValue,
      implementationCost: analysis.implementationCost,
      risksAndChallenges: analysis.risksAndChallenges,
      recommendedApproach: analysis.recommendedApproach,
      suggestedTechnologies: analysis.suggestedTechnologies,
      approvalStatus: 'pending',
      sentToPipeline: false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    return analysisResult;
  }
  
  /**
   * Get analysis for an idea
   */
  async getAnalysis(ideaId: number): Promise<IdeaAnalysisResult | null> {
    return storage.getIdeaAnalysisByIdeaId(ideaId);
  }
  
  /**
   * Update approval status for an idea analysis
   */
  async updateApprovalStatus(
    analysisId: string, 
    status: 'approved' | 'rejected' | 'needs_revision',
    feedback?: string,
    approverUserId?: string
  ): Promise<IdeaAnalysisResult> {
    const updates: any = {
      approvalStatus: status,
      approvalFeedback: feedback,
      updatedAt: new Date()
    };
    
    if (status === 'approved' && approverUserId) {
      updates.approvedBy = approverUserId;
      updates.approvedAt = new Date();
    }
    
    const updatedAnalysis = await storage.updateIdeaAnalysis(analysisId, updates);
    
    // If approved, check if it should be sent to the pipeline
    if (status === 'approved' && !updatedAnalysis.sentToPipeline) {
      await this.sendToPipeline(updatedAnalysis.ideaId, updatedAnalysis.id);
    }
    
    return updatedAnalysis;
  }
  
  /**
   * Send an approved idea to the development pipeline
   */
  async sendToPipeline(ideaId: number, analysisId: string): Promise<boolean> {
    try {
      // Get the idea and its analysis
      const idea = await storage.getIdeaById(ideaId);
      const analysis = await storage.getIdeaAnalysisById(analysisId);
      
      if (!idea || !analysis) {
        throw new Error('Idea or analysis not found');
      }
      
      if (analysis.approvalStatus !== 'approved') {
        throw new Error('Cannot send unapproved idea to pipeline');
      }
      
      // Create a checkpoint for this idea
      const checkpoint = await storage.createCheckpoint({
        name: `Idea: ${idea.title}`,
        description: idea.description,
        category: 'development',
        status: 'pending',
        platformType: null,
        platformId: null,
        projectId: idea.projectId || 1, // Default to project 1 if not specified
        userId: idea.userId,
        metadata: {
          ideaId: idea.id,
          analysisId: analysis.id,
          technicalFeasibility: analysis.technicalFeasibility,
          businessValue: analysis.businessValue,
          approvedBy: analysis.approvedBy,
          approvedAt: analysis.approvedAt
        }
      });
      
      // Create default development status
      await storage.createDevelopmentStatus({
        checkpointId: checkpoint.id,
        environmentSetup: 'pending',
        versionControl: 'pending',
        ciCdPipeline: 'pending',
        codeReview: 'pending',
        dependencyUpdates: 'pending',
        securityScanning: 'pending',
        metadata: {
          implementationCost: analysis.implementationCost,
          recommendedApproach: analysis.recommendedApproach,
          suggestedTechnologies: analysis.suggestedTechnologies
        }
      });
      
      // Mark the analysis as sent to pipeline
      await storage.updateIdeaAnalysis(analysisId, {
        sentToPipeline: true,
        updatedAt: new Date()
      });
      
      // Update the idea status
      await storage.updateIdea(ideaId, {
        status: 'in_development',
        updatedAt: new Date()
      });
      
      return true;
    } catch (error: any) {
      console.error('Error sending idea to pipeline:', error);
      return false;
    }
  }
  
  /**
   * Ensure a directory exists
   */
  private ensureDirectoryExists(dir: string): void {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
}

// Create and export service instance
export const ideaAnalysisService = new IdeaAnalysisService();
export default ideaAnalysisService;