/**
 * PinkSync Webhook Manager
 * 
 * Manages webhook registrations, validations, and processing.
 */

import crypto from 'crypto';
import { logger } from '../../utils/logger';
import { neuralProcessor } from '../neural/neuralProcessor';
import { NeuralSignal } from '../../../shared/types/neural';

// Webhook configuration types
export interface WebhookConfig {
  id: string;
  name: string;
  url: string;
  secret: string;
  owner: string;
  enabled: boolean;
  createdAt: Date;
  lastUsedAt?: Date;
  signalMapping?: SignalMapping;
}

export interface SignalMapping {
  userId?: string;
  modality?: string;
  contextMapping?: Record<string, string>;
}

export interface WebhookPayload {
  event: string;
  timestamp: string;
  data: Record<string, any>;
}

export interface WebhookVerificationResult {
  valid: boolean;
  webhookId?: string;
  error?: string;
}

/**
 * Webhook Manager Service
 */
class WebhookManager {
  private webhooks: Map<string, WebhookConfig> = new Map();
  
  constructor() {
    logger.info('Initializing Webhook Manager');
  }
  
  /**
   * Create a new webhook
   */
  createWebhook(name: string, owner: string, signalMapping?: SignalMapping): WebhookConfig {
    const id = crypto.randomUUID();
    const secret = this.generateWebhookSecret();
    
    // Generate a unique URL path for this webhook
    const url = `/api/webhooks/${id}`;
    
    const webhook: WebhookConfig = {
      id,
      name,
      url,
      secret,
      owner,
      enabled: true,
      createdAt: new Date(),
      signalMapping
    };
    
    this.webhooks.set(id, webhook);
    logger.info(`Created webhook: ${name} (${id})`);
    
    return webhook;
  }
  
  /**
   * Generate a secure webhook secret
   */
  private generateWebhookSecret(): string {
    return crypto.randomBytes(32).toString('hex');
  }
  
  /**
   * Verify webhook signature
   */
  verifyWebhookSignature(webhookId: string, payload: string, signature: string): WebhookVerificationResult {
    const webhook = this.webhooks.get(webhookId);
    
    if (!webhook) {
      return { valid: false, error: 'Webhook not found' };
    }
    
    if (!webhook.enabled) {
      return { valid: false, error: 'Webhook is disabled' };
    }
    
    // Compute expected signature
    const hmac = crypto.createHmac('sha256', webhook.secret);
    hmac.update(payload);
    const computedSignature = hmac.digest('hex');
    
    // Verify signature
    if (computedSignature !== signature) {
      return { valid: false, error: 'Invalid signature' };
    }
    
    // Update last used timestamp
    webhook.lastUsedAt = new Date();
    this.webhooks.set(webhookId, webhook);
    
    return { valid: true, webhookId };
  }
  
  /**
   * Process webhook payload and convert to neural signal
   */
  async processWebhookToNeuralSignal(
    webhookId: string, 
    payload: WebhookPayload
  ): Promise<{ success: boolean; result?: any; error?: string }> {
    try {
      const webhook = this.webhooks.get(webhookId);
      
      if (!webhook) {
        return { success: false, error: 'Webhook not found' };
      }
      
      // Map webhook payload to neural signal
      const signal = this.mapToNeuralSignal(webhook, payload);
      
      // Process through neural processor
      const result = await neuralProcessor.processSignal(signal);
      
      return { success: true, result };
    } catch (error: any) {
      logger.error('Error processing webhook:', error);
      return { success: false, error: error.message || 'Unknown error' };
    }
  }
  
  /**
   * Map webhook payload to neural signal based on configured mapping
   */
  private mapToNeuralSignal(webhook: WebhookConfig, payload: WebhookPayload): NeuralSignal {
    const { signalMapping } = webhook;
    const { data } = payload;
    
    // Create a neural signal
    const signal: NeuralSignal = {
      userId: signalMapping?.userId || webhook.owner,
      modality: (signalMapping?.modality || 'webhook') as any,
      context: {
        webhookId: webhook.id,
        event: payload.event,
        timestamp: payload.timestamp,
        rawData: data
      },
      metadata: {
        source: 'webhook',
        sourceId: webhook.id,
        timestamp: new Date().toISOString()
      }
    };
    
    // Apply context mapping if defined
    if (signalMapping?.contextMapping) {
      const mappedContext: Record<string, any> = {};
      
      // Apply mapping
      for (const [targetField, sourceField] of Object.entries(signalMapping.contextMapping)) {
        if (data[sourceField] !== undefined) {
          mappedContext[targetField] = data[sourceField];
        }
      }
      
      // Merge with existing context
      signal.context = {
        ...signal.context,
        ...mappedContext
      };
    }
    
    return signal;
  }
  
  /**
   * Get webhook by ID
   */
  getWebhook(webhookId: string): WebhookConfig | undefined {
    return this.webhooks.get(webhookId);
  }
  
  /**
   * Get all webhooks
   */
  getAllWebhooks(): WebhookConfig[] {
    return Array.from(this.webhooks.values());
  }
  
  /**
   * Get webhooks by owner
   */
  getWebhooksByOwner(owner: string): WebhookConfig[] {
    return Array.from(this.webhooks.values()).filter(webhook => webhook.owner === owner);
  }
  
  /**
   * Update webhook
   */
  updateWebhook(webhookId: string, updates: Partial<WebhookConfig>): WebhookConfig | undefined {
    const webhook = this.webhooks.get(webhookId);
    
    if (!webhook) {
      return undefined;
    }
    
    // Apply updates
    const updatedWebhook: WebhookConfig = {
      ...webhook,
      ...updates,
      id: webhook.id, // Ensure ID doesn't change
      url: webhook.url, // Ensure URL doesn't change
      secret: updates.secret || webhook.secret, // Allow secret rotation
      createdAt: webhook.createdAt // Ensure creation date doesn't change
    };
    
    this.webhooks.set(webhookId, updatedWebhook);
    logger.info(`Updated webhook: ${updatedWebhook.name} (${webhookId})`);
    
    return updatedWebhook;
  }
  
  /**
   * Delete webhook
   */
  deleteWebhook(webhookId: string): boolean {
    if (!this.webhooks.has(webhookId)) {
      return false;
    }
    
    this.webhooks.delete(webhookId);
    logger.info(`Deleted webhook: ${webhookId}`);
    
    return true;
  }
  
  /**
   * Rotate webhook secret
   */
  rotateWebhookSecret(webhookId: string): string | undefined {
    const webhook = this.webhooks.get(webhookId);
    
    if (!webhook) {
      return undefined;
    }
    
    // Generate new secret
    const newSecret = this.generateWebhookSecret();
    
    // Update webhook
    webhook.secret = newSecret;
    this.webhooks.set(webhookId, webhook);
    
    logger.info(`Rotated secret for webhook: ${webhook.name} (${webhookId})`);
    
    return newSecret;
  }
}

// Export a singleton instance
export const webhookManager = new WebhookManager();
export default webhookManager;