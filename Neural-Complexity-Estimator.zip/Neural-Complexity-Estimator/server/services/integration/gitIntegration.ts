/**
 * Git Integration Service
 * 
 * Provides integration with Git repositories (GitHub, GitLab, etc.)
 * for automated code generation, pull requests, and deployments.
 */

import axios from 'axios';
import { logger } from '../../utils/logger';
import EventEmitter from 'events';

// Git provider types
export type GitProvider = 'github' | 'gitlab' | 'bitbucket';

// Repository interface
export interface Repository {
  id: string;
  provider: GitProvider;
  name: string;
  owner: string;
  defaultBranch: string;
  cloneUrl: string;
  apiUrl?: string;
  accessToken?: string;
  webhookUrl?: string;
  active: boolean;
}

// Branch interface
export interface Branch {
  name: string;
  commit: {
    sha: string;
    url: string;
  };
  protected: boolean;
}

// Commit interface
export interface Commit {
  id: string;
  message: string;
  author: {
    name: string;
    email: string;
    date: string;
  };
  committer: {
    name: string;
    email: string;
    date: string;
  };
  tree: {
    sha: string;
    url: string;
  };
  parents: {
    sha: string;
    url: string;
  }[];
  url: string;
}

// Pull request interface
export interface PullRequest {
  id: string;
  number: number;
  title: string;
  description: string;
  sourceBranch: string;
  targetBranch: string;
  state: 'open' | 'closed' | 'merged';
  createdAt: string;
  updatedAt: string;
  mergedAt?: string;
  author: {
    username: string;
  };
  url: string;
}

// File change for creating commits or PRs
export interface FileChange {
  path: string;
  content: string;
  operation: 'create' | 'update' | 'delete';
  encoding?: 'utf-8' | 'base64';
}

class GitIntegrationService extends EventEmitter {
  private repositories: Map<string, Repository> = new Map();
  private isInitialized = false;
  
  constructor() {
    super();
  }
  
  /**
   * Initialize the Git integration service
   */
  async initialize(repositories: Repository[] = []): Promise<boolean> {
    try {
      logger.info('Initializing Git integration service');
      
      // Add repositories
      for (const repo of repositories) {
        this.repositories.set(repo.id, repo);
      }
      
      this.isInitialized = true;
      logger.info(`Initialized Git integration service with ${this.repositories.size} repositories`);
      
      return true;
    } catch (error) {
      logger.error('Failed to initialize Git integration service', error);
      return false;
    }
  }
  
  /**
   * Get all repositories
   */
  getRepositories(): Repository[] {
    return Array.from(this.repositories.values());
  }
  
  /**
   * Get a repository by ID
   */
  getRepository(id: string): Repository | null {
    return this.repositories.get(id) || null;
  }
  
  /**
   * Add a repository
   */
  addRepository(repository: Repository): boolean {
    try {
      this.repositories.set(repository.id, repository);
      
      // Emit event
      this.emit('repository:added', {
        id: repository.id,
        name: repository.name,
        provider: repository.provider
      });
      
      return true;
    } catch (error) {
      logger.error(`Error adding repository ${repository.name}`, error);
      return false;
    }
  }
  
  /**
   * Update a repository
   */
  updateRepository(id: string, updates: Partial<Repository>): boolean {
    try {
      const repository = this.repositories.get(id);
      
      if (!repository) {
        return false;
      }
      
      // Update fields
      const updatedRepository = { ...repository, ...updates };
      this.repositories.set(id, updatedRepository);
      
      // Emit event
      this.emit('repository:updated', {
        id,
        name: updatedRepository.name,
        provider: updatedRepository.provider
      });
      
      return true;
    } catch (error) {
      logger.error(`Error updating repository ${id}`, error);
      return false;
    }
  }
  
  /**
   * Remove a repository
   */
  removeRepository(id: string): boolean {
    try {
      if (!this.repositories.has(id)) {
        return false;
      }
      
      // Get repository before removing
      const repository = this.repositories.get(id)!;
      
      // Remove repository
      this.repositories.delete(id);
      
      // Emit event
      this.emit('repository:removed', {
        id,
        name: repository.name,
        provider: repository.provider
      });
      
      return true;
    } catch (error) {
      logger.error(`Error removing repository ${id}`, error);
      return false;
    }
  }
  
  /**
   * Get branches for a repository
   */
  async getBranches(repositoryId: string): Promise<Branch[]> {
    try {
      const repository = this.repositories.get(repositoryId);
      
      if (!repository) {
        throw new Error(`Repository ${repositoryId} not found`);
      }
      
      if (!repository.accessToken) {
        throw new Error(`Repository ${repositoryId} does not have an access token`);
      }
      
      // Different API calls based on provider
      switch (repository.provider) {
        case 'github':
          return await this.getGitHubBranches(repository);
        case 'gitlab':
          return await this.getGitLabBranches(repository);
        case 'bitbucket':
          return await this.getBitbucketBranches(repository);
        default:
          throw new Error(`Unsupported provider: ${repository.provider}`);
      }
    } catch (error) {
      logger.error(`Error getting branches for repository ${repositoryId}`, error);
      throw error;
    }
  }
  
  /**
   * Get branches from GitHub
   */
  private async getGitHubBranches(repository: Repository): Promise<Branch[]> {
    const url = `https://api.github.com/repos/${repository.owner}/${repository.name}/branches`;
    
    const response = await axios.get(url, {
      headers: {
        'Authorization': `token ${repository.accessToken}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    });
    
    return response.data.map((branch: any) => ({
      name: branch.name,
      commit: {
        sha: branch.commit.sha,
        url: branch.commit.url
      },
      protected: branch.protected
    }));
  }
  
  /**
   * Get branches from GitLab
   */
  private async getGitLabBranches(repository: Repository): Promise<Branch[]> {
    const url = `https://gitlab.com/api/v4/projects/${repository.owner}%2F${repository.name}/repository/branches`;
    
    const response = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${repository.accessToken}`
      }
    });
    
    return response.data.map((branch: any) => ({
      name: branch.name,
      commit: {
        sha: branch.commit.id,
        url: branch.commit.web_url
      },
      protected: branch.protected
    }));
  }
  
  /**
   * Get branches from Bitbucket
   */
  private async getBitbucketBranches(repository: Repository): Promise<Branch[]> {
    const url = `https://api.bitbucket.org/2.0/repositories/${repository.owner}/${repository.name}/refs/branches`;
    
    const response = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${repository.accessToken}`
      }
    });
    
    return response.data.values.map((branch: any) => ({
      name: branch.name,
      commit: {
        sha: branch.target.hash,
        url: branch.target.links.self.href
      },
      protected: false // Bitbucket API doesn't return this info directly
    }));
  }
  
  /**
   * Create a branch
   */
  async createBranch(
    repositoryId: string, 
    branchName: string, 
    sourceBranch?: string
  ): Promise<Branch> {
    try {
      const repository = this.repositories.get(repositoryId);
      
      if (!repository) {
        throw new Error(`Repository ${repositoryId} not found`);
      }
      
      if (!repository.accessToken) {
        throw new Error(`Repository ${repositoryId} does not have an access token`);
      }
      
      // Use source branch or default branch
      const source = sourceBranch || repository.defaultBranch;
      
      // Different API calls based on provider
      switch (repository.provider) {
        case 'github':
          return await this.createGitHubBranch(repository, branchName, source);
        case 'gitlab':
          return await this.createGitLabBranch(repository, branchName, source);
        case 'bitbucket':
          return await this.createBitbucketBranch(repository, branchName, source);
        default:
          throw new Error(`Unsupported provider: ${repository.provider}`);
      }
    } catch (error) {
      logger.error(`Error creating branch ${branchName} for repository ${repositoryId}`, error);
      throw error;
    }
  }
  
  /**
   * Create a branch on GitHub
   */
  private async createGitHubBranch(
    repository: Repository,
    branchName: string,
    sourceBranch: string
  ): Promise<Branch> {
    // Get the source branch SHA
    const sourceUrl = `https://api.github.com/repos/${repository.owner}/${repository.name}/git/refs/heads/${sourceBranch}`;
    
    const sourceResponse = await axios.get(sourceUrl, {
      headers: {
        'Authorization': `token ${repository.accessToken}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    });
    
    const sha = sourceResponse.data.object.sha;
    
    // Create the new branch
    const url = `https://api.github.com/repos/${repository.owner}/${repository.name}/git/refs`;
    
    const response = await axios.post(url, {
      ref: `refs/heads/${branchName}`,
      sha
    }, {
      headers: {
        'Authorization': `token ${repository.accessToken}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    });
    
    return {
      name: branchName,
      commit: {
        sha: response.data.object.sha,
        url: response.data.object.url
      },
      protected: false
    };
  }
  
  /**
   * Create a branch on GitLab
   */
  private async createGitLabBranch(
    repository: Repository,
    branchName: string,
    sourceBranch: string
  ): Promise<Branch> {
    const url = `https://gitlab.com/api/v4/projects/${repository.owner}%2F${repository.name}/repository/branches`;
    
    const response = await axios.post(url, {
      branch: branchName,
      ref: sourceBranch
    }, {
      headers: {
        'Authorization': `Bearer ${repository.accessToken}`
      }
    });
    
    return {
      name: response.data.name,
      commit: {
        sha: response.data.commit.id,
        url: response.data.commit.web_url
      },
      protected: response.data.protected
    };
  }
  
  /**
   * Create a branch on Bitbucket
   */
  private async createBitbucketBranch(
    repository: Repository,
    branchName: string,
    sourceBranch: string
  ): Promise<Branch> {
    // Get the source branch SHA
    const sourceUrl = `https://api.bitbucket.org/2.0/repositories/${repository.owner}/${repository.name}/refs/branches/${sourceBranch}`;
    
    const sourceResponse = await axios.get(sourceUrl, {
      headers: {
        'Authorization': `Bearer ${repository.accessToken}`
      }
    });
    
    const sha = sourceResponse.data.target.hash;
    
    // Create the new branch
    const url = `https://api.bitbucket.org/2.0/repositories/${repository.owner}/${repository.name}/refs/branches`;
    
    const response = await axios.post(url, {
      name: branchName,
      target: {
        hash: sha
      }
    }, {
      headers: {
        'Authorization': `Bearer ${repository.accessToken}`
      }
    });
    
    return {
      name: response.data.name,
      commit: {
        sha: response.data.target.hash,
        url: response.data.target.links.self.href
      },
      protected: false
    };
  }
  
  /**
   * Create a file or update files in a repository
   */
  async createCommit(
    repositoryId: string,
    branch: string,
    message: string,
    files: FileChange[]
  ): Promise<Commit> {
    try {
      const repository = this.repositories.get(repositoryId);
      
      if (!repository) {
        throw new Error(`Repository ${repositoryId} not found`);
      }
      
      if (!repository.accessToken) {
        throw new Error(`Repository ${repositoryId} does not have an access token`);
      }
      
      // Different API calls based on provider
      switch (repository.provider) {
        case 'github':
          return await this.createGitHubCommit(repository, branch, message, files);
        case 'gitlab':
          return await this.createGitLabCommit(repository, branch, message, files);
        case 'bitbucket':
          return await this.createBitbucketCommit(repository, branch, message, files);
        default:
          throw new Error(`Unsupported provider: ${repository.provider}`);
      }
    } catch (error) {
      logger.error(`Error creating commit in repository ${repositoryId}`, error);
      throw error;
    }
  }
  
  /**
   * Create a commit on GitHub
   */
  private async createGitHubCommit(
    repository: Repository,
    branch: string,
    message: string,
    files: FileChange[]
  ): Promise<Commit> {
    // For GitHub, we need to create a commit for each file
    // First, let's get the latest commit SHA
    const refUrl = `https://api.github.com/repos/${repository.owner}/${repository.name}/git/refs/heads/${branch}`;
    
    const refResponse = await axios.get(refUrl, {
      headers: {
        'Authorization': `token ${repository.accessToken}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    });
    
    const latestSha = refResponse.data.object.sha;
    
    // Get the tree of the latest commit
    const treeUrl = `https://api.github.com/repos/${repository.owner}/${repository.name}/git/trees/${latestSha}`;
    
    const treeResponse = await axios.get(treeUrl, {
      headers: {
        'Authorization': `token ${repository.accessToken}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    });
    
    // Create blobs for each file
    const blobPromises = files.map(async file => {
      if (file.operation === 'delete') {
        return {
          path: file.path,
          mode: '100644',
          type: 'blob',
          sha: null
        };
      }
      
      const blobUrl = `https://api.github.com/repos/${repository.owner}/${repository.name}/git/blobs`;
      
      const blobResponse = await axios.post(blobUrl, {
        content: file.content,
        encoding: file.encoding || 'utf-8'
      }, {
        headers: {
          'Authorization': `token ${repository.accessToken}`,
          'Accept': 'application/vnd.github.v3+json'
        }
      });
      
      return {
        path: file.path,
        mode: '100644',
        type: 'blob',
        sha: blobResponse.data.sha
      };
    });
    
    const blobs = await Promise.all(blobPromises);
    
    // Create a new tree
    const newTreeUrl = `https://api.github.com/repos/${repository.owner}/${repository.name}/git/trees`;
    
    const newTreeResponse = await axios.post(newTreeUrl, {
      base_tree: treeResponse.data.sha,
      tree: blobs.filter(blob => blob.sha !== null)
    }, {
      headers: {
        'Authorization': `token ${repository.accessToken}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    });
    
    // Create a commit
    const commitUrl = `https://api.github.com/repos/${repository.owner}/${repository.name}/git/commits`;
    
    const commitResponse = await axios.post(commitUrl, {
      message,
      tree: newTreeResponse.data.sha,
      parents: [latestSha]
    }, {
      headers: {
        'Authorization': `token ${repository.accessToken}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    });
    
    // Update the reference
    await axios.patch(`${refUrl}`, {
      sha: commitResponse.data.sha
    }, {
      headers: {
        'Authorization': `token ${repository.accessToken}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    });
    
    return {
      id: commitResponse.data.sha,
      message: commitResponse.data.message,
      author: {
        name: commitResponse.data.author.name,
        email: commitResponse.data.author.email,
        date: commitResponse.data.author.date
      },
      committer: {
        name: commitResponse.data.committer.name,
        email: commitResponse.data.committer.email,
        date: commitResponse.data.committer.date
      },
      tree: {
        sha: commitResponse.data.tree.sha,
        url: commitResponse.data.tree.url
      },
      parents: commitResponse.data.parents,
      url: commitResponse.data.url
    };
  }
  
  /**
   * Create a commit on GitLab
   */
  private async createGitLabCommit(
    repository: Repository,
    branch: string,
    message: string,
    files: FileChange[]
  ): Promise<Commit> {
    // GitLab has a simpler API for commits
    const url = `https://gitlab.com/api/v4/projects/${repository.owner}%2F${repository.name}/repository/commits`;
    
    // Format actions
    const actions = files.map(file => {
      const action: any = {
        action: file.operation,
        file_path: file.path,
      };
      
      if (file.operation !== 'delete') {
        action.content = file.content;
        if (file.encoding === 'base64') {
          action.encoding = 'base64';
        }
      }
      
      return action;
    });
    
    // Create commit
    const response = await axios.post(url, {
      branch,
      commit_message: message,
      actions
    }, {
      headers: {
        'Authorization': `Bearer ${repository.accessToken}`
      }
    });
    
    // Format response
    return {
      id: response.data.id,
      message: response.data.message,
      author: {
        name: response.data.author_name,
        email: response.data.author_email,
        date: response.data.authored_date
      },
      committer: {
        name: response.data.committer_name,
        email: response.data.committer_email,
        date: response.data.committed_date
      },
      tree: {
        sha: response.data.id, // GitLab doesn't have a separate tree SHA
        url: `https://gitlab.com/api/v4/projects/${repository.owner}%2F${repository.name}/repository/tree`
      },
      parents: response.data.parent_ids.map((id: string) => ({
        sha: id,
        url: `https://gitlab.com/api/v4/projects/${repository.owner}%2F${repository.name}/repository/commits/${id}`
      })),
      url: response.data.web_url
    };
  }
  
  /**
   * Create a commit on Bitbucket
   */
  private async createBitbucketCommit(
    repository: Repository,
    branch: string,
    message: string,
    files: FileChange[]
  ): Promise<Commit> {
    // Bitbucket doesn't have a simple API for multiple file commits
    // We'd need to use their source API which is complex
    // This is a simplified implementation
    
    // We'll handle each file separately
    for (const file of files) {
      const url = `https://api.bitbucket.org/2.0/repositories/${repository.owner}/${repository.name}/src`;
      
      if (file.operation === 'delete') {
        await axios.post(url, `files=${file.path}`, {
          headers: {
            'Authorization': `Bearer ${repository.accessToken}`,
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          params: {
            branch,
            message: `Delete ${file.path}`
          }
        });
      } else {
        // We need to use form data for Bitbucket
        const formData = new FormData();
        formData.append(file.path, file.content);
        
        await axios.post(url, formData, {
          headers: {
            'Authorization': `Bearer ${repository.accessToken}`,
            'Content-Type': 'multipart/form-data'
          },
          params: {
            branch,
            message: file.operation === 'create' ? `Add ${file.path}` : `Update ${file.path}`
          }
        });
      }
    }
    
    // Get the latest commit
    const commitUrl = `https://api.bitbucket.org/2.0/repositories/${repository.owner}/${repository.name}/commits/${branch}`;
    
    const response = await axios.get(commitUrl, {
      headers: {
        'Authorization': `Bearer ${repository.accessToken}`
      }
    });
    
    const latestCommit = response.data.values[0];
    
    return {
      id: latestCommit.hash,
      message: latestCommit.message,
      author: {
        name: latestCommit.author.user.display_name,
        email: latestCommit.author.raw, // Bitbucket doesn't directly provide email
        date: latestCommit.date
      },
      committer: {
        name: latestCommit.author.user.display_name,
        email: latestCommit.author.raw,
        date: latestCommit.date
      },
      tree: {
        sha: latestCommit.hash,
        url: latestCommit.links.self.href
      },
      parents: latestCommit.parents.map((parent: any) => ({
        sha: parent.hash,
        url: parent.links.self.href
      })),
      url: latestCommit.links.self.href
    };
  }
  
  /**
   * Create a pull request
   */
  async createPullRequest(
    repositoryId: string,
    title: string,
    description: string,
    sourceBranch: string,
    targetBranch: string
  ): Promise<PullRequest> {
    try {
      const repository = this.repositories.get(repositoryId);
      
      if (!repository) {
        throw new Error(`Repository ${repositoryId} not found`);
      }
      
      if (!repository.accessToken) {
        throw new Error(`Repository ${repositoryId} does not have an access token`);
      }
      
      // Different API calls based on provider
      switch (repository.provider) {
        case 'github':
          return await this.createGitHubPullRequest(repository, title, description, sourceBranch, targetBranch);
        case 'gitlab':
          return await this.createGitLabPullRequest(repository, title, description, sourceBranch, targetBranch);
        case 'bitbucket':
          return await this.createBitbucketPullRequest(repository, title, description, sourceBranch, targetBranch);
        default:
          throw new Error(`Unsupported provider: ${repository.provider}`);
      }
    } catch (error) {
      logger.error(`Error creating pull request in repository ${repositoryId}`, error);
      throw error;
    }
  }
  
  /**
   * Create a pull request on GitHub
   */
  private async createGitHubPullRequest(
    repository: Repository,
    title: string,
    description: string,
    sourceBranch: string,
    targetBranch: string
  ): Promise<PullRequest> {
    const url = `https://api.github.com/repos/${repository.owner}/${repository.name}/pulls`;
    
    const response = await axios.post(url, {
      title,
      body: description,
      head: sourceBranch,
      base: targetBranch
    }, {
      headers: {
        'Authorization': `token ${repository.accessToken}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    });
    
    return {
      id: response.data.id.toString(),
      number: response.data.number,
      title: response.data.title,
      description: response.data.body,
      sourceBranch: response.data.head.ref,
      targetBranch: response.data.base.ref,
      state: response.data.state,
      createdAt: response.data.created_at,
      updatedAt: response.data.updated_at,
      mergedAt: response.data.merged_at,
      author: {
        username: response.data.user.login
      },
      url: response.data.html_url
    };
  }
  
  /**
   * Create a pull request on GitLab (called Merge Request)
   */
  private async createGitLabPullRequest(
    repository: Repository,
    title: string,
    description: string,
    sourceBranch: string,
    targetBranch: string
  ): Promise<PullRequest> {
    const url = `https://gitlab.com/api/v4/projects/${repository.owner}%2F${repository.name}/merge_requests`;
    
    const response = await axios.post(url, {
      title,
      description,
      source_branch: sourceBranch,
      target_branch: targetBranch
    }, {
      headers: {
        'Authorization': `Bearer ${repository.accessToken}`
      }
    });
    
    return {
      id: response.data.id.toString(),
      number: response.data.iid,
      title: response.data.title,
      description: response.data.description,
      sourceBranch: response.data.source_branch,
      targetBranch: response.data.target_branch,
      state: response.data.state,
      createdAt: response.data.created_at,
      updatedAt: response.data.updated_at,
      mergedAt: response.data.merged_at,
      author: {
        username: response.data.author.username
      },
      url: response.data.web_url
    };
  }
  
  /**
   * Create a pull request on Bitbucket
   */
  private async createBitbucketPullRequest(
    repository: Repository,
    title: string,
    description: string,
    sourceBranch: string,
    targetBranch: string
  ): Promise<PullRequest> {
    const url = `https://api.bitbucket.org/2.0/repositories/${repository.owner}/${repository.name}/pullrequests`;
    
    const response = await axios.post(url, {
      title,
      description,
      source: {
        branch: {
          name: sourceBranch
        }
      },
      destination: {
        branch: {
          name: targetBranch
        }
      }
    }, {
      headers: {
        'Authorization': `Bearer ${repository.accessToken}`
      }
    });
    
    return {
      id: response.data.id.toString(),
      number: response.data.id,
      title: response.data.title,
      description: response.data.description,
      sourceBranch: response.data.source.branch.name,
      targetBranch: response.data.destination.branch.name,
      state: response.data.state === 'OPEN' ? 'open' : 
             response.data.state === 'MERGED' ? 'merged' : 'closed',
      createdAt: response.data.created_on,
      updatedAt: response.data.updated_on,
      mergedAt: undefined, // Not directly available in response
      author: {
        username: response.data.author.username
      },
      url: response.data.links.html.href
    };
  }
  
  /**
   * Check if service is initialized
   */
  isReady(): boolean {
    return this.isInitialized;
  }
}

// Create singleton instance
const gitIntegrationService = new GitIntegrationService();

export default gitIntegrationService;