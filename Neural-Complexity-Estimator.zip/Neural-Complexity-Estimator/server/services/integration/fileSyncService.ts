import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { v4 as uuidv4 } from 'uuid';
import { Dropbox } from 'dropbox';
import SftpClient from 'ssh2-sftp-client';
import { astraService } from '../astra/astraService';

// Define types for platform connections
export interface PlatformConnection {
  id: string;
  name: string;
  type: 'ubuntu' | 'windows' | 'dropbox' | 'local';
  config: {
    [key: string]: any;
  };
  rootPath: string;
  active: boolean;
  lastSync?: string;
}

export interface SyncOptions {
  platforms: string[]; // IDs of platforms to sync
  direction: 'push' | 'pull' | 'bidirectional';
  includePaths?: string[];
  excludePaths?: string[];
  deleteOrphaned?: boolean;
}

export interface SyncedFile {
  id: string;
  relativePath: string;
  filename: string;
  size: number;
  hash: string;
  lastModified: string;
  platformVersions: {
    platformId: string;
    path: string;
    lastSync: string;
    hash: string;
  }[];
}

/**
 * Service for syncing files across multiple platforms
 */
export class FileSyncService {
  private platforms: Map<string, PlatformConnection> = new Map();
  private readonly syncDir: string;
  
  constructor() {
    this.syncDir = path.join(process.cwd(), 'uploads', 'synced_files');
    
    // Create sync directory if it doesn't exist
    if (!fs.existsSync(this.syncDir)) {
      fs.mkdirSync(this.syncDir, { recursive: true });
    }
  }
  
  /**
   * Add or update a platform connection
   */
  addPlatform(platform: PlatformConnection): string {
    const id = platform.id || uuidv4();
    
    this.platforms.set(id, {
      ...platform,
      id
    });
    
    return id;
  }
  
  /**
   * Remove a platform connection
   */
  removePlatform(id: string): boolean {
    return this.platforms.delete(id);
  }
  
  /**
   * Get all platform connections
   */
  getAllPlatforms(): PlatformConnection[] {
    return Array.from(this.platforms.values());
  }
  
  /**
   * Get a platform by ID
   */
  getPlatform(id: string): PlatformConnection | undefined {
    return this.platforms.get(id);
  }
  
  /**
   * Initialize a connection to a platform
   */
  private async connectToPlatform(
    platform: PlatformConnection
  ): Promise<any> {
    switch (platform.type) {
      case 'ubuntu':
      case 'windows':
        return this.connectToSftp(platform);
      case 'dropbox':
        return this.connectToDropbox(platform);
      case 'local':
        return null; // No need to connect for local
      default:
        throw new Error(`Unsupported platform type: ${platform.type}`);
    }
  }
  
  /**
   * Connect to SFTP (Ubuntu/Windows)
   */
  private async connectToSftp(platform: PlatformConnection): Promise<SftpClient> {
    const sftp = new SftpClient();
    
    await sftp.connect({
      host: platform.config.host,
      port: platform.config.port || 22,
      username: platform.config.username,
      password: platform.config.password,
      privateKey: platform.config.privateKey
    });
    
    return sftp;
  }
  
  /**
   * Connect to Dropbox
   */
  private connectToDropbox(platform: PlatformConnection): Dropbox {
    return new Dropbox({
      accessToken: platform.config.accessToken
    });
  }
  
  /**
   * Sync files between platforms
   */
  async syncFiles(options: SyncOptions): Promise<{
    success: boolean;
    filesProcessed: number;
    filesUpdated: number;
    errors: string[];
  }> {
    const { platforms, direction, includePaths = [], excludePaths = [], deleteOrphaned = false } = options;
    
    const selectedPlatforms = platforms
      .map(id => this.platforms.get(id))
      .filter(Boolean) as PlatformConnection[];
    
    if (selectedPlatforms.length < 1) {
      return {
        success: false,
        filesProcessed: 0,
        filesUpdated: 0,
        errors: ['At least one platform must be selected for sync']
      };
    }
    
    // Results tracking
    const results = {
      success: true,
      filesProcessed: 0,
      filesUpdated: 0,
      errors: [] as string[]
    };
    
    try {
      // Establish connections
      const connections = new Map();
      
      for (const platform of selectedPlatforms) {
        try {
          const connection = await this.connectToPlatform(platform);
          connections.set(platform.id, connection);
        } catch (error) {
          results.errors.push(`Failed to connect to ${platform.name}: ${error.message}`);
          results.success = false;
        }
      }
      
      if (!results.success) {
        return results;
      }
      
      // For simplicity, we'll implement a source -> destination sync
      if (direction === 'bidirectional') {
        // This would need a more complex implementation to handle conflicts
        results.errors.push('Bidirectional sync is not fully implemented yet');
        return {
          ...results,
          success: false
        };
      }
      
      // Determine source and destination platforms
      const sourcePlatforms = direction === 'push' 
        ? [selectedPlatforms[0]] // Local is typically first
        : selectedPlatforms.slice(1);
        
      const destPlatforms = direction === 'push'
        ? selectedPlatforms.slice(1)
        : [selectedPlatforms[0]];
      
      // Implement a basic sync algorithm
      for (const sourcePlatform of sourcePlatforms) {
        // List files from source platform
        const sourceFiles = await this.listFilesFromPlatform(
          sourcePlatform,
          connections.get(sourcePlatform.id),
          sourcePlatform.rootPath,
          includePaths,
          excludePaths
        );
        
        results.filesProcessed += sourceFiles.length;
        
        // Sync each file to destination platforms
        for (const file of sourceFiles) {
          for (const destPlatform of destPlatforms) {
            try {
              const updated = await this.syncFileToDestination(
                file,
                sourcePlatform,
                connections.get(sourcePlatform.id),
                destPlatform,
                connections.get(destPlatform.id)
              );
              
              if (updated) {
                results.filesUpdated++;
              }
            } catch (error) {
              results.errors.push(`Failed to sync ${file.relativePath} to ${destPlatform.name}: ${error.message}`);
            }
          }
        }
      }
      
      // Close connections
      for (const [platformId, connection] of connections.entries()) {
        if (connection && typeof connection.end === 'function') {
          await connection.end();
        }
      }
      
      return results;
    } catch (error) {
      console.error('Error syncing files:', error);
      return {
        success: false,
        filesProcessed: results.filesProcessed,
        filesUpdated: results.filesUpdated,
        errors: [...results.errors, error.message]
      };
    }
  }
  
  /**
   * List files from a platform
   */
  private async listFilesFromPlatform(
    platform: PlatformConnection,
    connection: any,
    rootPath: string,
    includePaths: string[],
    excludePaths: string[]
  ): Promise<{
    relativePath: string;
    fullPath: string;
    size: number;
    lastModified: Date;
  }[]> {
    switch (platform.type) {
      case 'ubuntu':
      case 'windows':
        return this.listFilesFromSftp(connection, rootPath, includePaths, excludePaths);
      case 'dropbox':
        return this.listFilesFromDropbox(connection, rootPath, includePaths, excludePaths);
      case 'local':
        return this.listFilesFromLocal(rootPath, includePaths, excludePaths);
      default:
        throw new Error(`Unsupported platform type: ${platform.type}`);
    }
  }
  
  /**
   * List files from SFTP
   */
  private async listFilesFromSftp(
    sftp: SftpClient,
    rootPath: string,
    includePaths: string[],
    excludePaths: string[]
  ): Promise<{
    relativePath: string;
    fullPath: string;
    size: number;
    lastModified: Date;
  }[]> {
    // For simplicity, we're just listing files directly
    // A more robust implementation would handle directories recursively
    const files = [];
    const list = await sftp.list(rootPath);
    
    for (const item of list) {
      if (item.type === '-') { // Regular file
        const relativePath = item.name;
        const fullPath = path.join(rootPath, relativePath);
        
        // Check if file should be included
        if (
          (includePaths.length === 0 || includePaths.some(pattern => fullPath.includes(pattern))) &&
          !excludePaths.some(pattern => fullPath.includes(pattern))
        ) {
          files.push({
            relativePath,
            fullPath,
            size: item.size,
            lastModified: new Date(item.modifyTime)
          });
        }
      }
    }
    
    return files;
  }
  
  /**
   * List files from Dropbox
   */
  private async listFilesFromDropbox(
    dropbox: Dropbox,
    rootPath: string,
    includePaths: string[],
    excludePaths: string[]
  ): Promise<{
    relativePath: string;
    fullPath: string;
    size: number;
    lastModified: Date;
  }[]> {
    const files = [];
    
    // Normalize Dropbox path (should start with '/')
    const normalizedPath = rootPath.startsWith('/') ? rootPath : `/${rootPath}`;
    
    const response = await dropbox.filesListFolder({
      path: normalizedPath,
      recursive: true
    });
    
    for (const entry of response.result.entries) {
      if (entry['.tag'] === 'file') {
        const fullPath = entry.path_display;
        const relativePath = fullPath?.replace(normalizedPath, '').replace(/^\//, '') || '';
        
        // Check if file should be included
        if (
          (includePaths.length === 0 || includePaths.some(pattern => fullPath?.includes(pattern))) &&
          !excludePaths.some(pattern => fullPath?.includes(pattern))
        ) {
          files.push({
            relativePath,
            fullPath: fullPath || '',
            size: entry.size || 0,
            lastModified: new Date(entry.server_modified || Date.now())
          });
        }
      }
    }
    
    return files;
  }
  
  /**
   * List files from local filesystem
   */
  private async listFilesFromLocal(
    rootPath: string,
    includePaths: string[],
    excludePaths: string[]
  ): Promise<{
    relativePath: string;
    fullPath: string;
    size: number;
    lastModified: Date;
  }[]> {
    const files = [];
    
    // Get all files recursively (simplified)
    const processDirectory = (dirPath: string, base = '') => {
      const entries = fs.readdirSync(dirPath, { withFileTypes: true });
      
      for (const entry of entries) {
        const fullPath = path.join(dirPath, entry.name);
        const relativePath = path.join(base, entry.name);
        
        if (entry.isDirectory()) {
          processDirectory(fullPath, relativePath);
        } else {
          // Check if file should be included
          if (
            (includePaths.length === 0 || includePaths.some(pattern => fullPath.includes(pattern))) &&
            !excludePaths.some(pattern => fullPath.includes(pattern))
          ) {
            const stats = fs.statSync(fullPath);
            
            files.push({
              relativePath,
              fullPath,
              size: stats.size,
              lastModified: stats.mtime
            });
          }
        }
      }
    };
    
    processDirectory(rootPath);
    return files;
  }
  
  /**
   * Sync a file to a destination platform
   */
  private async syncFileToDestination(
    file: {
      relativePath: string;
      fullPath: string;
      size: number;
      lastModified: Date;
    },
    sourcePlatform: PlatformConnection,
    sourceConnection: any,
    destPlatform: PlatformConnection,
    destConnection: any
  ): Promise<boolean> {
    // Determine destination path
    const destFullPath = path.join(destPlatform.rootPath, file.relativePath);
    
    // Check if destination file exists and is newer
    let needsUpdate = true;
    
    try {
      const destFileInfo = await this.getFileInfo(destPlatform, destConnection, destFullPath);
      
      if (destFileInfo) {
        // Compare modification times (simplified)
        needsUpdate = file.lastModified > destFileInfo.lastModified;
      }
    } catch (error) {
      // File probably doesn't exist on destination
      needsUpdate = true;
    }
    
    if (!needsUpdate) {
      return false;
    }
    
    // Transfer the file
    // For simplicity, we'll download to a temp location then upload
    const tempPath = path.join(this.syncDir, uuidv4() + path.extname(file.relativePath));
    
    try {
      // Download from source
      await this.downloadFile(sourcePlatform, sourceConnection, file.fullPath, tempPath);
      
      // Upload to destination
      await this.uploadFile(destPlatform, destConnection, tempPath, destFullPath);
      
      // Clean up temp file
      fs.unlinkSync(tempPath);
      
      return true;
    } catch (error) {
      // Clean up temp file in case of error
      if (fs.existsSync(tempPath)) {
        fs.unlinkSync(tempPath);
      }
      
      throw error;
    }
  }
  
  /**
   * Get file info from a platform
   */
  private async getFileInfo(
    platform: PlatformConnection,
    connection: any,
    filePath: string
  ): Promise<{
    exists: boolean;
    size?: number;
    lastModified: Date;
  }> {
    switch (platform.type) {
      case 'ubuntu':
      case 'windows':
        try {
          const stats = await connection.stat(filePath);
          return {
            exists: true,
            size: stats.size,
            lastModified: new Date(stats.mtime)
          };
        } catch (error) {
          return { exists: false, lastModified: new Date(0) };
        }
      
      case 'dropbox':
        try {
          const response = await connection.filesGetMetadata({
            path: filePath
          });
          
          return {
            exists: true,
            size: response.result.size,
            lastModified: new Date(response.result.server_modified)
          };
        } catch (error) {
          return { exists: false, lastModified: new Date(0) };
        }
      
      case 'local':
        try {
          const stats = fs.statSync(filePath);
          return {
            exists: true,
            size: stats.size,
            lastModified: stats.mtime
          };
        } catch (error) {
          return { exists: false, lastModified: new Date(0) };
        }
      
      default:
        throw new Error(`Unsupported platform type: ${platform.type}`);
    }
  }
  
  /**
   * Download a file from a platform
   */
  private async downloadFile(
    platform: PlatformConnection,
    connection: any,
    remotePath: string,
    localPath: string
  ): Promise<void> {
    switch (platform.type) {
      case 'ubuntu':
      case 'windows':
        await connection.get(remotePath, localPath);
        break;
      
      case 'dropbox':
        const response = await connection.filesDownload({
          path: remotePath
        });
        
        fs.writeFileSync(localPath, response.result.fileBinary);
        break;
      
      case 'local':
        fs.copyFileSync(remotePath, localPath);
        break;
      
      default:
        throw new Error(`Unsupported platform type: ${platform.type}`);
    }
  }
  
  /**
   * Upload a file to a platform
   */
  private async uploadFile(
    platform: PlatformConnection,
    connection: any,
    localPath: string,
    remotePath: string
  ): Promise<void> {
    switch (platform.type) {
      case 'ubuntu':
      case 'windows':
        // Create parent directory if it doesn't exist
        const remoteDir = path.dirname(remotePath);
        try {
          await connection.stat(remoteDir);
        } catch (error) {
          await connection.mkdir(remoteDir, true);
        }
        
        await connection.put(localPath, remotePath);
        break;
      
      case 'dropbox':
        const fileContent = fs.readFileSync(localPath);
        
        await connection.filesUpload({
          path: remotePath,
          contents: fileContent,
          mode: 'overwrite'
        });
        break;
      
      case 'local':
        // Create parent directory if it doesn't exist
        const localDir = path.dirname(remotePath);
        if (!fs.existsSync(localDir)) {
          fs.mkdirSync(localDir, { recursive: true });
        }
        
        fs.copyFileSync(localPath, remotePath);
        break;
      
      default:
        throw new Error(`Unsupported platform type: ${platform.type}`);
    }
  }
}

// Export a singleton instance
export const fileSyncService = new FileSyncService();