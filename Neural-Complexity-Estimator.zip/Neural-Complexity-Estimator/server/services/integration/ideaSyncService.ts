/**
 * PinkSync - Idea Sync Service
 * 
 * This service integrates the Idea Ingestor with platform synchronization capabilities,
 * allowing ideas to be exported to and imported from various connected platforms.
 */

import * as fs from 'fs';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { storage } from '../../storage';
import { platformSyncManager } from '../../utils/platformSyncManager';
import openaiService from '../../services/openai';
import { 
  PlatformConnection,
  SyncItem,
  SyncStatus
} from '../../../shared/platformSyncSchema';

/**
 * Format options for idea import/export
 */
export enum IdeaFormat {
  JSON = 'json',
  MARKDOWN = 'markdown',
  CSV = 'csv',
  TEXT = 'text'
}

/**
 * Interface for idea sync options
 */
export interface IdeaSyncOptions {
  connectionId: string;
  format: IdeaFormat;
  includeAnalysis?: boolean;
  targetPath?: string;
  userId: string;
  ideaIds?: number[];  // Optional specific ideas to sync
}

/**
 * Service for synchronizing ideas with external platforms
 */
export class IdeaSyncService {
  private readonly tempDir: string;
  
  constructor() {
    this.tempDir = path.join(process.cwd(), 'uploads', 'idea_exports');
    this.ensureDirectoryExists(this.tempDir);
  }
  
  /**
   * Export ideas to a connected platform
   */
  async exportIdeasToPlatform(options: IdeaSyncOptions): Promise<{
    success: boolean;
    ideasExported: number;
    filePath?: string;
    error?: string;
  }> {
    try {
      // Get the connection
      const connection = await storage.getPlatformConnection(options.connectionId);
      if (!connection) {
        return {
          success: false,
          ideasExported: 0,
          error: `Platform connection with ID ${options.connectionId} not found`
        };
      }
      
      // Get ideas
      const ideas = options.ideaIds && options.ideaIds.length > 0
        ? await Promise.all(options.ideaIds.map(id => storage.getIdeaById(id)))
        : await storage.getIdeasByUserId(options.userId);
      
      // Filter out any null values (ideas not found)
      const validIdeas = ideas.filter(Boolean);
      
      if (validIdeas.length === 0) {
        return {
          success: false,
          ideasExported: 0,
          error: 'No ideas found to export'
        };
      }
      
      // Convert ideas to the desired format
      const formattedContent = await this.formatIdeas(validIdeas, options.format, options.includeAnalysis);
      
      // Determine file extension based on format
      const fileExtension = this.getFileExtensionForFormat(options.format);
      
      // Create temporary file
      const timestamp = new Date().toISOString().replace(/[-:.TZ]/g, '');
      const fileName = `pinksync_ideas_${timestamp}${fileExtension}`;
      const tempFilePath = path.join(this.tempDir, fileName);
      
      // Write content to temporary file
      fs.writeFileSync(tempFilePath, formattedContent);
      
      // Determine target path on the remote platform
      const targetPath = options.targetPath || 
                        connection.rootPath || 
                        '/PinkSync/Ideas';
      
      // Create a sync item for the file
      const syncItem: SyncItem = {
        id: uuidv4(),
        connectionId: options.connectionId,
        path: path.join(targetPath, fileName).replace(/\\/g, '/'),
        isDirectory: false,
        size: fs.statSync(tempFilePath).size,
        mimeType: this.getMimeTypeForFormat(options.format),
        hash: null,
        lastSyncedAt: null,
        syncStatus: SyncStatus.PENDING,
        conflict: false,
        localModified: new Date(),
        remoteModified: null,
        conflictResolution: null,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      // Save sync item to database
      await storage.createSyncItem(syncItem);
      
      // Upload file to remote platform
      const uploadResult = await platformSyncManager.uploadFile(
        options.connectionId,
        tempFilePath,
        syncItem.path
      );
      
      // Update sync item
      await storage.updateSyncItem(syncItem.id, {
        syncStatus: uploadResult.success ? SyncStatus.COMPLETED : SyncStatus.FAILED,
        lastSyncedAt: uploadResult.success ? new Date() : null
      });
      
      return {
        success: uploadResult.success,
        ideasExported: validIdeas.length,
        filePath: syncItem.path,
        error: uploadResult.error
      };
    } catch (error: any) {
      console.error('Error exporting ideas to platform:', error);
      return {
        success: false,
        ideasExported: 0,
        error: error.message || 'Unknown error during export'
      };
    }
  }
  
  /**
   * Import ideas from a connected platform
   */
  async importIdeasFromPlatform(
    connectionId: string,
    filePath: string,
    format: IdeaFormat,
    userId: string
  ): Promise<{
    success: boolean;
    ideasImported: number;
    newIdeaIds: number[];
    error?: string;
  }> {
    try {
      // Get the connection
      const connection = await storage.getPlatformConnection(connectionId);
      if (!connection) {
        return {
          success: false,
          ideasImported: 0,
          newIdeaIds: [],
          error: `Platform connection with ID ${connectionId} not found`
        };
      }
      
      // Download file from platform
      const tempFilePath = path.join(this.tempDir, `import_${Date.now()}${path.extname(filePath)}`);
      
      const downloadResult = await platformSyncManager.downloadFile(
        connectionId,
        filePath,
        tempFilePath
      );
      
      if (!downloadResult.success) {
        return {
          success: false,
          ideasImported: 0,
          newIdeaIds: [],
          error: downloadResult.error
        };
      }
      
      // Read file content
      const fileContent = fs.readFileSync(tempFilePath, 'utf8');
      
      // Parse ideas from the file based on format
      const parsedIdeas = await this.parseIdeasFromFile(fileContent, format);
      
      if (!parsedIdeas || parsedIdeas.length === 0) {
        return {
          success: false,
          ideasImported: 0,
          newIdeaIds: [],
          error: 'No valid ideas found in the file'
        };
      }
      
      // Save ideas to database
      const savedIdeas = [];
      
      for (const idea of parsedIdeas) {
        try {
          const newIdea = await storage.createIdea({
            ...idea,
            userId,
            status: idea.status || 'draft',
            inspirationSource: `Imported from ${connection.name}`
          });
          
          savedIdeas.push(newIdea);
        } catch (error) {
          console.error('Error saving imported idea:', error);
          // Continue with other ideas
        }
      }
      
      // Clean up temp file
      fs.unlinkSync(tempFilePath);
      
      return {
        success: true,
        ideasImported: savedIdeas.length,
        newIdeaIds: savedIdeas.map(idea => idea.id)
      };
    } catch (error: any) {
      console.error('Error importing ideas from platform:', error);
      return {
        success: false,
        ideasImported: 0,
        newIdeaIds: [],
        error: error.message || 'Unknown error during import'
      };
    }
  }
  
  /**
   * Auto-organize ideas that are synced to a platform
   * This uses OpenAI to enhance and organize ideas
   */
  async organizeIdeas(userId: string, connectionId: string): Promise<{
    success: boolean;
    ideasOrganized: number;
    error?: string;
  }> {
    try {
      // Get ideas for this user
      const ideas = await storage.getIdeasByUserId(userId);
      
      if (ideas.length === 0) {
        return {
          success: false,
          ideasOrganized: 0,
          error: 'No ideas found to organize'
        };
      }
      
      // Batch ideas into groups for AI categorization
      const batchSize = 5;
      const batches = [];
      
      for (let i = 0; i < ideas.length; i += batchSize) {
        batches.push(ideas.slice(i, i + batchSize));
      }
      
      let organizedCount = 0;
      
      for (const batch of batches) {
        const ideaSummaries = batch.map(idea => ({
          id: idea.id,
          title: idea.title,
          description: idea.description,
          category: idea.category,
          priority: idea.priority
        }));
        
        const messages = [
          {
            role: 'system' as const,
            content: `You are an expert idea organizer. You'll receive a batch of entrepreneurial ideas. For each idea, suggest an improved category, relevant tags, and a priority score (1-10). Format your response as a JSON array with objects containing: id, category, tags, priority.`
          },
          {
            role: 'user' as const,
            content: `Please organize these ideas:\n${JSON.stringify(ideaSummaries, null, 2)}`
          }
        ];
        
        // Generate AI suggestions
        const completion = await openaiService.chat.generateChatCompletion(
          messages,
          { model: 'gpt-4o' }
        );
        
        // Extract JSON response
        try {
          const responseText = completion.content.trim();
          const jsonMatch = responseText.match(/```json\n([\s\S]*?)\n```/) || 
                            responseText.match(/```\n([\s\S]*?)\n```/) ||
                            responseText.match(/`([\s\S]*?)`/);
          
          const jsonContent = jsonMatch ? jsonMatch[1] : responseText;
          const suggestions = JSON.parse(jsonContent);
          
          // Apply suggestions
          for (const suggestion of suggestions) {
            await storage.updateIdea(suggestion.id, {
              category: suggestion.category,
              tags: suggestion.tags,
              priority: suggestion.priority
            });
            
            organizedCount++;
          }
        } catch (error) {
          console.error('Error parsing AI suggestions:', error);
          continue;
        }
      }
      
      // Export the organized ideas to the platform
      if (organizedCount > 0) {
        await this.exportIdeasToPlatform({
          connectionId,
          format: IdeaFormat.JSON,
          includeAnalysis: true,
          userId,
          targetPath: '/PinkSync/OrganizedIdeas'
        });
      }
      
      return {
        success: true,
        ideasOrganized: organizedCount
      };
    } catch (error: any) {
      console.error('Error organizing ideas:', error);
      return {
        success: false,
        ideasOrganized: 0,
        error: error.message || 'Unknown error during idea organization'
      };
    }
  }
  
  /**
   * Format ideas for export based on the specified format
   */
  private async formatIdeas(
    ideas: any[],
    format: IdeaFormat,
    includeAnalysis: boolean = false
  ): Promise<string> {
    switch (format) {
      case IdeaFormat.JSON:
        return this.formatIdeasAsJson(ideas, includeAnalysis);
      case IdeaFormat.MARKDOWN:
        return this.formatIdeasAsMarkdown(ideas, includeAnalysis);
      case IdeaFormat.CSV:
        return this.formatIdeasAsCsv(ideas);
      case IdeaFormat.TEXT:
        return this.formatIdeasAsText(ideas, includeAnalysis);
      default:
        throw new Error(`Unsupported format: ${format}`);
    }
  }
  
  /**
   * Format ideas as JSON
   */
  private async formatIdeasAsJson(ideas: any[], includeAnalysis: boolean): Promise<string> {
    if (!includeAnalysis) {
      return JSON.stringify(ideas, null, 2);
    }
    
    // Include analysis for each idea
    const ideasWithAnalysis = [];
    
    for (const idea of ideas) {
      try {
        const analysis = await this.getIdeaAnalysis(idea);
        ideasWithAnalysis.push({
          ...idea,
          analysis
        });
      } catch (error) {
        ideasWithAnalysis.push(idea);
        console.error(`Error getting analysis for idea ${idea.id}:`, error);
      }
    }
    
    return JSON.stringify(ideasWithAnalysis, null, 2);
  }
  
  /**
   * Format ideas as Markdown
   */
  private async formatIdeasAsMarkdown(ideas: any[], includeAnalysis: boolean): Promise<string> {
    let markdown = '# PinkSync Ideas\n\n';
    
    for (const idea of ideas) {
      markdown += `## ${idea.title}\n\n`;
      markdown += `**Category:** ${idea.category || 'Uncategorized'}\n`;
      markdown += `**Priority:** ${idea.priority || 'Unset'}\n`;
      markdown += `**Status:** ${idea.status}\n`;
      
      if (idea.tags) {
        markdown += `**Tags:** ${idea.tags}\n`;
      }
      
      markdown += '\n';
      markdown += `${idea.description}\n\n`;
      
      if (includeAnalysis) {
        try {
          const analysis = await this.getIdeaAnalysis(idea);
          markdown += '### Analysis\n\n';
          markdown += `**Strengths:** ${analysis.strengths || analysis.Strengths || 'Not available'}\n\n`;
          markdown += `**Weaknesses:** ${analysis.weaknesses || analysis.Weaknesses || 'Not available'}\n\n`;
          markdown += `**Opportunities:** ${analysis.opportunities || analysis.Opportunities || 'Not available'}\n\n`;
          markdown += `**Threats:** ${analysis.threats || analysis.Threats || 'Not available'}\n\n`;
          markdown += `**Next Steps:** ${analysis.nextSteps || analysis["Next Steps"] || 'Not available'}\n\n`;
        } catch (error) {
          console.error(`Error getting analysis for idea ${idea.id}:`, error);
        }
      }
      
      markdown += '---\n\n';
    }
    
    return markdown;
  }
  
  /**
   * Format ideas as CSV
   */
  private formatIdeasAsCsv(ideas: any[]): string {
    if (ideas.length === 0) {
      return '';
    }
    
    // Determine CSV headers
    const headers = ['id', 'title', 'description', 'category', 'status', 'priority', 'tags', 'createdAt'];
    let csv = headers.join(',') + '\n';
    
    // Add rows
    for (const idea of ideas) {
      const row = [
        idea.id,
        this.escapeCsvField(idea.title),
        this.escapeCsvField(idea.description),
        this.escapeCsvField(idea.category),
        this.escapeCsvField(idea.status),
        idea.priority || '',
        this.escapeCsvField(idea.tags),
        idea.createdAt ? new Date(idea.createdAt).toISOString() : ''
      ];
      
      csv += row.join(',') + '\n';
    }
    
    return csv;
  }
  
  /**
   * Format ideas as plain text
   */
  private async formatIdeasAsText(ideas: any[], includeAnalysis: boolean): Promise<string> {
    let text = 'PINKSYNC IDEAS\n\n';
    
    for (const idea of ideas) {
      text += `TITLE: ${idea.title}\n`;
      text += `CATEGORY: ${idea.category || 'Uncategorized'}\n`;
      text += `PRIORITY: ${idea.priority || 'Unset'}\n`;
      text += `STATUS: ${idea.status}\n`;
      
      if (idea.tags) {
        text += `TAGS: ${idea.tags}\n`;
      }
      
      text += '\n';
      text += `DESCRIPTION:\n${idea.description}\n\n`;
      
      if (includeAnalysis) {
        try {
          const analysis = await this.getIdeaAnalysis(idea);
          text += 'ANALYSIS:\n';
          text += `STRENGTHS: ${analysis.strengths || analysis.Strengths || 'Not available'}\n\n`;
          text += `WEAKNESSES: ${analysis.weaknesses || analysis.Weaknesses || 'Not available'}\n\n`;
          text += `OPPORTUNITIES: ${analysis.opportunities || analysis.Opportunities || 'Not available'}\n\n`;
          text += `THREATS: ${analysis.threats || analysis.Threats || 'Not available'}\n\n`;
          text += `NEXT STEPS: ${analysis.nextSteps || analysis["Next Steps"] || 'Not available'}\n\n`;
        } catch (error) {
          console.error(`Error getting analysis for idea ${idea.id}:`, error);
        }
      }
      
      text += '------------------------\n\n';
    }
    
    return text;
  }
  
  /**
   * Escape a CSV field
   */
  private escapeCsvField(field: string): string {
    if (!field) {
      return '';
    }
    
    // If field contains comma, newline, or double-quote, enclose in double-quotes
    if (/[,\n"]/.test(field)) {
      return `"${field.replace(/"/g, '""')}"`;
    }
    
    return field;
  }
  
  /**
   * Parse ideas from an imported file
   */
  private async parseIdeasFromFile(
    content: string,
    format: IdeaFormat
  ): Promise<any[]> {
    switch (format) {
      case IdeaFormat.JSON:
        return this.parseIdeasFromJson(content);
      case IdeaFormat.MARKDOWN:
        return this.parseIdeasFromMarkdown(content);
      case IdeaFormat.CSV:
        return this.parseIdeasFromCsv(content);
      case IdeaFormat.TEXT:
        return this.parseIdeasFromText(content);
      default:
        throw new Error(`Unsupported format: ${format}`);
    }
  }
  
  /**
   * Parse ideas from JSON format
   */
  private parseIdeasFromJson(content: string): any[] {
    try {
      const parsed = JSON.parse(content);
      
      if (Array.isArray(parsed)) {
        return parsed.map(idea => ({
          title: idea.title,
          description: idea.description,
          category: idea.category,
          status: idea.status || 'draft',
          priority: idea.priority,
          tags: idea.tags
        }));
      } else if (typeof parsed === 'object' && parsed !== null) {
        // Handle single object case
        return [{
          title: parsed.title,
          description: parsed.description,
          category: parsed.category,
          status: parsed.status || 'draft',
          priority: parsed.priority,
          tags: parsed.tags
        }];
      }
      
      throw new Error('Invalid JSON format for ideas');
    } catch (error) {
      console.error('Error parsing JSON ideas:', error);
      throw error;
    }
  }
  
  /**
   * Parse ideas from CSV format
   */
  private parseIdeasFromCsv(content: string): any[] {
    const lines = content.split('\n');
    if (lines.length < 2) {
      return [];
    }
    
    const headers = lines[0].split(',');
    const ideas = [];
    
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      
      const fields = this.parseCsvLine(line);
      const idea: any = {};
      
      for (let j = 0; j < headers.length; j++) {
        const header = headers[j].trim();
        idea[header] = fields[j];
      }
      
      // Ensure required fields
      if (idea.title && idea.description) {
        ideas.push({
          title: idea.title,
          description: idea.description,
          category: idea.category || null,
          status: idea.status || 'draft',
          priority: idea.priority ? parseInt(idea.priority) : 5,
          tags: idea.tags || null
        });
      }
    }
    
    return ideas;
  }
  
  /**
   * Parse a single CSV line, handling quoted fields
   */
  private parseCsvLine(line: string): string[] {
    const fields = [];
    let field = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      const nextChar = i < line.length - 1 ? line[i + 1] : '';
      
      if (char === '"') {
        if (inQuotes && nextChar === '"') {
          // Quote escape
          field += '"';
          i++;
        } else {
          // Toggle quote mode
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        // End of field
        fields.push(field);
        field = '';
      } else {
        field += char;
      }
    }
    
    // Add the last field
    fields.push(field);
    
    return fields;
  }
  
  /**
   * Parse ideas from Markdown format
   * This uses OpenAI to extract structured data from the markdown
   */
  private async parseIdeasFromMarkdown(content: string): Promise<any[]> {
    try {
      // Use OpenAI to extract structured ideas from markdown
      const messages = [
        {
          role: 'system' as const,
          content: `You are an expert at extracting structured data from markdown text. 
          Extract entrepreneurial ideas with the following fields:
          - title: The title or name of the idea
          - description: The detailed description of the idea
          - category: The category of the idea (if specified)
          - priority: A number from 1-10 indicating importance (if specified)
          - status: The current status (draft, in_progress, etc.)
          - tags: Comma-separated tags (if specified)
          
          Return the data as a JSON array of objects.`
        },
        {
          role: 'user' as const,
          content: content
        }
      ];
      
      const completion = await openaiService.chat.generateChatCompletion(
        messages,
        { model: 'gpt-4o' }
      );
      
      // Parse the JSON response
      const responseText = completion.content.trim();
      const jsonMatch = responseText.match(/```json\n([\s\S]*?)\n```/) || 
                        responseText.match(/```\n([\s\S]*?)\n```/) ||
                        responseText.match(/`([\s\S]*?)`/);
      
      const jsonContent = jsonMatch ? jsonMatch[1] : responseText;
      
      const parsedIdeas = JSON.parse(jsonContent);
      
      if (!Array.isArray(parsedIdeas)) {
        throw new Error('Invalid response format from AI parsing');
      }
      
      return parsedIdeas.map(idea => ({
        title: idea.title,
        description: idea.description,
        category: idea.category || null,
        status: idea.status || 'draft',
        priority: idea.priority ? parseInt(idea.priority) : 5,
        tags: idea.tags || null
      }));
    } catch (error) {
      console.error('Error parsing markdown ideas:', error);
      throw error;
    }
  }
  
  /**
   * Parse ideas from plain text format
   * This uses OpenAI to extract structured data from the text
   */
  private async parseIdeasFromText(content: string): Promise<any[]> {
    try {
      // Similar approach to markdown parsing
      const messages = [
        {
          role: 'system' as const,
          content: `You are an expert at extracting structured data from plain text. 
          Extract entrepreneurial ideas with the following fields:
          - title: The title or name of the idea
          - description: The detailed description of the idea
          - category: The category of the idea (if specified)
          - priority: A number from 1-10 indicating importance (if specified)
          - status: The current status (draft, in_progress, etc.)
          - tags: Comma-separated tags (if specified)
          
          Return the data as a JSON array of objects.`
        },
        {
          role: 'user' as const,
          content: content
        }
      ];
      
      const completion = await openaiService.chat.generateChatCompletion(
        messages,
        { model: 'gpt-4o' }
      );
      
      // Parse the JSON response
      const responseText = completion.content.trim();
      const jsonMatch = responseText.match(/```json\n([\s\S]*?)\n```/) || 
                        responseText.match(/```\n([\s\S]*?)\n```/) ||
                        responseText.match(/`([\s\S]*?)`/);
      
      const jsonContent = jsonMatch ? jsonMatch[1] : responseText;
      
      const parsedIdeas = JSON.parse(jsonContent);
      
      if (!Array.isArray(parsedIdeas)) {
        throw new Error('Invalid response format from AI parsing');
      }
      
      return parsedIdeas.map(idea => ({
        title: idea.title,
        description: idea.description,
        category: idea.category || null,
        status: idea.status || 'draft',
        priority: idea.priority ? parseInt(idea.priority) : 5,
        tags: idea.tags || null
      }));
    } catch (error) {
      console.error('Error parsing text ideas:', error);
      throw error;
    }
  }
  
  /**
   * Get file extension for the specified format
   */
  private getFileExtensionForFormat(format: IdeaFormat): string {
    switch (format) {
      case IdeaFormat.JSON:
        return '.json';
      case IdeaFormat.MARKDOWN:
        return '.md';
      case IdeaFormat.CSV:
        return '.csv';
      case IdeaFormat.TEXT:
        return '.txt';
      default:
        return '.txt';
    }
  }
  
  /**
   * Get MIME type for the specified format
   */
  private getMimeTypeForFormat(format: IdeaFormat): string {
    switch (format) {
      case IdeaFormat.JSON:
        return 'application/json';
      case IdeaFormat.MARKDOWN:
        return 'text/markdown';
      case IdeaFormat.CSV:
        return 'text/csv';
      case IdeaFormat.TEXT:
        return 'text/plain';
      default:
        return 'text/plain';
    }
  }
  
  /**
   * Get AI analysis for an idea
   */
  private async getIdeaAnalysis(idea: any): Promise<any> {
    // Use OpenAI to analyze the idea
    const messages = [
      {
        role: 'system' as const,
        content: `You are an AI entrepreneurship advisor specialized in analyzing and improving business ideas.
        Analyze the provided idea and provide thoughtful feedback in the following areas:
        1. Strengths - What's strong about this idea?
        2. Weaknesses - What areas need improvement?
        3. Opportunities - What opportunities could be leveraged?
        4. Threats - What potential challenges might arise?
        5. Next Steps - What concrete steps would improve this idea or move it forward?
        
        Format your response as a JSON object with these fields.`
      },
      {
        role: 'user' as const,
        content: `Analyze this entrepreneurial idea:\n\nTitle: ${idea.title}\nDescription: ${idea.description}\nCategory: ${idea.category}`
      }
    ];
    
    const completion = await openaiService.chat.generateChatCompletion(
      messages,
      { model: 'gpt-4o' }
    );
    
    // Extract JSON from the response
    try {
      const responseText = completion.content.trim();
      const jsonMatch = responseText.match(/```json\n([\s\S]*?)\n```/) || 
                        responseText.match(/```\n([\s\S]*?)\n```/) ||
                        responseText.match(/`([\s\S]*?)`/);
      
      const jsonContent = jsonMatch ? jsonMatch[1] : responseText;
      return JSON.parse(jsonContent);
    } catch (error) {
      console.error('Error parsing AI analysis:', error);
      return {
        strengths: 'Analysis not available',
        weaknesses: 'Analysis not available',
        opportunities: 'Analysis not available',
        threats: 'Analysis not available',
        nextSteps: 'Analysis not available'
      };
    }
  }
  
  /**
   * Ensure a directory exists
   */
  private ensureDirectoryExists(dir: string): void {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
}

// Create and export service instance
export const ideaSyncService = new IdeaSyncService();
export default ideaSyncService;