import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import axios from 'axios';
import crypto from 'crypto';

// Define types for Google Sheets integration
export interface GoogleSheetsConfig {
  id: string;
  name: string;
  sheetId: string;  // Google Sheet ID
  tabName?: string; // Optional specific tab name
  apiKey?: string;  // For public sheets
  serviceAccountKey?: string; // For private sheets (JSON key content)
  events: string[];
  createdAt: string;
  lastTriggered?: string;
  lastStatus?: number;
  active: boolean;
  mappingFunction?: string; // Optional JS function as string for data transformation
}

// Type for config creation - active is optional
export type CreateGoogleSheetsConfig = Omit<GoogleSheetsConfig, 'id' | 'createdAt'> & { 
  active?: boolean 
};

export interface SheetUpdateEvent {
  id: string;
  configId: string;
  type: string;
  data: any;
  transformedData?: any; // After mapping function is applied
  timestamp: string;
}

export interface SheetUpdateDelivery {
  id: string;
  configId: string;
  eventId: string;
  timestamp: string;
  status: number;
  response?: string;
  retries: number;
  duration: number;
  rowsUpdated?: number;
}

/**
 * Service for Google Sheets integration
 */
export class GoogleSheetsService {
  private configs: Map<string, GoogleSheetsConfig> = new Map();
  private readonly configsDir: string;
  private readonly deliveriesDir: string;
  private readonly eventsDir: string;
  
  constructor() {
    this.configsDir = path.join(process.cwd(), 'data', 'google_sheets', 'configs');
    this.deliveriesDir = path.join(process.cwd(), 'data', 'google_sheets', 'deliveries');
    this.eventsDir = path.join(process.cwd(), 'data', 'google_sheets', 'events');
    
    // Create directories if they don't exist
    [this.configsDir, this.deliveriesDir, this.eventsDir].forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    });
    
    // Load existing configs
    this.loadConfigs();
    
    console.log("GoogleSheetsService initialized");
  }
  
  /**
   * Load configs from disk
   */
  private loadConfigs(): void {
    try {
      if (!fs.existsSync(this.configsDir)) {
        return;
      }
      
      const files = fs.readdirSync(this.configsDir);
      
      for (const file of files) {
        if (file.endsWith('.json')) {
          try {
            const filePath = path.join(this.configsDir, file);
            const configData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            this.configs.set(configData.id, configData);
          } catch (error) {
            console.error(`Error loading Google Sheets config from ${file}:`, error);
          }
        }
      }
      
      console.log(`Loaded ${this.configs.size} Google Sheets configs`);
    } catch (error) {
      console.error('Error loading Google Sheets configs:', error);
    }
  }
  
  /**
   * Save a config to disk
   */
  private saveConfig(config: GoogleSheetsConfig): void {
    try {
      const filePath = path.join(this.configsDir, `${config.id}.json`);
      fs.writeFileSync(filePath, JSON.stringify(config, null, 2));
    } catch (error) {
      console.error(`Error saving Google Sheets config ${config.id}:`, error);
      throw error;
    }
  }
  
  /**
   * Save an event to disk
   */
  private saveEvent(event: SheetUpdateEvent): void {
    try {
      const filePath = path.join(this.eventsDir, `${event.id}.json`);
      fs.writeFileSync(filePath, JSON.stringify(event, null, 2));
    } catch (error) {
      console.error(`Error saving Google Sheets event ${event.id}:`, error);
      throw error;
    }
  }
  
  /**
   * Save a delivery to disk
   */
  private saveDelivery(delivery: SheetUpdateDelivery): void {
    try {
      const filePath = path.join(this.deliveriesDir, `${delivery.id}.json`);
      fs.writeFileSync(filePath, JSON.stringify(delivery, null, 2));
    } catch (error) {
      console.error(`Error saving Google Sheets delivery ${delivery.id}:`, error);
      throw error;
    }
  }
  
  /**
   * Create a new Google Sheets config
   */
  createConfig(config: CreateGoogleSheetsConfig): GoogleSheetsConfig {
    const id = uuidv4();
    const createdAt = new Date().toISOString();
    
    const newConfig: GoogleSheetsConfig = {
      ...config,
      id,
      createdAt,
      active: config.active !== undefined ? config.active : true
    };
    
    this.configs.set(id, newConfig);
    this.saveConfig(newConfig);
    
    return newConfig;
  }
  
  /**
   * Get a config by ID
   */
  getConfig(id: string): GoogleSheetsConfig | undefined {
    return this.configs.get(id);
  }
  
  /**
   * Update a config
   */
  updateConfig(id: string, updates: Partial<Omit<GoogleSheetsConfig, 'id' | 'createdAt'>>): GoogleSheetsConfig | undefined {
    const config = this.configs.get(id);
    
    if (!config) {
      return undefined;
    }
    
    const updatedConfig: GoogleSheetsConfig = {
      ...config,
      ...updates
    };
    
    this.configs.set(id, updatedConfig);
    this.saveConfig(updatedConfig);
    
    return updatedConfig;
  }
  
  /**
   * Delete a config
   */
  deleteConfig(id: string): boolean {
    if (!this.configs.has(id)) {
      return false;
    }
    
    this.configs.delete(id);
    
    // Delete from disk
    try {
      const filePath = path.join(this.configsDir, `${id}.json`);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
      return true;
    } catch (error) {
      console.error(`Error deleting Google Sheets config ${id}:`, error);
      return false;
    }
  }
  
  /**
   * Get all configs
   */
  getAllConfigs(): GoogleSheetsConfig[] {
    return Array.from(this.configs.values());
  }
  
  /**
   * Trigger a sheet update event
   */
  async triggerEvent(type: string, data: any): Promise<SheetUpdateEvent[]> {
    const eventId = uuidv4();
    const timestamp = new Date().toISOString();
    const events: SheetUpdateEvent[] = [];
    
    // Find configs that listen to this event type
    const matchingConfigs = Array.from(this.configs.values()).filter(
      config => config.active && config.events.includes(type)
    );
    
    // For each matching config, create and process an event
    for (const config of matchingConfigs) {
      // Create event with this specific config
      const event: SheetUpdateEvent = {
        id: `${eventId}-${config.id}`,
        configId: config.id,
        type,
        data,
        timestamp
      };
      
      // Apply mapping function if present
      if (config.mappingFunction) {
        try {
          const mapFunc = new Function('data', config.mappingFunction);
          event.transformedData = mapFunc(data);
        } catch (error) {
          console.error(`Error executing mapping function for config ${config.id}:`, error);
          // Use original data if mapping fails
          event.transformedData = data;
        }
      } else {
        event.transformedData = data;
      }
      
      // Save event
      this.saveEvent(event);
      events.push(event);
      
      // Deliver to Google Sheets
      await this.updateGoogleSheet(config, event);
    }
    
    return events;
  }
  
  /**
   * Update Google Sheet with event data
   */
  private async updateGoogleSheet(config: GoogleSheetsConfig, event: SheetUpdateEvent): Promise<SheetUpdateDelivery> {
    const deliveryId = uuidv4();
    const timestamp = new Date().toISOString();
    const startTime = Date.now();
    
    // Prepare result
    let status = 0;
    let response = '';
    let retries = 0;
    let rowsUpdated = 0;
    
    try {
      // Determine which API to use based on available credentials
      if (config.apiKey) {
        // Use Google Sheets API v4 with API key (for public sheets)
        await this.updateSheetWithApiKey(config, event);
      } else if (config.serviceAccountKey) {
        // Use Google Sheets API with service account (for private sheets)
        await this.updateSheetWithServiceAccount(config, event);
      } else {
        // Use Apps Script Web App as middleware
        await this.updateSheetWithWebhook(config, event);
      }
      
      status = 200;
      response = 'Successfully updated Google Sheet';
      rowsUpdated = Array.isArray(event.transformedData) ? event.transformedData.length : 1;
      
      // Update config last triggered and status
      this.updateConfig(config.id, {
        lastTriggered: timestamp,
        lastStatus: status
      });
    } catch (error: unknown) {
      status = 500;
      response = error instanceof Error ? error.message : 'Error updating Google Sheet';
      retries = 0; // TODO: Implement retry logic
    }
    
    const endTime = Date.now();
    const duration = endTime - startTime;
    
    // Create delivery record
    const delivery: SheetUpdateDelivery = {
      id: deliveryId,
      configId: config.id,
      eventId: event.id,
      timestamp,
      status,
      response,
      retries,
      duration,
      rowsUpdated
    };
    
    // Save delivery
    this.saveDelivery(delivery);
    
    return delivery;
  }
  
  /**
   * Update Google Sheet using API key (for public sheets)
   */
  private async updateSheetWithApiKey(config: GoogleSheetsConfig, event: SheetUpdateEvent): Promise<void> {
    // For demo/placeholder - in production this would use the Sheets API
    console.log(`Updating Google Sheet ${config.sheetId} with API key`);
    console.log('This is a placeholder - API key method not fully implemented');
    
    // In a real implementation, this would use the Google Sheets API v4
    // with an API key, but that only works for public sheets
    throw new Error('API key method not fully implemented');
  }
  
  /**
   * Update Google Sheet using service account (for private sheets)
   */
  private async updateSheetWithServiceAccount(config: GoogleSheetsConfig, event: SheetUpdateEvent): Promise<void> {
    // For demo/placeholder - in production this would use a service account
    console.log(`Updating Google Sheet ${config.sheetId} with service account`);
    console.log('This is a placeholder - service account method not fully implemented');
    
    // In a real implementation, this would use the Google Sheets API v4
    // with a service account for authentication
    throw new Error('Service account method not fully implemented');
  }
  
  /**
   * Update Google Sheet using a webhook to a Google Apps Script Web App
   * This is a common approach for users who don't want to set up API credentials
   */
  private async updateSheetWithWebhook(config: GoogleSheetsConfig, event: SheetUpdateEvent): Promise<void> {
    const { type, transformedData } = event;
    
    // This uses a Google Apps Script Web App as a middleware
    // The user would need to deploy a small Apps Script that accepts webhooks
    // and updates their Google Sheet
    
    // For demonstration purposes, this is how we would send a webhook to a Google Apps Script Web App
    // that the user has deployed
    try {
      let webhookUrl = config.sheetId;
      
      // If this is not a webhook URL but just a sheet ID,
      // explain to the user they need to set up a webhook endpoint
      if (!webhookUrl.startsWith('https://')) {
        throw new Error('No webhook URL provided. User needs to create a Google Apps Script Web App and provide its URL.');
      }
      
      const response = await axios.post(webhookUrl, {
        type,
        data: transformedData,
        tabName: config.tabName,
        timestamp: event.timestamp
      }, {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 30000 // 30 seconds timeout for Google's sometimes slow response
      });
      
      if (response.status !== 200) {
        throw new Error(`Error updating Google Sheet: ${response.statusText}`);
      }
      
      return;
    } catch (error: unknown) {
      console.error('Error updating Google Sheet with webhook:', error);
      throw error;
    }
  }
  
  /**
   * Get sheet update deliveries for a config
   */
  getSheetUpdateDeliveries(configId: string, limit = 10): SheetUpdateDelivery[] {
    try {
      const files = fs.readdirSync(this.deliveriesDir);
      const deliveries: SheetUpdateDelivery[] = [];
      
      for (const file of files) {
        if (file.endsWith('.json')) {
          try {
            const filePath = path.join(this.deliveriesDir, file);
            const delivery = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            
            if (delivery.configId === configId) {
              deliveries.push(delivery);
              
              if (deliveries.length >= limit) {
                break;
              }
            }
          } catch (error) {
            console.error(`Error reading delivery from ${file}:`, error);
          }
        }
      }
      
      // Sort by timestamp descending
      return deliveries.sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
    } catch (error) {
      console.error(`Error getting deliveries for config ${configId}:`, error);
      return [];
    }
  }
  
  /**
   * Get sheet update events
   */
  getSheetUpdateEvents(limit = 10): SheetUpdateEvent[] {
    try {
      const files = fs.readdirSync(this.eventsDir);
      const events: SheetUpdateEvent[] = [];
      
      for (const file of files) {
        if (file.endsWith('.json')) {
          try {
            const filePath = path.join(this.eventsDir, file);
            const event = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            
            events.push(event);
            
            if (events.length >= limit) {
              break;
            }
          } catch (error) {
            console.error(`Error reading event from ${file}:`, error);
          }
        }
      }
      
      // Sort by timestamp descending
      return events.sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
    } catch (error) {
      console.error('Error getting events:', error);
      return [];
    }
  }
  
  /**
   * Generate a Google Apps Script template for the user
   * This creates a script they can paste into Google Apps Script
   * to create a webhook endpoint for their sheet
   */
  generateAppsScriptTemplate(sheetId: string, tabName?: string): string {
    return `/**
 * Google Apps Script Webhook Handler for Google Sheets
 * This script accepts webhook requests and updates a Google Sheet.
 * 
 * To use:
 * 1. Create a new Google Apps Script project from your Google Sheet (Extensions → Apps Script)
 * 2. Replace this code with the code below
 * 3. Deploy as a web app (Deploy → New deployment → Web app)
 *    - Execute as: Me (your Google account)
 *    - Who has access: Anyone (if you want no authentication)
 *    - Or use: Anyone with Google account (more secure)
 * 4. Copy the web app URL and paste it as the sheetId in your Google Sheets config
 */

// Sheet ID to update (change this to your sheet ID)
const SHEET_ID = "${sheetId}";
// Sheet tab/name to update (change this to your sheet tab name)
const SHEET_TAB_NAME = "${tabName || 'Sheet1'}";

/**
 * Handles POST requests to this web app
 */
function doPost(e) {
  try {
    // Parse the request body
    const body = JSON.parse(e.postData.contents);
    
    // Get the sheet
    const ss = SpreadsheetApp.openById(SHEET_ID);
    
    // Use the tab name from the request if provided, otherwise use default
    const tabName = body.tabName || SHEET_TAB_NAME;
    const sheet = ss.getSheetByName(tabName);
    
    if (!sheet) {
      return ContentService
        .createTextOutput(JSON.stringify({ error: 'Sheet tab not found' }))
        .setMimeType(ContentService.MimeType.JSON);
    }
    
    // Process the data
    const result = processData(sheet, body);
    
    // Return success response
    return ContentService
      .createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    // Return error response
    return ContentService
      .createTextOutput(JSON.stringify({ error: error.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Process the data and update the sheet
 */
function processData(sheet, body) {
  const { type, data, timestamp } = body;
  
  // Add a header row if the sheet is empty
  if (sheet.getLastRow() === 0) {
    // Default headers for different event types
    let headers = ['Timestamp', 'Event Type'];
    
    // Add additional headers based on data
    if (Array.isArray(data)) {
      // If data is an array of objects, use the keys from the first object
      if (data.length > 0 && typeof data[0] === 'object') {
        headers = headers.concat(Object.keys(data[0]));
      }
    } else if (typeof data === 'object') {
      // If data is a single object, use its keys
      headers = headers.concat(Object.keys(data));
    }
    
    // Append the header row
    sheet.appendRow(headers);
  }
  
  // Handle different event types
  switch (type) {
    case 'file_sync':
      return handleFileSync(sheet, data, timestamp);
    
    case 'chat_extract':
      return handleChatExtract(sheet, data, timestamp);
    
    case 'platform_connection':
      return handlePlatformConnection(sheet, data, timestamp);
    
    default:
      // Generic handler for any event type
      return handleGenericEvent(sheet, type, data, timestamp);
  }
}

/**
 * Handle file sync events
 */
function handleFileSync(sheet, data, timestamp) {
  // For file syncs, each row represents a single file
  const rowsAdded = [];
  
  if (Array.isArray(data)) {
    // If data is an array of files
    data.forEach(file => {
      const row = [
        timestamp, 
        'file_sync',
        file.relativePath || '',
        file.size || 0,
        file.lastModified || '',
        file.sourcePlatform || '',
        file.destinationPlatform || ''
      ];
      
      sheet.appendRow(row);
      rowsAdded.push(row);
    });
  } else {
    // If data is a summary
    const row = [
      timestamp, 
      'file_sync',
      data.filesProcessed || 0,
      data.filesUpdated || 0,
      data.success ? 'Success' : 'Failed',
      data.errors ? data.errors.join(', ') : ''
    ];
    
    sheet.appendRow(row);
    rowsAdded.push(row);
  }
  
  return { 
    success: true, 
    rowsAdded: rowsAdded.length 
  };
}

/**
 * Handle chat extraction events
 */
function handleChatExtract(sheet, data, timestamp) {
  // For chat extracts
  const row = [
    timestamp, 
    'chat_extract',
    data.totalExtracted || 0,
    data.totalUploaded || 0,
    data.platformType || '',
    data.collectionName || ''
  ];
  
  sheet.appendRow(row);
  
  return { 
    success: true, 
    rowsAdded: 1 
  };
}

/**
 * Handle platform connection events
 */
function handlePlatformConnection(sheet, data, timestamp) {
  // For platform connections
  const row = [
    timestamp, 
    'platform_connection',
    data.name || '',
    data.type || '',
    data.rootPath || '',
    data.active ? 'Active' : 'Inactive'
  ];
  
  sheet.appendRow(row);
  
  return { 
    success: true, 
    rowsAdded: 1 
  };
}

/**
 * Handle any generic event
 */
function handleGenericEvent(sheet, type, data, timestamp) {
  if (Array.isArray(data)) {
    // If data is an array, add each item as a separate row
    const rowsAdded = [];
    
    data.forEach(item => {
      if (typeof item === 'object') {
        const row = [timestamp, type];
        
        // Add each property value to the row
        Object.values(item).forEach(value => {
          row.push(typeof value === 'object' ? JSON.stringify(value) : value);
        });
        
        sheet.appendRow(row);
        rowsAdded.push(row);
      } else {
        // Simple value
        sheet.appendRow([timestamp, type, item]);
        rowsAdded.push([timestamp, type, item]);
      }
    });
    
    return { 
      success: true, 
      rowsAdded: rowsAdded.length 
    };
  } else if (typeof data === 'object') {
    // If data is a single object, add it as one row
    const row = [timestamp, type];
    
    // Add each property value to the row
    Object.values(data).forEach(value => {
      row.push(typeof value === 'object' ? JSON.stringify(value) : value);
    });
    
    sheet.appendRow(row);
    
    return { 
      success: true, 
      rowsAdded: 1 
    };
  } else {
    // Simple value
    sheet.appendRow([timestamp, type, data]);
    
    return { 
      success: true, 
      rowsAdded: 1 
    };
  }
}

/**
 * Handles GET requests to this web app (for testing)
 */
function doGet() {
  return ContentService
    .createTextOutput(JSON.stringify({ 
      status: 'ok', 
      message: 'Webhook endpoint is active. Send POST requests to update the sheet.' 
    }))
    .setMimeType(ContentService.MimeType.JSON);
}`;
  }
}

// Export a singleton instance
export const googleSheetsService = new GoogleSheetsService();