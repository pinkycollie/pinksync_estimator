/**
 * Notion Integration Service
 * 
 * Provides bidirectional sync between PinkSync and Notion.
 * Sources task definitions, project specs, and other data.
 */

import { Client } from '@notionhq/client';
import { logger } from '../../utils/logger';
import EventEmitter from 'events';

// Types for database items
export interface NotionTaskDefinition {
  id: string;
  title: string;
  status: string;
  priority: string;
  assignedTo?: string;
  dueDate?: Date;
  description?: string;
  tags?: string[];
  properties: Record<string, any>;
}

export interface NotionDatabase {
  id: string;
  title: string;
  description?: string;
  lastSync?: Date;
}

export interface NotionConnection {
  id: string;
  name: string;
  databaseIds: string[];
  active: boolean;
  syncFrequency: number; // in minutes
  lastSync?: Date;
}

class NotionIntegrationService extends EventEmitter {
  private notion: Client;
  private databases: Map<string, NotionDatabase> = new Map();
  private connections: NotionConnection[] = [];
  private syncIntervals: Map<string, NodeJS.Timeout> = new Map();
  private isInitialized = false;
  
  constructor() {
    super();
    
    // Initialize Notion client
    const notionApiKey = process.env.NOTION_API_KEY;
    
    if (!notionApiKey) {
      logger.error('Notion API key not found');
      throw new Error('Notion API key is required for NotionIntegrationService');
    }
    
    this.notion = new Client({ auth: notionApiKey });
  }
  
  /**
   * Initialize the service with connections
   */
  async initialize(connections: NotionConnection[] = []) {
    try {
      logger.info('Initializing Notion service');
      
      this.connections = connections;
      
      // Set up database sync intervals for each connection
      for (const connection of this.connections) {
        if (connection.active) {
          this.setupSyncInterval(connection);
        }
      }
      
      this.isInitialized = true;
      logger.info(`Initialized Notion service with ${this.connections.length} connections`);
      
      return true;
    } catch (error) {
      logger.error('Failed to initialize Notion service', error);
      return false;
    }
  }
  
  /**
   * Set up sync interval for a connection
   */
  private setupSyncInterval(connection: NotionConnection) {
    if (this.syncIntervals.has(connection.id)) {
      clearInterval(this.syncIntervals.get(connection.id)!);
    }
    
    // Set up interval based on connection frequency
    const interval = setInterval(async () => {
      try {
        await this.syncDatabases(connection);
      } catch (error) {
        logger.error(`Error syncing databases for connection ${connection.id}`, error);
      }
    }, connection.syncFrequency * 60 * 1000);
    
    this.syncIntervals.set(connection.id, interval);
  }
  
  /**
   * Sync all databases for a connection
   */
  private async syncDatabases(connection: NotionConnection) {
    logger.info(`Syncing databases for connection ${connection.name}`);
    
    for (const databaseId of connection.databaseIds) {
      try {
        await this.syncDatabase(databaseId);
      } catch (error) {
        logger.error(`Error syncing database ${databaseId}`, error);
      }
    }
    
    // Update last sync time
    connection.lastSync = new Date();
    
    // Emit sync event
    this.emit('sync:completed', {
      connectionId: connection.id,
      timestamp: connection.lastSync
    });
  }
  
  /**
   * Sync a single database
   */
  private async syncDatabase(databaseId: string) {
    try {
      // Fetch database metadata
      const database = await this.notion.databases.retrieve({
        database_id: databaseId
      });
      
      // Store database info
      this.databases.set(databaseId, {
        id: databaseId,
        title: database.title.map((text: any) => text.plain_text).join(''),
        lastSync: new Date()
      });
      
      // Query database items
      const response = await this.notion.databases.query({
        database_id: databaseId,
        sorts: [
          {
            property: 'Created time',
            direction: 'descending'
          }
        ]
      });
      
      // Process items
      const items = response.results.map((item: any) => this.mapNotionItemToTask(item));
      
      logger.info(`Synced ${items.length} items from database ${databaseId}`);
      
      // Emit items event
      this.emit('items:updated', {
        databaseId,
        items
      });
      
      return items;
    } catch (error) {
      logger.error(`Error syncing database ${databaseId}`, error);
      throw error;
    }
  }
  
  /**
   * Map a Notion page to a task definition
   */
  private mapNotionItemToTask(item: any): NotionTaskDefinition {
    const properties = item.properties;
    const title = properties.Name?.title?.[0]?.plain_text || 
                 properties.Title?.title?.[0]?.plain_text || 
                 'Untitled';
    
    // Extract status and other properties
    const status = properties.Status?.select?.name || 'Not Started';
    const priority = properties.Priority?.select?.name || 'Medium';
    const description = properties.Description?.rich_text?.[0]?.plain_text || '';
    const tags = properties.Tags?.multi_select?.map((tag: any) => tag.name) || [];
    
    // Convert to our task format
    return {
      id: item.id,
      title,
      status,
      priority,
      description,
      tags,
      properties
    };
  }
  
  /**
   * Fetch all tasks from a database
   */
  async getTasks(databaseId: string): Promise<NotionTaskDefinition[]> {
    try {
      const response = await this.notion.databases.query({
        database_id: databaseId
      });
      
      return response.results.map((item: any) => this.mapNotionItemToTask(item));
    } catch (error) {
      logger.error(`Error fetching tasks from database ${databaseId}`, error);
      throw error;
    }
  }
  
  /**
   * Update a task in Notion
   */
  async updateTask(taskId: string, updates: Partial<NotionTaskDefinition>): Promise<boolean> {
    try {
      // Convert our updates to Notion format
      const properties: any = {};
      
      if (updates.title) {
        properties.Name = {
          title: [
            {
              text: {
                content: updates.title
              }
            }
          ]
        };
      }
      
      if (updates.status) {
        properties.Status = {
          select: {
            name: updates.status
          }
        };
      }
      
      if (updates.priority) {
        properties.Priority = {
          select: {
            name: updates.priority
          }
        };
      }
      
      if (updates.description) {
        properties.Description = {
          rich_text: [
            {
              text: {
                content: updates.description
              }
            }
          ]
        };
      }
      
      // Update the page
      await this.notion.pages.update({
        page_id: taskId,
        properties
      });
      
      return true;
    } catch (error) {
      logger.error(`Error updating task ${taskId}`, error);
      return false;
    }
  }
  
  /**
   * Create a new task in Notion
   */
  async createTask(databaseId: string, task: Partial<NotionTaskDefinition>): Promise<string | null> {
    try {
      // Convert task to Notion format
      const properties: any = {
        Name: {
          title: [
            {
              text: {
                content: task.title || 'New Task'
              }
            }
          ]
        }
      };
      
      if (task.status) {
        properties.Status = {
          select: {
            name: task.status
          }
        };
      }
      
      if (task.priority) {
        properties.Priority = {
          select: {
            name: task.priority
          }
        };
      }
      
      if (task.description) {
        properties.Description = {
          rich_text: [
            {
              text: {
                content: task.description
              }
            }
          ]
        };
      }
      
      if (task.tags && task.tags.length > 0) {
        properties.Tags = {
          multi_select: task.tags.map(tag => ({ name: tag }))
        };
      }
      
      // Create the page
      const response = await this.notion.pages.create({
        parent: {
          database_id: databaseId
        },
        properties
      });
      
      return response.id;
    } catch (error) {
      logger.error(`Error creating task in database ${databaseId}`, error);
      return null;
    }
  }
  
  /**
   * Get all connections
   */
  getConnections(): NotionConnection[] {
    return this.connections;
  }
  
  /**
   * Add a new connection
   */
  addConnection(connection: NotionConnection): boolean {
    try {
      this.connections.push(connection);
      
      if (connection.active) {
        this.setupSyncInterval(connection);
      }
      
      return true;
    } catch (error) {
      logger.error('Error adding connection', error);
      return false;
    }
  }
  
  /**
   * Update a connection
   */
  updateConnection(connectionId: string, updates: Partial<NotionConnection>): boolean {
    try {
      const connectionIndex = this.connections.findIndex(conn => conn.id === connectionId);
      
      if (connectionIndex === -1) {
        return false;
      }
      
      const connection = { ...this.connections[connectionIndex], ...updates };
      this.connections[connectionIndex] = connection;
      
      // Update sync interval if active status or frequency changed
      if (updates.active !== undefined || updates.syncFrequency !== undefined) {
        this.setupSyncInterval(connection);
      }
      
      return true;
    } catch (error) {
      logger.error(`Error updating connection ${connectionId}`, error);
      return false;
    }
  }
  
  /**
   * Remove a connection
   */
  removeConnection(connectionId: string): boolean {
    try {
      const connectionIndex = this.connections.findIndex(conn => conn.id === connectionId);
      
      if (connectionIndex === -1) {
        return false;
      }
      
      // Clear sync interval
      if (this.syncIntervals.has(connectionId)) {
        clearInterval(this.syncIntervals.get(connectionId)!);
        this.syncIntervals.delete(connectionId);
      }
      
      // Remove connection
      this.connections.splice(connectionIndex, 1);
      
      return true;
    } catch (error) {
      logger.error(`Error removing connection ${connectionId}`, error);
      return false;
    }
  }
  
  /**
   * Check if the service is initialized
   */
  isReady(): boolean {
    return this.isInitialized;
  }
}

// Create singleton instance
const notionIntegrationService = new NotionIntegrationService();

export default notionIntegrationService;