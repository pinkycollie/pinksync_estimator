/**
 * PinkSync - Notion Integration Service
 * 
 * This service provides integration with Notion for PinkSync, allowing ideas to be
 * synchronized with Notion databases and documentation to be created and managed.
 * 
 * Follows Pinky's "idea, build, grow, manage" collaborative workflow with AI hub integration.
 */

import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { Client } from '@notionhq/client';
import { storage } from '../../storage';
import { 
  NotionConnection, 
  NotionIntegration,
  NotionDatabaseType as SchemaNotionDatabaseType
} from '../../../shared/notionSchema';

/**
 * Notion database type
 */
export enum NotionDatabaseType {
  IDEAS = 'ideas',
  PROJECTS = 'projects',
  TASKS = 'tasks',
  DOCUMENTATION = 'documentation',
  TRENDS = 'trends',
  VALIDATIONS = 'validations',
  CHECKPOINTS = 'checkpoints',
  CUSTOM = 'custom'
}

/**
 * Configuration for a Notion database
 */
export interface NotionDatabaseConfig {
  id: string;
  type: NotionDatabaseType;
  name: string;
  description?: string;
  schema?: Record<string, any>;
  customMapping?: Record<string, string>;
}

/**
 * Notion connection configuration
 */
export interface NotionConnectionConfig {
  id: string;
  name: string;
  authToken: string;
  workspaceId?: string;
  databases: NotionDatabaseConfig[];
  defaultDatabase?: string;
  webhookUrl?: string;
  lastSync?: Date;
  isActive: boolean;
}

/**
 * Options for syncing an idea to Notion
 */
export interface IdeaToNotionOptions {
  ideaId: number;
  connectionId: string;
  databaseId?: string;
  includeAnalysis?: boolean;
  includeValidation?: boolean;
  includeFiles?: boolean;
  asTemplate?: boolean;
  templateType?: 'project' | 'document' | 'task' | 'custom';
  templateProperties?: Record<string, any>;
}

/**
 * Options for importing content from Notion
 */
export interface NotionImportOptions {
  connectionId: string;
  databaseId: string;
  pageId?: string; // If specified, import a single page, otherwise import the whole database
  asIdea?: boolean; // Whether to import as an idea or just as content
  userId?: number; // User ID to associate with imported content
  categoryMapping?: Record<string, string>; // Map Notion categories to PinkSync categories
  statusMapping?: Record<string, string>; // Map Notion statuses to PinkSync statuses
  limit?: number; // Maximum number of items to import
}

/**
 * Result of a Notion operation
 */
export interface NotionOperationResult {
  success: boolean;
  message: string;
  data?: any;
  error?: any;
}

/**
 * Notion Integration Service
 */
class NotionService {
  private clients: Map<string, Client> = new Map();
  
  constructor() {
    this.initialize();
  }
  
  /**
   * Initialize the Notion service
   */
  async initialize(): Promise<void> {
    try {
      // Load connections from storage
      const connections = await storage.getNotionConnections();
      
      // Initialize clients for each active connection
      for (const connection of connections) {
        if (connection.isActive && connection.authToken) {
          this.initializeClient(connection.id, connection.authToken);
        }
      }
      
      console.log(`Initialized Notion service with ${this.clients.size} connections`);
    } catch (error) {
      console.error('Error initializing Notion service:', error);
    }
  }
  
  /**
   * Initialize a Notion client
   */
  initializeClient(connectionId: string, authToken: string): void {
    this.clients.set(connectionId, new Client({ auth: authToken }));
  }
  
  /**
   * Get a Notion client for a connection
   */
  getClient(connectionId: string): Client | null {
    return this.clients.get(connectionId) || null;
  }
  
  /**
   * Add a Notion connection
   */
  async addConnection(config: Omit<NotionConnectionConfig, 'id'>): Promise<NotionConnectionConfig> {
    try {
      const connectionId = uuidv4();
      
      // Initialize client
      this.initializeClient(connectionId, config.authToken);
      
      // Test connection
      const client = this.getClient(connectionId);
      if (!client) {
        throw new Error('Failed to initialize Notion client');
      }
      
      // Verify the token works by getting user info
      await client.users.me();
      
      // Save connection to storage
      const connection: NotionConnectionConfig = {
        ...config,
        id: connectionId,
        databases: config.databases || [],
        isActive: true
      };
      
      await storage.saveNotionConnection(connection);
      
      return connection;
    } catch (error: any) {
      console.error('Error adding Notion connection:', error);
      throw new Error(`Failed to add Notion connection: ${error.message}`);
    }
  }
  
  /**
   * Update a Notion connection
   */
  async updateConnection(
    connectionId: string, 
    updates: Partial<Omit<NotionConnectionConfig, 'id'>>
  ): Promise<NotionConnectionConfig> {
    try {
      // Get existing connection
      const existingConnection = await storage.getNotionConnection(connectionId);
      if (!existingConnection) {
        throw new Error(`Notion connection not found: ${connectionId}`);
      }
      
      // If auth token is being updated, re-initialize client
      if (updates.authToken && updates.authToken !== existingConnection.authToken) {
        this.initializeClient(connectionId, updates.authToken);
        
        // Test new token
        const client = this.getClient(connectionId);
        if (!client) {
          throw new Error('Failed to initialize Notion client with new token');
        }
        
        // Verify the token works
        await client.users.me();
      }
      
      // Update connection
      const updatedConnection: NotionConnectionConfig = {
        ...existingConnection,
        ...updates
      };
      
      await storage.saveNotionConnection(updatedConnection);
      
      return updatedConnection;
    } catch (error: any) {
      console.error('Error updating Notion connection:', error);
      throw new Error(`Failed to update Notion connection: ${error.message}`);
    }
  }
  
  /**
   * Remove a Notion connection
   */
  async removeConnection(connectionId: string): Promise<boolean> {
    try {
      // Remove client
      this.clients.delete(connectionId);
      
      // Remove from storage
      await storage.deleteNotionConnection(connectionId);
      
      return true;
    } catch (error: any) {
      console.error('Error removing Notion connection:', error);
      throw new Error(`Failed to remove Notion connection: ${error.message}`);
    }
  }
  
  /**
   * Get available Notion connections
   */
  async getConnections(): Promise<NotionConnectionConfig[]> {
    try {
      return await storage.getNotionConnections();
    } catch (error: any) {
      console.error('Error getting Notion connections:', error);
      throw new Error(`Failed to get Notion connections: ${error.message}`);
    }
  }
  
  /**
   * Get a Notion connection by ID
   */
  async getConnection(connectionId: string): Promise<NotionConnectionConfig | null> {
    try {
      return await storage.getNotionConnection(connectionId);
    } catch (error: any) {
      console.error('Error getting Notion connection:', error);
      throw new Error(`Failed to get Notion connection: ${error.message}`);
    }
  }
  
  /**
   * Add a database to a Notion connection
   */
  async addDatabase(
    connectionId: string, 
    database: Omit<NotionDatabaseConfig, 'id'>
  ): Promise<NotionDatabaseConfig> {
    try {
      // Get connection
      const connection = await this.getConnection(connectionId);
      if (!connection) {
        throw new Error(`Notion connection not found: ${connectionId}`);
      }
      
      // Add database
      const databaseConfig: NotionDatabaseConfig = {
        ...database,
        id: uuidv4()
      };
      
      // Update connection
      const updatedDatabases = [...connection.databases, databaseConfig];
      await this.updateConnection(connectionId, { databases: updatedDatabases });
      
      return databaseConfig;
    } catch (error: any) {
      console.error('Error adding database to Notion connection:', error);
      throw new Error(`Failed to add database to Notion connection: ${error.message}`);
    }
  }
  
  /**
   * Update a database in a Notion connection
   */
  async updateDatabase(
    connectionId: string,
    databaseId: string,
    updates: Partial<Omit<NotionDatabaseConfig, 'id'>>
  ): Promise<NotionDatabaseConfig> {
    try {
      // Get connection
      const connection = await this.getConnection(connectionId);
      if (!connection) {
        throw new Error(`Notion connection not found: ${connectionId}`);
      }
      
      // Find database
      const index = connection.databases.findIndex(db => db.id === databaseId);
      if (index === -1) {
        throw new Error(`Database not found in connection: ${databaseId}`);
      }
      
      // Update database
      const updatedDatabase: NotionDatabaseConfig = {
        ...connection.databases[index],
        ...updates
      };
      
      // Update connection
      const updatedDatabases = [...connection.databases];
      updatedDatabases[index] = updatedDatabase;
      await this.updateConnection(connectionId, { databases: updatedDatabases });
      
      return updatedDatabase;
    } catch (error: any) {
      console.error('Error updating database in Notion connection:', error);
      throw new Error(`Failed to update database in Notion connection: ${error.message}`);
    }
  }
  
  /**
   * Remove a database from a Notion connection
   */
  async removeDatabase(connectionId: string, databaseId: string): Promise<boolean> {
    try {
      // Get connection
      const connection = await this.getConnection(connectionId);
      if (!connection) {
        throw new Error(`Notion connection not found: ${connectionId}`);
      }
      
      // Remove database
      const updatedDatabases = connection.databases.filter(db => db.id !== databaseId);
      
      // Update connection
      await this.updateConnection(connectionId, { databases: updatedDatabases });
      
      return true;
    } catch (error: any) {
      console.error('Error removing database from Notion connection:', error);
      throw new Error(`Failed to remove database from Notion connection: ${error.message}`);
    }
  }
  
  /**
   * Sync an idea to Notion
   * Follows the "idea, build, grow, manage" collaborative workflow
   */
  async syncIdeaToNotion(options: IdeaToNotionOptions): Promise<NotionOperationResult> {
    try {
      const { 
        ideaId, 
        connectionId, 
        databaseId,
        includeAnalysis = false,
        includeValidation = false,
        includeFiles = false,
        asTemplate = false,
        templateType = 'document',
        templateProperties = {}
      } = options;
      
      // Get idea
      const idea = await storage.getIdeaById(ideaId);
      if (!idea) {
        return {
          success: false,
          message: `Idea not found: ${ideaId}`
        };
      }
      
      // Get connection
      const connection = await this.getConnection(connectionId);
      if (!connection) {
        return {
          success: false,
          message: `Notion connection not found: ${connectionId}`
        };
      }
      
      // Get client
      const client = this.getClient(connectionId);
      if (!client) {
        return {
          success: false,
          message: 'Notion client not available'
        };
      }
      
      // Determine database to use
      const targetDatabaseId = databaseId || connection.defaultDatabase;
      
      if (!targetDatabaseId) {
        return {
          success: false,
          message: 'No target database specified or set as default'
        };
      }
      
      // Find database config
      const databaseConfig = connection.databases.find(db => db.id === targetDatabaseId);
      
      if (!databaseConfig) {
        return {
          success: false,
          message: `Database not found in connection: ${targetDatabaseId}`
        };
      }
      
      // Get additional data
      let analysis = null;
      let validation = null;
      let files = [];
      
      if (includeAnalysis) {
        analysis = await storage.getIdeaAnalysisByIdeaId(ideaId);
      }
      
      if (includeValidation) {
        validation = await storage.getIdeaValidationsByIdeaId(ideaId);
      }
      
      if (includeFiles && idea.relatedFiles) {
        // Get file details
        files = Array.isArray(idea.relatedFiles) ? idea.relatedFiles : [];
      }
      
      // Create page properties
      const properties: Record<string, any> = {};
      
      // Basic properties
      properties.Name = {
        title: [
          {
            text: {
              content: idea.title
            }
          }
        ]
      };
      
      // Status
      if (idea.status) {
        properties.Status = {
          select: {
            name: idea.status
          }
        };
      }
      
      // Category
      if (idea.category) {
        properties.Category = {
          select: {
            name: idea.category
          }
        };
      }
      
      // Priority
      if (idea.priority) {
        properties.Priority = {
          number: idea.priority
        };
      }
      
      // Due date
      if (idea.dueDate) {
        properties['Due Date'] = {
          date: {
            start: new Date(idea.dueDate).toISOString()
          }
        };
      }
      
      // Timestamps
      properties['Created At'] = {
        date: {
          start: new Date(idea.createdAt).toISOString()
        }
      };
      
      properties['Updated At'] = {
        date: {
          start: new Date(idea.updatedAt).toISOString()
        }
      };
      
      // PinkSync ID for reference
      properties['PinkSync ID'] = {
        number: idea.id
      };
      
      // Type
      properties.Type = {
        select: {
          name: asTemplate ? 'Template' : 'Idea'
        }
      };
      
      // If using as template, add template-specific properties
      if (asTemplate) {
        properties.Template = {
          select: {
            name: templateType.charAt(0).toUpperCase() + templateType.slice(1)
          }
        };
        
        // Add any custom template properties
        for (const [key, value] of Object.entries(templateProperties)) {
          if (typeof value === 'string') {
            properties[key] = {
              rich_text: [
                {
                  text: {
                    content: value
                  }
                }
              ]
            };
          } else if (typeof value === 'number') {
            properties[key] = {
              number: value
            };
          } else if (value instanceof Date) {
            properties[key] = {
              date: {
                start: value.toISOString()
              }
            };
          } else if (typeof value === 'boolean') {
            properties[key] = {
              checkbox: value
            };
          }
        }
      }
      
      // Create page content
      const children = [];
      
      // Add idea description
      children.push({
        object: 'block',
        type: 'paragraph',
        paragraph: {
          rich_text: [
            {
              type: 'text',
              text: {
                content: idea.description || 'No description provided'
              }
            }
          ]
        }
      });
      
      // Add separator
      children.push({
        object: 'block',
        type: 'divider',
        divider: {}
      });
      
      // Add analysis if available
      if (analysis) {
        children.push({
          object: 'block',
          type: 'heading_2',
          heading_2: {
            rich_text: [
              {
                type: 'text',
                text: {
                  content: 'Analysis'
                }
              }
            ]
          }
        });
        
        children.push({
          object: 'block',
          type: 'paragraph',
          paragraph: {
            rich_text: [
              {
                type: 'text',
                text: {
                  content: JSON.stringify(analysis, null, 2)
                }
              }
            ]
          }
        });
        
        children.push({
          object: 'block',
          type: 'divider',
          divider: {}
        });
      }
      
      // Add validation if available
      if (validation && validation.length > 0) {
        children.push({
          object: 'block',
          type: 'heading_2',
          heading_2: {
            rich_text: [
              {
                type: 'text',
                text: {
                  content: 'Validation'
                }
              }
            ]
          }
        });
        
        for (const val of validation) {
          children.push({
            object: 'block',
            type: 'paragraph',
            paragraph: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: `Validation Date: ${new Date(val.validationDate).toLocaleDateString()}`
                  }
                }
              ]
            }
          });
          
          children.push({
            object: 'block',
            type: 'paragraph',
            paragraph: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: `Overall Result: ${val.overallResult}`
                  }
                }
              ]
            }
          });
          
          children.push({
            object: 'block',
            type: 'paragraph',
            paragraph: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: JSON.stringify(val, null, 2)
                  }
                }
              ]
            }
          });
        }
        
        children.push({
          object: 'block',
          type: 'divider',
          divider: {}
        });
      }
      
      // Add files if available
      if (files.length > 0) {
        children.push({
          object: 'block',
          type: 'heading_2',
          heading_2: {
            rich_text: [
              {
                type: 'text',
                text: {
                  content: 'Related Files'
                }
              }
            ]
          }
        });
        
        // Add bullet list of files
        for (const file of files) {
          children.push({
            object: 'block',
            type: 'bulleted_list_item',
            bulleted_list_item: {
              rich_text: [
                {
                  type: 'text',
                  text: {
                    content: file.name || 'Unknown file'
                  }
                }
              ]
            }
          });
        }
      }
      
      // Create page in Notion
      const response = await client.pages.create({
        parent: {
          database_id: databaseConfig.id
        },
        properties,
        children
      });
      
      // Store the mapping between PinkSync idea and Notion page
      await storage.createNotionIntegration({
        ideaId: idea.id,
        connectionId,
        notionPageId: response.id,
        notionDatabaseId: databaseConfig.id,
        syncedAt: new Date(),
        lastSyncedAt: new Date()
      });
      
      // Update connection last sync time
      await this.updateConnection(connectionId, { lastSync: new Date() });
      
      return {
        success: true,
        message: 'Idea successfully synced to Notion',
        data: {
          notionPageId: response.id,
          notionUrl: `https://notion.so/${response.id.replace(/-/g, '')}`
        }
      };
    } catch (error: any) {
      console.error('Error syncing idea to Notion:', error);
      return {
        success: false,
        message: `Failed to sync idea to Notion: ${error.message}`,
        error
      };
    }
  }
  
  /**
   * Import content from Notion
   */
  async importFromNotion(options: NotionImportOptions): Promise<NotionOperationResult> {
    try {
      const {
        connectionId,
        databaseId,
        pageId,
        asIdea = true,
        userId,
        categoryMapping = {},
        statusMapping = {},
        limit = 100
      } = options;
      
      // Get connection
      const connection = await this.getConnection(connectionId);
      if (!connection) {
        return {
          success: false,
          message: `Notion connection not found: ${connectionId}`
        };
      }
      
      // Get client
      const client = this.getClient(connectionId);
      if (!client) {
        return {
          success: false,
          message: 'Notion client not available'
        };
      }
      
      // Find database config
      const databaseConfig = connection.databases.find(db => db.id === databaseId);
      
      if (!databaseConfig) {
        return {
          success: false,
          message: `Database not found in connection: ${databaseId}`
        };
      }
      
      // If pageId is specified, import a single page
      if (pageId) {
        // Get page
        const page = await client.pages.retrieve({ page_id: pageId });
        
        // Convert to idea if needed
        if (asIdea && userId) {
          // Extract properties
          const properties = page.properties as Record<string, any>;
          
          // Get title
          const titleProp = Object.values(properties).find(prop => prop.type === 'title');
          const title = titleProp?.title?.[0]?.text?.content || 'Imported from Notion';
          
          // Get description
          const descriptionProp = Object.values(properties).find(
            prop => prop.type === 'rich_text' && (prop.name === 'Description' || prop.name === 'description')
          );
          const description = descriptionProp?.rich_text?.[0]?.text?.content || '';
          
          // Get status
          const statusProp = Object.values(properties).find(
            prop => prop.type === 'select' && (prop.name === 'Status' || prop.name === 'status')
          );
          const notionStatus = statusProp?.select?.name || 'New';
          const status = statusMapping[notionStatus] || notionStatus;
          
          // Get category
          const categoryProp = Object.values(properties).find(
            prop => prop.type === 'select' && (prop.name === 'Category' || prop.name === 'category')
          );
          const notionCategory = categoryProp?.select?.name || null;
          const category = categoryMapping[notionCategory || ''] || notionCategory;
          
          // Get priority
          const priorityProp = Object.values(properties).find(
            prop => prop.type === 'number' && (prop.name === 'Priority' || prop.name === 'priority')
          );
          const priority = priorityProp?.number || null;
          
          // Get due date
          const dueDateProp = Object.values(properties).find(
            prop => prop.type === 'date' && (prop.name === 'Due Date' || prop.name === 'due_date' || prop.name === 'dueDate')
          );
          const dueDate = dueDateProp?.date?.start ? new Date(dueDateProp.date.start) : null;
          
          // Create the idea
          const idea = await storage.createIdea({
            userId,
            title,
            description,
            status,
            category,
            priority,
            dueDate,
            source: 'notion',
            sourceReference: pageId,
            metadata: {
              notionPageId: pageId,
              notionDatabaseId: databaseId,
              notionConnectionId: connectionId,
              importedAt: new Date().toISOString()
            }
          });
          
          // Store the mapping
          await storage.createNotionIntegration({
            ideaId: idea.id,
            connectionId,
            notionPageId: pageId,
            notionDatabaseId: databaseId,
            syncedAt: new Date(),
            lastSyncedAt: new Date()
          });
          
          return {
            success: true,
            message: 'Notion page successfully imported as idea',
            data: {
              ideaId: idea.id,
              notionPageId: pageId
            }
          };
        }
        
        // Just return the page data
        return {
          success: true,
          message: 'Notion page successfully imported',
          data: {
            page
          }
        };
      } else {
        // Import multiple pages from the database
        // Query the database
        const response = await client.databases.query({
          database_id: databaseId,
          page_size: limit
        });
        
        if (asIdea && userId) {
          const importedIdeas = [];
          
          // Convert each page to an idea
          for (const page of response.results) {
            // Extract properties
            const properties = page.properties as Record<string, any>;
            
            // Get title
            const titleProp = Object.values(properties).find(prop => prop.type === 'title');
            const title = titleProp?.title?.[0]?.text?.content || 'Imported from Notion';
            
            // Get description
            const descriptionProp = Object.values(properties).find(
              prop => prop.type === 'rich_text' && (prop.name === 'Description' || prop.name === 'description')
            );
            const description = descriptionProp?.rich_text?.[0]?.text?.content || '';
            
            // Get status
            const statusProp = Object.values(properties).find(
              prop => prop.type === 'select' && (prop.name === 'Status' || prop.name === 'status')
            );
            const notionStatus = statusProp?.select?.name || 'New';
            const status = statusMapping[notionStatus] || notionStatus;
            
            // Get category
            const categoryProp = Object.values(properties).find(
              prop => prop.type === 'select' && (prop.name === 'Category' || prop.name === 'category')
            );
            const notionCategory = categoryProp?.select?.name || null;
            const category = categoryMapping[notionCategory || ''] || notionCategory;
            
            // Get priority
            const priorityProp = Object.values(properties).find(
              prop => prop.type === 'number' && (prop.name === 'Priority' || prop.name === 'priority')
            );
            const priority = priorityProp?.number || null;
            
            // Get due date
            const dueDateProp = Object.values(properties).find(
              prop => prop.type === 'date' && (prop.name === 'Due Date' || prop.name === 'due_date' || prop.name === 'dueDate')
            );
            const dueDate = dueDateProp?.date?.start ? new Date(dueDateProp.date.start) : null;
            
            // Create the idea
            const idea = await storage.createIdea({
              userId,
              title,
              description,
              status,
              category,
              priority,
              dueDate,
              source: 'notion',
              sourceReference: page.id,
              metadata: {
                notionPageId: page.id,
                notionDatabaseId: databaseId,
                notionConnectionId: connectionId,
                importedAt: new Date().toISOString()
              }
            });
            
            // Store the mapping
            await storage.createNotionIntegration({
              ideaId: idea.id,
              connectionId,
              notionPageId: page.id,
              notionDatabaseId: databaseId,
              syncedAt: new Date(),
              lastSyncedAt: new Date()
            });
            
            importedIdeas.push({
              ideaId: idea.id,
              notionPageId: page.id,
              title
            });
          }
          
          return {
            success: true,
            message: `Successfully imported ${importedIdeas.length} Notion pages as ideas`,
            data: {
              importedIdeas
            }
          };
        }
        
        // Just return the database query results
        return {
          success: true,
          message: 'Notion database successfully queried',
          data: {
            pages: response.results
          }
        };
      }
    } catch (error: any) {
      console.error('Error importing from Notion:', error);
      return {
        success: false,
        message: `Failed to import from Notion: ${error.message}`,
        error
      };
    }
  }
  
  /**
   * Get available databases from Notion
   */
  async getAvailableDatabases(connectionId: string): Promise<NotionOperationResult> {
    try {
      // Get connection
      const connection = await this.getConnection(connectionId);
      if (!connection) {
        return {
          success: false,
          message: `Notion connection not found: ${connectionId}`
        };
      }
      
      // Get client
      const client = this.getClient(connectionId);
      if (!client) {
        return {
          success: false,
          message: 'Notion client not available'
        };
      }
      
      // Search for databases
      const response = await client.search({
        filter: {
          property: 'object',
          value: 'database'
        }
      });
      
      return {
        success: true,
        message: `Found ${response.results.length} databases`,
        data: {
          databases: response.results
        }
      };
    } catch (error: any) {
      console.error('Error getting available databases from Notion:', error);
      return {
        success: false,
        message: `Failed to get available databases from Notion: ${error.message}`,
        error
      };
    }
  }
  
  /**
   * Create a new database in Notion
   */
  async createDatabase(
    connectionId: string,
    title: string,
    parentPageId: string,
    type: NotionDatabaseType = NotionDatabaseType.IDEAS
  ): Promise<NotionOperationResult> {
    try {
      // Get connection
      const connection = await this.getConnection(connectionId);
      if (!connection) {
        return {
          success: false,
          message: `Notion connection not found: ${connectionId}`
        };
      }
      
      // Get client
      const client = this.getClient(connectionId);
      if (!client) {
        return {
          success: false,
          message: 'Notion client not available'
        };
      }
      
      // Create database properties based on type
      const properties: Record<string, any> = {
        Name: {
          title: {}
        },
        Status: {
          select: {
            options: [
              { name: 'New', color: 'blue' },
              { name: 'In Progress', color: 'yellow' },
              { name: 'Completed', color: 'green' },
              { name: 'On Hold', color: 'orange' },
              { name: 'Cancelled', color: 'red' }
            ]
          }
        }
      };
      
      // Add type-specific properties
      switch (type) {
        case NotionDatabaseType.IDEAS:
          properties.Category = {
            select: {
              options: [
                { name: 'Feature', color: 'green' },
                { name: 'Bug', color: 'red' },
                { name: 'Improvement', color: 'yellow' },
                { name: 'Documentation', color: 'blue' },
                { name: 'Other', color: 'gray' }
              ]
            }
          };
          properties.Priority = {
            number: {}
          };
          properties['Due Date'] = {
            date: {}
          };
          properties['Created At'] = {
            date: {}
          };
          properties['Updated At'] = {
            date: {}
          };
          properties['PinkSync ID'] = {
            number: {}
          };
          properties.Description = {
            rich_text: {}
          };
          break;
          
        case NotionDatabaseType.PROJECTS:
          properties.Category = {
            select: {
              options: [
                { name: 'Development', color: 'blue' },
                { name: 'Design', color: 'purple' },
                { name: 'Research', color: 'yellow' },
                { name: 'Marketing', color: 'green' },
                { name: 'Other', color: 'gray' }
              ]
            }
          };
          properties.Priority = {
            number: {}
          };
          properties['Start Date'] = {
            date: {}
          };
          properties['Due Date'] = {
            date: {}
          };
          properties.Team = {
            multi_select: {}
          };
          properties.Owner = {
            people: {}
          };
          properties['PinkSync ID'] = {
            number: {}
          };
          properties.Description = {
            rich_text: {}
          };
          break;
          
        case NotionDatabaseType.TASKS:
          properties.Assignee = {
            people: {}
          };
          properties.Priority = {
            select: {
              options: [
                { name: 'Low', color: 'blue' },
                { name: 'Medium', color: 'yellow' },
                { name: 'High', color: 'orange' },
                { name: 'Critical', color: 'red' }
              ]
            }
          };
          properties['Due Date'] = {
            date: {}
          };
          properties['Related Project'] = {
            relation: {}
          };
          properties['Time Estimate'] = {
            number: {}
          };
          properties['PinkSync ID'] = {
            number: {}
          };
          properties.Description = {
            rich_text: {}
          };
          break;
          
        case NotionDatabaseType.DOCUMENTATION:
          properties.Category = {
            select: {
              options: [
                { name: 'API', color: 'blue' },
                { name: 'Guide', color: 'green' },
                { name: 'Tutorial', color: 'yellow' },
                { name: 'Reference', color: 'purple' },
                { name: 'Architecture', color: 'red' },
                { name: 'Other', color: 'gray' }
              ]
            }
          };
          properties.Author = {
            people: {}
          };
          properties['Last Updated'] = {
            date: {}
          };
          properties['Related Project'] = {
            relation: {}
          };
          properties.Version = {
            rich_text: {}
          };
          properties['PinkSync ID'] = {
            number: {}
          };
          break;
          
        case NotionDatabaseType.TRENDS:
          properties.Category = {
            select: {
              options: [
                { name: 'Technology', color: 'blue' },
                { name: 'Market', color: 'green' },
                { name: 'Competition', color: 'red' },
                { name: 'Industry', color: 'purple' },
                { name: 'Other', color: 'gray' }
              ]
            }
          };
          properties['Growth Rate'] = {
            number: {}
          };
          properties['First Detected'] = {
            date: {}
          };
          properties['Last Updated'] = {
            date: {}
          };
          properties.Source = {
            url: {}
          };
          properties['Mention Count'] = {
            number: {}
          };
          properties['PinkSync ID'] = {
            number: {}
          };
          properties.Description = {
            rich_text: {}
          };
          break;
          
        case NotionDatabaseType.VALIDATIONS:
          properties['Idea Title'] = {
            rich_text: {}
          };
          properties['Validation Date'] = {
            date: {}
          };
          properties['Market Validation'] = {
            rich_text: {}
          };
          properties['Technical Validation'] = {
            rich_text: {}
          };
          properties['Economic Validation'] = {
            rich_text: {}
          };
          properties['Competitive Validation'] = {
            rich_text: {}
          };
          properties['Overall Result'] = {
            select: {
              options: [
                { name: 'Validated', color: 'green' },
                { name: 'Partially Validated', color: 'yellow' },
                { name: 'Not Validated', color: 'red' }
              ]
            }
          };
          properties['PinkSync ID'] = {
            number: {}
          };
          break;
          
        case NotionDatabaseType.CHECKPOINTS:
          properties['Project Title'] = {
            rich_text: {}
          };
          properties.Platform = {
            select: {
              options: [
                { name: 'GitHub', color: 'purple' },
                { name: 'Replit', color: 'blue' },
                { name: 'Vercel', color: 'black' },
                { name: 'Cursor', color: 'green' },
                { name: 'Other', color: 'gray' }
              ]
            }
          };
          properties['Checkpoint Date'] = {
            date: {}
          };
          properties.Status = {
            select: {
              options: [
                { name: 'Pending', color: 'gray' },
                { name: 'In Progress', color: 'yellow' },
                { name: 'Successful', color: 'green' },
                { name: 'Failed', color: 'red' }
              ]
            }
          };
          properties['Reference URL'] = {
            url: {}
          };
          properties['PinkSync ID'] = {
            number: {}
          };
          properties.Description = {
            rich_text: {}
          };
          break;
          
        default:
          // Use default properties for custom type
          break;
      }
      
      // Create the database
      const response = await client.databases.create({
        parent: {
          page_id: parentPageId
        },
        title: [
          {
            type: 'text',
            text: {
              content: title
            }
          }
        ],
        properties
      });
      
      // Add database to connection
      const databaseConfig: NotionDatabaseConfig = {
        id: response.id,
        type,
        name: title,
        description: `PinkSync ${type} database`,
        schema: properties
      };
      
      await this.addDatabase(connectionId, databaseConfig);
      
      return {
        success: true,
        message: 'Database successfully created in Notion',
        data: {
          databaseId: response.id,
          databaseConfig
        }
      };
    } catch (error: any) {
      console.error('Error creating database in Notion:', error);
      return {
        success: false,
        message: `Failed to create database in Notion: ${error.message}`,
        error
      };
    }
  }
}

// Create and export service instance
export const notionService = new NotionService();
export default notionService;