/**
 * Civic Integration Service
 * 
 * Provides integration with Civic identity services for Web2/Web3 bridging.
 * Handles authentication, verification, and identity management.
 */

import axios from 'axios';
import { createHmac } from 'crypto';
import { logger } from '../../utils/logger';
import EventEmitter from 'events';

// Define types for Civic integration
export interface CivicConfig {
  appId: string;
  privateKey: string;
  appSecret: string;
  apiUrl: string;
}

export interface CivicIdentity {
  userId: string;
  walletAddress?: string;
  email?: string;
  verificationLevel: 'basic' | 'verified' | 'advanced';
  verifiedAttributes: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface VerificationRequest {
  type: 'email' | 'wallet' | 'phone' | 'kyc';
  userId: string;
  data: Record<string, any>;
}

export interface VerificationResult {
  success: boolean;
  userId: string;
  type: string;
  verificationId?: string;
  status: 'pending' | 'verified' | 'failed';
  message?: string;
  timestamp: Date;
}

export interface Web2ToWeb3MappingResult {
  success: boolean;
  web2UserId: string;
  web3WalletAddress: string;
  status: 'connected' | 'pending' | 'failed';
  message?: string;
  timestamp: Date;
}

class CivicIntegrationService extends EventEmitter {
  private config: CivicConfig | null = null;
  private apiClient: any = null;
  private identities: Map<string, CivicIdentity> = new Map();
  private isInitialized = false;
  private mockMode = false;
  
  constructor() {
    super();
  }
  
  /**
   * Initialize the Civic integration service
   */
  async initialize(config?: CivicConfig): Promise<boolean> {
    try {
      logger.info('Initializing Civic integration service');
      
      // Use provided config or try to build from environment
      if (!config) {
        config = this.buildConfigFromEnvironment();
      }
      
      if (!config) {
        // If still no config, use mock mode
        logger.warn('No Civic config available, using mock mode');
        this.mockMode = true;
        this.isInitialized = true;
        return true;
      }
      
      this.config = config;
      
      // Set up the API client
      this.apiClient = axios.create({
        baseURL: config.apiUrl,
        headers: {
          'Content-Type': 'application/json',
          'X-App-Id': config.appId
        }
      });
      
      // Add a request interceptor to sign requests
      this.apiClient.interceptors.request.use((axiosConfig: any) => {
        if (!this.config) return axiosConfig;
        
        const timestamp = Date.now().toString();
        const path = new URL(axiosConfig.url, this.config.apiUrl).pathname;
        const body = axiosConfig.data ? JSON.stringify(axiosConfig.data) : '';
        
        // Create the signature
        const signature = this.createRequestSignature(
          this.config.appSecret,
          axiosConfig.method.toUpperCase(),
          path,
          timestamp,
          body
        );
        
        // Add headers
        axiosConfig.headers['X-Timestamp'] = timestamp;
        axiosConfig.headers['X-Signature'] = signature;
        
        return axiosConfig;
      });
      
      this.isInitialized = true;
      logger.info('Civic integration service initialized');
      
      return true;
    } catch (error) {
      logger.error('Failed to initialize Civic integration service', error);
      return false;
    }
  }
  
  /**
   * Build configuration from environment variables
   */
  private buildConfigFromEnvironment(): CivicConfig | null {
    const appId = process.env.CIVIC_APP_ID;
    const privateKey = process.env.CIVIC_PRIVATE_KEY;
    const appSecret = process.env.CIVIC_APP_SECRET;
    const apiUrl = process.env.CIVIC_API_URL;
    
    if (!appId || !privateKey || !appSecret || !apiUrl) {
      logger.warn('Missing Civic environment variables');
      return null;
    }
    
    return {
      appId,
      privateKey,
      appSecret,
      apiUrl
    };
  }
  
  /**
   * Create a signature for Civic API requests
   */
  private createRequestSignature(
    secret: string,
    method: string,
    path: string,
    timestamp: string,
    body: string
  ): string {
    const message = `${method}${path}${timestamp}${body}`;
    const hmac = createHmac('sha256', secret);
    return hmac.update(message).digest('hex');
  }
  
  /**
   * Verify an identity token from Civic
   */
  async verifyToken(token: string): Promise<CivicIdentity | null> {
    try {
      if (this.mockMode) {
        return this.mockVerifyToken(token);
      }
      
      if (!this.apiClient) {
        throw new Error('Civic API client not initialized');
      }
      
      // Verify the token with Civic API
      const response = await this.apiClient.post('/api/verify/token', {
        token
      });
      
      if (!response.data?.success) {
        throw new Error(response.data?.message || 'Token verification failed');
      }
      
      // Map the response to our identity model
      const identity: CivicIdentity = {
        userId: response.data.userId,
        email: response.data.email,
        walletAddress: response.data.wallet,
        verificationLevel: response.data.level || 'basic',
        verifiedAttributes: response.data.verified || [],
        createdAt: new Date(response.data.createdAt),
        updatedAt: new Date()
      };
      
      // Store the identity
      this.identities.set(identity.userId, identity);
      
      return identity;
    } catch (error) {
      logger.error('Error verifying Civic token', error);
      return null;
    }
  }
  
  /**
   * Mock token verification for testing
   */
  private mockVerifyToken(token: string): CivicIdentity {
    // Parse the user ID from the token
    let userId = 'mock-user-123';
    
    try {
      // Assume token is in format "user-{id}-{timestamp}"
      const parts = token.split('-');
      if (parts.length >= 2) {
        userId = parts[1];
      }
    } catch (error) {
      // Ignore parsing errors
    }
    
    // Create a mock identity
    const identity: CivicIdentity = {
      userId,
      email: `user-${userId}@example.com`,
      walletAddress: `0x${userId}123456789abcdef`,
      verificationLevel: 'verified',
      verifiedAttributes: ['email', 'wallet'],
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    // Store the identity
    this.identities.set(identity.userId, identity);
    
    return identity;
  }
  
  /**
   * Request verification for a specific attribute
   */
  async requestVerification(request: VerificationRequest): Promise<VerificationResult> {
    try {
      if (this.mockMode) {
        return this.mockRequestVerification(request);
      }
      
      if (!this.apiClient) {
        throw new Error('Civic API client not initialized');
      }
      
      // Request verification from Civic API
      const response = await this.apiClient.post('/api/request/verification', request);
      
      if (!response.data?.success) {
        throw new Error(response.data?.message || 'Verification request failed');
      }
      
      const result: VerificationResult = {
        success: true,
        userId: request.userId,
        type: request.type,
        verificationId: response.data.verificationId,
        status: 'pending',
        timestamp: new Date()
      };
      
      return result;
    } catch (error: any) {
      logger.error('Error requesting Civic verification', error);
      
      return {
        success: false,
        userId: request.userId,
        type: request.type,
        status: 'failed',
        message: error.message || 'Verification request failed',
        timestamp: new Date()
      };
    }
  }
  
  /**
   * Mock verification request for testing
   */
  private mockRequestVerification(request: VerificationRequest): VerificationResult {
    return {
      success: true,
      userId: request.userId,
      type: request.type,
      verificationId: `v-${Date.now()}`,
      status: 'pending',
      timestamp: new Date()
    };
  }
  
  /**
   * Connect Web2 identity to Web3 wallet
   */
  async connectWeb2ToWeb3(
    web2UserId: string, 
    walletAddress: string,
    civicToken: string
  ): Promise<Web2ToWeb3MappingResult> {
    try {
      if (this.mockMode) {
        return this.mockConnectWeb2ToWeb3(web2UserId, walletAddress);
      }
      
      if (!this.apiClient) {
        throw new Error('Civic API client not initialized');
      }
      
      // First verify the token
      const identity = await this.verifyToken(civicToken);
      
      if (!identity) {
        throw new Error('Invalid Civic token');
      }
      
      // Now connect the identities
      const response = await this.apiClient.post('/api/identity/connect', {
        web2UserId,
        walletAddress,
        civicUserId: identity.userId
      });
      
      if (!response.data?.success) {
        throw new Error(response.data?.message || 'Identity connection failed');
      }
      
      const result: Web2ToWeb3MappingResult = {
        success: true,
        web2UserId,
        web3WalletAddress: walletAddress,
        status: 'connected',
        timestamp: new Date()
      };
      
      // Emit an event
      this.emit('identity:connected', result);
      
      return result;
    } catch (error: any) {
      logger.error('Error connecting Web2 to Web3 identity', error);
      
      return {
        success: false,
        web2UserId,
        web3WalletAddress: walletAddress,
        status: 'failed',
        message: error.message || 'Identity connection failed',
        timestamp: new Date()
      };
    }
  }
  
  /**
   * Mock Web2 to Web3 connection for testing
   */
  private mockConnectWeb2ToWeb3(
    web2UserId: string, 
    walletAddress: string
  ): Web2ToWeb3MappingResult {
    return {
      success: true,
      web2UserId,
      web3WalletAddress: walletAddress,
      status: 'connected',
      timestamp: new Date()
    };
  }
  
  /**
   * Get an identity by user ID
   */
  getIdentity(userId: string): CivicIdentity | null {
    return this.identities.get(userId) || null;
  }
  
  /**
   * Check if a wallet is verified for a user
   */
  isWalletVerified(userId: string, walletAddress: string): boolean {
    const identity = this.identities.get(userId);
    
    if (!identity || !identity.walletAddress) {
      return false;
    }
    
    return identity.walletAddress.toLowerCase() === walletAddress.toLowerCase();
  }
  
  /**
   * Check if the service is ready
   */
  isReady(): boolean {
    return this.isInitialized;
  }
  
  /**
   * Check if running in mock mode
   */
  isMockMode(): boolean {
    return this.mockMode;
  }
}

// Create singleton instance
const civicIntegrationService = new CivicIntegrationService();

export { civicIntegrationService };
export default civicIntegrationService;