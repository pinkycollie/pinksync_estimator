import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import axios from 'axios';
import crypto from 'crypto';

// Define types for webhooks
export interface Webhook {
  id: string;
  name: string;
  url: string;
  events: string[];
  secret?: string;
  createdAt: string;
  lastTriggered?: string;
  lastStatus?: number;
  active: boolean;
  headers?: Record<string, string>;
}

export interface WebhookEvent {
  id: string;
  type: string;
  data: any;
  timestamp: string;
}

export interface WebhookDelivery {
  id: string;
  webhookId: string;
  eventId: string;
  timestamp: string;
  status: number;
  response?: string;
  retries: number;
  duration: number;
}

/**
 * Service for managing webhooks
 */
export class WebhookService {
  private webhooks: Map<string, Webhook> = new Map();
  private readonly webhooksDir: string;
  private readonly deliveriesDir: string;
  private readonly eventsDir: string;
  
  constructor() {
    this.webhooksDir = path.join(process.cwd(), 'data', 'webhooks');
    this.deliveriesDir = path.join(process.cwd(), 'data', 'webhook_deliveries');
    this.eventsDir = path.join(process.cwd(), 'data', 'webhook_events');
    
    // Create directories if they don't exist
    [this.webhooksDir, this.deliveriesDir, this.eventsDir].forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    });
    
    // Load existing webhooks
    this.loadWebhooks();
  }
  
  /**
   * Load webhooks from disk
   */
  private loadWebhooks(): void {
    try {
      if (!fs.existsSync(this.webhooksDir)) {
        return;
      }
      
      const files = fs.readdirSync(this.webhooksDir);
      
      for (const file of files) {
        if (file.endsWith('.json')) {
          try {
            const filePath = path.join(this.webhooksDir, file);
            const webhookData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            this.webhooks.set(webhookData.id, webhookData);
          } catch (error) {
            console.error(`Error loading webhook from ${file}:`, error);
          }
        }
      }
      
      console.log(`Loaded ${this.webhooks.size} webhooks`);
    } catch (error) {
      console.error('Error loading webhooks:', error);
    }
  }
  
  /**
   * Save a webhook to disk
   */
  private saveWebhook(webhook: Webhook): void {
    try {
      const filePath = path.join(this.webhooksDir, `${webhook.id}.json`);
      fs.writeFileSync(filePath, JSON.stringify(webhook, null, 2));
    } catch (error) {
      console.error(`Error saving webhook ${webhook.id}:`, error);
      throw error;
    }
  }
  
  /**
   * Save an event to disk
   */
  private saveEvent(event: WebhookEvent): void {
    try {
      const filePath = path.join(this.eventsDir, `${event.id}.json`);
      fs.writeFileSync(filePath, JSON.stringify(event, null, 2));
    } catch (error) {
      console.error(`Error saving event ${event.id}:`, error);
      throw error;
    }
  }
  
  /**
   * Save a delivery to disk
   */
  private saveDelivery(delivery: WebhookDelivery): void {
    try {
      const filePath = path.join(this.deliveriesDir, `${delivery.id}.json`);
      fs.writeFileSync(filePath, JSON.stringify(delivery, null, 2));
    } catch (error) {
      console.error(`Error saving delivery ${delivery.id}:`, error);
      throw error;
    }
  }
  
  /**
   * Create a new webhook
   */
  createWebhook(webhook: Omit<Webhook, 'id' | 'createdAt'>): Webhook {
    const id = uuidv4();
    const createdAt = new Date().toISOString();
    
    const newWebhook: Webhook = {
      ...webhook,
      id,
      createdAt,
      active: webhook.active ?? true
    };
    
    this.webhooks.set(id, newWebhook);
    this.saveWebhook(newWebhook);
    
    return newWebhook;
  }
  
  /**
   * Get a webhook by ID
   */
  getWebhook(id: string): Webhook | undefined {
    return this.webhooks.get(id);
  }
  
  /**
   * Update a webhook
   */
  updateWebhook(id: string, updates: Partial<Omit<Webhook, 'id' | 'createdAt'>>): Webhook | undefined {
    const webhook = this.webhooks.get(id);
    
    if (!webhook) {
      return undefined;
    }
    
    const updatedWebhook: Webhook = {
      ...webhook,
      ...updates
    };
    
    this.webhooks.set(id, updatedWebhook);
    this.saveWebhook(updatedWebhook);
    
    return updatedWebhook;
  }
  
  /**
   * Delete a webhook
   */
  deleteWebhook(id: string): boolean {
    if (!this.webhooks.has(id)) {
      return false;
    }
    
    this.webhooks.delete(id);
    
    // Delete from disk
    try {
      const filePath = path.join(this.webhooksDir, `${id}.json`);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
      return true;
    } catch (error) {
      console.error(`Error deleting webhook ${id}:`, error);
      return false;
    }
  }
  
  /**
   * Get all webhooks
   */
  getAllWebhooks(): Webhook[] {
    return Array.from(this.webhooks.values());
  }
  
  /**
   * Trigger a webhook event
   */
  async triggerEvent(type: string, data: any): Promise<WebhookEvent> {
    const eventId = uuidv4();
    const timestamp = new Date().toISOString();
    
    // Create event
    const event: WebhookEvent = {
      id: eventId,
      type,
      data,
      timestamp
    };
    
    // Save event
    this.saveEvent(event);
    
    // Find webhooks that listen to this event
    const matchingWebhooks = Array.from(this.webhooks.values()).filter(
      webhook => webhook.active && webhook.events.includes(type)
    );
    
    // Deliver event to webhooks
    const deliveryPromises = matchingWebhooks.map(webhook => 
      this.deliverEvent(webhook, event)
    );
    
    // Wait for all deliveries to complete
    await Promise.all(deliveryPromises);
    
    return event;
  }
  
  /**
   * Deliver an event to a webhook
   */
  private async deliverEvent(webhook: Webhook, event: WebhookEvent): Promise<WebhookDelivery> {
    const deliveryId = uuidv4();
    const timestamp = new Date().toISOString();
    const startTime = Date.now();
    
    // Prepare payload
    const payload = {
      id: event.id,
      type: event.type,
      data: event.data,
      timestamp: event.timestamp
    };
    
    // Prepare headers
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'User-Agent': 'Pinky-AI-OS-Webhook/1.0',
      'X-Webhook-ID': webhook.id,
      'X-Event-ID': event.id,
      'X-Event-Type': event.type,
      'X-Delivery-ID': deliveryId,
      ...webhook.headers || {}
    };
    
    // Add signature if webhook has a secret
    if (webhook.secret) {
      const signature = this.signPayload(payload, webhook.secret);
      headers['X-Webhook-Signature'] = signature;
    }
    
    // Delivery result
    let status = 0;
    let response = '';
    let retries = 0;
    
    try {
      // Attempt delivery
      const axiosResponse = await axios.post(webhook.url, payload, {
        headers,
        timeout: 10000, // 10 seconds timeout
        validateStatus: () => true // Accept any status code
      });
      
      status = axiosResponse.status;
      response = typeof axiosResponse.data === 'object' 
        ? JSON.stringify(axiosResponse.data)
        : String(axiosResponse.data).substring(0, 1000); // Limit response size
      
      // Update webhook last triggered and status
      this.updateWebhook(webhook.id, {
        lastTriggered: timestamp,
        lastStatus: status
      });
    } catch (error) {
      status = 0; // Connection error
      response = error.message || 'Connection error';
      retries = 0; // TODO: Implement retry logic
    }
    
    const endTime = Date.now();
    const duration = endTime - startTime;
    
    // Create delivery record
    const delivery: WebhookDelivery = {
      id: deliveryId,
      webhookId: webhook.id,
      eventId: event.id,
      timestamp,
      status,
      response,
      retries,
      duration
    };
    
    // Save delivery
    this.saveDelivery(delivery);
    
    return delivery;
  }
  
  /**
   * Sign payload with secret
   */
  private signPayload(payload: any, secret: string): string {
    const payloadStr = typeof payload === 'string' 
      ? payload 
      : JSON.stringify(payload);
    
    return crypto
      .createHmac('sha256', secret)
      .update(payloadStr)
      .digest('hex');
  }
  
  /**
   * Verify webhook signature
   */
  verifySignature(payload: any, signature: string, secret: string): boolean {
    const expectedSignature = this.signPayload(payload, secret);
    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expectedSignature)
    );
  }
  
  /**
   * Get webhook deliveries
   */
  getWebhookDeliveries(webhookId: string, limit = 10): WebhookDelivery[] {
    try {
      const files = fs.readdirSync(this.deliveriesDir);
      const deliveries: WebhookDelivery[] = [];
      
      for (const file of files) {
        if (file.endsWith('.json')) {
          try {
            const filePath = path.join(this.deliveriesDir, file);
            const delivery = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            
            if (delivery.webhookId === webhookId) {
              deliveries.push(delivery);
              
              if (deliveries.length >= limit) {
                break;
              }
            }
          } catch (error) {
            console.error(`Error reading delivery from ${file}:`, error);
          }
        }
      }
      
      // Sort by timestamp descending
      return deliveries.sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
    } catch (error) {
      console.error(`Error getting deliveries for webhook ${webhookId}:`, error);
      return [];
    }
  }
  
  /**
   * Get webhook events
   */
  getWebhookEvents(limit = 10): WebhookEvent[] {
    try {
      const files = fs.readdirSync(this.eventsDir);
      const events: WebhookEvent[] = [];
      
      for (const file of files) {
        if (file.endsWith('.json')) {
          try {
            const filePath = path.join(this.eventsDir, file);
            const event = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            
            events.push(event);
            
            if (events.length >= limit) {
              break;
            }
          } catch (error) {
            console.error(`Error reading event from ${file}:`, error);
          }
        }
      }
      
      // Sort by timestamp descending
      return events.sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
    } catch (error) {
      console.error('Error getting events:', error);
      return [];
    }
  }
}

// Export a singleton instance
export const webhookService = new WebhookService();