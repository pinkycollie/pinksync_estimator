import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { v4 as uuidv4 } from 'uuid';
import { astraService } from '../astra/astraService';

/**
 * Service to extract chat history and upload to Astra DB
 * This is a lightweight solution for occasional bulk uploads
 */
export class ChatToAstraService {
  private readonly scriptPath: string;
  private readonly outputDir: string;
  
  constructor() {
    // Set path to Python script and output directory
    this.scriptPath = path.join(process.cwd(), 'scripts', 'chat_history_extractor.py');
    this.outputDir = path.join(process.cwd(), 'uploads', 'chat_exports');
    
    // Create output directory if it doesn't exist
    if (!fs.existsSync(this.outputDir)) {
      fs.mkdirSync(this.outputDir, { recursive: true });
    }
    
    // Create scripts directory if it doesn't exist
    const scriptsDir = path.join(process.cwd(), 'scripts');
    if (!fs.existsSync(scriptsDir)) {
      fs.mkdirSync(scriptsDir, { recursive: true });
    }
  }
  
  /**
   * Extract chat history and directly upload to Astra DB
   */
  async extractAndUpload(
    collectionName: string,
    platformType: 'claude' | 'chatgpt' | 'generic',
    filePath: string,
    options: {
      fileFormat?: 'json' | 'csv' | 'txt';
      tags?: string[];
      userId?: string;
      namespace?: string;
    } = {}
  ): Promise<{
    success: boolean;
    totalExtracted: number;
    totalUploaded: number;
    failedUploads: number;
    outputPath?: string;
    error?: string;
  }> {
    try {
      // Extract chat history first
      const extractionResult = await this.extractChatHistory(platformType, filePath, options.fileFormat);
      
      if (!extractionResult.success) {
        return {
          success: false,
          totalExtracted: 0,
          totalUploaded: 0,
          failedUploads: 0,
          error: extractionResult.error
        };
      }
      
      // Now upload the extracted data to Astra DB
      const uploadResult = await this.uploadToAstra(
        collectionName, 
        extractionResult.outputPath,
        options
      );
      
      return {
        success: uploadResult.success,
        totalExtracted: extractionResult.totalExtracted,
        totalUploaded: uploadResult.totalUploaded,
        failedUploads: uploadResult.failedUploads,
        outputPath: extractionResult.outputPath,
        error: uploadResult.error
      };
    } catch (error) {
      console.error('Error in extractAndUpload:', error);
      return {
        success: false,
        totalExtracted: 0,
        totalUploaded: 0,
        failedUploads: 0,
        error: error.message || 'Unknown error'
      };
    }
  }
  
  /**
   * Extract chat history using the Python script
   */
  private async extractChatHistory(
    platformType: 'claude' | 'chatgpt' | 'generic',
    filePath: string,
    fileFormat?: 'json' | 'csv' | 'txt'
  ): Promise<{
    success: boolean;
    totalExtracted: number;
    outputPath: string;
    error?: string;
  }> {
    return new Promise((resolve) => {
      const outputFileName = `${platformType}_export_${Date.now()}.json`;
      const outputPath = path.join(this.outputDir, outputFileName);
      
      // Build command arguments
      const args = [
        this.scriptPath,
        `--${platformType}`, filePath,
        '--output', this.outputDir
      ];
      
      // Add file format if specified
      if (fileFormat && platformType === 'generic') {
        args.push('--format', fileFormat);
      }
      
      // Execute Python script
      const pythonProcess = spawn('python', args);
      
      let output = '';
      let errorOutput = '';
      
      pythonProcess.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      pythonProcess.stderr.on('data', (data) => {
        errorOutput += data.toString();
      });
      
      pythonProcess.on('close', (code) => {
        if (code !== 0) {
          return resolve({
            success: false,
            totalExtracted: 0,
            outputPath,
            error: errorOutput || 'Chat history extraction failed'
          });
        }
        
        try {
          // Get message count from output
          const extractedMatch = output.match(/Extracted (\d+) messages/);
          const totalExtracted = extractedMatch ? parseInt(extractedMatch[1], 10) : 0;
          
          resolve({
            success: true,
            totalExtracted,
            outputPath
          });
        } catch (error) {
          resolve({
            success: true,
            totalExtracted: 0,
            outputPath,
            error: error.message
          });
        }
      });
    });
  }
  
  /**
   * Upload extracted chat data to Astra DB
   */
  private async uploadToAstra(
    collectionName: string,
    jsonFilePath: string,
    options: {
      tags?: string[];
      userId?: string;
      namespace?: string;
    } = {}
  ): Promise<{
    success: boolean;
    totalUploaded: number;
    failedUploads: number;
    error?: string;
  }> {
    try {
      // Read the JSON file
      const fileContent = fs.readFileSync(jsonFilePath, 'utf8');
      const chatData = JSON.parse(fileContent);
      
      if (!Array.isArray(chatData)) {
        return {
          success: false,
          totalUploaded: 0,
          failedUploads: 0,
          error: 'Invalid chat data format: not an array'
        };
      }
      
      const namespace = options.namespace || 'default';
      const userId = options.userId || 'anonymous';
      const tags = options.tags || [];
      const platformTags = new Set<string>(['chat_history']);
      
      // Extract platform types from the data
      for (const item of chatData) {
        if (item.platform) {
          platformTags.add(item.platform.toLowerCase());
        }
      }
      
      // Group chats by conversation
      const conversations: Record<string, any[]> = {};
      
      for (const message of chatData) {
        const conversationId = message.conversation_id || 'unknown';
        
        if (!conversations[conversationId]) {
          conversations[conversationId] = [];
        }
        
        conversations[conversationId].push(message);
      }
      
      // Upload each conversation as a separate document
      let totalUploaded = 0;
      let failedUploads = 0;
      
      for (const [conversationId, messages] of Object.entries(conversations)) {
        try {
          // Create document with all conversation messages
          const documentId = uuidv4();
          const title = messages[0]?.conversation_title || 'Untitled Conversation';
          
          await astraService.createDocument(
            namespace,
            collectionName,
            documentId,
            {
              conversation_id: conversationId,
              title,
              messages,
              platform: messages[0]?.platform || 'unknown',
              message_count: messages.length,
              extracted_at: new Date().toISOString(),
              _tags: [...tags, ...Array.from(platformTags)],
              _metadata: {
                userId,
                source_file: path.basename(jsonFilePath),
                extracted_at: new Date().toISOString()
              }
            }
          );
          
          totalUploaded++;
        } catch (error) {
          console.error(`Failed to upload conversation ${conversationId}:`, error);
          failedUploads++;
        }
      }
      
      return {
        success: totalUploaded > 0,
        totalUploaded,
        failedUploads
      };
    } catch (error) {
      console.error('Error uploading to Astra DB:', error);
      return {
        success: false,
        totalUploaded: 0,
        failedUploads: 0,
        error: error.message || 'Unknown error'
      };
    }
  }
  
  /**
   * Get conversation statistics from extracted chats
   */
  async getConversationStats(jsonFilePath: string): Promise<{
    totalMessages: number;
    conversations: number;
    averageMessageLength: number;
    topicDistribution: Record<string, number>;
    requirements: string[];
  }> {
    try {
      // Read the JSON file
      const fileContent = fs.readFileSync(jsonFilePath, 'utf8');
      const chatData = JSON.parse(fileContent);
      
      if (!Array.isArray(chatData)) {
        throw new Error('Invalid chat data format: not an array');
      }
      
      // Calculate stats
      const conversationIds = new Set<string>();
      let totalLength = 0;
      
      for (const message of chatData) {
        if (message.conversation_id) {
          conversationIds.add(message.conversation_id);
        }
        
        if (message.content) {
          totalLength += message.content.length;
        }
      }
      
      // Extract topics (simple implementation)
      const topics: Record<string, number> = {};
      const keywords = [
        'deaf', 'accessibility', 'api', 'infrastructure', 'platform',
        'tax', 'insurance', 'real estate', 'business', 'modular',
        'integration', 'processor', 'digital space'
      ];
      
      for (const message of chatData) {
        const content = message.content?.toLowerCase() || '';
        
        for (const keyword of keywords) {
          if (content.includes(keyword.toLowerCase())) {
            topics[keyword] = (topics[keyword] || 0) + 1;
          }
        }
      }
      
      // Extract requirements (simple implementation)
      const requirements: string[] = [];
      const patterns = [
        /(?:need|must|should|could|would require) to (\w+\s.+?)(?:\.|\n|$)/i,
        /(?:necessary|important) to (\w+\s.+?)(?:\.|\n|$)/i,
        /requirement(?:s)? (?:is|are|include|for) (\w+\s.+?)(?:\.|\n|$)/i
      ];
      
      for (const message of chatData) {
        const content = message.content || '';
        
        for (const pattern of patterns) {
          const matches = content.match(pattern);
          if (matches && matches[1]) {
            const req = matches[1].trim();
            if (!requirements.includes(req)) {
              requirements.push(req);
            }
          }
        }
      }
      
      return {
        totalMessages: chatData.length,
        conversations: conversationIds.size,
        averageMessageLength: totalLength / Math.max(1, chatData.length),
        topicDistribution: topics,
        requirements: requirements.slice(0, 10) // Top 10 requirements
      };
    } catch (error) {
      console.error('Error analyzing chat data:', error);
      throw error;
    }
  }
}

// Export a singleton instance
export const chatToAstraService = new ChatToAstraService();