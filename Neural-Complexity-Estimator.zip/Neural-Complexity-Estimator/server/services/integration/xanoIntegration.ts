/**
 * Xano Integration Service
 * 
 * Provides connectivity to Xano API platforms including:
 * - Standard API endpoints
 * - Meta API for advanced data processing
 * - Dev API for development environment
 */

import axios from 'axios';
import { logger } from '../../utils/logger';
import EventEmitter from 'events';

export interface XanoEndpoint {
  id: string;
  name: string;
  path: string;
  method: string;
  workspace: string; // 'dev', 'meta', etc.
  requiresAuth: boolean;
  params?: Record<string, any>;
  headers?: Record<string, any>;
}

export interface XanoConnection {
  id: string;
  name: string;
  baseUrl: string;
  apiKey: string;
  workspaces: string[];
  endpoints: XanoEndpoint[];
  active: boolean;
}

// API response interfaces
export interface XanoApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  code?: string;
  timestamp: string;
}

export interface XanoMetaResult<T = any> {
  status: string;
  result: T;
  processingTime: number;
  metaData?: Record<string, any>;
}

class XanoIntegrationService extends EventEmitter {
  private connections: Map<string, XanoConnection> = new Map();
  private apiClients: Map<string, any> = new Map();
  private isInitialized = false;
  
  constructor() {
    super();
  }
  
  /**
   * Initialize the Xano integration service
   */
  async initialize(connections: XanoConnection[] = []): Promise<boolean> {
    try {
      logger.info('Initializing Xano integration service');
      
      // Initialize from environment variables if no connections provided
      if (connections.length === 0) {
        const defaultConnection = this.createDefaultConnection();
        if (defaultConnection) {
          connections = [defaultConnection];
        }
      }
      
      // Set up connections
      for (const connection of connections) {
        this.addConnection(connection);
      }
      
      this.isInitialized = true;
      logger.info(`Initialized Xano integration service with ${this.connections.size} connections`);
      
      return true;
    } catch (error) {
      logger.error('Failed to initialize Xano integration service', error);
      return false;
    }
  }
  
  /**
   * Create a default connection from environment variables
   */
  private createDefaultConnection(): XanoConnection | null {
    try {
      const baseUrl = process.env.XANO_BASE_URL;
      const apiKey = process.env.XANO_API_KEY;
      const workspace = process.env.XANO_WORKSPACE || 'dev';
      const appId = process.env.XANO_APP_ID;
      
      if (!baseUrl || !apiKey) {
        logger.warn('Missing Xano environment variables');
        return null;
      }
      
      return {
        id: 'default',
        name: 'Default Xano Connection',
        baseUrl,
        apiKey,
        workspaces: [workspace, 'meta'],
        endpoints: [],
        active: true
      };
    } catch (error) {
      logger.error('Error creating default Xano connection', error);
      return null;
    }
  }
  
  /**
   * Add a new Xano connection
   */
  addConnection(connection: XanoConnection): boolean {
    try {
      this.connections.set(connection.id, connection);
      
      // Create axios client for this connection
      const client = axios.create({
        baseURL: connection.baseUrl,
        headers: {
          'Authorization': `Bearer ${connection.apiKey}`,
          'Content-Type': 'application/json'
        }
      });
      
      this.apiClients.set(connection.id, client);
      
      return true;
    } catch (error) {
      logger.error(`Error adding Xano connection ${connection.id}`, error);
      return false;
    }
  }
  
  /**
   * Execute an API call to Xano
   */
  async executeRequest<T = any>(
    connectionId: string, 
    endpoint: XanoEndpoint, 
    data?: any
  ): Promise<XanoApiResponse<T>> {
    try {
      const connection = this.connections.get(connectionId);
      const client = this.apiClients.get(connectionId);
      
      if (!connection || !client) {
        throw new Error(`Connection ${connectionId} not found`);
      }
      
      // Build the URL with workspace
      const url = `:${endpoint.workspace}/${endpoint.path}`;
      
      // Set up headers
      const headers: Record<string, string> = {
        ...endpoint.headers
      };
      
      if (endpoint.requiresAuth) {
        headers['Authorization'] = `Bearer ${connection.apiKey}`;
      }
      
      // Execute the request
      const response = await client({
        method: endpoint.method,
        url,
        headers,
        data: data || endpoint.params,
        timeout: 10000 // 10 seconds timeout
      });
      
      // Process the response
      const result: XanoApiResponse<T> = {
        success: true,
        data: response.data,
        timestamp: new Date().toISOString()
      };
      
      return result;
    } catch (error: any) {
      logger.error(`Error executing Xano request to ${endpoint.path}`, error);
      
      // Format the error response
      const errorResponse: XanoApiResponse<T> = {
        success: false,
        error: error.message || 'Unknown error',
        code: error.response?.status?.toString() || 'UNKNOWN_ERROR',
        timestamp: new Date().toISOString()
      };
      
      // Add any available response data
      if (error.response?.data) {
        errorResponse.data = error.response.data as T;
      }
      
      return errorResponse;
    }
  }
  
  /**
   * Execute a request to the Xano Meta API
   */
  async executeMeta<T = any>(
    connectionId: string,
    path: string,
    data?: any
  ): Promise<XanoMetaResult<T>> {
    try {
      // Create an endpoint for the Meta API
      const metaEndpoint: XanoEndpoint = {
        id: `meta-${Date.now()}`,
        name: 'Meta API Request',
        path,
        method: 'POST',
        workspace: 'meta',
        requiresAuth: true
      };
      
      // Execute the request
      const response = await this.executeRequest<T>(connectionId, metaEndpoint, data);
      
      if (!response.success) {
        throw new Error(response.error || 'Meta API request failed');
      }
      
      // Process the meta API result
      const result: XanoMetaResult<T> = {
        status: 'success',
        result: response.data as T,
        processingTime: 0
      };
      
      return result;
    } catch (error: any) {
      logger.error(`Error executing Xano Meta API request to ${path}`, error);
      
      return {
        status: 'error',
        result: null as any,
        processingTime: 0,
        metaData: {
          error: error.message || 'Unknown error'
        }
      };
    }
  }
  
  /**
   * Fast forward facility - accelerated Meta API processing
   */
  async fastForward<T = any>(
    connectionId: string,
    operation: string,
    data: any,
    options: { priority?: 'high' | 'normal' | 'low' } = {}
  ): Promise<XanoMetaResult<T>> {
    try {
      const path = `fast-forward/${operation}`;
      
      // Add priority and timestamp to data
      const payload = {
        ...data,
        _meta: {
          priority: options.priority || 'normal',
          timestamp: Date.now()
        }
      };
      
      // Execute through meta API
      return await this.executeMeta<T>(connectionId, path, payload);
    } catch (error: any) {
      logger.error(`Error in fast forward facility for ${operation}`, error);
      
      return {
        status: 'error',
        result: null as any,
        processingTime: 0,
        metaData: {
          error: error.message || 'Unknown error'
        }
      };
    }
  }
  
  /**
   * Get all endpoints for a connection
   */
  getEndpoints(connectionId: string): XanoEndpoint[] {
    const connection = this.connections.get(connectionId);
    
    if (!connection) {
      return [];
    }
    
    return connection.endpoints;
  }
  
  /**
   * Add an endpoint to a connection
   */
  addEndpoint(connectionId: string, endpoint: XanoEndpoint): boolean {
    try {
      const connection = this.connections.get(connectionId);
      
      if (!connection) {
        throw new Error(`Connection ${connectionId} not found`);
      }
      
      // Check if endpoint already exists
      const existingIndex = connection.endpoints.findIndex(e => e.id === endpoint.id);
      
      if (existingIndex >= 0) {
        connection.endpoints[existingIndex] = endpoint;
      } else {
        connection.endpoints.push(endpoint);
      }
      
      return true;
    } catch (error) {
      logger.error(`Error adding endpoint to connection ${connectionId}`, error);
      return false;
    }
  }
  
  /**
   * Remove an endpoint from a connection
   */
  removeEndpoint(connectionId: string, endpointId: string): boolean {
    try {
      const connection = this.connections.get(connectionId);
      
      if (!connection) {
        throw new Error(`Connection ${connectionId} not found`);
      }
      
      // Filter out the endpoint
      connection.endpoints = connection.endpoints.filter(e => e.id !== endpointId);
      
      return true;
    } catch (error) {
      logger.error(`Error removing endpoint ${endpointId} from connection ${connectionId}`, error);
      return false;
    }
  }
  
  /**
   * Get all connections
   */
  getConnections(): XanoConnection[] {
    return Array.from(this.connections.values());
  }
  
  /**
   * Check if the service is initialized
   */
  isReady(): boolean {
    return this.isInitialized;
  }
}

// Create singleton instance
const xanoIntegrationService = new XanoIntegrationService();

export default xanoIntegrationService;