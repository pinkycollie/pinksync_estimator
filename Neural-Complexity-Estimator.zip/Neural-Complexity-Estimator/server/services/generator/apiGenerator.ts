/**
 * API Generator Service
 * 
 * Generates API specifications, endpoints, and webhook configurations
 * for automated full-stack development.
 */

import fs from 'fs';
import path from 'path';
import { logger } from '../../utils/logger';
import EventEmitter from 'events';
import { v4 as uuidv4 } from 'uuid';

import xanoIntegrationService from '../integration/xanoIntegration';
import gitIntegrationService, { FileChange } from '../integration/gitIntegration';
import webhookManagerService from '../webhook/webhookManager';

// API specification types
export interface ApiSpec {
  id: string;
  name: string;
  description?: string;
  version: string;
  endpoints: ApiEndpoint[];
  models: ApiModel[];
  webhooks: ApiWebhook[];
  security?: ApiSecurity[];
  createdAt: Date;
  updatedAt: Date;
}

export interface ApiEndpoint {
  id: string;
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  summary: string;
  description?: string;
  requestBody?: ApiRequestBody;
  parameters?: ApiParameter[];
  responses: Record<string, ApiResponse>;
  security?: string[];
  tags?: string[];
}

export interface ApiRequestBody {
  required: boolean;
  content: {
    'application/json': {
      schema: ApiSchema;
    };
  };
}

export interface ApiParameter {
  name: string;
  in: 'path' | 'query' | 'header' | 'cookie';
  required: boolean;
  schema: ApiSchema;
  description?: string;
}

export interface ApiResponse {
  description: string;
  content?: {
    'application/json': {
      schema: ApiSchema;
    };
  };
}

export interface ApiSchema {
  type: 'object' | 'array' | 'string' | 'number' | 'integer' | 'boolean' | 'null';
  format?: string;
  properties?: Record<string, ApiSchema>;
  items?: ApiSchema;
  $ref?: string;
  required?: string[];
  enum?: any[];
  oneOf?: ApiSchema[];
  allOf?: ApiSchema[];
  anyOf?: ApiSchema[];
  minimum?: number;
  maximum?: number;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  additionalProperties?: boolean | ApiSchema;
}

export interface ApiModel {
  id: string;
  name: string;
  description?: string;
  schema: ApiSchema;
}

export interface ApiWebhook {
  id: string;
  name: string;
  description?: string;
  event: string;
  payload: {
    schema: ApiSchema;
  };
  security?: string[];
}

export interface ApiSecurity {
  id: string;
  name: string;
  type: 'apiKey' | 'http' | 'oauth2' | 'openIdConnect';
  scheme?: string;
  bearerFormat?: string;
  in?: 'query' | 'header' | 'cookie';
  flows?: Record<string, any>;
}

// Generator options
export interface GeneratorOptions {
  outputPath?: string;
  format?: 'json' | 'yaml';
  framework?: 'express' | 'nestjs' | 'nextjs' | 'remix' | 'xano';
  language?: 'typescript' | 'javascript';
  includeTests?: boolean;
  includeDocs?: boolean;
  deployTarget?: 'vercel' | 'netlify' | 'custom';
}

class ApiGeneratorService extends EventEmitter {
  private specs: Map<string, ApiSpec> = new Map();
  private isInitialized = false;
  
  constructor() {
    super();
  }
  
  /**
   * Initialize the API generator service
   */
  async initialize(specs: ApiSpec[] = []): Promise<boolean> {
    try {
      logger.info('Initializing API Generator service');
      
      // Register specs
      for (const spec of specs) {
        this.specs.set(spec.id, spec);
      }
      
      this.isInitialized = true;
      logger.info(`API Generator service initialized with ${this.specs.size} specifications`);
      
      return true;
    } catch (error) {
      logger.error('Failed to initialize API Generator service', error);
      return false;
    }
  }
  
  /**
   * Get all API specifications
   */
  getSpecs(): ApiSpec[] {
    return Array.from(this.specs.values());
  }
  
  /**
   * Get an API specification by ID
   */
  getSpec(id: string): ApiSpec | null {
    return this.specs.get(id) || null;
  }
  
  /**
   * Create a new API specification
   */
  createSpec(spec: Omit<ApiSpec, 'id' | 'createdAt' | 'updatedAt'>): string {
    try {
      // Generate unique ID
      const id = `spec-${uuidv4()}`;
      
      // Create specification with metadata
      const newSpec: ApiSpec = {
        id,
        ...spec,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      // Add to specs
      this.specs.set(id, newSpec);
      
      // Emit event
      this.emit('spec:created', { id, name: newSpec.name });
      
      logger.info(`Created API specification ${id}: ${newSpec.name}`);
      
      return id;
    } catch (error) {
      logger.error('Error creating API specification', error);
      throw error;
    }
  }
  
  /**
   * Update an API specification
   */
  updateSpec(id: string, updates: Partial<ApiSpec>): boolean {
    try {
      const spec = this.specs.get(id);
      
      if (!spec) {
        return false;
      }
      
      // Update fields
      const updatedSpec = { 
        ...spec, 
        ...updates,
        updatedAt: new Date()
      };
      
      this.specs.set(id, updatedSpec);
      
      // Emit event
      this.emit('spec:updated', { id, name: updatedSpec.name });
      
      return true;
    } catch (error) {
      logger.error(`Error updating API specification ${id}`, error);
      return false;
    }
  }
  
  /**
   * Delete an API specification
   */
  deleteSpec(id: string): boolean {
    try {
      if (!this.specs.has(id)) {
        return false;
      }
      
      // Get spec before removing
      const spec = this.specs.get(id)!;
      
      // Remove spec
      this.specs.delete(id);
      
      // Emit event
      this.emit('spec:deleted', { id, name: spec.name });
      
      return true;
    } catch (error) {
      logger.error(`Error deleting API specification ${id}`, error);
      return false;
    }
  }
  
  /**
   * Generate OpenAPI/Swagger specification
   */
  generateOpenApiSpec(id: string): Record<string, any> {
    try {
      const spec = this.specs.get(id);
      
      if (!spec) {
        throw new Error(`API specification ${id} not found`);
      }
      
      // Create OpenAPI object
      const openApi = {
        openapi: '3.0.0',
        info: {
          title: spec.name,
          description: spec.description || '',
          version: spec.version
        },
        paths: {},
        components: {
          schemas: {},
          securitySchemes: {}
        }
      };
      
      // Add paths (endpoints)
      for (const endpoint of spec.endpoints) {
        if (!openApi.paths[endpoint.path]) {
          openApi.paths[endpoint.path] = {};
        }
        
        const method = endpoint.method.toLowerCase();
        
        openApi.paths[endpoint.path][method] = {
          summary: endpoint.summary,
          description: endpoint.description || '',
          tags: endpoint.tags || [],
          parameters: endpoint.parameters || [],
          responses: endpoint.responses
        };
        
        // Add request body if present
        if (endpoint.requestBody) {
          openApi.paths[endpoint.path][method].requestBody = endpoint.requestBody;
        }
        
        // Add security if present
        if (endpoint.security && endpoint.security.length > 0) {
          openApi.paths[endpoint.path][method].security = endpoint.security.map(sec => ({ [sec]: [] }));
        }
      }
      
      // Add models (schemas)
      for (const model of spec.models) {
        openApi.components.schemas[model.name] = model.schema;
      }
      
      // Add security schemes
      if (spec.security) {
        for (const security of spec.security) {
          openApi.components.securitySchemes[security.name] = {
            type: security.type
          };
          
          // Add scheme-specific properties
          if (security.type === 'http') {
            openApi.components.securitySchemes[security.name].scheme = security.scheme;
            
            if (security.bearerFormat) {
              openApi.components.securitySchemes[security.name].bearerFormat = security.bearerFormat;
            }
          } else if (security.type === 'apiKey') {
            openApi.components.securitySchemes[security.name].in = security.in;
            openApi.components.securitySchemes[security.name].name = security.name;
          } else if (security.type === 'oauth2') {
            openApi.components.securitySchemes[security.name].flows = security.flows;
          }
        }
      }
      
      return openApi;
    } catch (error) {
      logger.error(`Error generating OpenAPI specification for ${id}`, error);
      throw error;
    }
  }
  
  /**
   * Generate Xano API configuration
   */
  async generateXanoApi(
    specId: string, 
    connectionId: string, 
    deploy: boolean = false
  ): Promise<boolean> {
    try {
      const spec = this.specs.get(specId);
      
      if (!spec) {
        throw new Error(`API specification ${specId} not found`);
      }
      
      // Convert spec to Xano format
      const xanoDefinition = this.convertSpecToXanoFormat(spec);
      
      // Use Xano service to create API
      const result = await xanoIntegrationService.executeMeta(
        connectionId, 
        'create-api',
        {
          definition: xanoDefinition,
          deploy
        }
      );
      
      if (result.status !== 'success') {
        throw new Error(`Failed to create Xano API: ${JSON.stringify(result)}`);
      }
      
      logger.info(`Successfully generated Xano API for spec ${specId}`);
      
      // Emit event
      this.emit('api:generated:xano', { 
        specId, 
        connectionId,
        result
      });
      
      return true;
    } catch (error) {
      logger.error(`Error generating Xano API for spec ${specId}`, error);
      return false;
    }
  }
  
  /**
   * Convert API specification to Xano format
   */
  private convertSpecToXanoFormat(spec: ApiSpec): Record<string, any> {
    // This is a simplified conversion - in reality, this would be more complex
    const xanoDefinition = {
      name: spec.name,
      description: spec.description || '',
      version: spec.version,
      endpoints: spec.endpoints.map(endpoint => ({
        name: endpoint.summary,
        method: endpoint.method,
        path: endpoint.path,
        description: endpoint.description || '',
        input: this.convertSchemaToXanoFormat(
          endpoint.requestBody?.content?.['application/json']?.schema
        ),
        output: this.convertSchemaToXanoFormat(
          endpoint.responses['200']?.content?.['application/json']?.schema
        ),
        middleware: []
      })),
      models: spec.models.map(model => ({
        name: model.name,
        description: model.description || '',
        schema: this.convertSchemaToXanoFormat(model.schema)
      })),
      webhooks: spec.webhooks.map(webhook => ({
        name: webhook.name,
        description: webhook.description || '',
        event: webhook.event,
        payload: this.convertSchemaToXanoFormat(webhook.payload.schema)
      }))
    };
    
    return xanoDefinition;
  }
  
  /**
   * Convert API schema to Xano format
   */
  private convertSchemaToXanoFormat(schema?: ApiSchema): Record<string, any> {
    if (!schema) {
      return {};
    }
    
    // Basic conversion - would need more complexity for a real implementation
    const xanoSchema: Record<string, any> = {
      type: schema.type
    };
    
    if (schema.properties) {
      xanoSchema.fields = {};
      
      for (const [key, prop] of Object.entries(schema.properties)) {
        xanoSchema.fields[key] = this.convertSchemaToXanoFormat(prop);
      }
    }
    
    if (schema.items && schema.type === 'array') {
      xanoSchema.items = this.convertSchemaToXanoFormat(schema.items);
    }
    
    return xanoSchema;
  }
  
  /**
   * Generate code for an API specification
   */
  async generateCode(
    specId: string, 
    options: GeneratorOptions = {}
  ): Promise<string> {
    try {
      const spec = this.specs.get(specId);
      
      if (!spec) {
        throw new Error(`API specification ${specId} not found`);
      }
      
      // Default options
      const opts = {
        outputPath: options.outputPath || './generated',
        format: options.format || 'json',
        framework: options.framework || 'express',
        language: options.language || 'typescript',
        includeTests: options.includeTests !== undefined ? options.includeTests : true,
        includeDocs: options.includeDocs !== undefined ? options.includeDocs : true
      };
      
      // Create output directory if it doesn't exist
      if (!fs.existsSync(opts.outputPath)) {
        fs.mkdirSync(opts.outputPath, { recursive: true });
      }
      
      // Generate OpenAPI spec
      const openApiSpec = this.generateOpenApiSpec(specId);
      
      // Save OpenAPI spec
      const specFilePath = path.join(
        opts.outputPath, 
        `openapi.${opts.format === 'json' ? 'json' : 'yaml'}`
      );
      
      if (opts.format === 'json') {
        fs.writeFileSync(specFilePath, JSON.stringify(openApiSpec, null, 2));
      } else {
        // For YAML, we'd need a library like js-yaml
        // This is a placeholder
        fs.writeFileSync(specFilePath, JSON.stringify(openApiSpec, null, 2));
      }
      
      // Generate code based on framework and language
      const generatedFiles = await this.generateFrameworkCode(spec, opts);
      
      // Emit event
      this.emit('code:generated', { 
        specId, 
        framework: opts.framework,
        language: opts.language,
        outputPath: opts.outputPath
      });
      
      logger.info(`Generated code for API spec ${specId} at ${opts.outputPath}`);
      
      return opts.outputPath;
    } catch (error) {
      logger.error(`Error generating code for API spec ${specId}`, error);
      throw error;
    }
  }
  
  /**
   * Generate framework-specific code
   */
  private async generateFrameworkCode(
    spec: ApiSpec, 
    options: Required<Omit<GeneratorOptions, 'deployTarget'>>
  ): Promise<string[]> {
    // This would be a complex implementation specific to each framework
    // For now, we'll return a placeholder
    const generatedFiles: string[] = [];
    
    switch (options.framework) {
      case 'express':
        generatedFiles.push(...this.generateExpressCode(spec, options));
        break;
      case 'nestjs':
        generatedFiles.push(...this.generateNestJsCode(spec, options));
        break;
      case 'nextjs':
        generatedFiles.push(...this.generateNextJsCode(spec, options));
        break;
      case 'remix':
        generatedFiles.push(...this.generateRemixCode(spec, options));
        break;
      case 'xano':
        // For Xano, we'd use the Xano integration service
        // This is handled separately
        break;
    }
    
    return generatedFiles;
  }
  
  /**
   * Generate Express code
   */
  private generateExpressCode(
    spec: ApiSpec, 
    options: Required<Omit<GeneratorOptions, 'deployTarget'>>
  ): string[] {
    const generatedFiles: string[] = [];
    const extension = options.language === 'typescript' ? 'ts' : 'js';
    
    // Generate server file
    const serverFilePath = path.join(options.outputPath, `server.${extension}`);
    
    // Simple Express server template
    const serverCode = options.language === 'typescript' 
      ? `
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import routes from './routes';

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use('/api', routes);

app.listen(port, () => {
  console.log(\`Server running at http://localhost:\${port}\`);
});
` 
      : `
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const routes = require('./routes');

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use('/api', routes);

app.listen(port, () => {
  console.log(\`Server running at http://localhost:\${port}\`);
});
`;
    
    fs.writeFileSync(serverFilePath, serverCode);
    generatedFiles.push(serverFilePath);
    
    // Generate routes file
    const routesFilePath = path.join(options.outputPath, `routes.${extension}`);
    
    // Generate routes based on API spec
    let routesCode = options.language === 'typescript'
      ? `
import { Router } from 'express';
const router = Router();

`
      : `
const { Router } = require('express');
const router = Router();

`;
    
    // Add routes for each endpoint
    for (const endpoint of spec.endpoints) {
      const method = endpoint.method.toLowerCase();
      const path = endpoint.path;
      
      routesCode += options.language === 'typescript'
        ? `
router.${method}('${path}', (req, res) => {
  // Implement ${endpoint.summary}
  res.json({ message: '${endpoint.summary} implementation pending' });
});
`
        : `
router.${method}('${path}', (req, res) => {
  // Implement ${endpoint.summary}
  res.json({ message: '${endpoint.summary} implementation pending' });
});
`;
    }
    
    // Add export
    routesCode += options.language === 'typescript'
      ? `
export default router;
`
      : `
module.exports = router;
`;
    
    fs.writeFileSync(routesFilePath, routesCode);
    generatedFiles.push(routesFilePath);
    
    // Generate model files
    for (const model of spec.models) {
      const modelFilePath = path.join(options.outputPath, `models/${model.name}.${extension}`);
      
      // Ensure directory exists
      const modelDir = path.join(options.outputPath, 'models');
      if (!fs.existsSync(modelDir)) {
        fs.mkdirSync(modelDir, { recursive: true });
      }
      
      // Generate model code based on schema
      const modelCode = options.language === 'typescript'
        ? `
export interface ${model.name} {
${this.generateTypeScriptInterface(model.schema, 2)}
}
`
        : `
// ${model.name} model
// This would be implementation specific based on the framework
`;
      
      fs.writeFileSync(modelFilePath, modelCode);
      generatedFiles.push(modelFilePath);
    }
    
    return generatedFiles;
  }
  
  /**
   * Generate TypeScript interface from schema
   */
  private generateTypeScriptInterface(schema: ApiSchema, indent: number = 0): string {
    const indentation = ' '.repeat(indent);
    
    if (schema.type !== 'object' || !schema.properties) {
      return `${indentation}// Not an object schema or no properties defined`;
    }
    
    let interfaceText = '';
    
    for (const [key, prop] of Object.entries(schema.properties)) {
      const isRequired = schema.required?.includes(key) ?? false;
      const propName = `${key}${isRequired ? '' : '?'}`;
      
      interfaceText += `${indentation}${propName}: `;
      
      if (prop.type === 'string') {
        interfaceText += 'string';
      } else if (prop.type === 'number' || prop.type === 'integer') {
        interfaceText += 'number';
      } else if (prop.type === 'boolean') {
        interfaceText += 'boolean';
      } else if (prop.type === 'array' && prop.items) {
        if (prop.items.type === 'object') {
          interfaceText += '{\n';
          interfaceText += this.generateTypeScriptInterface(prop.items, indent + 2);
          interfaceText += `${indentation}}[]`;
        } else {
          interfaceText += `${prop.items.type}[]`;
        }
      } else if (prop.type === 'object') {
        interfaceText += '{\n';
        interfaceText += this.generateTypeScriptInterface(prop, indent + 2);
        interfaceText += `${indentation}}`;
      } else {
        interfaceText += 'any';
      }
      
      interfaceText += ';\n';
    }
    
    return interfaceText;
  }
  
  /**
   * Generate NestJS code
   */
  private generateNestJsCode(
    spec: ApiSpec, 
    options: Required<Omit<GeneratorOptions, 'deployTarget'>>
  ): string[] {
    // Placeholder for NestJS code generation
    // Would implement similar to Express but with NestJS patterns
    return [];
  }
  
  /**
   * Generate Next.js code
   */
  private generateNextJsCode(
    spec: ApiSpec, 
    options: Required<Omit<GeneratorOptions, 'deployTarget'>>
  ): string[] {
    // Placeholder for Next.js code generation
    // Would create API routes in pages/api directory
    return [];
  }
  
  /**
   * Generate Remix code
   */
  private generateRemixCode(
    spec: ApiSpec, 
    options: Required<Omit<GeneratorOptions, 'deployTarget'>>
  ): string[] {
    // Placeholder for Remix code generation
    // Would create routes in app directory
    return [];
  }
  
  /**
   * Generate webhooks for an API specification
   */
  async generateWebhooks(specId: string): Promise<string[]> {
    try {
      const spec = this.specs.get(specId);
      
      if (!spec) {
        throw new Error(`API specification ${specId} not found`);
      }
      
      const webhookIds: string[] = [];
      
      // Generate a webhook for each webhook definition
      for (const webhookDef of spec.webhooks) {
        // Create webhook in webhook manager
        const webhookId = webhookManagerService.createWebhook({
          name: webhookDef.name,
          description: webhookDef.description,
          source: {
            type: 'custom', // Default to custom
            config: {}
          },
          destination: {
            url: 'https://example.com/webhook', // Placeholder
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            }
          },
          eventType: webhookDef.event,
          active: false // Start inactive
        });
        
        webhookIds.push(webhookId);
      }
      
      // Emit event
      this.emit('webhooks:generated', { 
        specId, 
        webhookIds
      });
      
      logger.info(`Generated ${webhookIds.length} webhooks for API spec ${specId}`);
      
      return webhookIds;
    } catch (error) {
      logger.error(`Error generating webhooks for API spec ${specId}`, error);
      throw error;
    }
  }
  
  /**
   * Deploy API code to a Git repository
   */
  async deployToGit(
    specId: string, 
    repositoryId: string, 
    branch: string = 'main',
    options: GeneratorOptions = {}
  ): Promise<boolean> {
    try {
      const spec = this.specs.get(specId);
      
      if (!spec) {
        throw new Error(`API specification ${specId} not found`);
      }
      
      // Generate code
      const outputPath = await this.generateCode(specId, options);
      
      // Get a list of files to commit
      const files = this.getFilesInDirectory(outputPath);
      
      // Create file changes
      const fileChanges: FileChange[] = [];
      
      for (const file of files) {
        const relativePath = path.relative(outputPath, file);
        const content = fs.readFileSync(file, 'utf-8');
        
        fileChanges.push({
          path: relativePath,
          content,
          operation: 'create',
          encoding: 'utf-8'
        });
      }
      
      // Create commit
      const commit = await gitIntegrationService.createCommit(
        repositoryId,
        branch,
        `Generated API code for ${spec.name}`,
        fileChanges
      );
      
      // Emit event
      this.emit('api:deployed:git', { 
        specId, 
        repositoryId,
        branch,
        commit
      });
      
      logger.info(`Deployed API code for spec ${specId} to Git repository ${repositoryId}`);
      
      return true;
    } catch (error) {
      logger.error(`Error deploying API code for spec ${specId} to Git`, error);
      return false;
    }
  }
  
  /**
   * Get all files in a directory recursively
   */
  private getFilesInDirectory(dir: string): string[] {
    const files: string[] = [];
    
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      
      if (entry.isDirectory()) {
        files.push(...this.getFilesInDirectory(fullPath));
      } else {
        files.push(fullPath);
      }
    }
    
    return files;
  }
  
  /**
   * Check if service is initialized
   */
  isReady(): boolean {
    return this.isInitialized;
  }
}

// Create singleton instance
const apiGeneratorService = new ApiGeneratorService();

export default apiGeneratorService;