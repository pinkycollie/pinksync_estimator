import { v4 as uuidv4 } from 'uuid';
import OpenAI from 'openai';

/**
 * Base response interface for all OpenAI service responses
 */
export interface BaseAIResponse {
  id: string;
  timestamp: string;
  model: string;
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
}

/**
 * OpenAI client singleton to ensure we only create one instance
 */
export class OpenAIClient {
  private static instance: OpenAI;

  /**
   * Get the OpenAI client instance
   */
  public static getInstance(): OpenAI {
    if (!OpenAIClient.instance) {
      if (!process.env.OPENAI_API_KEY) {
        throw new Error('OPENAI_API_KEY environment variable is not set');
      }

      OpenAIClient.instance = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
      });
    }
    
    return OpenAIClient.instance;
  }
}

/**
 * Create response metadata common to all AI responses
 */
export function createResponseMetadata(
  model: string, 
  usage: { prompt_tokens?: number; completion_tokens?: number; total_tokens?: number }
): BaseAIResponse {
  return {
    id: uuidv4(),
    timestamp: new Date().toISOString(),
    model,
    usage: {
      promptTokens: usage.prompt_tokens || 0,
      completionTokens: usage.completion_tokens || 0,
      totalTokens: usage.total_tokens || 0,
    },
  };
}

/**
 * Error handler wrapper for OpenAI API calls
 */
export async function handleOpenAIRequest<T>(
  requestFn: () => Promise<T>
): Promise<T> {
  try {
    return await requestFn();
  } catch (error) {
    // Log the error with additional context
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error(`OpenAI API error: ${errorMessage}`);
    
    // Rethrow with more context
    if (error instanceof Error) {
      if (error.message.includes('API key')) {
        throw new Error('Invalid or missing OpenAI API key. Please check your environment configuration.');
      } else if (error.message.includes('rate limit')) {
        throw new Error('OpenAI rate limit exceeded. Please try again later or adjust your request frequency.');
      }
      throw error;
    }
    
    throw new Error(`An error occurred while communicating with OpenAI: ${errorMessage}`);
  }
}

/**
 * Default parameters for OpenAI requests
 */
export const defaultParams = {
  // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
  chatModel: 'gpt-4o',
  completionModel: 'gpt-4o',
  embeddingModel: 'text-embedding-ada-002',
  temperature: 0.7,
  maxTokens: 500,
};