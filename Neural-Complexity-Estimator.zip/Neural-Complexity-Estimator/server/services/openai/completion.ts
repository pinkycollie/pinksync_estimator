/**
 * OpenAI Text Completion Service
 * Handles text completions with OpenAI models.
 */

import OpenAI from 'openai';

// Initialize OpenAI client
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY 
});

export interface CompletionOptions {
  model?: string;
  temperature?: number;
  maxTokens?: number;
  prompt?: string;
  systemPrompt?: string;
}

const defaultOptions: CompletionOptions = {
  // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
  model: 'gpt-4o',
  temperature: 0.7,
  maxTokens: 500,
};

/**
 * Text completion service
 */
export const completionService = {
  /**
   * Generate a text completion
   * @param prompt The text prompt
   * @param options Options for the completion
   * @returns The completion text
   */
  async generateTextCompletion(
    prompt: string,
    options: CompletionOptions = {}
  ): Promise<string> {
    try {
      const mergedOptions = { ...defaultOptions, ...options };
      
      // For newer models, use chat completion API
      const response = await openai.chat.completions.create({
        model: mergedOptions.model!,
        messages: [
          ...(mergedOptions.systemPrompt ? [{ role: 'system', content: mergedOptions.systemPrompt }] : []),
          { role: 'user', content: prompt }
        ],
        temperature: mergedOptions.temperature,
        max_tokens: mergedOptions.maxTokens,
      });
      
      return response.choices[0].message.content || '';
    } catch (error) {
      console.error('Error generating text completion:', error);
      throw error;
    }
  },
  
  /**
   * Generate image description from an image
   * @param base64Image Base64-encoded image data
   * @param prompt Optional prompt for guiding the description
   * @param options Options for the completion
   * @returns The image description
   */
  async generateImageDescription(
    base64Image: string,
    prompt: string = 'Describe this image in detail.',
    options: CompletionOptions = {}
  ): Promise<string> {
    try {
      const mergedOptions = { ...defaultOptions, ...options };
      
      const response = await openai.chat.completions.create({
        model: 'gpt-4o', // For vision tasks, use GPT-4o
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: prompt },
              {
                type: 'image_url',
                image_url: {
                  url: `data:image/jpeg;base64,${base64Image}`
                }
              }
            ],
          },
        ],
        max_tokens: mergedOptions.maxTokens,
      });
      
      return response.choices[0].message.content || '';
    } catch (error) {
      console.error('Error generating image description:', error);
      throw error;
    }
  },
};

export default completionService;