/**
 * OpenAI Chat Completion Service
 * Handles chat-based completions with OpenAI models.
 */

import OpenAI from 'openai';
import type { ChatCompletionMessageParam } from 'openai/resources/chat';

// Initialize OpenAI client
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY 
});

// Define message types
export interface ChatMessage {
  role: 'system' | 'user' | 'assistant' | 'function';
  content: string;
  name?: string;
}

export interface ChatCompletionOptions {
  model?: string;
  temperature?: number;
  maxTokens?: number;
  systemPrompt?: string;
  useContext?: boolean;
  contextId?: string;
}

const defaultOptions: ChatCompletionOptions = {
  // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
  model: 'gpt-4o',
  temperature: 0.7,
  maxTokens: 1000,
  useContext: false
};

/**
 * Chat completion service
 */
export const chatCompletionService = {
  /**
   * Generate a chat completion response
   * @param messages Array of chat messages
   * @param options Options for the completion
   * @returns The assistant's response
   */
  async generateChatCompletion(
    messages: ChatMessage[],
    options: ChatCompletionOptions = {}
  ): Promise<ChatMessage> {
    try {
      const mergedOptions = { ...defaultOptions, ...options };
      
      // Prepare messages array with system prompt if provided
      let chatMessages = [...messages];
      
      if (mergedOptions.systemPrompt && !messages.some(m => m.role === 'system')) {
        chatMessages.unshift({
          role: 'system',
          content: mergedOptions.systemPrompt
        });
      }
      
      // Add context from context manager if enabled
      if (mergedOptions.useContext && mergedOptions.contextId) {
        // Import dynamically to avoid circular dependency
        const { default: contextManager } = await import('./context');
        const contextMessages = await contextManager.getContext(mergedOptions.contextId);
        if (contextMessages && contextMessages.length > 0) {
          chatMessages = [...contextMessages, ...chatMessages];
        }
      }
      
      // Call OpenAI API
      const response = await openai.chat.completions.create({
        model: mergedOptions.model!,
        messages: chatMessages.map(m => ({
          role: m.role,
          content: m.content,
          ...(m.name ? { name: m.name } : {})
        })),
        temperature: mergedOptions.temperature,
        max_tokens: mergedOptions.maxTokens,
      });
      
      // Extract the assistant's message
      const completionMessage = response.choices[0].message;
      
      // Store in context if context management is enabled
      if (mergedOptions.useContext && mergedOptions.contextId) {
        // Import dynamically to avoid circular dependency
        const { default: contextManager } = await import('./context');
        await contextManager.addToContext(
          mergedOptions.contextId,
          [...chatMessages, { role: 'assistant', content: completionMessage.content || "" }]
        );
      }
      
      return {
        role: 'assistant',
        content: completionMessage.content
      };
    } catch (error) {
      console.error('Error generating chat completion:', error);
      throw error;
    }
  },
  
  /**
   * Generate a chat completion with JSON output
   * @param messages Array of chat messages
   * @param responseSchema Description of the expected JSON schema
   * @param options Options for the completion
   * @returns The assistant's response parsed as JSON
   */
  async generateJsonResponse(
    messages: ChatMessage[],
    responseSchema: string,
    options: ChatCompletionOptions = {}
  ): Promise<any> {
    try {
      // Add system instruction for JSON output
      const systemPrompt = options.systemPrompt || '';
      const jsonSystemPrompt = `${systemPrompt}\n\nYou must respond in valid JSON format according to this schema: ${responseSchema}`;
      
      const mergedOptions = { 
        ...defaultOptions, 
        ...options,
        systemPrompt: jsonSystemPrompt,
        temperature: options.temperature || 0.1 // Lower temperature for JSON outputs
      };
      
      const chatMessages = [...messages];
      
      // Call OpenAI API with response_format: json_object
      const response = await openai.chat.completions.create({
        model: mergedOptions.model!,
        messages: [
          { role: 'system', content: jsonSystemPrompt },
          ...chatMessages.map(m => ({
            role: m.role,
            content: m.content,
            ...(m.name ? { name: m.name } : {})
          }))
        ],
        temperature: mergedOptions.temperature,
        max_tokens: mergedOptions.maxTokens,
        response_format: { type: "json_object" }
      });
      
      // Parse the JSON response
      const content = response.choices[0].message.content;
      return JSON.parse(content);
    } catch (error) {
      console.error('Error generating JSON response:', error);
      throw error;
    }
  }
};

export default chatCompletionService;