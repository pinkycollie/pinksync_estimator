/**
 * OpenAI Context Manager
 * Manages conversation context for AI chat interactions.
 */

import { ChatMessage } from './chat';

// Simple in-memory storage for contexts
interface ContextStore {
  [contextId: string]: ChatMessage[];
}

// Default context window size (number of messages to keep)
const DEFAULT_CONTEXT_WINDOW = 10;

/**
 * In-memory implementation of context management
 * In a production system, this would likely be stored in a database
 */
class ContextManager {
  private contexts: ContextStore = {};
  private windowSize: number;
  
  constructor(windowSize: number = DEFAULT_CONTEXT_WINDOW) {
    this.windowSize = windowSize;
  }
  
  /**
   * Initialize a new context or clear an existing one
   * @param contextId The ID for the context
   */
  async initializeContext(contextId: string): Promise<void> {
    this.contexts[contextId] = [];
  }
  
  /**
   * Get the current conversation context
   * @param contextId The ID for the context
   * @returns Array of messages in the context, or undefined if not found
   */
  async getContext(contextId: string): Promise<ChatMessage[] | undefined> {
    return this.contexts[contextId];
  }
  
  /**
   * Add messages to the context, maintaining the window size
   * @param contextId The ID for the context
   * @param messages The messages to add
   */
  async addToContext(contextId: string, messages: ChatMessage[]): Promise<void> {
    if (!this.contexts[contextId]) {
      this.contexts[contextId] = [];
    }
    
    // Add new messages
    this.contexts[contextId] = [...this.contexts[contextId], ...messages];
    
    // Trim to window size if needed
    if (this.contexts[contextId].length > this.windowSize) {
      // Keep the most recent messages up to window size
      // Also try to keep system messages if possible
      const systemMessages = this.contexts[contextId].filter(m => m.role === 'system');
      const nonSystemMessages = this.contexts[contextId].filter(m => m.role !== 'system');
      
      // Calculate how many non-system messages we can keep
      const availableSpace = this.windowSize - systemMessages.length;
      const recentNonSystemMessages = nonSystemMessages.slice(-availableSpace);
      
      // Combine system messages with recent non-system messages
      this.contexts[contextId] = [...systemMessages, ...recentNonSystemMessages];
    }
  }
  
  /**
   * Delete a context
   * @param contextId The ID for the context to delete
   */
  async deleteContext(contextId: string): Promise<void> {
    delete this.contexts[contextId];
  }
  
  /**
   * Set the window size (number of messages to keep in context)
   * @param size New window size
   */
  setWindowSize(size: number): void {
    this.windowSize = size;
  }
}

// Export singleton instance
export const contextManager = new ContextManager();

export default contextManager;