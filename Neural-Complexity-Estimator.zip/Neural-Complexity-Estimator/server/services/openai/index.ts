/**
 * OpenAI Service
 * Provides access to OpenAI API functionality.
 */

import chatCompletionService from './chat';
import embeddingService from './embeddings';
import completionService from './completion';
import contextManager from './context';

// Export services as a single module
export const openaiService = {
  chat: chatCompletionService,
  embeddings: embeddingService,
  completion: completionService,
  context: contextManager
};

export default openaiService;