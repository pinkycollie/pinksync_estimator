/**
 * Project Complexity Estimator Service
 * 
 * Self-contained wrapper service that uses neural complexity analysis.
 * No external dependencies required - everything runs within PinkSync.
 */

import { logger } from '../../utils/logger';
import { 
  neuralComplexityEstimator,
  type ProjectRequirements,
  type ComplexityAnalysis,
  type ProjectPhase,
  type RiskFactor,
  type ResourceRequirements
} from './neuralComplexityEstimator';

// Re-export types for backward compatibility
export type {
  ProjectRequirements,
  ComplexityAnalysis,
  ProjectPhase,
  RiskFactor,
  ResourceRequirements
};

class ComplexityEstimatorService {
  private isInitialized = false;

  constructor() {}

  async initialize(): Promise<boolean> {
    try {
      logger.info('Initializing self-contained Complexity Estimator service');
      const neuralInitialized = await neuralComplexityEstimator.initialize();
      this.isInitialized = neuralInitialized;
      return neuralInitialized;
    } catch (error) {
      logger.error('Failed to initialize Complexity Estimator service', error);
      return false;
    }
  }

  async analyzeProjectComplexity(requirements: ProjectRequirements): Promise<ComplexityAnalysis> {
    if (!this.isInitialized) {
      throw new Error('Complexity Estimator service not initialized');
    }

    try {
      return await neuralComplexityEstimator.analyzeProjectComplexity(requirements);
    } catch (error) {
      logger.error('Error analyzing project complexity', error);
      throw new Error('Failed to analyze project complexity');
    }
  }

  async generateProjectRoadmap(requirements: ProjectRequirements, analysis: ComplexityAnalysis): Promise<string[]> {
    try {
      return await neuralComplexityEstimator.generateProjectRoadmap(requirements, analysis);
    } catch (error) {
      logger.error('Error generating project roadmap', error);
      return [];
    }
  }

  isReady(): boolean {
    return this.isInitialized && neuralComplexityEstimator.isReady();
  }
}

// Create singleton instance
const complexityEstimatorService = new ComplexityEstimatorService();

export { complexityEstimatorService };
export default complexityEstimatorService;