/**
 * PinkSync - Trend Database Synchronization Service
 * 
 * This service manages the synchronization of trend analysis data across multiple
 * platforms and environments, ensuring consistency throughout the PinkSync ecosystem.
 */

import * as fs from 'fs';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { storage } from '../../storage';
import { platformSyncManager } from '../../utils/platformSyncManager';
import {
  InsertTechnologyTrend,
  InsertGithubTrend,
  InsertEconomicNews,
  InsertIdeaValidation,
  TechnologyTrend,
  GithubTrend,
  EconomicNews,
  IdeaValidation
} from '../../../shared/trendAnalysisSchema';

/**
 * Sync options for trend database
 */
export interface TrendSyncOptions {
  connectionId: string;
  targetPath?: string;
  syncTechnologyTrends?: boolean;
  syncGithubTrends?: boolean;
  syncEconomicNews?: boolean;
  syncIdeaValidations?: boolean;
  lastSyncTimestamp?: Date;
  fullSync?: boolean;
}

/**
 * Result of trend database sync operation
 */
export interface TrendSyncResult {
  success: boolean;
  syncTimestamp: Date;
  technologyTrendsCount: number;
  githubTrendsCount: number;
  economicNewsCount: number;
  ideaValidationsCount: number;
  totalItemsSynced: number;
  error?: string;
}

class TrendSyncService {
  private readonly syncDir: string;
  
  constructor() {
    this.syncDir = path.join(process.cwd(), 'data', 'trend_sync');
    this.ensureDirectoryExists(this.syncDir);
  }
  
  /**
   * Synchronize trend database to a connected platform
   */
  async syncToRemote(options: TrendSyncOptions): Promise<TrendSyncResult> {
    try {
      // Default options
      const syncOptions: TrendSyncOptions = {
        ...options,
        syncTechnologyTrends: options.syncTechnologyTrends !== false,
        syncGithubTrends: options.syncGithubTrends !== false,
        syncEconomicNews: options.syncEconomicNews !== false,
        syncIdeaValidations: options.syncIdeaValidations !== false,
        fullSync: options.fullSync || false
      };
      
      // Get the connection
      const connection = await storage.getPlatformConnection(options.connectionId);
      if (!connection) {
        return {
          success: false,
          syncTimestamp: new Date(),
          technologyTrendsCount: 0,
          githubTrendsCount: 0,
          economicNewsCount: 0,
          ideaValidationsCount: 0,
          totalItemsSynced: 0,
          error: `Platform connection with ID ${options.connectionId} not found`
        };
      }
      
      // Determine target path on the remote platform
      const targetPath = options.targetPath || 
                         connection.rootPath || 
                         '/PinkSync/TrendData';
      
      const syncTimestamp = new Date();
      const result: TrendSyncResult = {
        success: true,
        syncTimestamp,
        technologyTrendsCount: 0,
        githubTrendsCount: 0,
        economicNewsCount: 0,
        ideaValidationsCount: 0,
        totalItemsSynced: 0
      };
      
      // Create a sync manifest
      const syncManifest = {
        syncId: uuidv4(),
        timestamp: syncTimestamp,
        connection: {
          id: connection.id,
          name: connection.name,
          platform: connection.platform
        },
        syncedItems: {
          technologyTrends: [] as { id: number, name: string }[],
          githubTrends: [] as { id: number, name: string }[],
          economicNews: [] as { id: number, title: string }[],
          ideaValidations: [] as { id: number, ideaId: number }[]
        }
      };
      
      // Sync technology trends
      if (syncOptions.syncTechnologyTrends) {
        // Get technology trends to sync
        const trends = syncOptions.fullSync ?
          await storage.getAllTechnologyTrends() :
          await storage.getTechnologyTrendsSince(syncOptions.lastSyncTimestamp || new Date(0));
        
        if (trends.length > 0) {
          // Create JSON file with technology trends
          const trendsFileName = `technology_trends_${syncTimestamp.toISOString().replace(/[:.-]/g, '_')}.json`;
          const trendsFilePath = path.join(this.syncDir, trendsFileName);
          fs.writeFileSync(trendsFilePath, JSON.stringify(trends, null, 2));
          
          // Upload to remote platform
          const remotePath = path.join(targetPath, 'technology_trends', trendsFileName).replace(/\\/g, '/');
          const uploadResult = await platformSyncManager.uploadFile(
            options.connectionId,
            trendsFilePath,
            remotePath
          );
          
          if (uploadResult.success) {
            result.technologyTrendsCount = trends.length;
            result.totalItemsSynced += trends.length;
            
            // Add to manifest
            syncManifest.syncedItems.technologyTrends = trends.map(trend => ({
              id: trend.id,
              name: trend.name
            }));
          }
        }
      }
      
      // Sync GitHub trends
      if (syncOptions.syncGithubTrends) {
        // Get GitHub trends to sync
        const githubTrends = syncOptions.fullSync ?
          await storage.getAllGithubTrends() :
          await storage.getGithubTrendsSince(syncOptions.lastSyncTimestamp || new Date(0));
        
        if (githubTrends.length > 0) {
          // Create JSON file with GitHub trends
          const githubFileName = `github_trends_${syncTimestamp.toISOString().replace(/[:.-]/g, '_')}.json`;
          const githubFilePath = path.join(this.syncDir, githubFileName);
          fs.writeFileSync(githubFilePath, JSON.stringify(githubTrends, null, 2));
          
          // Upload to remote platform
          const remotePath = path.join(targetPath, 'github_trends', githubFileName).replace(/\\/g, '/');
          const uploadResult = await platformSyncManager.uploadFile(
            options.connectionId,
            githubFilePath,
            remotePath
          );
          
          if (uploadResult.success) {
            result.githubTrendsCount = githubTrends.length;
            result.totalItemsSynced += githubTrends.length;
            
            // Add to manifest
            syncManifest.syncedItems.githubTrends = githubTrends.map(trend => ({
              id: trend.id,
              name: `${trend.ownerName}/${trend.repositoryName}`
            }));
          }
        }
      }
      
      // Sync economic news
      if (syncOptions.syncEconomicNews) {
        // Get economic news to sync
        const economicNews = syncOptions.fullSync ?
          await storage.getAllEconomicNews() :
          await storage.getEconomicNewsSince(syncOptions.lastSyncTimestamp || new Date(0));
        
        if (economicNews.length > 0) {
          // Create JSON file with economic news
          const newsFileName = `economic_news_${syncTimestamp.toISOString().replace(/[:.-]/g, '_')}.json`;
          const newsFilePath = path.join(this.syncDir, newsFileName);
          fs.writeFileSync(newsFilePath, JSON.stringify(economicNews, null, 2));
          
          // Upload to remote platform
          const remotePath = path.join(targetPath, 'economic_news', newsFileName).replace(/\\/g, '/');
          const uploadResult = await platformSyncManager.uploadFile(
            options.connectionId,
            newsFilePath,
            remotePath
          );
          
          if (uploadResult.success) {
            result.economicNewsCount = economicNews.length;
            result.totalItemsSynced += economicNews.length;
            
            // Add to manifest
            syncManifest.syncedItems.economicNews = economicNews.map(news => ({
              id: news.id,
              title: news.title
            }));
          }
        }
      }
      
      // Sync idea validations
      if (syncOptions.syncIdeaValidations) {
        // Get idea validations to sync
        const ideaValidations = syncOptions.fullSync ?
          await storage.getAllIdeaValidations() :
          await storage.getIdeaValidationsSince(syncOptions.lastSyncTimestamp || new Date(0));
        
        if (ideaValidations.length > 0) {
          // Create JSON file with idea validations
          const validationsFileName = `idea_validations_${syncTimestamp.toISOString().replace(/[:.-]/g, '_')}.json`;
          const validationsFilePath = path.join(this.syncDir, validationsFileName);
          fs.writeFileSync(validationsFilePath, JSON.stringify(ideaValidations, null, 2));
          
          // Upload to remote platform
          const remotePath = path.join(targetPath, 'idea_validations', validationsFileName).replace(/\\/g, '/');
          const uploadResult = await platformSyncManager.uploadFile(
            options.connectionId,
            validationsFilePath,
            remotePath
          );
          
          if (uploadResult.success) {
            result.ideaValidationsCount = ideaValidations.length;
            result.totalItemsSynced += ideaValidations.length;
            
            // Add to manifest
            syncManifest.syncedItems.ideaValidations = ideaValidations.map(validation => ({
              id: validation.id,
              ideaId: validation.ideaId
            }));
          }
        }
      }
      
      // Upload sync manifest
      const manifestFileName = `sync_manifest_${syncTimestamp.toISOString().replace(/[:.-]/g, '_')}.json`;
      const manifestFilePath = path.join(this.syncDir, manifestFileName);
      fs.writeFileSync(manifestFilePath, JSON.stringify(syncManifest, null, 2));
      
      const manifestRemotePath = path.join(targetPath, 'manifests', manifestFileName).replace(/\\/g, '/');
      await platformSyncManager.uploadFile(
        options.connectionId,
        manifestFilePath,
        manifestRemotePath
      );
      
      // Save sync record to database
      await storage.createSyncRecord({
        syncId: syncManifest.syncId,
        connectionId: options.connectionId,
        timestamp: syncTimestamp,
        direction: 'outgoing',
        itemTypes: [
          ...(syncOptions.syncTechnologyTrends ? ['technology_trends'] : []),
          ...(syncOptions.syncGithubTrends ? ['github_trends'] : []),
          ...(syncOptions.syncEconomicNews ? ['economic_news'] : []),
          ...(syncOptions.syncIdeaValidations ? ['idea_validations'] : [])
        ],
        itemCounts: {
          technologyTrends: result.technologyTrendsCount,
          githubTrends: result.githubTrendsCount,
          economicNews: result.economicNewsCount,
          ideaValidations: result.ideaValidationsCount,
          total: result.totalItemsSynced
        },
        manifestPath: manifestRemotePath,
        success: true
      });
      
      return result;
    } catch (error: any) {
      console.error('Error syncing trend database to remote:', error);
      return {
        success: false,
        syncTimestamp: new Date(),
        technologyTrendsCount: 0,
        githubTrendsCount: 0,
        economicNewsCount: 0,
        ideaValidationsCount: 0,
        totalItemsSynced: 0,
        error: error.message || 'Unknown error during sync'
      };
    }
  }
  
  /**
   * Synchronize trend database from a connected platform
   */
  async syncFromRemote(connectionId: string, manifestPath?: string): Promise<TrendSyncResult> {
    try {
      // Get the connection
      const connection = await storage.getPlatformConnection(connectionId);
      if (!connection) {
        return {
          success: false,
          syncTimestamp: new Date(),
          technologyTrendsCount: 0,
          githubTrendsCount: 0,
          economicNewsCount: 0,
          ideaValidationsCount: 0,
          totalItemsSynced: 0,
          error: `Platform connection with ID ${connectionId} not found`
        };
      }
      
      // Determine remote base path
      const remotePath = connection.rootPath || '/PinkSync/TrendData';
      
      let manifestFilePath: string;
      
      // If manifest path is provided, use it; otherwise, find latest manifest
      if (manifestPath) {
        // Download the specified manifest
        const tempManifestPath = path.join(this.syncDir, `temp_manifest_${Date.now()}.json`);
        const downloadResult = await platformSyncManager.downloadFile(
          connectionId,
          manifestPath,
          tempManifestPath
        );
        
        if (!downloadResult.success) {
          return {
            success: false,
            syncTimestamp: new Date(),
            technologyTrendsCount: 0,
            githubTrendsCount: 0,
            economicNewsCount: 0,
            ideaValidationsCount: 0,
            totalItemsSynced: 0,
            error: `Failed to download manifest: ${downloadResult.error || 'Unknown error'}`
          };
        }
        
        manifestFilePath = tempManifestPath;
      } else {
        // List manifest directory to find latest manifest
        const manifestsDir = path.join(remotePath, 'manifests').replace(/\\/g, '/');
        const manifestFiles = await this.listRemoteFiles(connectionId, manifestsDir);
        
        if (!manifestFiles.length) {
          return {
            success: false,
            syncTimestamp: new Date(),
            technologyTrendsCount: 0,
            githubTrendsCount: 0,
            economicNewsCount: 0,
            ideaValidationsCount: 0,
            totalItemsSynced: 0,
            error: 'No sync manifests found on remote platform'
          };
        }
        
        // Sort manifests by name (which contains timestamp) in descending order
        manifestFiles.sort((a, b) => b.localeCompare(a));
        
        // Download the latest manifest
        const latestManifestPath = path.join(manifestsDir, manifestFiles[0]).replace(/\\/g, '/');
        const tempManifestPath = path.join(this.syncDir, manifestFiles[0]);
        const downloadResult = await platformSyncManager.downloadFile(
          connectionId,
          latestManifestPath,
          tempManifestPath
        );
        
        if (!downloadResult.success) {
          return {
            success: false,
            syncTimestamp: new Date(),
            technologyTrendsCount: 0,
            githubTrendsCount: 0,
            economicNewsCount: 0,
            ideaValidationsCount: 0,
            totalItemsSynced: 0,
            error: `Failed to download latest manifest: ${downloadResult.error || 'Unknown error'}`
          };
        }
        
        manifestFilePath = tempManifestPath;
      }
      
      // Read and parse the manifest
      const manifestContent = fs.readFileSync(manifestFilePath, 'utf8');
      const manifest = JSON.parse(manifestContent);
      
      const result: TrendSyncResult = {
        success: true,
        syncTimestamp: new Date(manifest.timestamp),
        technologyTrendsCount: 0,
        githubTrendsCount: 0,
        economicNewsCount: 0,
        ideaValidationsCount: 0,
        totalItemsSynced: 0
      };
      
      // Process each trend type based on the manifest
      // Technology Trends
      if (manifest.syncedItems.technologyTrends && manifest.syncedItems.technologyTrends.length > 0) {
        // Find the file containing technology trends
        const trendDir = path.join(remotePath, 'technology_trends').replace(/\\/g, '/');
        const trendFiles = await this.listRemoteFiles(connectionId, trendDir);
        
        // Filter files by timestamp in the manifest
        const manifestTimestamp = new Date(manifest.timestamp).toISOString().replace(/[:.-]/g, '_');
        const matchingFiles = trendFiles.filter(file => file.includes(manifestTimestamp));
        
        if (matchingFiles.length > 0) {
          // Download the file
          const remoteTrendFile = path.join(trendDir, matchingFiles[0]).replace(/\\/g, '/');
          const localTrendFile = path.join(this.syncDir, matchingFiles[0]);
          const downloadResult = await platformSyncManager.downloadFile(
            connectionId,
            remoteTrendFile,
            localTrendFile
          );
          
          if (downloadResult.success) {
            // Parse the file
            const trendsContent = fs.readFileSync(localTrendFile, 'utf8');
            const trends: TechnologyTrend[] = JSON.parse(trendsContent);
            
            // Import each trend
            for (const trend of trends) {
              // Check if trend already exists
              const existingTrend = await storage.getTechnologyTrendByNameAndCategory(trend.name, trend.category);
              
              if (existingTrend) {
                // Update existing trend
                await storage.updateTechnologyTrend(existingTrend.id, {
                  description: trend.description,
                  source: trend.source,
                  sourceUrl: trend.sourceUrl,
                  mentionCount: trend.mentionCount,
                  growthRate: trend.growthRate,
                  lastMentionedAt: trend.lastMentionedAt,
                  metadata: trend.metadata,
                  isActive: trend.isActive,
                  updatedAt: new Date()
                });
              } else {
                // Create new trend
                await storage.createTechnologyTrend({
                  name: trend.name,
                  category: trend.category,
                  description: trend.description,
                  source: trend.source,
                  sourceUrl: trend.sourceUrl,
                  mentionCount: trend.mentionCount,
                  growthRate: trend.growthRate,
                  firstDetectedAt: trend.firstDetectedAt,
                  lastMentionedAt: trend.lastMentionedAt,
                  metadata: trend.metadata,
                  isActive: trend.isActive
                });
              }
              
              result.technologyTrendsCount++;
              result.totalItemsSynced++;
            }
          }
        }
      }
      
      // GitHub Trends
      if (manifest.syncedItems.githubTrends && manifest.syncedItems.githubTrends.length > 0) {
        // Find the file containing GitHub trends
        const githubDir = path.join(remotePath, 'github_trends').replace(/\\/g, '/');
        const githubFiles = await this.listRemoteFiles(connectionId, githubDir);
        
        // Filter files by timestamp in the manifest
        const manifestTimestamp = new Date(manifest.timestamp).toISOString().replace(/[:.-]/g, '_');
        const matchingFiles = githubFiles.filter(file => file.includes(manifestTimestamp));
        
        if (matchingFiles.length > 0) {
          // Download the file
          const remoteGithubFile = path.join(githubDir, matchingFiles[0]).replace(/\\/g, '/');
          const localGithubFile = path.join(this.syncDir, matchingFiles[0]);
          const downloadResult = await platformSyncManager.downloadFile(
            connectionId,
            remoteGithubFile,
            localGithubFile
          );
          
          if (downloadResult.success) {
            // Parse the file
            const githubContent = fs.readFileSync(localGithubFile, 'utf8');
            const githubTrends: GithubTrend[] = JSON.parse(githubContent);
            
            // Import each GitHub trend
            for (const trend of githubTrends) {
              // Check if trend already exists
              const existingTrend = await storage.getGithubTrendByRepositoryName(trend.ownerName, trend.repositoryName);
              
              if (existingTrend) {
                // Update existing trend
                await storage.updateGithubTrend(existingTrend.id, {
                  description: trend.description,
                  category: trend.category,
                  language: trend.language,
                  starCount: trend.starCount,
                  forkCount: trend.forkCount,
                  issueCount: trend.issueCount,
                  contributorCount: trend.contributorCount,
                  growthRate: trend.growthRate,
                  relatedTrendId: trend.relatedTrendId,
                  lastUpdatedAt: trend.lastUpdatedAt,
                  metadata: trend.metadata,
                  isActive: trend.isActive,
                  updatedAt: new Date()
                });
              } else {
                // Create new trend
                await storage.createGithubTrend({
                  repositoryName: trend.repositoryName,
                  ownerName: trend.ownerName,
                  url: trend.url,
                  description: trend.description,
                  category: trend.category,
                  language: trend.language,
                  starCount: trend.starCount,
                  forkCount: trend.forkCount,
                  issueCount: trend.issueCount,
                  contributorCount: trend.contributorCount,
                  growthRate: trend.growthRate,
                  relatedTrendId: trend.relatedTrendId,
                  firstDetectedAt: trend.firstDetectedAt,
                  lastUpdatedAt: trend.lastUpdatedAt,
                  metadata: trend.metadata,
                  isActive: trend.isActive
                });
              }
              
              result.githubTrendsCount++;
              result.totalItemsSynced++;
            }
          }
        }
      }
      
      // Economic News
      if (manifest.syncedItems.economicNews && manifest.syncedItems.economicNews.length > 0) {
        // Find the file containing economic news
        const newsDir = path.join(remotePath, 'economic_news').replace(/\\/g, '/');
        const newsFiles = await this.listRemoteFiles(connectionId, newsDir);
        
        // Filter files by timestamp in the manifest
        const manifestTimestamp = new Date(manifest.timestamp).toISOString().replace(/[:.-]/g, '_');
        const matchingFiles = newsFiles.filter(file => file.includes(manifestTimestamp));
        
        if (matchingFiles.length > 0) {
          // Download the file
          const remoteNewsFile = path.join(newsDir, matchingFiles[0]).replace(/\\/g, '/');
          const localNewsFile = path.join(this.syncDir, matchingFiles[0]);
          const downloadResult = await platformSyncManager.downloadFile(
            connectionId,
            remoteNewsFile,
            localNewsFile
          );
          
          if (downloadResult.success) {
            // Parse the file
            const newsContent = fs.readFileSync(localNewsFile, 'utf8');
            const news: EconomicNews[] = JSON.parse(newsContent);
            
            // Import each economic news
            for (const newsItem of news) {
              // Check if news already exists (by title and source)
              const existingNews = await storage.getEconomicNewsByTitleAndSource(newsItem.title, newsItem.source);
              
              if (!existingNews) {
                // Only create if it doesn't exist (news are typically immutable)
                await storage.createEconomicNews({
                  title: newsItem.title,
                  summary: newsItem.summary,
                  source: newsItem.source,
                  url: newsItem.url,
                  category: newsItem.category,
                  sector: newsItem.sector,
                  sentimentScore: newsItem.sentimentScore,
                  impactLevel: newsItem.impactLevel,
                  relatedTrendIds: newsItem.relatedTrendIds,
                  publishedAt: newsItem.publishedAt,
                  detectedAt: newsItem.detectedAt,
                  metadata: newsItem.metadata
                });
                
                result.economicNewsCount++;
                result.totalItemsSynced++;
              }
            }
          }
        }
      }
      
      // Idea Validations
      if (manifest.syncedItems.ideaValidations && manifest.syncedItems.ideaValidations.length > 0) {
        // Find the file containing idea validations
        const validationsDir = path.join(remotePath, 'idea_validations').replace(/\\/g, '/');
        const validationFiles = await this.listRemoteFiles(connectionId, validationsDir);
        
        // Filter files by timestamp in the manifest
        const manifestTimestamp = new Date(manifest.timestamp).toISOString().replace(/[:.-]/g, '_');
        const matchingFiles = validationFiles.filter(file => file.includes(manifestTimestamp));
        
        if (matchingFiles.length > 0) {
          // Download the file
          const remoteValidationFile = path.join(validationsDir, matchingFiles[0]).replace(/\\/g, '/');
          const localValidationFile = path.join(this.syncDir, matchingFiles[0]);
          const downloadResult = await platformSyncManager.downloadFile(
            connectionId,
            remoteValidationFile,
            localValidationFile
          );
          
          if (downloadResult.success) {
            // Parse the file
            const validationsContent = fs.readFileSync(localValidationFile, 'utf8');
            const validations: IdeaValidation[] = JSON.parse(validationsContent);
            
            // Import each idea validation
            for (const validation of validations) {
              // Check if validation already exists for this idea
              const existingValidation = await storage.getIdeaValidationByIdeaAndAnalysisId(
                validation.ideaId, 
                validation.analysisId || ''
              );
              
              if (existingValidation) {
                // Update existing validation
                await storage.updateIdeaValidation(existingValidation.id, {
                  marketValidation: validation.marketValidation,
                  technicalValidation: validation.technicalValidation,
                  economicValidation: validation.economicValidation,
                  competitiveValidation: validation.competitiveValidation,
                  overallResult: validation.overallResult,
                  validationDate: validation.validationDate,
                  validatedBy: validation.validatedBy,
                  metadata: validation.metadata,
                  updatedAt: new Date()
                });
              } else {
                // Create new validation
                await storage.createIdeaValidation({
                  ideaId: validation.ideaId,
                  analysisId: validation.analysisId,
                  marketValidation: validation.marketValidation,
                  technicalValidation: validation.technicalValidation,
                  economicValidation: validation.economicValidation,
                  competitiveValidation: validation.competitiveValidation,
                  overallResult: validation.overallResult,
                  validationDate: validation.validationDate,
                  validatedBy: validation.validatedBy,
                  metadata: validation.metadata
                });
              }
              
              result.ideaValidationsCount++;
              result.totalItemsSynced++;
            }
          }
        }
      }
      
      // Save sync record to database
      await storage.createSyncRecord({
        syncId: manifest.syncId,
        connectionId,
        timestamp: new Date(manifest.timestamp),
        direction: 'incoming',
        itemTypes: [
          ...(result.technologyTrendsCount > 0 ? ['technology_trends'] : []),
          ...(result.githubTrendsCount > 0 ? ['github_trends'] : []),
          ...(result.economicNewsCount > 0 ? ['economic_news'] : []),
          ...(result.ideaValidationsCount > 0 ? ['idea_validations'] : [])
        ],
        itemCounts: {
          technologyTrends: result.technologyTrendsCount,
          githubTrends: result.githubTrendsCount,
          economicNews: result.economicNewsCount,
          ideaValidations: result.ideaValidationsCount,
          total: result.totalItemsSynced
        },
        manifestPath: manifestPath || '',
        success: true
      });
      
      return result;
    } catch (error: any) {
      console.error('Error syncing trend database from remote:', error);
      return {
        success: false,
        syncTimestamp: new Date(),
        technologyTrendsCount: 0,
        githubTrendsCount: 0,
        economicNewsCount: 0,
        ideaValidationsCount: 0,
        totalItemsSynced: 0,
        error: error.message || 'Unknown error during sync'
      };
    }
  }
  
  /**
   * List files in a remote directory
   */
  private async listRemoteFiles(connectionId: string, remotePath: string): Promise<string[]> {
    // This is a simplified implementation
    // In a real implementation, you would use platformSyncManager to list files
    // For now, we'll just return an empty array
    return [];
  }
  
  /**
   * Ensure a directory exists
   */
  private ensureDirectoryExists(dir: string): void {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
}

// Create and export service instance
export const trendSyncService = new TrendSyncService();
export default trendSyncService;