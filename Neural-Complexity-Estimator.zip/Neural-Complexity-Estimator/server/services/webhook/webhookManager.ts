/**
 * Webhook Manager Service
 * 
 * Manages webhook definitions, registrations, and executions.
 * Provides bidirectional communication between PinkSync and external services.
 */

import axios from 'axios';
import crypto from 'crypto';
import { logger } from '../../utils/logger';
import EventEmitter from 'events';

// Webhook types
export interface WebhookDefinition {
  id: string;
  name: string;
  description?: string;
  source: WebhookSource;
  destination: WebhookDestination;
  eventType: string;
  transformationScript?: string;
  active: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface WebhookSource {
  type: 'notion' | 'xano' | 'github' | 'vercel' | 'replit' | 'custom';
  config: Record<string, any>;
}

export interface WebhookDestination {
  url: string;
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  headers?: Record<string, string>;
  authType?: 'none' | 'basic' | 'bearer' | 'api_key';
  authConfig?: Record<string, string>;
  retryConfig?: {
    maxRetries: number;
    retryInterval: number;
  };
}

export interface WebhookPayload {
  id: string;
  timestamp: string;
  event: string;
  source: string;
  data: any;
  signature?: string;
}

export interface WebhookEvent {
  webhookId: string;
  payload: WebhookPayload;
  status: 'pending' | 'delivered' | 'failed';
  attempts: number;
  createdAt: Date;
  processedAt?: Date;
  response?: any;
  error?: string;
}

class WebhookManagerService extends EventEmitter {
  private webhooks: Map<string, WebhookDefinition> = new Map();
  private events: WebhookEvent[] = [];
  private processingQueue: string[] = [];
  private isProcessing = false;
  private isInitialized = false;
  private secretKey: string;
  
  constructor() {
    super();
    
    // Use environment variable for secret key or generate one
    this.secretKey = process.env.WEBHOOK_SECRET_KEY || this.generateSecretKey();
  }
  
  /**
   * Initialize the webhook manager
   */
  async initialize(webhooks: WebhookDefinition[] = []): Promise<boolean> {
    try {
      logger.info('Initializing Webhook Manager');
      
      // Register webhooks
      for (const webhook of webhooks) {
        this.webhooks.set(webhook.id, webhook);
      }
      
      this.isInitialized = true;
      logger.info(`Webhook Manager initialized with ${this.webhooks.size} webhooks`);
      
      return true;
    } catch (error) {
      logger.error('Failed to initialize Webhook Manager', error);
      return false;
    }
  }
  
  /**
   * Generate a secret key
   */
  private generateSecretKey(): string {
    return crypto.randomBytes(32).toString('hex');
  }
  
  /**
   * Get all webhook definitions
   */
  getWebhooks(): WebhookDefinition[] {
    return Array.from(this.webhooks.values());
  }
  
  /**
   * Get a webhook by ID
   */
  getWebhook(id: string): WebhookDefinition | null {
    return this.webhooks.get(id) || null;
  }
  
  /**
   * Create a new webhook
   */
  createWebhook(webhook: Omit<WebhookDefinition, 'id' | 'createdAt' | 'updatedAt'>): string {
    try {
      // Generate unique ID
      const id = `webhook-${Date.now()}`;
      
      // Create webhook with metadata
      const newWebhook: WebhookDefinition = {
        id,
        ...webhook,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      // Add to webhooks
      this.webhooks.set(id, newWebhook);
      
      // Emit event
      this.emit('webhook:created', { id, name: newWebhook.name });
      
      logger.info(`Created webhook ${id}: ${newWebhook.name}`);
      
      return id;
    } catch (error) {
      logger.error('Error creating webhook', error);
      throw error;
    }
  }
  
  /**
   * Update a webhook
   */
  updateWebhook(id: string, updates: Partial<WebhookDefinition>): boolean {
    try {
      const webhook = this.webhooks.get(id);
      
      if (!webhook) {
        return false;
      }
      
      // Update fields
      const updatedWebhook = { 
        ...webhook, 
        ...updates,
        updatedAt: new Date()
      };
      
      this.webhooks.set(id, updatedWebhook);
      
      // Emit event
      this.emit('webhook:updated', { id, name: updatedWebhook.name });
      
      return true;
    } catch (error) {
      logger.error(`Error updating webhook ${id}`, error);
      return false;
    }
  }
  
  /**
   * Delete a webhook
   */
  deleteWebhook(id: string): boolean {
    try {
      if (!this.webhooks.has(id)) {
        return false;
      }
      
      // Remove webhook
      this.webhooks.delete(id);
      
      // Emit event
      this.emit('webhook:deleted', { id });
      
      return true;
    } catch (error) {
      logger.error(`Error deleting webhook ${id}`, error);
      return false;
    }
  }
  
  /**
   * Register a webhook with external service
   */
  async registerWebhook(id: string): Promise<boolean> {
    try {
      const webhook = this.webhooks.get(id);
      
      if (!webhook) {
        throw new Error(`Webhook ${id} not found`);
      }
      
      // Registration logic depends on the source type
      switch (webhook.source.type) {
        case 'github':
          return await this.registerGithubWebhook(webhook);
        case 'notion':
          return await this.registerNotionWebhook(webhook);
        case 'vercel':
          return await this.registerVercelWebhook(webhook);
        case 'replit':
          return await this.registerReplitWebhook(webhook);
        default:
          logger.info(`No registration needed for webhook type: ${webhook.source.type}`);
          return true;
      }
    } catch (error) {
      logger.error(`Error registering webhook ${id}`, error);
      return false;
    }
  }
  
  /**
   * Register a GitHub webhook
   */
  private async registerGithubWebhook(webhook: WebhookDefinition): Promise<boolean> {
    try {
      // GitHub registration requires:
      // - Repository owner/name
      // - Event types
      // - Webhook URL
      // - Secret
      
      const config = webhook.source.config;
      
      if (!config.owner || !config.repo || !config.accessToken) {
        throw new Error('Missing required GitHub configuration');
      }
      
      // GitHub API endpoint
      const url = `https://api.github.com/repos/${config.owner}/${config.repo}/hooks`;
      
      // Configure the webhook
      const webhookConfig = {
        name: 'web',
        active: webhook.active,
        events: [webhook.eventType],
        config: {
          url: webhook.destination.url,
          content_type: 'json',
          secret: this.secretKey
        }
      };
      
      // Register with GitHub
      const response = await axios.post(url, webhookConfig, {
        headers: {
          'Authorization': `token ${config.accessToken}`,
          'Accept': 'application/vnd.github.v3+json'
        }
      });
      
      if (response.status >= 200 && response.status < 300) {
        // Update webhook with GitHub hook ID
        this.updateWebhook(webhook.id, {
          source: {
            ...webhook.source,
            config: {
              ...webhook.source.config,
              hookId: response.data.id
            }
          }
        });
        
        logger.info(`Registered GitHub webhook for ${config.owner}/${config.repo}`);
        return true;
      } else {
        throw new Error(`GitHub API returned status ${response.status}`);
      }
    } catch (error) {
      logger.error('Error registering GitHub webhook', error);
      return false;
    }
  }
  
  /**
   * Register a Notion webhook
   */
  private async registerNotionWebhook(webhook: WebhookDefinition): Promise<boolean> {
    // Notion doesn't have a webhook API yet
    // This would be a placeholder for when they add support
    logger.info('Notion webhook registration is not yet supported');
    return true;
  }
  
  /**
   * Register a Vercel webhook
   */
  private async registerVercelWebhook(webhook: WebhookDefinition): Promise<boolean> {
    try {
      const config = webhook.source.config;
      
      if (!config.teamId || !config.accessToken) {
        throw new Error('Missing required Vercel configuration');
      }
      
      // Vercel API endpoint
      const url = `https://api.vercel.com/v1/integrations/webhooks`;
      
      // Configure the webhook
      const webhookConfig = {
        name: webhook.name,
        url: webhook.destination.url,
        events: [webhook.eventType],
        teamId: config.teamId
      };
      
      // Register with Vercel
      const response = await axios.post(url, webhookConfig, {
        headers: {
          'Authorization': `Bearer ${config.accessToken}`
        }
      });
      
      if (response.status >= 200 && response.status < 300) {
        // Update webhook with Vercel webhook ID
        this.updateWebhook(webhook.id, {
          source: {
            ...webhook.source,
            config: {
              ...webhook.source.config,
              webhookId: response.data.id
            }
          }
        });
        
        logger.info(`Registered Vercel webhook for team ${config.teamId}`);
        return true;
      } else {
        throw new Error(`Vercel API returned status ${response.status}`);
      }
    } catch (error) {
      logger.error('Error registering Vercel webhook', error);
      return false;
    }
  }
  
  /**
   * Register a Replit webhook
   */
  private async registerReplitWebhook(webhook: WebhookDefinition): Promise<boolean> {
    // Replit webhook integration would go here
    // Currently, Replit doesn't have a public webhook API
    logger.info('Replit webhook registration is not yet supported');
    return true;
  }
  
  /**
   * Receive a webhook event
   */
  async receiveWebhook(source: string, event: string, data: any, headers: Record<string, string>): Promise<boolean> {
    try {
      logger.info(`Received webhook from ${source} for event ${event}`);
      
      // Create a payload
      const payload: WebhookPayload = {
        id: `evt-${Date.now()}`,
        timestamp: new Date().toISOString(),
        event,
        source,
        data
      };
      
      // Verify signature if available
      if (headers['x-hub-signature'] || headers['x-webhook-signature']) {
        const signature = headers['x-hub-signature'] || headers['x-webhook-signature'];
        const isValid = this.verifySignature(JSON.stringify(data), signature);
        
        if (!isValid) {
          logger.warn(`Invalid signature for webhook from ${source}`);
          return false;
        }
      }
      
      // Find matching webhooks
      const matchingWebhooks = Array.from(this.webhooks.values()).filter(webhook => 
        webhook.source.type === source && webhook.eventType === event && webhook.active
      );
      
      if (matchingWebhooks.length === 0) {
        logger.warn(`No matching webhooks found for ${source}:${event}`);
        return false;
      }
      
      // Create webhook events for each matching webhook
      for (const webhook of matchingWebhooks) {
        const webhookEvent: WebhookEvent = {
          webhookId: webhook.id,
          payload,
          status: 'pending',
          attempts: 0,
          createdAt: new Date()
        };
        
        // Add to events queue
        this.events.push(webhookEvent);
        this.processingQueue.push(webhookEvent.webhookId);
        
        // Emit event
        this.emit('webhook:received', {
          webhookId: webhook.id,
          eventId: payload.id,
          source,
          event
        });
      }
      
      // Start processing if not already processing
      if (!this.isProcessing) {
        this.processWebhookQueue();
      }
      
      return true;
    } catch (error) {
      logger.error('Error receiving webhook', error);
      return false;
    }
  }
  
  /**
   * Verify webhook signature
   */
  private verifySignature(payload: string, signature: string): boolean {
    try {
      // Calculate expected signature
      const hmac = crypto.createHmac('sha256', this.secretKey);
      hmac.update(payload);
      const expectedSignature = `sha256=${hmac.digest('hex')}`;
      
      // Perform constant-time comparison
      return crypto.timingSafeEqual(
        Buffer.from(expectedSignature),
        Buffer.from(signature)
      );
    } catch (error) {
      logger.error('Error verifying signature', error);
      return false;
    }
  }
  
  /**
   * Process webhook queue
   */
  private async processWebhookQueue(): Promise<void> {
    if (this.processingQueue.length === 0) {
      this.isProcessing = false;
      return;
    }
    
    this.isProcessing = true;
    
    try {
      // Get next webhook to process
      const webhookId = this.processingQueue.shift();
      
      if (!webhookId) {
        this.isProcessing = false;
        return;
      }
      
      // Find the webhook event
      const eventIndex = this.events.findIndex(event => 
        event.webhookId === webhookId && event.status === 'pending'
      );
      
      if (eventIndex === -1) {
        // Continue processing queue
        setImmediate(() => this.processWebhookQueue());
        return;
      }
      
      const webhookEvent = this.events[eventIndex];
      const webhook = this.webhooks.get(webhookEvent.webhookId);
      
      if (!webhook) {
        // Webhook no longer exists, mark as failed
        webhookEvent.status = 'failed';
        webhookEvent.error = 'Webhook definition not found';
        webhookEvent.processedAt = new Date();
        
        // Continue processing queue
        setImmediate(() => this.processWebhookQueue());
        return;
      }
      
      // Process the webhook
      await this.deliverWebhook(webhookEvent, webhook);
      
      // Continue processing queue
      setImmediate(() => this.processWebhookQueue());
    } catch (error) {
      logger.error('Error processing webhook queue', error);
      
      // Continue processing queue after a short delay
      setTimeout(() => this.processWebhookQueue(), 1000);
    }
  }
  
  /**
   * Deliver a webhook
   */
  private async deliverWebhook(event: WebhookEvent, webhook: WebhookDefinition): Promise<void> {
    try {
      event.attempts += 1;
      
      // Apply transformation if needed
      let payload = event.payload.data;
      
      if (webhook.transformationScript) {
        try {
          // Simple transformation - in production, this would use a safer evaluation method
          const transformFn = new Function('data', webhook.transformationScript);
          payload = transformFn(event.payload.data);
        } catch (error) {
          logger.error(`Error applying transformation for webhook ${webhook.id}`, error);
          // Continue with original payload
          payload = event.payload.data;
        }
      }
      
      // Configure request
      const request = {
        method: webhook.destination.method,
        url: webhook.destination.url,
        headers: webhook.destination.headers || {},
        data: payload
      };
      
      // Add authentication if configured
      if (webhook.destination.authType && webhook.destination.authConfig) {
        switch (webhook.destination.authType) {
          case 'basic':
            const auth = webhook.destination.authConfig;
            const username = auth.username || '';
            const password = auth.password || '';
            request.headers['Authorization'] = `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}`;
            break;
            
          case 'bearer':
            request.headers['Authorization'] = `Bearer ${webhook.destination.authConfig.token || ''}`;
            break;
            
          case 'api_key':
            const keyConfig = webhook.destination.authConfig;
            const headerName = keyConfig.headerName || 'X-API-Key';
            request.headers[headerName] = keyConfig.apiKey || '';
            break;
        }
      }
      
      // Add signature
      const signature = this.generateSignature(JSON.stringify(payload));
      request.headers['X-PinkSync-Signature'] = signature;
      request.headers['X-PinkSync-Event'] = event.payload.event;
      request.headers['X-PinkSync-Delivery'] = event.payload.id;
      
      // Execute request
      const response = await axios(request);
      
      // Update event
      event.status = 'delivered';
      event.processedAt = new Date();
      event.response = {
        status: response.status,
        headers: response.headers,
        data: response.data
      };
      
      // Emit delivery event
      this.emit('webhook:delivered', {
        webhookId: webhook.id,
        eventId: event.payload.id
      });
      
      logger.info(`Delivered webhook ${webhook.id} to ${webhook.destination.url}`);
    } catch (error) {
      // Handle delivery failure
      logger.error(`Error delivering webhook ${webhook.id}`, error);
      
      const maxRetries = webhook.destination.retryConfig?.maxRetries || 3;
      
      if (event.attempts < maxRetries) {
        // Retry later
        const retryInterval = webhook.destination.retryConfig?.retryInterval || 60000; // 1 minute default
        
        setTimeout(() => {
          // Add back to processing queue
          this.processingQueue.push(event.webhookId);
          
          // Start processing if needed
          if (!this.isProcessing) {
            this.processWebhookQueue();
          }
        }, retryInterval);
      } else {
        // Max retries reached, mark as failed
        event.status = 'failed';
        event.processedAt = new Date();
        event.error = error.message;
        
        // Emit failure event
        this.emit('webhook:failed', {
          webhookId: webhook.id,
          eventId: event.payload.id,
          error: error.message
        });
      }
    }
  }
  
  /**
   * Generate a signature for outgoing webhooks
   */
  private generateSignature(payload: string): string {
    const hmac = crypto.createHmac('sha256', this.secretKey);
    hmac.update(payload);
    return `sha256=${hmac.digest('hex')}`;
  }
  
  /**
   * Check if the webhook manager is initialized
   */
  isReady(): boolean {
    return this.isInitialized;
  }
}

// Create singleton instance
const webhookManagerService = new WebhookManagerService();

export default webhookManagerService;