import { astraService } from './astraService';
import * as fs from 'fs';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';
import * as csv from 'csv-parser';
import { Readable } from 'stream';

export interface DocumentUploadOptions {
  collection: string;
  documentId?: string;
  content: any;
  namespace?: string;
  tags?: string[];
  metadata?: Record<string, any>;
}

export interface BatchUploadOptions {
  collection: string;
  files?: {
    path: string;
    format: 'json' | 'csv' | 'txt';
    idField?: string;
  }[];
  data?: any[];
  namespace?: string;
  tags?: string[];
  generateIds?: boolean;
}

/**
 * Service for uploading documents to Astra DB
 */
export class DocumentUploaderService {
  private readonly DEFAULT_NAMESPACE = 'default';

  /**
   * Upload a single document to Astra DB
   */
  async uploadDocument(options: DocumentUploadOptions): Promise<any> {
    try {
      const {
        collection,
        documentId = uuidv4(),
        content,
        namespace = this.DEFAULT_NAMESPACE,
        tags = [],
        metadata = {}
      } = options;

      // Add metadata and tags to the document
      const documentToUpload = {
        ...content,
        _tags: tags,
        _metadata: {
          ...metadata,
          uploadedAt: new Date().toISOString()
        }
      };

      // Upload to Astra DB
      const result = await astraService.createDocument(
        namespace,
        collection,
        documentId,
        documentToUpload
      );

      return {
        documentId,
        status: 'success',
        result
      };
    } catch (error) {
      console.error('Error uploading document:', error);
      throw error;
    }
  }

  /**
   * Batch upload documents from files or data arrays
   */
  async batchUpload(options: BatchUploadOptions): Promise<any> {
    try {
      const {
        collection,
        files = [],
        data = [],
        namespace = this.DEFAULT_NAMESPACE,
        tags = [],
        generateIds = true
      } = options;

      const results = {
        total: 0,
        success: 0,
        failures: 0,
        failedDocuments: [],
        successDocuments: []
      };

      // Process files if provided
      for (const file of files) {
        const fileData = await this.parseFile(file.path, file.format);
        
        for (const item of fileData) {
          results.total++;
          
          try {
            // Use specified field as ID or generate a new one
            const documentId = file.idField && item[file.idField] 
              ? item[file.idField].toString() 
              : (generateIds ? uuidv4() : undefined);
            
            // Upload to Astra DB
            const uploadResult = await this.uploadDocument({
              collection,
              documentId,
              content: item,
              namespace,
              tags,
              metadata: {
                sourceFile: path.basename(file.path),
                sourceFormat: file.format
              }
            });
            
            results.success++;
            results.successDocuments.push({
              documentId: uploadResult.documentId,
              sourceFile: path.basename(file.path)
            });
          } catch (error) {
            results.failures++;
            results.failedDocuments.push({
              document: item,
              sourceFile: path.basename(file.path),
              error: error.message
            });
          }
        }
      }

      // Process data array if provided
      for (const item of data) {
        results.total++;
        
        try {
          // Generate a new ID if needed
          const documentId = generateIds ? uuidv4() : undefined;
          
          // Upload to Astra DB
          const uploadResult = await this.uploadDocument({
            collection,
            documentId,
            content: item,
            namespace,
            tags,
            metadata: {
              source: 'direct_upload'
            }
          });
          
          results.success++;
          results.successDocuments.push({
            documentId: uploadResult.documentId
          });
        } catch (error) {
          results.failures++;
          results.failedDocuments.push({
            document: item,
            error: error.message
          });
        }
      }

      return results;
    } catch (error) {
      console.error('Error batch uploading documents:', error);
      throw error;
    }
  }

  /**
   * Parse a file based on its format
   */
  private async parseFile(filePath: string, format: 'json' | 'csv' | 'txt'): Promise<any[]> {
    try {
      switch (format) {
        case 'json':
          return this.parseJsonFile(filePath);
        case 'csv':
          return this.parseCsvFile(filePath);
        case 'txt':
          return this.parseTxtFile(filePath);
        default:
          throw new Error(`Unsupported file format: ${format}`);
      }
    } catch (error) {
      console.error(`Error parsing ${format} file:`, error);
      throw error;
    }
  }

  /**
   * Parse a JSON file
   */
  private async parseJsonFile(filePath: string): Promise<any[]> {
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent);
    
    // Handle array or object format
    if (Array.isArray(data)) {
      return data;
    } else {
      return [data];
    }
  }

  /**
   * Parse a CSV file
   */
  private async parseCsvFile(filePath: string): Promise<any[]> {
    return new Promise((resolve, reject) => {
      const results: any[] = [];
      
      fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (data) => results.push(data))
        .on('end', () => resolve(results))
        .on('error', (error) => reject(error));
    });
  }

  /**
   * Parse a text file (one document per line)
   */
  private async parseTxtFile(filePath: string): Promise<any[]> {
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const lines = fileContent.split('\n').filter(line => line.trim());
    
    return lines.map((line, index) => ({
      content: line,
      lineNumber: index + 1
    }));
  }

  /**
   * Create a collection if it doesn't exist
   */
  async ensureCollection(collection: string): Promise<void> {
    try {
      const collections = await astraService.listCollections();
      
      if (!collections.includes(collection)) {
        // Create collection by inserting a dummy document and then deleting it
        const dummyId = `tmp_${uuidv4()}`;
        await astraService.createDocument(this.DEFAULT_NAMESPACE, collection, dummyId, { _tmp: true });
        await astraService.deleteDocument(this.DEFAULT_NAMESPACE, collection, dummyId);
        console.log(`Created collection: ${collection}`);
      }
    } catch (error) {
      console.error('Error ensuring collection exists:', error);
      throw error;
    }
  }
}

// Export a singleton instance
export const documentUploaderService = new DocumentUploaderService();