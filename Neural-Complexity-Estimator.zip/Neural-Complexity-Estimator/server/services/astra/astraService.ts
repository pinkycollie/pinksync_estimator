import { DataAPIClient } from "@datastax/astra-db-ts";

/**
 * Service for interacting with Astra DB using the newer DataAPIClient
 */
export class AstraDBService {
  private client: DataAPIClient | null = null;
  private db: any = null;
  private isInitialized: boolean = false;
  private readonly astraDbToken: string;
  private readonly astraDbUrl: string;
  private readonly keyspace: string;

  constructor() {
    this.astraDbToken = process.env.ASTRA_DB_TOKEN || "";
    this.astraDbUrl = "https://2ba73933-3d26-47d9-a6f8-69b4f93a4611-us-east-2.apps.astra.datastax.com";
    this.keyspace = "pinky_os";
    
    // Validate configuration
    if (!this.astraDbToken) {
      console.error("Missing Astra DB Token");
    }
  }

  /**
   * Initialize the Astra DB client
   */
  async initialize() {
    if (this.isInitialized) {
      return;
    }

    try {
      this.client = new DataAPIClient(this.astraDbToken);
      this.db = this.client.db(this.astraDbUrl, { keyspace: this.keyspace });
      
      // Test connection by listing collections
      const collections = await this.db.listCollections();
      console.log("Astra DB client initialized successfully, collections:", collections);
      
      this.isInitialized = true;
    } catch (error) {
      console.error("Failed to initialize Astra DB client:", error);
      throw error;
    }
  }

  /**
   * Get all collections in the database
   */
  async listCollections() {
    if (!this.isInitialized) {
      await this.initialize();
    }
    
    return this.db.listCollections();
  }

  /**
   * Get a collection reference
   */
  async getCollection(namespace: string, collection: string) {
    if (!this.isInitialized) {
      await this.initialize();
    }
    
    // With the new API, namespace is the collection name
    return this.db.collection(collection);
  }

  /**
   * Create a document in a collection
   */
  async createDocument(namespace: string, collection: string, documentId: string, data: any) {
    const collectionRef = await this.getCollection(namespace, collection);
    return collectionRef.insertOne({ 
      _id: documentId, 
      ...data 
    });
  }

  /**
   * Get a document by ID
   */
  async getDocument(namespace: string, collection: string, documentId: string) {
    const collectionRef = await this.getCollection(namespace, collection);
    return collectionRef.findOne({ _id: documentId });
  }

  /**
   * Find documents in a collection
   */
  async findDocuments(namespace: string, collection: string, query: any, options: any = {}) {
    const collectionRef = await this.getCollection(namespace, collection);
    const { limit = 100 } = options;
    
    // Convert to array format
    const result = await collectionRef.find(query).toArray();
    return result.slice(0, limit);
  }

  /**
   * Update a document
   */
  async updateDocument(namespace: string, collection: string, documentId: string, data: any) {
    const collectionRef = await this.getCollection(namespace, collection);
    return collectionRef.updateOne(
      { _id: documentId }, 
      { $set: data }
    );
  }

  /**
   * Delete a document
   */
  async deleteDocument(namespace: string, collection: string, documentId: string) {
    const collectionRef = await this.getCollection(namespace, collection);
    return collectionRef.deleteOne({ _id: documentId });
  }
}

// Export a singleton instance
export const astraService = new AstraDBService();