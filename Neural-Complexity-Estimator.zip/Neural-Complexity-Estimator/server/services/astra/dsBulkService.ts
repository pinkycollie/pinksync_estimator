import { spawn } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { v4 as uuidv4 } from 'uuid';

export interface DSBulkConfig {
  // Connection settings
  url: string;
  token: string;
  keyspace: string;
  
  // Table settings
  table: string;
  
  // File settings
  filePath: string;
  fileFormat: 'csv' | 'json';
  
  // Mapping settings
  fieldDelimiter?: string;
  nullValue?: string;
  header?: boolean;
  mapping?: string | Record<string, string>;
  
  // Performance settings
  batchSize?: number;
  maxConcurrentQueries?: number;
  
  // Other options
  dryRun?: boolean;
  logDir?: string;
}

export interface DSBulkResult {
  success: boolean;
  recordsProcessed: number;
  recordsFailed: number;
  duration: number;
  logFile?: string;
  error?: string;
}

/**
 * Service for bulk loading data into Astra DB using dsbulk
 */
export class DSBulkService {
  private readonly tempDir: string;
  private readonly dsBulkDir: string;
  private downloadedDsBulk: boolean = false;
  
  constructor() {
    this.tempDir = path.join(os.tmpdir(), 'pinky-os-dsbulk');
    this.dsBulkDir = path.join(this.tempDir, 'dsbulk');
    
    // Create temp directory if it doesn't exist
    if (!fs.existsSync(this.tempDir)) {
      fs.mkdirSync(this.tempDir, { recursive: true });
    }
  }
  
  /**
   * Download and extract dsbulk if needed
   */
  private async ensureDsBulk(): Promise<string> {
    if (this.downloadedDsBulk) {
      return path.join(this.dsBulkDir, 'bin', 'dsbulk');
    }
    
    // Ensure dsbulk directory exists
    if (!fs.existsSync(this.dsBulkDir)) {
      fs.mkdirSync(this.dsBulkDir, { recursive: true });
    }
    
    const dsbulkExecPath = path.join(this.dsBulkDir, 'bin', 'dsbulk');
    
    // Check if dsbulk already exists
    if (fs.existsSync(dsbulkExecPath)) {
      this.downloadedDsBulk = true;
      return dsbulkExecPath;
    }
    
    // If not, download and extract dsbulk
    console.log('Downloading and extracting dsbulk...');
    
    return new Promise((resolve, reject) => {
      // For simplicity, we'll use a bash script to download and extract
      const downloadScript = `
        cd ${this.tempDir}
        curl -L -o dsbulk.tar.gz https://downloads.datastax.com/dsbulk/dsbulk-1.10.0.tar.gz
        tar -xzf dsbulk.tar.gz
        mv dsbulk-* dsbulk
        chmod +x dsbulk/bin/dsbulk
        rm dsbulk.tar.gz
      `;
      
      const tempScriptPath = path.join(this.tempDir, 'download-dsbulk.sh');
      fs.writeFileSync(tempScriptPath, downloadScript);
      fs.chmodSync(tempScriptPath, '755');
      
      const process = spawn('bash', [tempScriptPath]);
      
      let error = '';
      
      process.stderr.on('data', (data) => {
        error += data.toString();
      });
      
      process.on('close', (code) => {
        // Clean up temp script
        try {
          fs.unlinkSync(tempScriptPath);
        } catch (e) {
          // Ignore errors
        }
        
        if (code !== 0) {
          return reject(new Error(`Failed to download dsbulk: ${error}`));
        }
        
        this.downloadedDsBulk = true;
        resolve(dsbulkExecPath);
      });
    });
  }
  
  /**
   * Create a mapping file for dsbulk
   */
  private createMappingFile(mapping: Record<string, string>): string {
    const mappingPath = path.join(this.tempDir, `mapping-${uuidv4()}.json`);
    fs.writeFileSync(mappingPath, JSON.stringify(mapping, null, 2));
    return mappingPath;
  }
  
  /**
   * Load data using dsbulk
   */
  async loadData(config: DSBulkConfig): Promise<DSBulkResult> {
    try {
      // Ensure dsbulk is available
      const dsbulkPath = await this.ensureDsBulk();
      
      // Prepare arguments
      const args = ['load'];
      
      // Connection settings
      args.push('-url', config.url);
      args.push('-k', config.keyspace);
      args.push('-t', config.table);
      args.push('-b', 'token:' + config.token);
      
      // File settings
      args.push('-f', config.filePath);
      
      // Format settings
      if (config.fileFormat === 'csv') {
        args.push('-format', 'csv');
        
        if (config.fieldDelimiter) {
          args.push('-delimiter', config.fieldDelimiter);
        }
        
        if (config.nullValue) {
          args.push('-nullValue', config.nullValue);
        }
        
        if (config.header !== undefined) {
          args.push('-header', config.header.toString());
        }
      } else {
        args.push('-format', 'json');
      }
      
      // Mapping settings
      if (config.mapping) {
        let mappingPath: string;
        
        if (typeof config.mapping === 'string') {
          mappingPath = config.mapping;
        } else {
          mappingPath = this.createMappingFile(config.mapping);
        }
        
        args.push('-m', mappingPath);
      }
      
      // Performance settings
      if (config.batchSize) {
        args.push('-batchSize', config.batchSize.toString());
      }
      
      if (config.maxConcurrentQueries) {
        args.push('-maxConcurrentQueries', config.maxConcurrentQueries.toString());
      }
      
      // Other options
      if (config.dryRun) {
        args.push('-dryRun', 'true');
      }
      
      // Set up log directory
      const logDir = config.logDir || path.join(this.tempDir, 'logs');
      if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
      }
      
      const logFile = path.join(logDir, `dsbulk-${Date.now()}.log`);
      args.push('-logDir', logDir);
      
      console.log(`Running dsbulk with arguments: ${args.join(' ')}`);
      
      // Execute dsbulk
      const startTime = Date.now();
      
      return new Promise((resolve, reject) => {
        const process = spawn(dsbulkPath, args);
        
        let stdout = '';
        let stderr = '';
        
        process.stdout.on('data', (data) => {
          stdout += data.toString();
          console.log(`[dsbulk stdout] ${data.toString().trim()}`);
        });
        
        process.stderr.on('data', (data) => {
          stderr += data.toString();
          console.error(`[dsbulk stderr] ${data.toString().trim()}`);
        });
        
        process.on('close', (code) => {
          const duration = Date.now() - startTime;
          
          if (code !== 0) {
            return resolve({
              success: false,
              recordsProcessed: 0,
              recordsFailed: 0,
              duration,
              logFile,
              error: stderr || 'Unknown error'
            });
          }
          
          // Try to parse output to get records processed
          let recordsProcessed = 0;
          let recordsFailed = 0;
          
          const processedMatch = stdout.match(/(\d+) rows processed/);
          if (processedMatch && processedMatch[1]) {
            recordsProcessed = parseInt(processedMatch[1], 10);
          }
          
          const failedMatch = stdout.match(/(\d+) rows failed/);
          if (failedMatch && failedMatch[1]) {
            recordsFailed = parseInt(failedMatch[1], 10);
          }
          
          resolve({
            success: true,
            recordsProcessed,
            recordsFailed,
            duration,
            logFile
          });
        });
      });
    } catch (error) {
      console.error('Error loading data with dsbulk:', error);
      
      return {
        success: false,
        recordsProcessed: 0,
        recordsFailed: 0,
        duration: 0,
        error: error.message || 'Unknown error'
      };
    }
  }
}

// Export a singleton instance
export const dsBulkService = new DSBulkService();