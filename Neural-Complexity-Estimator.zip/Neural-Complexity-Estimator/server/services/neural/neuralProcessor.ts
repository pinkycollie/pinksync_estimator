/**
 * Neural Processor
 * 
 * Main controller for routing neural signals to the appropriate specialized processors.
 */

import { 
  NeuralSignal, 
  ProcessingResult, 
  ProcessorMetadata,
  ProcessingConfig,
  ResponsePath,
  NeuralModality
} from '../../../shared/types/neural';
import { logger } from '../../utils/logger';

// Processor function type
type ProcessorFunction = (signal: NeuralSignal, metadata: ProcessorMetadata) => Promise<ProcessingResult>;

// Default processing configuration
const DEFAULT_PROCESSING_CONFIG: ProcessingConfig = {
  processorMap: {
    'text-processor': ['sentiment-analyzer', 'keyword-extractor'],
    'asl-processor': ['gesture-analyzer', 'expression-analyzer', 'translator'],
    'sentiment-analyzer': ['intent-analyzer'],
    'translator': ['formatter']
  },
  defaultPath: {
    'text': 'text-processor',
    'asl_video': 'asl-processor',
    'vr_gesture': 'gesture-analyzer',
    'voice': 'speech-processor',
    'image': 'image-processor',
    'combined': 'multimodal-processor'
  },
  fallbackProcessor: 'general-processor'
};

/**
 * Neural Processor Service
 * 
 * Central service for processing all neural signals
 */
class NeuralProcessorService {
  private processors: Map<string, ProcessorFunction> = new Map();
  private processingConfig: ProcessingConfig;
  private initialized: boolean = false;

  constructor(config?: ProcessingConfig) {
    this.processingConfig = config || DEFAULT_PROCESSING_CONFIG;
  }

  /**
   * Initialize the neural processor
   */
  async initialize(): Promise<void> {
    if (this.initialized) {
      return;
    }

    logger.info('Initializing Neural Processor Service');
    
    // Additional initialization can be added here (loading ML models, etc.)
    
    this.initialized = true;
    logger.info('Neural Processor Service initialized');
  }

  /**
   * Register a processor with the neural processor
   */
  registerProcessor(id: string, processor: ProcessorFunction): void {
    logger.debug(`Registering processor: ${id}`);
    this.processors.set(id, processor);
  }

  /**
   * Process a neural signal
   */
  async processSignal(signal: NeuralSignal): Promise<ProcessingResult> {
    if (!this.initialized) {
      await this.initialize();
    }

    if (!signal.processingPath) {
      signal.processingPath = [];
    }

    // Create initial processing path if not present
    if (signal.processingPath.length === 0) {
      // Get default processor for this modality
      const defaultProcessor = this.processingConfig.defaultPath[signal.modality];
      
      return this.routeToProcessor(signal, defaultProcessor);
    } else {
      // Continue existing processing path
      const lastStep = signal.processingPath[signal.processingPath.length - 1];
      
      if (lastStep.nextProcessor) {
        return this.routeToProcessor(signal, lastStep.nextProcessor);
      } else {
        // Processing path complete, return final result
        return {
          type: 'processing-complete',
          timestamp: new Date().toISOString(),
          processingTime: signal.processingPath.reduce((total, path) => total + path.duration, 0),
          processingPath: signal.processingPath,
          result: 'Processing complete'
        };
      }
    }
  }

  /**
   * Route a signal to a specific processor
   */
  private async routeToProcessor(
    signal: NeuralSignal, 
    processorId: string, 
    metadata: ProcessorMetadata = {}
  ): Promise<ProcessingResult> {
    logger.debug(`Routing signal to processor: ${processorId}`);
    
    const processor = this.processors.get(processorId);
    
    if (!processor) {
      logger.warn(`Processor not found: ${processorId}, using fallback processor`);
      
      // Use fallback processor if available
      if (this.processingConfig.fallbackProcessor && 
          this.processors.has(this.processingConfig.fallbackProcessor)) {
        return this.routeToProcessor(signal, this.processingConfig.fallbackProcessor);
      }
      
      // No fallback available
      return {
        type: 'processor-error',
        timestamp: new Date().toISOString(),
        error: `Processor not found: ${processorId}`
      };
    }
    
    const startTime = Date.now();
    
    try {
      // Process the signal
      const result = await processor(signal, metadata);
      
      const endTime = Date.now();
      const duration = endTime - startTime;
      
      // Record processing path
      const pathStep: ResponsePath = {
        processorId,
        timestamp: new Date().toISOString(),
        duration,
        status: 'success'
      };
      
      // Add next processor if defined in processing map
      const nextProcessors = this.processingConfig.processorMap[processorId];
      if (nextProcessors && nextProcessors.length > 0) {
        pathStep.nextProcessor = nextProcessors[0];
        pathStep.status = 'forwarded';
      }
      
      // Add path step to signal
      signal.processingPath?.push(pathStep);
      
      // If this processor has a next step, route to it
      if (pathStep.nextProcessor) {
        return this.routeToProcessor(signal, pathStep.nextProcessor);
      }
      
      // No next step, return result directly
      return result;
      
    } catch (error: any) {
      const endTime = Date.now();
      const duration = endTime - startTime;
      
      logger.error(`Error in processor ${processorId}:`, error);
      
      // Record error in processing path
      signal.processingPath?.push({
        processorId,
        timestamp: new Date().toISOString(),
        duration,
        status: 'error',
        metadata: {
          error: error.message
        }
      });
      
      // Return error result
      return {
        type: 'processor-error',
        timestamp: new Date().toISOString(),
        processorId,
        error: error.message || 'Unknown error'
      };
    }
  }

  /**
   * Get the list of registered processors
   */
  getRegisteredProcessors(): string[] {
    return Array.from(this.processors.keys());
  }

  /**
   * Update processing configuration
   */
  updateProcessingConfig(config: Partial<ProcessingConfig>): void {
    this.processingConfig = {
      ...this.processingConfig,
      ...config
    };
  }
}

// Export a singleton instance
export const neuralProcessor = new NeuralProcessorService();
export default neuralProcessor;