/**
 * Text Processor
 * 
 * Neural processor specialized for text content.
 */

import { 
  NeuralSignal, 
  ProcessingResult, 
  ProcessorMetadata,
  NeuralProcessor,
  NeuralProcessorCapabilities
} from '../../../../shared/types/neural';
import { logger } from '../../../utils/logger';

/**
 * Text Processor Implementation
 */
class TextProcessor implements NeuralProcessor {
  private maxTextLength: number = 10000;
  
  /**
   * Process a text neural signal
   */
  async process(signal: NeuralSignal, metadata: ProcessorMetadata): Promise<ProcessingResult> {
    logger.debug('Text processor processing signal');
    
    // Validate that this is a text signal
    if (signal.modality !== 'text') {
      return {
        type: 'processor-error',
        timestamp: new Date().toISOString(),
        error: `Invalid modality for text processor: ${signal.modality}`
      };
    }
    
    // Extract text content
    const content = signal.context.content;
    
    if (!content) {
      return {
        type: 'processor-error',
        timestamp: new Date().toISOString(),
        error: 'No text content found in signal'
      };
    }
    
    // Check text length
    const originalLength = content.length;
    let truncated = false;
    let truncatedContent = content;
    
    if (originalLength > this.maxTextLength) {
      truncatedContent = content.substring(0, this.maxTextLength);
      truncated = true;
      logger.debug(`Text truncated from ${originalLength} to ${this.maxTextLength} characters`);
    }
    
    // Create base result
    const result: ProcessingResult = {
      type: 'text-processed',
      timestamp: new Date().toISOString(),
      content: truncatedContent,
      truncated,
      originalLength,
      confidence: 0.95
    };
    
    // Add sentiment analysis
    result.sentiment = await this.analyzeSentiment(truncatedContent);
    
    // Add keyword extraction
    result.keywords = await this.extractKeywords(truncatedContent);
    
    // Add intent recognition
    result.intent = await this.recognizeIntent(truncatedContent);
    
    return result;
  }
  
  /**
   * Get processor capabilities
   */
  getCapabilities(): NeuralProcessorCapabilities {
    return {
      supportedModalities: ['text'],
      processingSpeed: 'realtime',
      maxConcurrentSignals: 100,
      requiresPreprocessing: false,
      features: [
        'sentiment-analysis',
        'keyword-extraction',
        'intent-recognition',
        'language-detection'
      ]
    };
  }
  
  /**
   * Analyze sentiment of text
   */
  private async analyzeSentiment(text: string): Promise<{ label: string; score: number }> {
    // Simple sentiment analysis based on positive and negative word lists
    const positiveWords = [
      'good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 
      'love', 'like', 'happy', 'joy', 'beautiful', 'awesome', 'best',
      'better', 'perfect', 'nice', 'well', 'positive', 'incredible'
    ];
    
    const negativeWords = [
      'bad', 'terrible', 'awful', 'horrible', 'worst', 'hate', 
      'dislike', 'sad', 'poor', 'negative', 'disappointing', 'upset',
      'angry', 'annoyed', 'frustrated', 'wrong', 'fail', 'failed'
    ];
    
    // Count words (case insensitive)
    const lowerText = text.toLowerCase();
    const words = lowerText.split(/\s+/);
    
    let positiveCount = 0;
    let negativeCount = 0;
    
    for (const word of words) {
      const cleanWord = word.replace(/[^a-z]/g, '');
      if (positiveWords.includes(cleanWord)) positiveCount++;
      if (negativeWords.includes(cleanWord)) negativeCount++;
    }
    
    // Calculate sentiment score (-1 to 1)
    const totalSentimentWords = positiveCount + negativeCount;
    
    if (totalSentimentWords === 0) {
      return { label: 'neutral', score: 0 };
    }
    
    const score = (positiveCount - negativeCount) / totalSentimentWords;
    
    // Determine label
    let label: string;
    if (score > 0.25) label = 'positive';
    else if (score < -0.25) label = 'negative';
    else label = 'neutral';
    
    return { label, score };
  }
  
  /**
   * Extract keywords from text
   */
  private async extractKeywords(text: string): Promise<string[]> {
    // Simple keyword extraction based on word frequency and stop words
    const stopWords = [
      'the', 'and', 'a', 'an', 'in', 'on', 'at', 'to', 'for', 'of', 'with',
      'by', 'as', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
      'have', 'has', 'had', 'do', 'does', 'did', 'but', 'or', 'if', 'because',
      'this', 'that', 'these', 'those', 'it', 'its', 'they', 'them', 'their',
      'from', 'then', 'than', 'so', 'can', 'could', 'would', 'should', 'now'
    ];
    
    // Extract words and count frequency
    const lowerText = text.toLowerCase();
    const words = lowerText.split(/\s+/);
    const wordCounts: Record<string, number> = {};
    
    for (const word of words) {
      const cleanWord = word.replace(/[^a-z]/g, '');
      
      // Skip empty words and stop words
      if (cleanWord.length < 3 || stopWords.includes(cleanWord)) {
        continue;
      }
      
      wordCounts[cleanWord] = (wordCounts[cleanWord] || 0) + 1;
    }
    
    // Sort by frequency
    const sortedWords = Object.entries(wordCounts)
      .sort((a, b) => b[1] - a[1])
      .map(entry => entry[0]);
    
    // Return top keywords (up to 10)
    return sortedWords.slice(0, 10);
  }
  
  /**
   * Recognize intent from text
   */
  private async recognizeIntent(text: string): Promise<{ primary: string; confidence: number }> {
    // Simple intent recognition based on patterns
    const lowerText = text.toLowerCase();
    
    // Check for question intent
    if (lowerText.includes('?') || 
        lowerText.startsWith('what') || 
        lowerText.startsWith('how') || 
        lowerText.startsWith('who') || 
        lowerText.startsWith('when') || 
        lowerText.startsWith('where') || 
        lowerText.startsWith('why')) {
      return { primary: 'question', confidence: 0.9 };
    }
    
    // Check for command intent
    if (lowerText.startsWith('please') ||
        lowerText.includes('would you') ||
        lowerText.includes('could you') ||
        lowerText.includes('can you') ||
        lowerText.endsWith('please')) {
      return { primary: 'request', confidence: 0.85 };
    }
    
    // Check for greeting intent
    if (lowerText.includes('hello') ||
        lowerText.includes('hi ') ||
        lowerText.includes('hey ') ||
        lowerText.includes('good morning') ||
        lowerText.includes('good afternoon') ||
        lowerText.includes('good evening')) {
      return { primary: 'greeting', confidence: 0.9 };
    }
    
    // Default to statement
    return { primary: 'statement', confidence: 0.7 };
  }
}

/**
 * Create a new text processor
 */
export function createTextProcessor(): TextProcessor {
  return new TextProcessor();
}

export default createTextProcessor;