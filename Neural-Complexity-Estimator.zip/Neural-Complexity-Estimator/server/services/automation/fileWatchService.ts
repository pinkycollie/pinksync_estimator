import * as chokidar from 'chokidar';
import * as path from 'path';
import * as fs from 'fs';
import { v4 as uuidv4 } from 'uuid';
import { EventEmitter } from 'events';

// Define interface types for the file watch service
export interface WatchConfig {
  id: string;
  name: string;
  path: string;
  excludePaths: string[];
  isRecursive: boolean;
  watchForPatterns: string[];
  ignorePatterns: string[];
  active: boolean;
  createdAt: string;
  automationRules: AutomationRule[];
}

export interface AutomationRule {
  id: string;
  name: string;
  description?: string;
  eventType: 'add' | 'change' | 'unlink' | 'addDir' | 'unlinkDir' | 'all';
  filePattern: string;
  actions: AutomationAction[];
  active: boolean;
}

export interface AutomationAction {
  id: string;
  type: 'notify' | 'move' | 'copy' | 'delete' | 'rename' | 'sync' | 'extract' | 'execute' | 'googleSheets';
  config: Record<string, any>;
  active: boolean;
}

export interface FileEvent {
  id: string;
  watchId: string;
  eventType: string;
  filePath: string;
  relativePath: string;
  timestamp: string;
  fileStats?: any;
  automationResults?: AutomationResult[];
}

export interface AutomationResult {
  id: string;
  ruleId: string;
  ruleName: string;
  successful: boolean;
  actions: {
    id: string;
    type: string;
    successful: boolean;
    message?: string;
    details?: any;
  }[];
  timestamp: string;
}

// Singleton class for managing file watches
export class FileWatchService extends EventEmitter {
  private static instance: FileWatchService;
  private configs: WatchConfig[] = [];
  private watchers: Map<string, chokidar.FSWatcher> = new Map();
  private events: FileEvent[] = [];
  private readonly configFile = path.join(process.cwd(), 'data', 'fileWatchConfigs.json');
  private readonly eventsFile = path.join(process.cwd(), 'data', 'fileWatchEvents.json');
  private readonly eventsLimit = 1000; // Maximum number of events to keep in memory

  private constructor() {
    super();
    this.ensureConfigDirectory();
    this.loadConfigs();
    this.loadEvents();
    console.log(`Loaded ${this.configs.length} file watch configurations`);
    this.initializeWatchers();
  }

  // Get singleton instance
  public static getInstance(): FileWatchService {
    if (!FileWatchService.instance) {
      FileWatchService.instance = new FileWatchService();
    }
    return FileWatchService.instance;
  }

  // Ensure the data directory exists
  private ensureConfigDirectory(): void {
    const dataDir = path.dirname(this.configFile);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
  }

  // Load configurations from file
  private loadConfigs(): void {
    try {
      if (fs.existsSync(this.configFile)) {
        const data = fs.readFileSync(this.configFile, 'utf8');
        this.configs = JSON.parse(data);
      } else {
        this.configs = [];
        this.saveConfigs();
      }
    } catch (error) {
      console.error('Error loading file watch configurations:', error);
      this.configs = [];
    }
  }

  // Save configurations to file
  private saveConfigs(): void {
    try {
      fs.writeFileSync(this.configFile, JSON.stringify(this.configs, null, 2), 'utf8');
    } catch (error) {
      console.error('Error saving file watch configurations:', error);
    }
  }

  // Load events from file
  private loadEvents(): void {
    try {
      if (fs.existsSync(this.eventsFile)) {
        const data = fs.readFileSync(this.eventsFile, 'utf8');
        this.events = JSON.parse(data);
      } else {
        this.events = [];
        this.saveEvents();
      }
    } catch (error) {
      console.error('Error loading file watch events:', error);
      this.events = [];
    }
  }

  // Save events to file
  private saveEvents(): void {
    try {
      // Trim events to the limit
      if (this.events.length > this.eventsLimit) {
        this.events = this.events.slice(-this.eventsLimit);
      }
      fs.writeFileSync(this.eventsFile, JSON.stringify(this.events, null, 2), 'utf8');
    } catch (error) {
      console.error('Error saving file watch events:', error);
    }
  }

  // Initialize watchers for all active configurations
  private initializeWatchers(): void {
    // Close any existing watchers
    for (const [id, watcher] of this.watchers.entries()) {
      watcher.close();
      this.watchers.delete(id);
    }

    // Initialize watchers for active configurations
    for (const config of this.configs) {
      if (config.active) {
        this.startWatcher(config);
      }
    }
  }

  // Start a watcher for a configuration
  private startWatcher(config: WatchConfig): void {
    try {
      // Ensure the watch directory exists
      if (!fs.existsSync(config.path)) {
        console.warn(`Watch directory "${config.path}" does not exist for config "${config.name}"`);
        return;
      }

      // Build ignored paths
      const ignored = [
        ...config.excludePaths.map(excludePath => {
          const fullPath = path.isAbsolute(excludePath) 
            ? excludePath 
            : path.join(config.path, excludePath);
          return fullPath;
        }),
        ...config.ignorePatterns
      ];

      // Create the watcher
      const watcher = chokidar.watch(config.watchForPatterns, {
        cwd: config.path,
        ignored,
        persistent: true,
        ignoreInitial: true,
        depth: config.isRecursive ? undefined : 0,
        awaitWriteFinish: {
          stabilityThreshold: 2000,
          pollInterval: 100
        }
      });

      // Define event handlers
      const handleEvent = async (eventType: string, filePath: string, stats?: fs.Stats) => {
        // Create event
        const fileEvent: FileEvent = {
          id: uuidv4(),
          watchId: config.id,
          eventType,
          filePath: path.join(config.path, filePath),
          relativePath: filePath,
          timestamp: new Date().toISOString(),
          fileStats: stats ? {
            size: stats.size,
            mtime: stats.mtime.toISOString(),
            isDirectory: stats.isDirectory()
          } : undefined,
          automationResults: []
        };

        // Process automation rules
        const automationResults = await this.processRules(config, fileEvent);
        fileEvent.automationResults = automationResults;

        // Add event to list and save
        this.events.unshift(fileEvent);
        this.saveEvents();

        // Emit event
        this.emit('fileEvent', fileEvent);
      };

      // Attach event handlers
      watcher
        .on('add', (filePath, stats) => handleEvent('add', filePath, stats))
        .on('change', (filePath, stats) => handleEvent('change', filePath, stats))
        .on('unlink', (filePath) => handleEvent('unlink', filePath))
        .on('addDir', (filePath, stats) => handleEvent('addDir', filePath, stats))
        .on('unlinkDir', (filePath) => handleEvent('unlinkDir', filePath))
        .on('error', error => console.error(`Error in file watcher for "${config.name}":`, error));

      // Store the watcher
      this.watchers.set(config.id, watcher);
      console.log(`Started file watcher for "${config.name}" (${config.path})`);
    } catch (error) {
      console.error(`Error starting watcher for "${config.name}":`, error);
    }
  }

  // Process automation rules for an event
  private async processRules(config: WatchConfig, event: FileEvent): Promise<AutomationResult[]> {
    const results: AutomationResult[] = [];

    // Find matching rules
    for (const rule of config.automationRules) {
      // Skip inactive rules
      if (!rule.active) continue;

      // Check if event type matches
      if (rule.eventType !== 'all' && rule.eventType !== event.eventType) continue;

      // Check if file pattern matches
      const pattern = new RegExp(this.wildcardToRegex(rule.filePattern));
      if (!pattern.test(event.relativePath)) continue;

      // Process the rule's actions
      const actionResults = await this.processActions(rule, event);

      // Create rule result
      const ruleResult: AutomationResult = {
        id: uuidv4(),
        ruleId: rule.id,
        ruleName: rule.name,
        successful: actionResults.every(ar => ar.successful),
        actions: actionResults,
        timestamp: new Date().toISOString()
      };

      results.push(ruleResult);
    }

    return results;
  }

  // Process actions for a rule
  private async processActions(rule: AutomationRule, event: FileEvent): Promise<AutomationResult['actions']> {
    const results: AutomationResult['actions'] = [];

    for (const action of rule.actions) {
      // Skip inactive actions
      if (!action.active) continue;

      try {
        // Each action type has its own implementation
        switch (action.type) {
          case 'notify':
            results.push({
              id: uuidv4(),
              type: action.type,
              successful: true,
              message: action.config.message || `File ${event.eventType} event: ${event.relativePath}`,
              details: { timestamp: new Date().toISOString() }
            });
            break;

          case 'move':
            await this.executeFileMove(event, action, results);
            break;

          case 'copy':
            await this.executeFileCopy(event, action, results);
            break;

          case 'delete':
            await this.executeFileDelete(event, action, results);
            break;

          case 'rename':
            await this.executeFileRename(event, action, results);
            break;

          case 'googleSheets':
            results.push({
              id: uuidv4(),
              type: action.type,
              successful: true,
              message: `Google Sheets update triggered for event type: ${action.config.eventType || 'file_event'}`,
              details: { 
                eventType: action.config.eventType || 'file_event',
                filePath: event.relativePath 
              }
            });
            break;

          default:
            results.push({
              id: uuidv4(),
              type: action.type,
              successful: false,
              message: `Action type '${action.type}' not implemented`,
            });
        }
      } catch (error: any) {
        results.push({
          id: uuidv4(),
          type: action.type,
          successful: false,
          message: error.message || `Error executing action: ${action.type}`,
          details: { error: error.toString() }
        });
      }
    }

    return results;
  }

  // Execute move file action
  private async executeFileMove(event: FileEvent, action: AutomationAction, results: AutomationResult['actions']): Promise<void> {
    // Only process for add and change events
    if (event.eventType !== 'add' && event.eventType !== 'change') {
      results.push({
        id: uuidv4(),
        type: action.type,
        successful: false,
        message: `Move action only applies to 'add' and 'change' events, got '${event.eventType}'`,
      });
      return;
    }

    // Get config
    const { destinationPath, createDirectories, overwrite } = action.config;
    if (!destinationPath) {
      results.push({
        id: uuidv4(),
        type: action.type,
        successful: false,
        message: 'Destination path is required for move action',
      });
      return;
    }

    try {
      // Process destination path with placeholders
      const filename = path.basename(event.filePath);
      const dest = destinationPath.replace('{filename}', filename);
      const destPath = path.isAbsolute(dest) ? dest : path.join(path.dirname(event.filePath), dest);

      // Create destination directory if needed
      if (createDirectories) {
        fs.mkdirSync(path.dirname(destPath), { recursive: true });
      }

      // Check if destination exists
      const destExists = fs.existsSync(destPath);
      if (destExists && !overwrite) {
        results.push({
          id: uuidv4(),
          type: action.type,
          successful: false,
          message: `Destination file already exists: ${destPath}`,
        });
        return;
      }

      // Move the file
      fs.renameSync(event.filePath, destPath);

      results.push({
        id: uuidv4(),
        type: action.type,
        successful: true,
        message: `File moved to ${destPath}`,
        details: { source: event.filePath, destination: destPath }
      });
    } catch (error: any) {
      results.push({
        id: uuidv4(),
        type: action.type,
        successful: false,
        message: `Error moving file: ${error.message}`,
        details: { error: error.toString() }
      });
    }
  }

  // Execute copy file action
  private async executeFileCopy(event: FileEvent, action: AutomationAction, results: AutomationResult['actions']): Promise<void> {
    // Only process for add and change events
    if (event.eventType !== 'add' && event.eventType !== 'change') {
      results.push({
        id: uuidv4(),
        type: action.type,
        successful: false,
        message: `Copy action only applies to 'add' and 'change' events, got '${event.eventType}'`,
      });
      return;
    }

    // Get config
    const { destinationPath, createDirectories, overwrite } = action.config;
    if (!destinationPath) {
      results.push({
        id: uuidv4(),
        type: action.type,
        successful: false,
        message: 'Destination path is required for copy action',
      });
      return;
    }

    try {
      // Process destination path with placeholders
      const filename = path.basename(event.filePath);
      const dest = destinationPath.replace('{filename}', filename);
      const destPath = path.isAbsolute(dest) ? dest : path.join(path.dirname(event.filePath), dest);

      // Create destination directory if needed
      if (createDirectories) {
        fs.mkdirSync(path.dirname(destPath), { recursive: true });
      }

      // Check if destination exists
      const destExists = fs.existsSync(destPath);
      if (destExists && !overwrite) {
        results.push({
          id: uuidv4(),
          type: action.type,
          successful: false,
          message: `Destination file already exists: ${destPath}`,
        });
        return;
      }

      // Copy the file
      fs.copyFileSync(event.filePath, destPath);

      results.push({
        id: uuidv4(),
        type: action.type,
        successful: true,
        message: `File copied to ${destPath}`,
        details: { source: event.filePath, destination: destPath }
      });
    } catch (error: any) {
      results.push({
        id: uuidv4(),
        type: action.type,
        successful: false,
        message: `Error copying file: ${error.message}`,
        details: { error: error.toString() }
      });
    }
  }

  // Execute delete file action
  private async executeFileDelete(event: FileEvent, action: AutomationAction, results: AutomationResult['actions']): Promise<void> {
    // Only process for add and change events (we don't need to delete already deleted files)
    if (event.eventType !== 'add' && event.eventType !== 'change') {
      results.push({
        id: uuidv4(),
        type: action.type,
        successful: false,
        message: `Delete action only applies to 'add' and 'change' events, got '${event.eventType}'`,
      });
      return;
    }

    try {
      // Check if file exists
      if (!fs.existsSync(event.filePath)) {
        results.push({
          id: uuidv4(),
          type: action.type,
          successful: false,
          message: `File does not exist: ${event.filePath}`,
        });
        return;
      }

      // Delete the file
      fs.unlinkSync(event.filePath);

      results.push({
        id: uuidv4(),
        type: action.type,
        successful: true,
        message: `File deleted: ${event.filePath}`,
        details: { path: event.filePath }
      });
    } catch (error: any) {
      results.push({
        id: uuidv4(),
        type: action.type,
        successful: false,
        message: `Error deleting file: ${error.message}`,
        details: { error: error.toString() }
      });
    }
  }

  // Execute rename file action
  private async executeFileRename(event: FileEvent, action: AutomationAction, results: AutomationResult['actions']): Promise<void> {
    // Only process for add and change events
    if (event.eventType !== 'add' && event.eventType !== 'change') {
      results.push({
        id: uuidv4(),
        type: action.type,
        successful: false,
        message: `Rename action only applies to 'add' and 'change' events, got '${event.eventType}'`,
      });
      return;
    }

    // Get config
    const { pattern, replacement, overwrite } = action.config;
    if (!pattern || !replacement) {
      results.push({
        id: uuidv4(),
        type: action.type,
        successful: false,
        message: 'Pattern and replacement are required for rename action',
      });
      return;
    }

    try {
      // Get filename and directory
      const filename = path.basename(event.filePath);
      const dirname = path.dirname(event.filePath);

      // Apply pattern to filename
      let newFilename;
      try {
        const regex = new RegExp(pattern);
        newFilename = filename.replace(regex, replacement);
      } catch (error: any) {
        results.push({
          id: uuidv4(),
          type: action.type,
          successful: false,
          message: `Invalid regular expression pattern: ${error.message}`,
          details: { pattern, error: error.toString() }
        });
        return;
      }

      // Skip if filename doesn't change
      if (newFilename === filename) {
        results.push({
          id: uuidv4(),
          type: action.type,
          successful: false,
          message: `Pattern did not match filename, no change made`,
          details: { filename, pattern }
        });
        return;
      }

      // Create new path
      const newPath = path.join(dirname, newFilename);

      // Check if destination exists
      const destExists = fs.existsSync(newPath);
      if (destExists && !overwrite) {
        results.push({
          id: uuidv4(),
          type: action.type,
          successful: false,
          message: `Destination file already exists: ${newPath}`,
        });
        return;
      }

      // Rename the file
      fs.renameSync(event.filePath, newPath);

      results.push({
        id: uuidv4(),
        type: action.type,
        successful: true,
        message: `File renamed from ${filename} to ${newFilename}`,
        details: { oldPath: event.filePath, newPath }
      });
    } catch (error: any) {
      results.push({
        id: uuidv4(),
        type: action.type,
        successful: false,
        message: `Error renaming file: ${error.message}`,
        details: { error: error.toString() }
      });
    }
  }

  // Convert wildcard to regex
  private wildcardToRegex(pattern: string): string {
    return pattern
      .replace(/\./g, '\\.')   // Escape dots
      .replace(/\*/g, '.*')    // * becomes .*
      .replace(/\?/g, '.')     // ? becomes .
      .replace(/\//g, '\\/');  // Escape forward slashes
  }

  // Public methods for managing configurations

  // Get all configs
  public async getConfigs(): Promise<WatchConfig[]> {
    return [...this.configs];
  }

  // Get a specific config
  public async getConfig(id: string): Promise<WatchConfig | undefined> {
    return this.configs.find(config => config.id === id);
  }

  // Add a new config
  public async addConfig(config: Omit<WatchConfig, 'id' | 'createdAt'> & { id?: string, createdAt?: string }): Promise<WatchConfig> {
    const newConfig: WatchConfig = {
      id: config.id || uuidv4(),
      name: config.name,
      path: config.path,
      excludePaths: config.excludePaths || [],
      isRecursive: config.isRecursive !== undefined ? config.isRecursive : true,
      watchForPatterns: config.watchForPatterns || ['*'],
      ignorePatterns: config.ignorePatterns || [],
      active: config.active !== undefined ? config.active : true,
      createdAt: config.createdAt || new Date().toISOString(),
      automationRules: config.automationRules || []
    };

    this.configs.push(newConfig);
    this.saveConfigs();

    // Start watcher if active
    if (newConfig.active) {
      this.startWatcher(newConfig);
    }

    return newConfig;
  }

  // Update a config
  public async updateConfig(id: string, updates: Partial<WatchConfig>): Promise<WatchConfig> {
    const index = this.configs.findIndex(config => config.id === id);
    if (index === -1) {
      throw new Error(`Watch configuration with ID ${id} not found`);
    }

    // Update the config
    const oldConfig = this.configs[index];
    const updatedConfig: WatchConfig = {
      ...oldConfig,
      ...updates,
      id: oldConfig.id, // Ensure ID doesn't change
      createdAt: oldConfig.createdAt // Ensure createdAt doesn't change
    };
    this.configs[index] = updatedConfig;
    this.saveConfigs();

    // Handle watcher changes
    const wasActive = oldConfig.active;
    const isActive = updatedConfig.active;
    
    // If active status changed or watch parameters changed, update the watcher
    if (wasActive !== isActive || 
        oldConfig.path !== updatedConfig.path ||
        oldConfig.excludePaths.join() !== updatedConfig.excludePaths.join() ||
        oldConfig.isRecursive !== updatedConfig.isRecursive ||
        oldConfig.watchForPatterns.join() !== updatedConfig.watchForPatterns.join() ||
        oldConfig.ignorePatterns.join() !== updatedConfig.ignorePatterns.join()) {
      
      // Close existing watcher if any
      const existingWatcher = this.watchers.get(id);
      if (existingWatcher) {
        existingWatcher.close();
        this.watchers.delete(id);
      }
      
      // Start new watcher if active
      if (isActive) {
        this.startWatcher(updatedConfig);
      }
    }

    return updatedConfig;
  }

  // Remove a config
  public async removeConfig(id: string): Promise<void> {
    const index = this.configs.findIndex(config => config.id === id);
    if (index === -1) {
      throw new Error(`Watch configuration with ID ${id} not found`);
    }

    // Close watcher if exists
    const watcher = this.watchers.get(id);
    if (watcher) {
      watcher.close();
      this.watchers.delete(id);
    }

    // Remove the config
    this.configs.splice(index, 1);
    this.saveConfigs();
  }

  // Add a rule to a config
  public async addRule(configId: string, rule: AutomationRule): Promise<WatchConfig> {
    const config = await this.getConfig(configId);
    if (!config) {
      throw new Error(`Watch configuration with ID ${configId} not found`);
    }

    config.automationRules.push(rule);
    this.saveConfigs();
    return config;
  }

  // Update a rule
  public async updateRule(configId: string, ruleId: string, updates: Partial<AutomationRule>): Promise<AutomationRule> {
    const config = await this.getConfig(configId);
    if (!config) {
      throw new Error(`Watch configuration with ID ${configId} not found`);
    }

    const ruleIndex = config.automationRules.findIndex(rule => rule.id === ruleId);
    if (ruleIndex === -1) {
      throw new Error(`Rule with ID ${ruleId} not found in configuration ${configId}`);
    }

    // Update the rule
    const oldRule = config.automationRules[ruleIndex];
    const updatedRule: AutomationRule = {
      ...oldRule,
      ...updates,
      id: oldRule.id // Ensure ID doesn't change
    };
    config.automationRules[ruleIndex] = updatedRule;
    this.saveConfigs();

    return updatedRule;
  }

  // Remove a rule
  public async removeRule(configId: string, ruleId: string): Promise<void> {
    const config = await this.getConfig(configId);
    if (!config) {
      throw new Error(`Watch configuration with ID ${configId} not found`);
    }

    const ruleIndex = config.automationRules.findIndex(rule => rule.id === ruleId);
    if (ruleIndex === -1) {
      throw new Error(`Rule with ID ${ruleId} not found in configuration ${configId}`);
    }

    config.automationRules.splice(ruleIndex, 1);
    this.saveConfigs();
  }

  // Add an action to a rule
  public async addAction(configId: string, ruleId: string, action: AutomationAction): Promise<WatchConfig> {
    const config = await this.getConfig(configId);
    if (!config) {
      throw new Error(`Watch configuration with ID ${configId} not found`);
    }

    const rule = config.automationRules.find(rule => rule.id === ruleId);
    if (!rule) {
      throw new Error(`Rule with ID ${ruleId} not found in configuration ${configId}`);
    }

    rule.actions.push(action);
    this.saveConfigs();
    return config;
  }

  // Update an action
  public async updateAction(configId: string, ruleId: string, actionId: string, updates: Partial<AutomationAction>): Promise<AutomationAction> {
    const config = await this.getConfig(configId);
    if (!config) {
      throw new Error(`Watch configuration with ID ${configId} not found`);
    }

    const rule = config.automationRules.find(rule => rule.id === ruleId);
    if (!rule) {
      throw new Error(`Rule with ID ${ruleId} not found in configuration ${configId}`);
    }

    const actionIndex = rule.actions.findIndex(action => action.id === actionId);
    if (actionIndex === -1) {
      throw new Error(`Action with ID ${actionId} not found in rule ${ruleId}`);
    }

    // Update the action
    const oldAction = rule.actions[actionIndex];
    const updatedAction: AutomationAction = {
      ...oldAction,
      ...updates,
      id: oldAction.id // Ensure ID doesn't change
    };
    rule.actions[actionIndex] = updatedAction;
    this.saveConfigs();

    return updatedAction;
  }

  // Remove an action
  public async removeAction(configId: string, ruleId: string, actionId: string): Promise<void> {
    const config = await this.getConfig(configId);
    if (!config) {
      throw new Error(`Watch configuration with ID ${configId} not found`);
    }

    const rule = config.automationRules.find(rule => rule.id === ruleId);
    if (!rule) {
      throw new Error(`Rule with ID ${ruleId} not found in configuration ${configId}`);
    }

    const actionIndex = rule.actions.findIndex(action => action.id === actionId);
    if (actionIndex === -1) {
      throw new Error(`Action with ID ${actionId} not found in rule ${ruleId}`);
    }

    rule.actions.splice(actionIndex, 1);
    this.saveConfigs();
  }

  // Get events for a config
  public async getEventsByConfig(configId: string): Promise<FileEvent[]> {
    return this.events.filter(event => event.watchId === configId);
  }

  // Get recent events across all configs
  public async getRecentEvents(limit: number = 20): Promise<FileEvent[]> {
    return this.events.slice(0, limit);
  }
}

// Initialize the singleton instance
export const fileWatchService = FileWatchService.getInstance();