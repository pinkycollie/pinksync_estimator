import { db } from "../../db";
import { users, userBiometrics, userSessions, translationHistory } from "@shared/schema";
import { eq, and, gt } from "drizzle-orm";
import { randomBytes, scrypt, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { v4 as uuidv4 } from "uuid";

const scryptAsync = promisify(scrypt);

export interface BiometricTemplate {
  id: string;
  signaturePoints: number[][];
  motionPattern: number[];
  spatialCoordinates: number[][];
  timestamp: number;
  confidence: number;
}

export interface MotionPasswordData {
  sequence: string[];
  timingPattern: number[];
  spatialCoordinates: number[][];
  pressure: number[];
}

export interface SignAuthResult {
  success: boolean;
  confidence: number;
  userId?: number;
  sessionId?: string;
  error?: string;
}

export class SignLanguageAuthService {
  private readonly TEMPLATE_SIMILARITY_THRESHOLD = 0.75;
  private readonly MOTION_PASSWORD_THRESHOLD = 0.80;
  private readonly MAX_FAILED_ATTEMPTS = 5;
  private readonly LOCKOUT_DURATION = 15 * 60 * 1000; // 15 minutes

  /**
   * Enroll user biometric templates during registration
   */
  async enrollBiometrics(userId: number, templates: BiometricTemplate[]): Promise<boolean> {
    try {
      const encryptedTemplates = await this.encryptTemplates(templates);
      
      await db.insert(userBiometrics).values({
        userId,
        biometricTemplates: encryptedTemplates,
        templateVersion: '1.0',
        lastUpdated: new Date(),
      });

      return true;
    } catch (error) {
      console.error('Error enrolling biometrics:', error);
      return false;
    }
  }

  /**
   * Set motion password for user
   */
  async setMotionPassword(userId: number, motionData: MotionPasswordData): Promise<boolean> {
    try {
      const hash = await this.hashMotionPassword(motionData);
      
      await db.update(userBiometrics)
        .set({ 
          motionPasswordHash: hash,
          lastUpdated: new Date()
        })
        .where(eq(userBiometrics.userId, userId));

      return true;
    } catch (error) {
      console.error('Error setting motion password:', error);
      return false;
    }
  }

  /**
   * Authenticate using sign biometrics
   */
  async authenticateWithBiometrics(
    signData: BiometricTemplate, 
    deviceInfo?: any
  ): Promise<SignAuthResult> {
    try {
      // Find potential users based on biometric similarity
      const users = await this.findSimilarBiometrics(signData);
      
      if (users.length === 0) {
        return { success: false, confidence: 0, error: 'No matching biometric found' };
      }

      // Check lockout status
      const user = users[0];
      if (await this.isUserLockedOut(user.userId)) {
        return { success: false, confidence: 0, error: 'Account temporarily locked' };
      }

      // Calculate confidence score
      const confidence = await this.calculateBiometricConfidence(signData, user.templates);
      
      if (confidence < this.TEMPLATE_SIMILARITY_THRESHOLD) {
        await this.recordFailedAttempt(user.userId);
        return { success: false, confidence, error: 'Biometric verification failed' };
      }

      // Create session
      const sessionId = await this.createUserSession(user.userId, 'SIGN_BIOMETRIC', deviceInfo);
      
      // Reset failed attempts on successful auth
      await this.resetFailedAttempts(user.userId);

      return { 
        success: true, 
        confidence, 
        userId: user.userId, 
        sessionId 
      };

    } catch (error) {
      console.error('Error in biometric authentication:', error);
      return { success: false, confidence: 0, error: 'Authentication service error' };
    }
  }

  /**
   * Authenticate using motion password
   */
  async authenticateWithMotionPassword(
    userId: number,
    motionData: MotionPasswordData,
    deviceInfo?: any
  ): Promise<SignAuthResult> {
    try {
      // Check lockout status
      if (await this.isUserLockedOut(userId)) {
        return { success: false, confidence: 0, error: 'Account temporarily locked' };
      }

      // Get stored motion password hash
      const [biometric] = await db.select()
        .from(userBiometrics)
        .where(eq(userBiometrics.userId, userId));

      if (!biometric?.motionPasswordHash) {
        return { success: false, confidence: 0, error: 'Motion password not set' };
      }

      // Verify motion password
      const isValid = await this.verifyMotionPassword(motionData, biometric.motionPasswordHash);
      
      if (!isValid) {
        await this.recordFailedAttempt(userId);
        return { success: false, confidence: 0, error: 'Motion password verification failed' };
      }

      // Create session
      const sessionId = await this.createUserSession(userId, 'MOTION_PASSWORD', deviceInfo);
      
      // Reset failed attempts
      await this.resetFailedAttempts(userId);

      return { 
        success: true, 
        confidence: 1.0, 
        userId, 
        sessionId 
      };

    } catch (error) {
      console.error('Error in motion password authentication:', error);
      return { success: false, confidence: 0, error: 'Authentication service error' };
    }
  }

  /**
   * Validate existing session
   */
  async validateSession(sessionId: string): Promise<{ valid: boolean; userId?: number }> {
    try {
      const [session] = await db.select()
        .from(userSessions)
        .where(
          and(
            eq(userSessions.sessionId, sessionId),
            eq(userSessions.status, 'ACTIVE'),
            gt(userSessions.expiryTime, new Date())
          )
        );

      if (!session) {
        return { valid: false };
      }

      // Update last active time
      await db.update(userSessions)
        .set({ lastActive: new Date() })
        .where(eq(userSessions.sessionId, sessionId));

      return { valid: true, userId: session.userId };

    } catch (error) {
      console.error('Error validating session:', error);
      return { valid: false };
    }
  }

  /**
   * Terminate session
   */
  async terminateSession(sessionId: string): Promise<boolean> {
    try {
      await db.update(userSessions)
        .set({ 
          status: 'TERMINATED',
          lastActive: new Date()
        })
        .where(eq(userSessions.sessionId, sessionId));

      return true;
    } catch (error) {
      console.error('Error terminating session:', error);
      return false;
    }
  }

  // Private helper methods

  private async encryptTemplates(templates: BiometricTemplate[]): Promise<any> {
    // In a real implementation, this would use proper encryption
    // For now, we'll store with basic obfuscation
    return templates.map(template => ({
      ...template,
      signaturePoints: this.obfuscateData(template.signaturePoints),
      motionPattern: this.obfuscateData(template.motionPattern),
      spatialCoordinates: this.obfuscateData(template.spatialCoordinates)
    }));
  }

  private async hashMotionPassword(motionData: MotionPasswordData): Promise<string> {
    const salt = randomBytes(16).toString('hex');
    const combined = JSON.stringify(motionData);
    const hash = (await scryptAsync(combined, salt, 64)) as Buffer;
    return `${hash.toString('hex')}.${salt}`;
  }

  private async verifyMotionPassword(motionData: MotionPasswordData, stored: string): Promise<boolean> {
    const [hashed, salt] = stored.split('.');
    const hashedBuffer = Buffer.from(hashed, 'hex');
    const combined = JSON.stringify(motionData);
    const suppliedBuffer = (await scryptAsync(combined, salt, 64)) as Buffer;
    return timingSafeEqual(hashedBuffer, suppliedBuffer);
  }

  private async findSimilarBiometrics(signData: BiometricTemplate): Promise<any[]> {
    // In a real implementation, this would use vector similarity search
    // For now, we'll return a simplified match
    const allBiometrics = await db.select({
      userId: userBiometrics.userId,
      templates: userBiometrics.biometricTemplates
    }).from(userBiometrics);

    return allBiometrics.filter(bio => {
      // Simplified similarity check
      return this.calculateSimpleSimilarity(signData, bio.templates) > 0.5;
    });
  }

  private async calculateBiometricConfidence(
    inputData: BiometricTemplate, 
    storedTemplates: any
  ): Promise<number> {
    // Simplified confidence calculation
    // In a real implementation, this would use sophisticated ML algorithms
    return this.calculateSimpleSimilarity(inputData, storedTemplates);
  }

  private calculateSimpleSimilarity(template1: BiometricTemplate, template2: any): number {
    // Very basic similarity calculation for demonstration
    // Real implementation would use proper biometric matching algorithms
    return Math.random() * 0.5 + 0.5; // Returns 0.5-1.0
  }

  private async isUserLockedOut(userId: number): Promise<boolean> {
    const [biometric] = await db.select()
      .from(userBiometrics)
      .where(eq(userBiometrics.userId, userId));

    if (!biometric?.lockoutStatus) return false;
    
    if (biometric.lockoutUntil && new Date() > biometric.lockoutUntil) {
      // Lockout has expired, reset status
      await db.update(userBiometrics)
        .set({ 
          lockoutStatus: false, 
          lockoutUntil: null,
          failedAttempts: 0
        })
        .where(eq(userBiometrics.userId, userId));
      return false;
    }

    return biometric.lockoutStatus;
  }

  private async recordFailedAttempt(userId: number): Promise<void> {
    const [biometric] = await db.select()
      .from(userBiometrics)
      .where(eq(userBiometrics.userId, userId));

    const failedAttempts = (biometric?.failedAttempts || 0) + 1;
    const shouldLockout = failedAttempts >= this.MAX_FAILED_ATTEMPTS;

    await db.update(userBiometrics)
      .set({
        failedAttempts,
        lockoutStatus: shouldLockout,
        lockoutUntil: shouldLockout ? new Date(Date.now() + this.LOCKOUT_DURATION) : null
      })
      .where(eq(userBiometrics.userId, userId));
  }

  private async resetFailedAttempts(userId: number): Promise<void> {
    await db.update(userBiometrics)
      .set({
        failedAttempts: 0,
        lockoutStatus: false,
        lockoutUntil: null
      })
      .where(eq(userBiometrics.userId, userId));
  }

  async createUserSession(
    userId: number, 
    authMethod: string, 
    deviceInfo?: any
  ): Promise<string> {
    const sessionId = uuidv4();
    const expiryTime = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

    await db.insert(userSessions).values({
      sessionId,
      userId,
      deviceId: deviceInfo?.deviceId,
      ipAddress: deviceInfo?.ipAddress,
      userAgent: deviceInfo?.userAgent,
      expiryTime,
      authMethod,
      status: 'ACTIVE'
    });

    return sessionId;
  }

  private obfuscateData(data: any): any {
    // Simple obfuscation - in production, use proper encryption
    return JSON.stringify(data).split('').reverse().join('');
  }
}

export const signLanguageAuth = new SignLanguageAuthService();