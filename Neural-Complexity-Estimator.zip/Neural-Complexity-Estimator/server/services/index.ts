/**
 * Services Index
 * 
 * Initializes and exports all PinkSync services.
 */

import { logger } from '../utils/logger';

// Import integration services
import notionIntegrationService from './integration/notionIntegration';
import xanoIntegrationService from './integration/xanoIntegration';
import { civicIntegrationService } from './integration/civic-integration';
import gitIntegrationService from './integration/gitIntegration';

// Import development services
import developmentPipelineService from './development/developmentPipeline';

// Import webhook services
import webhookManagerService from './webhook/webhookManager';

// Import generator services
import apiGeneratorService from './generator/apiGenerator';

// Import AI services
import complexityEstimatorService from './ai/complexityEstimator';

/**
 * Initialize all services
 */
export async function initializeServices(): Promise<boolean> {
  try {
    logger.info('Initializing PinkSync services');
    
    // Initialize integration services
    await notionIntegrationService.initialize();
    await xanoIntegrationService.initialize();
    await civicIntegrationService.initialize();
    await gitIntegrationService.initialize();
    
    // Initialize development services
    await developmentPipelineService.initialize();
    
    // Initialize webhook services
    await webhookManagerService.initialize();
    
    // Initialize generator services
    await apiGeneratorService.initialize();
    
    // Initialize AI services
    await complexityEstimatorService.initialize();
    
    logger.info('All PinkSync services initialized successfully');
    
    return true;
  } catch (error) {
    logger.error('Failed to initialize PinkSync services', error);
    return false;
  }
}

/**
 * Check if services are ready
 */
export function areServicesReady(): boolean {
  return (
    notionIntegrationService.isReady() &&
    xanoIntegrationService.isReady() &&
    civicIntegrationService.isReady() &&
    gitIntegrationService.isReady() &&
    developmentPipelineService.isReady() &&
    webhookManagerService.isReady() &&
    apiGeneratorService.isReady() &&
    complexityEstimatorService.isReady()
  );
}

// Export all services
export {
  notionIntegrationService,
  xanoIntegrationService,
  civicIntegrationService,
  gitIntegrationService,
  developmentPipelineService,
  webhookManagerService,
  apiGeneratorService,
  complexityEstimatorService
};