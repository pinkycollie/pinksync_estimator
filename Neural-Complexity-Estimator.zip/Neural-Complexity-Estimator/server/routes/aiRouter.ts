/**
 * AI Hub API Router
 * Handles API endpoints for AI services.
 */

import express from 'express';
import { aiRateLimiter, chatRateLimiter, imageRateLimiter } from '../middleware/rateLimiter';
import openaiService from '../services/openai';
import accessControlService from '../services/security/accessControl';

// Create router
const router = express.Router();

/**
 * Middleware to check if user has AI access permission
 */
const checkAIAccess = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const userId = req.user?.claims?.sub;
  
  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized', message: 'Authentication required' });
  }
  
  const hasAccess = accessControlService.hasPermission(userId, 'useAI');
  
  if (!hasAccess) {
    return res.status(403).json({ 
      error: 'Forbidden', 
      message: 'You do not have permission to access AI features' 
    });
  }
  
  next();
};

/**
 * Middleware to check if user has AI admin permission
 */
const checkAIAdminAccess = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const userId = req.user?.claims?.sub;
  
  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized', message: 'Authentication required' });
  }
  
  const hasAccess = accessControlService.hasPermission(userId, 'aiAdmin');
  
  if (!hasAccess) {
    return res.status(403).json({ 
      error: 'Forbidden', 
      message: 'You do not have permission to access AI admin features' 
    });
  }
  
  next();
};

// Apply rate limiting and access control to all AI routes
router.use(aiRateLimiter);
router.use(checkAIAccess);

/**
 * GET /api/ai/models
 * Get available AI models
 */
router.get('/models', (req, res) => {
  // In a real implementation, this might be fetched from OpenAI API
  const models = [
    {
      id: 'gpt-4o',
      name: 'GPT-4o',
      description: 'Most capable GPT-4 model with vision',
      type: 'chat',
      capabilities: ['text', 'image', 'vision'],
    },
    {
      id: 'claude-3-7-sonnet-20250219',
      name: 'Claude 3.7 Sonnet',
      description: 'Advanced Claude model for various tasks',
      type: 'chat',
      capabilities: ['text', 'vision'],
    },
    {
      id: 'text-embedding-3-small',
      name: 'Text Embedding 3 Small',
      description: 'Efficient text embedding model',
      type: 'embedding',
      capabilities: ['text'],
    },
    {
      id: 'dall-e-3',
      name: 'DALL-E 3',
      description: 'Advanced image generation model',
      type: 'image',
      capabilities: ['generation'],
    }
  ];
  
  res.json(models);
});

/**
 * POST /api/ai/generate
 * Generate content using AI
 */
router.post('/generate', chatRateLimiter, async (req, res) => {
  try {
    const { messages, model, type = 'text' } = req.body;
    
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ 
        error: 'Bad Request', 
        message: 'Messages array is required' 
      });
    }
    
    // Generate chat completion
    const completion = await openaiService.chat.generateChatCompletion(
      messages,
      { model, useContext: true, contextId: req.user?.claims?.sub }
    );
    
    res.json({ content: completion.content });
  } catch (error: any) {
    console.error('Error generating AI response:', error);
    
    res.status(500).json({ 
      error: 'Internal Server Error', 
      message: error.message || 'Failed to generate AI response' 
    });
  }
});

/**
 * POST /api/ai/analyze-image
 * Analyze image using AI vision capabilities
 */
router.post('/analyze-image', imageRateLimiter, async (req, res) => {
  try {
    const { image, prompt } = req.body;
    
    if (!image) {
      return res.status(400).json({ 
        error: 'Bad Request', 
        message: 'Image data is required' 
      });
    }
    
    // Clean the base64 data if needed
    const base64Image = image.replace(/^data:image\/(png|jpeg|jpg);base64,/, '');
    
    // Generate image description
    const description = await openaiService.completion.generateImageDescription(
      base64Image,
      prompt || 'Describe this image in detail.'
    );
    
    res.json({ description });
  } catch (error: any) {
    console.error('Error analyzing image:', error);
    
    res.status(500).json({ 
      error: 'Internal Server Error', 
      message: error.message || 'Failed to analyze image' 
    });
  }
});

/**
 * POST /api/ai/embeddings
 * Generate embeddings for text
 */
router.post('/embeddings', async (req, res) => {
  try {
    const { text, texts } = req.body;
    
    if (!text && (!texts || !Array.isArray(texts))) {
      return res.status(400).json({ 
        error: 'Bad Request', 
        message: 'Text or texts array is required' 
      });
    }
    
    let embeddings;
    
    if (text) {
      // Generate embedding for single text
      embeddings = await openaiService.embeddings.generateEmbedding(text);
    } else {
      // Generate embeddings for multiple texts
      embeddings = await openaiService.embeddings.generateEmbeddings(texts);
    }
    
    res.json({ embeddings });
  } catch (error: any) {
    console.error('Error generating embeddings:', error);
    
    res.status(500).json({ 
      error: 'Internal Server Error', 
      message: error.message || 'Failed to generate embeddings' 
    });
  }
});

/**
 * Admin routes
 */
router.use('/admin', checkAIAdminAccess);

/**
 * GET /api/ai/admin/usage
 * Get AI usage statistics (admin only)
 */
router.get('/admin/usage', (req, res) => {
  // In a real implementation, this would fetch usage data from database
  const usage = {
    totalRequests: 1245,
    totalTokens: 78500,
    requestsByModel: {
      'gpt-4o': 825,
      'claude-3-7-sonnet-20250219': 320,
      'text-embedding-3-small': 50,
      'dall-e-3': 50
    },
    requestsByDay: [
      { date: '2025-03-01', count: 120 },
      { date: '2025-03-02', count: 145 },
      { date: '2025-03-03', count: 198 },
      { date: '2025-03-04', count: 210 },
      { date: '2025-03-05', count: 180 },
      { date: '2025-03-06', count: 205 },
      { date: '2025-03-07', count: 187 },
    ]
  };
  
  res.json(usage);
});

export default router;