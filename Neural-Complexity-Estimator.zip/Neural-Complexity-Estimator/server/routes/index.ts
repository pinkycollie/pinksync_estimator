/**
 * Routes Index
 * 
 * Exports all API routes for the application.
 */

import express from 'express';
import developmentRoutes from './development';

const router = express.Router();

// Mount routes
router.use('/development', developmentRoutes);

// Health check
router.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

export default router;