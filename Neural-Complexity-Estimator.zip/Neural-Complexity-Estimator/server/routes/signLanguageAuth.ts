import { Router } from "express";
import { signLanguageAuth } from "../services/auth/signLanguageAuth";
import { signTranslationService } from "../services/translation/signTranslation";
import { db } from "../db";
import { users, userBiometrics, userSessions, developerApps, webhookEvents } from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";
import { randomBytes } from "crypto";

const router = Router();

// Authentication API Routes - /api/v1/auth/*

/**
 * Sign Biometric Authentication
 * POST /api/v1/auth/sign-biometric
 */
router.post('/sign-biometric', async (req, res) => {
  try {
    const { signData, deviceInfo } = req.body;

    if (!signData) {
      return res.status(400).json({ error: 'Sign data is required' });
    }

    const result = await signLanguageAuth.authenticateWithBiometrics(signData, deviceInfo);

    if (result.success) {
      res.json({
        success: true,
        sessionId: result.sessionId,
        confidence: result.confidence,
        userId: result.userId
      });
    } else {
      res.status(401).json({
        success: false,
        error: result.error,
        confidence: result.confidence
      });
    }
  } catch (error) {
    console.error('Sign biometric auth error:', error);
    res.status(500).json({ error: 'Authentication service error' });
  }
});

/**
 * Motion Password Authentication
 * POST /api/v1/auth/motion-password
 */
router.post('/motion-password', async (req, res) => {
  try {
    const { userId, motionData, deviceInfo } = req.body;

    if (!userId || !motionData) {
      return res.status(400).json({ error: 'User ID and motion data are required' });
    }

    const result = await signLanguageAuth.authenticateWithMotionPassword(userId, motionData, deviceInfo);

    if (result.success) {
      res.json({
        success: true,
        sessionId: result.sessionId,
        confidence: result.confidence
      });
    } else {
      res.status(401).json({
        success: false,
        error: result.error
      });
    }
  } catch (error) {
    console.error('Motion password auth error:', error);
    res.status(500).json({ error: 'Authentication service error' });
  }
});

/**
 * Traditional Login with Enhanced Security
 * POST /api/v1/auth/login
 */
router.post('/login', async (req, res) => {
  try {
    const { username, password, preferredSignLanguage, deviceInfo } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }

    // Find user by username
    const [user] = await db.select()
      .from(users)
      .where(eq(users.username, username));

    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Verify password (simplified - in production use proper hashing)
    if (user.password !== password) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Update preferred sign language if provided
    if (preferredSignLanguage && preferredSignLanguage !== user.preferredSignLanguage) {
      await db.update(users)
        .set({ preferredSignLanguage })
        .where(eq(users.id, user.id));
    }

    // Create session
    const sessionId = await signLanguageAuth.createUserSession(user.id, 'EMAIL_PASSWORD', deviceInfo);

    // Update last login
    await db.update(users)
      .set({ lastLogin: new Date() })
      .where(eq(users.id, user.id));

    res.json({
      success: true,
      sessionId,
      user: {
        id: user.id,
        username: user.username,
        fullName: user.fullName,
        preferredSignLanguage: user.preferredSignLanguage,
        role: user.role
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Authentication service error' });
  }
});

/**
 * Logout
 * POST /api/v1/auth/logout
 */
router.post('/logout', async (req, res) => {
  try {
    const { sessionId } = req.body;

    if (!sessionId) {
      return res.status(400).json({ error: 'Session ID is required' });
    }

    const success = await signLanguageAuth.terminateSession(sessionId);

    if (success) {
      res.json({ success: true });
    } else {
      res.status(400).json({ error: 'Failed to logout' });
    }
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Authentication service error' });
  }
});

/**
 * Validate Session
 * GET /api/v1/auth/sessions/:sessionId
 */
router.get('/sessions/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;
    const result = await signLanguageAuth.validateSession(sessionId);

    if (result.valid) {
      // Get user details
      const [user] = await db.select()
        .from(users)
        .where(eq(users.id, result.userId!));

      res.json({
        valid: true,
        user: {
          id: user.id,
          username: user.username,
          fullName: user.fullName,
          preferredSignLanguage: user.preferredSignLanguage,
          role: user.role
        }
      });
    } else {
      res.status(401).json({ valid: false });
    }
  } catch (error) {
    console.error('Session validation error:', error);
    res.status(500).json({ error: 'Authentication service error' });
  }
});

/**
 * Get User Sessions
 * GET /api/v1/auth/sessions
 */
router.get('/sessions', async (req, res) => {
  try {
    const { userId } = req.query;

    if (!userId) {
      return res.status(400).json({ error: 'User ID is required' });
    }

    const sessions = await db.select()
      .from(userSessions)
      .where(eq(userSessions.userId, Number(userId)))
      .orderBy(desc(userSessions.startTime));

    res.json({ sessions });
  } catch (error) {
    console.error('Get sessions error:', error);
    res.status(500).json({ error: 'Authentication service error' });
  }
});

/**
 * Reset Credentials
 * POST /api/v1/auth/reset-credentials
 */
router.post('/reset-credentials', async (req, res) => {
  try {
    const { userId, resetType } = req.body;

    if (!userId || !resetType) {
      return res.status(400).json({ error: 'User ID and reset type are required' });
    }

    if (resetType === 'biometric') {
      // Reset biometric data
      await db.update(userBiometrics)
        .set({
          biometricTemplates: [],
          motionPasswordHash: null,
          failedAttempts: 0,
          lockoutStatus: false,
          lockoutUntil: null
        })
        .where(eq(userBiometrics.userId, userId));
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Reset credentials error:', error);
    res.status(500).json({ error: 'Authentication service error' });
  }
});

// User Management API Routes - /api/v1/users/*

/**
 * Create User
 * POST /api/v1/users
 */
router.post('/users', async (req, res) => {
  try {
    const userData = req.body;

    // Check if username already exists
    const [existingUser] = await db.select()
      .from(users)
      .where(eq(users.username, userData.username));

    if (existingUser) {
      return res.status(400).json({ error: 'Username already exists' });
    }

    // Create user
    const [newUser] = await db.insert(users)
      .values({
        ...userData,
        dateCreated: new Date(),
        status: 'PENDING_VERIFICATION'
      })
      .returning();

    // Initialize biometrics record
    await db.insert(userBiometrics)
      .values({
        userId: newUser.id,
        templateVersion: '1.0',
        lastUpdated: new Date()
      });

    res.status(201).json({
      success: true,
      user: {
        id: newUser.id,
        username: newUser.username,
        fullName: newUser.fullName,
        preferredSignLanguage: newUser.preferredSignLanguage,
        status: newUser.status
      }
    });

  } catch (error) {
    console.error('Create user error:', error);
    res.status(500).json({ error: 'User creation failed' });
  }
});

/**
 * Get User
 * GET /api/v1/users/:userId
 */
router.get('/users/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    const [user] = await db.select()
      .from(users)
      .where(eq(users.id, Number(userId)));

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      id: user.id,
      username: user.username,
      fullName: user.fullName,
      email: user.email,
      preferredSignLanguage: user.preferredSignLanguage,
      regionalVariant: user.regionalVariant,
      status: user.status,
      role: user.role,
      dateCreated: user.dateCreated,
      lastLogin: user.lastLogin
    });

  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Failed to get user' });
  }
});

/**
 * Update User
 * PUT /api/v1/users/:userId
 */
router.put('/users/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const updateData = req.body;

    const [updatedUser] = await db.update(users)
      .set({
        ...updateData,
        updatedAt: new Date()
      })
      .where(eq(users.id, Number(userId)))
      .returning();

    if (!updatedUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ success: true, user: updatedUser });

  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

/**
 * Enroll Biometrics
 * POST /api/v1/users/:userId/biometrics/enroll
 */
router.post('/users/:userId/biometrics/enroll', async (req, res) => {
  try {
    const { userId } = req.params;
    const { templates } = req.body;

    if (!templates || !Array.isArray(templates)) {
      return res.status(400).json({ error: 'Biometric templates are required' });
    }

    const success = await signLanguageAuth.enrollBiometrics(Number(userId), templates);

    if (success) {
      res.json({ success: true });
    } else {
      res.status(400).json({ error: 'Failed to enroll biometrics' });
    }

  } catch (error) {
    console.error('Enroll biometrics error:', error);
    res.status(500).json({ error: 'Biometric enrollment failed' });
  }
});

/**
 * Set Motion Password
 * POST /api/v1/users/:userId/motion-password
 */
router.post('/users/:userId/motion-password', async (req, res) => {
  try {
    const { userId } = req.params;
    const { motionData } = req.body;

    if (!motionData) {
      return res.status(400).json({ error: 'Motion data is required' });
    }

    const success = await signLanguageAuth.setMotionPassword(Number(userId), motionData);

    if (success) {
      res.json({ success: true });
    } else {
      res.status(400).json({ error: 'Failed to set motion password' });
    }

  } catch (error) {
    console.error('Set motion password error:', error);
    res.status(500).json({ error: 'Motion password setup failed' });
  }
});

// Translation API Routes - /api/v1/translate/*

/**
 * Sign to Text Translation
 * POST /api/v1/translate/sign-to-text
 */
router.post('/translate/sign-to-text', async (req, res) => {
  try {
    const request = req.body;
    const result = await signTranslationService.translateSignToText(request);
    
    res.json(result);
  } catch (error) {
    console.error('Sign to text translation error:', error);
    res.status(500).json({ error: 'Translation service error' });
  }
});

/**
 * Text to Sign Translation
 * POST /api/v1/translate/text-to-sign
 */
router.post('/translate/text-to-sign', async (req, res) => {
  try {
    const request = req.body;
    const result = await signTranslationService.translateTextToSign(request);
    
    res.json(result);
  } catch (error) {
    console.error('Text to sign translation error:', error);
    res.status(500).json({ error: 'Translation service error' });
  }
});

/**
 * Get Supported Languages
 * GET /api/v1/translate/supported-languages
 */
router.get('/translate/supported-languages', async (req, res) => {
  try {
    const languages = {
      signLanguages: ['ASL', 'BSL', 'Auslan', 'NZSL', 'ISL', 'JSL', 'CSL', 'LSF', 'DGS', 'LSE', 'LIS'],
      spokenLanguages: ['en', 'es', 'fr', 'de', 'it', 'pt', 'zh', 'ja', 'ko', 'ar'],
      regions: {
        'ASL': ['US', 'CA', 'MX'],
        'BSL': ['GB', 'IE', 'AU', 'NZ'],
        'Auslan': ['AU'],
        'NZSL': ['NZ']
      }
    };
    
    res.json(languages);
  } catch (error) {
    console.error('Get supported languages error:', error);
    res.status(500).json({ error: 'Translation service error' });
  }
});

// Cultural API Routes - /api/v1/cultural/*

/**
 * Get Cultural Variants
 * GET /api/v1/cultural/variants/:signLanguage
 */
router.get('/cultural/variants/:signLanguage', async (req, res) => {
  try {
    const { signLanguage } = req.params;
    const { term, region } = req.query;

    const variants = await signTranslationService.getCulturalVariants(
      signLanguage,
      term as string,
      region as string
    );

    res.json({ variants });
  } catch (error) {
    console.error('Get cultural variants error:', error);
    res.status(500).json({ error: 'Cultural service error' });
  }
});

/**
 * Submit Cultural Contribution
 * POST /api/v1/cultural/contribute
 */
router.post('/cultural/contribute', async (req, res) => {
  try {
    const contribution = req.body;
    const success = await signTranslationService.submitCulturalContribution(contribution);

    if (success) {
      res.json({ success: true });
    } else {
      res.status(400).json({ error: 'Failed to submit contribution' });
    }
  } catch (error) {
    console.error('Submit cultural contribution error:', error);
    res.status(500).json({ error: 'Cultural service error' });
  }
});

// Developer API Routes - /api/v1/developer/*

/**
 * Create Developer App
 * POST /api/v1/developer/apps
 */
router.post('/developer/apps', async (req, res) => {
  try {
    const { developerId, appName, description, permissions, webhookUrl } = req.body;

    const apiKey = `pk_${randomBytes(16).toString('hex')}`;
    const secretKey = `sk_${randomBytes(32).toString('hex')}`;

    const [app] = await db.insert(developerApps)
      .values({
        developerId,
        appName,
        description,
        apiKey,
        secretKey,
        permissions: permissions || [],
        webhookUrl,
        createdAt: new Date()
      })
      .returning();

    res.status(201).json({
      success: true,
      app: {
        id: app.id,
        appName: app.appName,
        apiKey: app.apiKey,
        permissions: app.permissions,
        webhookUrl: app.webhookUrl
      }
    });

  } catch (error) {
    console.error('Create developer app error:', error);
    res.status(500).json({ error: 'Developer service error' });
  }
});

/**
 * Get Developer Apps
 * GET /api/v1/developer/apps
 */
router.get('/developer/apps', async (req, res) => {
  try {
    const { developerId } = req.query;

    if (!developerId) {
      return res.status(400).json({ error: 'Developer ID is required' });
    }

    const apps = await db.select()
      .from(developerApps)
      .where(eq(developerApps.developerId, Number(developerId)));

    res.json({ apps });
  } catch (error) {
    console.error('Get developer apps error:', error);
    res.status(500).json({ error: 'Developer service error' });
  }
});

export default router;