import express from 'express';
import { storage } from '../storage';
import { insertProjectSchema, insertComplexityAnalysisSchema, insertProjectTaskSchema } from '../../shared/schema';
import { z } from 'zod';

const router = express.Router();

// Neural Complexity Estimator - Deaf-first cognitive accessibility analysis
class NeuralComplexityEstimator {
  public analyzeProjectComplexity(projectData: any) {
    // Deaf-first cognitive modeling and accessibility analysis
    const baseFactors = {
      // Cognitive load assessment for Deaf users
      cognitiveLoad: this.calculateCognitiveLoad(projectData.description || ''),
      
      // Visual accessibility complexity
      visualAccessibility: this.analyzeVisualAccessibility(projectData.requirements || ''),
      
      // Language complexity and ASL compatibility
      languageComplexity: this.assessLanguageComplexity(projectData.description || ''),
      
      // Workflow complexity for gesture-based interaction
      workflowComplexity: this.calculateWorkflowComplexity(projectData.technologies || [])
    };

    // Deaf-first accessibility weighted scoring
    const weights = {
      cognitive: 0.35,      // Highest priority - cognitive load
      visual: 0.30,         // Visual accessibility for Deaf users
      language: 0.25,       // ASL/language complexity
      workflow: 0.10        // Gesture-based workflow complexity
    };

    const complexityScore = Math.round(
      (baseFactors.cognitiveLoad * weights.cognitive) +
      (baseFactors.visualAccessibility * weights.visual) +
      (baseFactors.languageComplexity * weights.language) +
      (baseFactors.workflowComplexity * weights.workflow)
    );

    return {
      complexityScore: Math.min(100, Math.max(1, complexityScore)),
      breakdown: baseFactors,
      confidence: this.calculateConfidence(baseFactors),
      estimatedHours: this.estimateHours(complexityScore, baseFactors),
      riskFactors: this.identifyRiskFactors(baseFactors),
      recommendations: this.generateRecommendations(baseFactors)
    };
  }

  private calculateCognitiveLoad(description: string): number {
    const text = description.toLowerCase();
    let cognitiveLoad = 20; // Base cognitive load
    
    // Visual processing complexity indicators
    if (text.includes('dashboard') || text.includes('visualization')) cognitiveLoad += 15;
    if (text.includes('chart') || text.includes('graph') || text.includes('diagram')) cognitiveLoad += 10;
    if (text.includes('animation') || text.includes('transition')) cognitiveLoad += 12;
    
    // Information density indicators
    if (text.includes('multiple') || text.includes('complex') || text.includes('advanced')) cognitiveLoad += 8;
    if (text.includes('simultaneous') || text.includes('parallel')) cognitiveLoad += 15;
    
    // Document/text complexity
    if (text.includes('legal') || text.includes('technical') || text.includes('scientific')) cognitiveLoad += 20;
    if (text.includes('contract') || text.includes('agreement') || text.includes('policy')) cognitiveLoad += 18;
    
    // Interaction complexity
    if (text.includes('multi-step') || text.includes('workflow') || text.includes('process')) cognitiveLoad += 12;
    if (text.includes('form') || text.includes('input') || text.includes('validation')) cognitiveLoad += 8;
    
    return Math.min(80, cognitiveLoad);
  }

  private analyzeVisualAccessibility(requirements: string): number {
    const text = requirements.toLowerCase();
    let visualComplexity = 15; // Base visual accessibility burden
    
    // Color dependency indicators (higher complexity for Deaf users)
    if (text.includes('color') || text.includes('highlight') || text.includes('theme')) visualComplexity += 10;
    if (text.includes('red') || text.includes('green') || text.includes('blue')) visualComplexity += 8;
    
    // Text-heavy interfaces
    if (text.includes('text') || text.includes('paragraph') || text.includes('article')) visualComplexity += 12;
    if (text.includes('reading') || text.includes('comprehension')) visualComplexity += 15;
    
    // Video/audio content that needs visual alternatives
    if (text.includes('video') || text.includes('audio') || text.includes('sound')) visualComplexity += 20;
    if (text.includes('podcast') || text.includes('webinar') || text.includes('meeting')) visualComplexity += 18;
    
    // Positive indicators (reduces complexity)
    if (text.includes('visual') || text.includes('icon') || text.includes('gesture')) visualComplexity -= 5;
    if (text.includes('asl') || text.includes('sign language') || text.includes('caption')) visualComplexity -= 10;
    if (text.includes('accessible') || text.includes('inclusive')) visualComplexity -= 8;
    
    return Math.max(5, Math.min(75, visualComplexity));
  }

  private assessLanguageComplexity(description: string): number {
    const text = description.toLowerCase();
    let languageComplexity = 25; // Base language complexity
    
    // Flesch-Kincaid-inspired complexity scoring
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const words = text.split(/\s+/).filter(w => w.length > 0);
    const avgWordsPerSentence = sentences.length > 0 ? words.length / sentences.length : 0;
    
    // Sentence complexity scoring
    if (avgWordsPerSentence > 20) languageComplexity += 15;
    else if (avgWordsPerSentence > 15) languageComplexity += 10;
    else if (avgWordsPerSentence > 10) languageComplexity += 5;
    
    // Complex vocabulary indicators
    if (text.includes('utilize') || text.includes('facilitate') || text.includes('implement')) languageComplexity += 8;
    if (text.includes('methodology') || text.includes('paradigm') || text.includes('framework')) languageComplexity += 10;
    
    // Technical jargon
    if (text.includes('api') || text.includes('database') || text.includes('algorithm')) languageComplexity += 12;
    if (text.includes('authentication') || text.includes('encryption') || text.includes('protocol')) languageComplexity += 15;
    
    // ASL-friendly indicators (reduces complexity)
    if (text.includes('simple') || text.includes('clear') || text.includes('direct')) languageComplexity -= 5;
    if (text.includes('visual') || text.includes('picture') || text.includes('diagram')) languageComplexity -= 8;
    
    return Math.max(10, Math.min(70, languageComplexity));
  }

  private calculateWorkflowComplexity(technologies: string[]): number {
    const gestureComplexityMap: Record<string, number> = {
      // Gesture-friendly technologies (lower complexity)
      'touch': 5, 'mobile': 8, 'tablet': 8, 'ios': 10, 'android': 10,
      'react native': 12, 'flutter': 15,
      
      // Standard web technologies
      'html': 15, 'css': 18, 'javascript': 20, 'react': 25,
      'vue': 22, 'angular': 30,
      
      // Complex interaction technologies
      'webrtc': 40, 'websocket': 35, 'three.js': 45,
      'canvas': 35, 'webgl': 50,
      
      // Backend complexity for Deaf users
      'api': 20, 'rest': 18, 'graphql': 25,
      'microservices': 35, 'serverless': 30
    };

    if (technologies.length === 0) return 20;

    const totalComplexity = technologies.reduce((sum, tech) => {
      return sum + (gestureComplexityMap[tech.toLowerCase()] || 20);
    }, 0);

    return Math.min(60, totalComplexity / technologies.length);
  }

  private analyzeRequirements(requirements: string): number {
    const text = requirements.toLowerCase();
    let complexity = 20; // Base

    // Authentication complexity
    if (text.includes('auth') || text.includes('login')) complexity += 15;
    if (text.includes('oauth') || text.includes('sso')) complexity += 10;
    
    // Data complexity
    if (text.includes('database') || text.includes('crud')) complexity += 10;
    if (text.includes('migration') || text.includes('schema')) complexity += 15;
    
    // Integration complexity
    if (text.includes('api') || text.includes('integration')) complexity += 10;
    if (text.includes('webhook') || text.includes('third-party')) complexity += 15;
    
    // Real-time features
    if (text.includes('real-time') || text.includes('websocket')) complexity += 20;
    if (text.includes('notification') || text.includes('push')) complexity += 15;
    
    // Security requirements
    if (text.includes('security') || text.includes('encryption')) complexity += 20;
    if (text.includes('compliance') || text.includes('gdpr')) complexity += 25;
    
    // Performance requirements
    if (text.includes('scale') || text.includes('performance')) complexity += 15;
    if (text.includes('load balancing') || text.includes('caching')) complexity += 20;

    return Math.min(90, complexity);
  }

  private assessProjectScope(description: string): number {
    const text = description.toLowerCase();
    let scope = 25; // Base scope

    // Feature count estimation
    const featureKeywords = [
      'dashboard', 'admin', 'report', 'analytics', 'search',
      'upload', 'download', 'export', 'import', 'payment',
      'chat', 'messaging', 'notification', 'email'
    ];

    const featureCount = featureKeywords.filter(keyword => 
      text.includes(keyword)
    ).length;

    scope += featureCount * 5;

    // Complexity indicators
    if (text.includes('complex') || text.includes('advanced')) scope += 15;
    if (text.includes('simple') || text.includes('basic')) scope -= 10;
    if (text.includes('enterprise') || text.includes('scalable')) scope += 20;
    if (text.includes('mvp') || text.includes('prototype')) scope -= 15;

    return Math.min(85, Math.max(10, scope));
  }

  private calculateIntegrationComplexity(technologies: string[]): number {
    let integrationScore = 15; // Base

    // Database integrations
    const databases = ['PostgreSQL', 'MySQL', 'MongoDB', 'Redis'];
    const dbCount = technologies.filter(tech => databases.includes(tech)).length;
    integrationScore += dbCount * 8;

    // Cloud services
    const cloudServices = ['AWS', 'Google Cloud', 'Azure', 'Vercel', 'Netlify'];
    const cloudCount = technologies.filter(tech => cloudServices.includes(tech)).length;
    integrationScore += cloudCount * 10;

    // External APIs
    const apiServices = ['OpenAI', 'Stripe', 'Twilio', 'SendGrid'];
    const apiCount = technologies.filter(tech => apiServices.includes(tech)).length;
    integrationScore += apiCount * 12;

    return Math.min(75, integrationScore);
  }

  private calculateConfidence(factors: any): number {
    // Confidence based on data completeness and factor consistency
    const factorValues = Object.values(factors) as number[];
    const variance = this.calculateVariance(factorValues);
    
    // Lower variance = higher confidence
    const baseConfidence = 85;
    const variancePenalty = Math.min(30, variance / 2);
    
    return Math.round(Math.max(50, baseConfidence - variancePenalty));
  }

  private calculateVariance(values: number[]): number {
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const squaredDiffs = values.map(value => Math.pow(value - mean, 2));
    return squaredDiffs.reduce((a, b) => a + b, 0) / values.length;
  }

  private estimateHours(complexityScore: number, factors: any): number {
    // Base hours calculation using neural network inspired formula
    const baseHours = complexityScore * 1.5;
    
    // Technology multiplier
    const avgTechComplexity = factors.technologyComplexity;
    const techMultiplier = 1 + (avgTechComplexity - 30) / 100;
    
    // Requirements multiplier
    const reqMultiplier = 1 + (factors.requirementsComplexity - 30) / 150;
    
    const estimatedHours = baseHours * techMultiplier * reqMultiplier;
    
    return Math.round(Math.max(8, Math.min(500, estimatedHours)));
  }

  private identifyRiskFactors(factors: any): string[] {
    const risks: string[] = [];
    
    if (factors.cognitiveLoad > 50) {
      risks.push('High cognitive load may overwhelm Deaf users requiring visual processing');
    }
    
    if (factors.visualAccessibility > 45) {
      risks.push('Complex visual elements may create barriers for sign language users');
    }
    
    if (factors.languageComplexity > 50) {
      risks.push('Complex language patterns may not translate well to ASL structure');
    }
    
    if (factors.workflowComplexity > 40) {
      risks.push('Multi-step workflows may be difficult to navigate with gesture-based interaction');
    }
    
    if (factors.cognitiveLoad > 40 && factors.visualAccessibility > 40) {
      risks.push('Combined cognitive and visual complexity creates significant accessibility barriers');
    }
    
    return risks;
  }

  private generateRecommendations(factors: any): string[] {
    const recommendations: string[] = [];
    
    if (factors.cognitiveLoad > 35) {
      recommendations.push('Implement progressive disclosure to reduce cognitive burden');
      recommendations.push('Add visual hierarchy and clear information grouping');
    }
    
    if (factors.visualAccessibility > 35) {
      recommendations.push('Ensure strong visual contrast and clear iconography');
      recommendations.push('Implement gesture-friendly navigation patterns');
      recommendations.push('Add visual indicators for all audio content');
    }
    
    if (factors.languageComplexity > 40) {
      recommendations.push('Simplify language to ASL-compatible sentence structures');
      recommendations.push('Add visual glossaries for technical terms');
      recommendations.push('Consider bilingual ASL video explanations');
    }
    
    if (factors.workflowComplexity > 30) {
      recommendations.push('Design single-handed gesture navigation options');
      recommendations.push('Implement clear visual progress indicators');
      recommendations.push('Add contextual help with visual demonstrations');
    }
    
    if (factors.cognitiveLoad > 25 || factors.visualAccessibility > 25) {
      recommendations.push('Consider integration with ASL interpretation services');
      recommendations.push('Implement customizable interface complexity levels');
    }
    
    return recommendations;
  }

  public async generateTaskBreakdown(projectData: any, analysis: any): Promise<any[]> {
    const tasks = [];
    const complexity = analysis.complexityScore;
    
    // Core development tasks based on complexity
    const coreTasks = [
      {
        title: 'Project Setup and Configuration',
        category: 'setup',
        estimatedHours: Math.max(4, Math.round(complexity * 0.05)),
        complexity: Math.min(10, Math.max(3, Math.round(complexity * 0.1)))
      },
      {
        title: 'Database Design and Setup',
        category: 'database',
        estimatedHours: Math.max(6, Math.round(complexity * 0.08)),
        complexity: Math.min(10, Math.max(4, Math.round(complexity * 0.12)))
      },
      {
        title: 'Core Backend Development',
        category: 'backend',
        estimatedHours: Math.max(12, Math.round(complexity * 0.15)),
        complexity: Math.min(10, Math.max(5, Math.round(complexity * 0.15)))
      },
      {
        title: 'Frontend Development',
        category: 'frontend',
        estimatedHours: Math.max(10, Math.round(complexity * 0.12)),
        complexity: Math.min(10, Math.max(4, Math.round(complexity * 0.13)))
      },
      {
        title: 'Testing and Quality Assurance',
        category: 'testing',
        estimatedHours: Math.max(8, Math.round(complexity * 0.1)),
        complexity: Math.min(10, Math.max(3, Math.round(complexity * 0.08)))
      },
      {
        title: 'Deployment and DevOps',
        category: 'deployment',
        estimatedHours: Math.max(4, Math.round(complexity * 0.06)),
        complexity: Math.min(10, Math.max(3, Math.round(complexity * 0.09)))
      }
    ];

    // Add conditional tasks based on requirements
    const requirements = (projectData.requirements || '').toLowerCase();
    
    if (requirements.includes('auth') || requirements.includes('login')) {
      coreTasks.push({
        title: 'Authentication System',
        category: 'backend',
        estimatedHours: Math.max(6, Math.round(complexity * 0.08)),
        complexity: Math.min(10, Math.max(4, Math.round(complexity * 0.1)))
      });
    }
    
    if (requirements.includes('api') || requirements.includes('integration')) {
      coreTasks.push({
        title: 'API Integration',
        category: 'integration',
        estimatedHours: Math.max(8, Math.round(complexity * 0.1)),
        complexity: Math.min(10, Math.max(5, Math.round(complexity * 0.12)))
      });
    }

    return coreTasks.map((task, index) => ({
      ...task,
      description: `Implement ${task.title.toLowerCase()} for the project`,
      dependencies: index > 0 ? [index - 1] : [],
      status: 'pending'
    }));
  }
}

const neuralEstimator = new NeuralComplexityEstimator();

// Get all project templates
router.get('/templates', async (req, res) => {
  try {
    const templates = await storage.getAllProjectTemplates();
    res.json(templates);
  } catch (error) {
    console.error('Error fetching templates:', error);
    res.status(500).json({ error: 'Failed to fetch templates' });
  }
});

// Create new project and analyze complexity
router.post('/projects', async (req, res) => {
  try {
    const userId = 1; // For demo - in real app would come from auth
    
    const projectData = insertProjectSchema.parse({
      ...req.body,
      userId
    });

    // Create project
    const project = await storage.createProject(projectData);

    // Generate neural complexity analysis
    const analysisResult = neuralEstimator.analyzeProjectComplexity({
      technologies: project.technologies,
      requirements: project.requirements,
      description: project.description
    });

    // Save complexity analysis
    const analysis = await storage.createComplexityAnalysis({
      projectId: project.id,
      analysisType: 'initial',
      inputData: {
        technologies: project.technologies,
        requirements: project.requirements,
        description: project.description
      },
      complexityBreakdown: analysisResult.breakdown,
      estimatedTimeBreakdown: {
        totalHours: analysisResult.estimatedHours,
        breakdown: analysisResult.breakdown
      },
      riskFactors: analysisResult.riskFactors,
      recommendations: analysisResult.recommendations,
      confidence: analysisResult.confidence,
      modelVersion: '1.0'
    });

    // Update project with estimated hours
    const updatedProject = await storage.updateProject(project.id, {
      estimatedHours: analysisResult.estimatedHours
    });

    // Generate task breakdown
    const tasks = await neuralEstimator.generateTaskBreakdown(project, analysisResult);
    
    // Save tasks
    const createdTasks = [];
    for (const taskData of tasks) {
      const task = await storage.createTask({
        projectId: project.id,
        analysisId: analysis.id,
        ...taskData
      });
      createdTasks.push(task);
    }

    res.json({
      project: updatedProject,
      analysis,
      tasks: createdTasks
    });
  } catch (error) {
    console.error('Error creating project:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Invalid input data', details: error.errors });
    }
    res.status(500).json({ error: 'Failed to create project' });
  }
});

// Get user's projects
router.get('/projects', async (req, res) => {
  try {
    const userId = 1; // For demo
    const projects = await storage.getProjectsByUserId(userId);
    res.json(projects);
  } catch (error) {
    console.error('Error fetching projects:', error);
    res.status(500).json({ error: 'Failed to fetch projects' });
  }
});

// Get project details with analysis and tasks
router.get('/projects/:id', async (req, res) => {
  try {
    const projectId = parseInt(req.params.id);
    
    const project = await storage.getProject(projectId);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const analyses = await storage.getComplexityAnalysesByProjectId(projectId);
    const tasks = await storage.getTasksByProjectId(projectId);

    res.json({
      project,
      analyses,
      tasks
    });
  } catch (error) {
    console.error('Error fetching project:', error);
    res.status(500).json({ error: 'Failed to fetch project' });
  }
});

// Re-analyze project complexity
router.post('/projects/:id/analyze', async (req, res) => {
  try {
    const projectId = parseInt(req.params.id);
    
    const project = await storage.getProject(projectId);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Generate new analysis
    const analysisResult = neuralEstimator.analyzeProjectComplexity({
      technologies: project.technologies,
      requirements: project.requirements,
      description: project.description
    });

    // Save new analysis
    const analysis = await storage.createComplexityAnalysis({
      projectId: project.id,
      analysisType: 'updated',
      inputData: {
        technologies: project.technologies,
        requirements: project.requirements,
        description: project.description
      },
      complexityBreakdown: analysisResult.breakdown,
      estimatedTimeBreakdown: {
        totalHours: analysisResult.estimatedHours,
        breakdown: analysisResult.breakdown
      },
      riskFactors: analysisResult.riskFactors,
      recommendations: analysisResult.recommendations,
      confidence: analysisResult.confidence,
      modelVersion: '1.0'
    });

    // Update project
    await storage.updateProject(project.id, {
      estimatedHours: analysisResult.estimatedHours
    });

    res.json({
      ...analysisResult,
      analysis: analysis
    });
  } catch (error) {
    console.error('Error re-analyzing project:', error);
    res.status(500).json({ error: 'Failed to re-analyze project' });
  }
});

// Update task status
router.patch('/tasks/:id', async (req, res) => {
  try {
    const taskId = parseInt(req.params.id);
    const updates = req.body;

    const task = await storage.updateTask(taskId, updates);
    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }

    res.json(task);
  } catch (error) {
    console.error('Error updating task:', error);
    res.status(500).json({ error: 'Failed to update task' });
  }
});

export default router;