/**
 * Development Pipeline Routes
 * 
 * Provides API endpoints for automated development pipeline between
 * Replit, Vercel, GitHub, and other services.
 */

import express from 'express';
import { 
  developmentPipelineService, 
  apiGeneratorService, 
  gitIntegrationService,
  notionIntegrationService,
  xanoIntegrationService 
} from '../services';
import { logger } from '../utils/logger';

const router = express.Router();

/**
 * Get all development pipelines
 */
router.get('/pipelines', (req, res) => {
  try {
    const pipelines = developmentPipelineService.getAllPipelines();
    res.json({ success: true, pipelines });
  } catch (error) {
    logger.error('Error getting pipelines', error);
    res.status(500).json({ success: false, error: 'Failed to get pipelines' });
  }
});

/**
 * Get a specific pipeline
 */
router.get('/pipelines/:id', (req, res) => {
  try {
    const pipeline = developmentPipelineService.getPipeline(req.params.id);
    
    if (!pipeline) {
      return res.status(404).json({ success: false, error: 'Pipeline not found' });
    }
    
    res.json({ success: true, pipeline });
  } catch (error) {
    logger.error(`Error getting pipeline ${req.params.id}`, error);
    res.status(500).json({ success: false, error: 'Failed to get pipeline' });
  }
});

/**
 * Create a new development pipeline
 */
router.post('/pipelines', async (req, res) => {
  try {
    const pipelineData = req.body;
    
    // Validate request
    if (!pipelineData.name) {
      return res.status(400).json({ success: false, error: 'Pipeline name is required' });
    }
    
    // Create pipeline
    const pipelineId = await developmentPipelineService.createPipeline({
      name: pipelineData.name,
      description: pipelineData.description,
      repositoryUrl: pipelineData.repositoryUrl,
      vercelProjectId: pipelineData.vercelProjectId,
      replitId: pipelineData.replitId,
      cursorProjectId: pipelineData.cursorProjectId,
      webhooks: pipelineData.webhooks || [],
      active: pipelineData.active !== undefined ? pipelineData.active : true
    });
    
    res.status(201).json({ 
      success: true, 
      message: 'Pipeline created successfully',
      pipelineId
    });
  } catch (error) {
    logger.error('Error creating pipeline', error);
    res.status(500).json({ success: false, error: 'Failed to create pipeline' });
  }
});

/**
 * Update a pipeline
 */
router.put('/pipelines/:id', (req, res) => {
  try {
    const pipelineId = req.params.id;
    const updates = req.body;
    
    const success = developmentPipelineService.updatePipeline(pipelineId, updates);
    
    if (!success) {
      return res.status(404).json({ success: false, error: 'Pipeline not found' });
    }
    
    res.json({ 
      success: true, 
      message: 'Pipeline updated successfully' 
    });
  } catch (error) {
    logger.error(`Error updating pipeline ${req.params.id}`, error);
    res.status(500).json({ success: false, error: 'Failed to update pipeline' });
  }
});

/**
 * Delete a pipeline
 */
router.delete('/pipelines/:id', (req, res) => {
  try {
    const pipelineId = req.params.id;
    
    const success = developmentPipelineService.deletePipeline(pipelineId);
    
    if (!success) {
      return res.status(404).json({ success: false, error: 'Pipeline not found' });
    }
    
    res.json({ 
      success: true, 
      message: 'Pipeline deleted successfully' 
    });
  } catch (error) {
    logger.error(`Error deleting pipeline ${req.params.id}`, error);
    res.status(500).json({ success: false, error: 'Failed to delete pipeline' });
  }
});

/**
 * Start a pipeline run
 */
router.post('/pipelines/:id/runs', async (req, res) => {
  try {
    const pipelineId = req.params.id;
    const options = req.body;
    
    const runId = await developmentPipelineService.startPipelineRun(
      pipelineId, 
      { 
        trigger: options.trigger || 'manual' 
      }
    );
    
    if (!runId) {
      return res.status(400).json({ success: false, error: 'Failed to start pipeline run' });
    }
    
    res.status(201).json({ 
      success: true, 
      message: 'Pipeline run started successfully',
      runId
    });
  } catch (error) {
    logger.error(`Error starting pipeline run for ${req.params.id}`, error);
    res.status(500).json({ success: false, error: 'Failed to start pipeline run' });
  }
});

/**
 * Get all runs for a pipeline
 */
router.get('/pipelines/:id/runs', (req, res) => {
  try {
    const pipelineId = req.params.id;
    
    const runs = developmentPipelineService.getPipelineRuns(pipelineId);
    
    res.json({ success: true, runs });
  } catch (error) {
    logger.error(`Error getting runs for pipeline ${req.params.id}`, error);
    res.status(500).json({ success: false, error: 'Failed to get pipeline runs' });
  }
});

/**
 * Get a specific pipeline run
 */
router.get('/runs/:runId', (req, res) => {
  try {
    const runId = req.params.runId;
    
    const run = developmentPipelineService.getPipelineRun(runId);
    
    if (!run) {
      return res.status(404).json({ success: false, error: 'Pipeline run not found' });
    }
    
    res.json({ success: true, run });
  } catch (error) {
    logger.error(`Error getting pipeline run ${req.params.runId}`, error);
    res.status(500).json({ success: false, error: 'Failed to get pipeline run' });
  }
});

/**
 * Get all API specifications
 */
router.get('/api-specs', (req, res) => {
  try {
    const specs = apiGeneratorService.getSpecs();
    res.json({ success: true, specs });
  } catch (error) {
    logger.error('Error getting API specs', error);
    res.status(500).json({ success: false, error: 'Failed to get API specs' });
  }
});

/**
 * Create a new API specification
 */
router.post('/api-specs', (req, res) => {
  try {
    const specData = req.body;
    
    // Validate request
    if (!specData.name || !specData.version) {
      return res.status(400).json({ 
        success: false, 
        error: 'API spec name and version are required' 
      });
    }
    
    // Create specification
    const specId = apiGeneratorService.createSpec({
      name: specData.name,
      description: specData.description,
      version: specData.version,
      endpoints: specData.endpoints || [],
      models: specData.models || [],
      webhooks: specData.webhooks || [],
      security: specData.security
    });
    
    res.status(201).json({ 
      success: true, 
      message: 'API specification created successfully',
      specId
    });
  } catch (error) {
    logger.error('Error creating API spec', error);
    res.status(500).json({ success: false, error: 'Failed to create API spec' });
  }
});

/**
 * Generate OpenAPI specification
 */
router.get('/api-specs/:id/openapi', (req, res) => {
  try {
    const specId = req.params.id;
    
    const openApiSpec = apiGeneratorService.generateOpenApiSpec(specId);
    
    res.json(openApiSpec);
  } catch (error) {
    logger.error(`Error generating OpenAPI spec for ${req.params.id}`, error);
    res.status(500).json({ success: false, error: 'Failed to generate OpenAPI spec' });
  }
});

/**
 * Generate code for an API specification
 */
router.post('/api-specs/:id/generate-code', async (req, res) => {
  try {
    const specId = req.params.id;
    const options = req.body;
    
    const outputPath = await apiGeneratorService.generateCode(specId, options);
    
    res.json({ 
      success: true, 
      message: 'Code generated successfully',
      outputPath
    });
  } catch (error) {
    logger.error(`Error generating code for API spec ${req.params.id}`, error);
    res.status(500).json({ success: false, error: 'Failed to generate code' });
  }
});

/**
 * Generate Xano API
 */
router.post('/api-specs/:id/generate-xano', async (req, res) => {
  try {
    const specId = req.params.id;
    const { connectionId, deploy } = req.body;
    
    if (!connectionId) {
      return res.status(400).json({ 
        success: false, 
        error: 'Xano connection ID is required' 
      });
    }
    
    const success = await apiGeneratorService.generateXanoApi(
      specId, 
      connectionId, 
      deploy
    );
    
    if (!success) {
      return res.status(400).json({ 
        success: false, 
        error: 'Failed to generate Xano API' 
      });
    }
    
    res.json({ 
      success: true, 
      message: 'Xano API generated successfully' 
    });
  } catch (error) {
    logger.error(`Error generating Xano API for spec ${req.params.id}`, error);
    res.status(500).json({ success: false, error: 'Failed to generate Xano API' });
  }
});

/**
 * Generate webhooks for an API specification
 */
router.post('/api-specs/:id/generate-webhooks', async (req, res) => {
  try {
    const specId = req.params.id;
    
    const webhookIds = await apiGeneratorService.generateWebhooks(specId);
    
    res.json({ 
      success: true, 
      message: `Generated ${webhookIds.length} webhooks successfully`,
      webhookIds
    });
  } catch (error) {
    logger.error(`Error generating webhooks for API spec ${req.params.id}`, error);
    res.status(500).json({ success: false, error: 'Failed to generate webhooks' });
  }
});

/**
 * Deploy API code to Git
 */
router.post('/api-specs/:id/deploy-to-git', async (req, res) => {
  try {
    const specId = req.params.id;
    const { repositoryId, branch, options } = req.body;
    
    if (!repositoryId) {
      return res.status(400).json({ 
        success: false, 
        error: 'Repository ID is required' 
      });
    }
    
    const success = await apiGeneratorService.deployToGit(
      specId,
      repositoryId,
      branch || 'main',
      options
    );
    
    if (!success) {
      return res.status(400).json({ 
        success: false, 
        error: 'Failed to deploy API code to Git' 
      });
    }
    
    res.json({ 
      success: true, 
      message: 'API code deployed to Git successfully' 
    });
  } catch (error) {
    logger.error(`Error deploying API code for spec ${req.params.id} to Git`, error);
    res.status(500).json({ success: false, error: 'Failed to deploy API code to Git' });
  }
});

/**
 * Automated full-stack development pipeline
 */
router.post('/full-stack-pipeline', async (req, res) => {
  try {
    const {
      name,
      description,
      apiSpec,
      repositoryConfig,
      deploymentConfig,
      webhookConfig
    } = req.body;
    
    // Validate request
    if (!name || !apiSpec || !apiSpec.name) {
      return res.status(400).json({ 
        success: false, 
        error: 'Name and API specification details are required' 
      });
    }
    
    // 1. Create a development pipeline
    const pipelineId = await developmentPipelineService.createPipeline({
      name,
      description,
      repositoryUrl: repositoryConfig?.url,
      vercelProjectId: deploymentConfig?.vercelProjectId,
      replitId: deploymentConfig?.replitId,
      webhooks: webhookConfig?.webhooks || [],
      active: true
    });
    
    // 2. Create an API specification
    const specId = apiGeneratorService.createSpec({
      name: apiSpec.name,
      description: apiSpec.description,
      version: apiSpec.version || '1.0.0',
      endpoints: apiSpec.endpoints || [],
      models: apiSpec.models || [],
      webhooks: apiSpec.webhooks || [],
      security: apiSpec.security
    });
    
    // 3. Generate API code
    const outputPath = await apiGeneratorService.generateCode(specId, {
      framework: apiSpec.framework || 'express',
      language: apiSpec.language || 'typescript'
    });
    
    // 4. Generate webhooks if needed
    let webhookIds: string[] = [];
    if (apiSpec.webhooks && apiSpec.webhooks.length > 0) {
      webhookIds = await apiGeneratorService.generateWebhooks(specId);
    }
    
    // 5. Deploy to Git if repository config is provided
    let gitDeployment = false;
    if (repositoryConfig && repositoryConfig.id) {
      gitDeployment = await apiGeneratorService.deployToGit(
        specId,
        repositoryConfig.id,
        repositoryConfig.branch || 'main'
      );
    }
    
    // 6. Start the pipeline run
    const runId = await developmentPipelineService.startPipelineRun(pipelineId);
    
    res.status(201).json({
      success: true,
      message: 'Full-stack development pipeline created and started successfully',
      pipelineId,
      specId,
      webhookIds,
      runId,
      gitDeployment
    });
  } catch (error) {
    logger.error('Error creating full-stack development pipeline', error);
    res.status(500).json({ success: false, error: 'Failed to create full-stack pipeline' });
  }
});

export default router;