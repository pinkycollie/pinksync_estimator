import { Router } from 'express';
import { z } from 'zod';
import { spawn } from 'child_process';
import { promises as fs } from 'fs';
import path from 'path';

const router = Router();

// Neural Complexity Estimator - Deaf-first cognitive modeling
class DeafFirstNeuralEstimator {
  analyzeComplexity(input: {
    title: string;
    description: string;
    content?: string;
    domain?: string;
  }) {
    const textContent = `${input.title} ${input.description} ${input.content || ''}`;
    
    // Cognitive load analysis (Deaf-specific)
    const cognitiveLoad = this.calculateCognitiveLoad(textContent, input.domain);
    
    // Visual accessibility analysis
    const visualAccessibility = this.calculateVisualAccessibility(textContent);
    
    // Language complexity (ASL compatibility)
    const languageComplexity = this.calculateLanguageComplexity(textContent);
    
    // Workflow complexity
    const workflowComplexity = this.calculateWorkflowComplexity(textContent, input.domain);
    
    return {
      cognitiveLoad,
      visualAccessibility,
      languageComplexity,
      workflowComplexity,
      overallScore: Math.round((cognitiveLoad + visualAccessibility + languageComplexity + workflowComplexity) / 4),
      recommendations: this.generateRecommendations(cognitiveLoad, visualAccessibility, languageComplexity, workflowComplexity),
      riskFactors: this.identifyRiskFactors(cognitiveLoad, visualAccessibility, languageComplexity, workflowComplexity)
    };
  }

  private calculateCognitiveLoad(text: string, domain?: string): number {
    let score = 20;
    
    // Text length factor
    const wordCount = text.split(/\s+/).length;
    if (wordCount > 500) score += 25;
    else if (wordCount > 200) score += 15;
    else if (wordCount > 100) score += 10;
    
    // Complex terminology (higher impact for Deaf users)
    const complexTerms = text.match(/\b(algorithm|implementation|architecture|infrastructure|methodology)\b/gi);
    if (complexTerms) score += complexTerms.length * 3;
    
    // Domain-specific complexity
    if (domain === 'legal') score += 20;
    else if (domain === 'technical') score += 15;
    else if (domain === 'medical') score += 18;
    
    // Sequential processing requirements
    const sequentialIndicators = text.match(/\b(first|then|next|finally|step|process|procedure)\b/gi);
    if (sequentialIndicators && sequentialIndicators.length > 5) score += 10;
    
    return Math.min(100, score);
  }

  private calculateVisualAccessibility(text: string): number {
    let score = 10;
    
    // Visual dependency indicators
    const visualTerms = text.match(/\b(see|look|observe|visual|diagram|chart|image)\b/gi);
    if (visualTerms) score += visualTerms.length * 2;
    
    // Color references (accessibility concern)
    const colorTerms = text.match(/\b(red|green|blue|yellow|color|highlight)\b/gi);
    if (colorTerms) score += colorTerms.length * 3;
    
    // Spatial references
    const spatialTerms = text.match(/\b(above|below|left|right|top|bottom|side)\b/gi);
    if (spatialTerms) score += spatialTerms.length * 2;
    
    return Math.min(100, score);
  }

  private calculateLanguageComplexity(text: string): number {
    let score = 15;
    
    // Sentence length (critical for ASL users)
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const avgSentenceLength = sentences.reduce((sum, s) => sum + s.split(/\s+/).length, 0) / sentences.length;
    
    if (avgSentenceLength > 25) score += 20;
    else if (avgSentenceLength > 15) score += 10;
    
    // Passive voice (harder for ASL users)
    const passiveIndicators = text.match(/\b(was|were|been|being)\s+\w+ed\b/gi);
    if (passiveIndicators) score += passiveIndicators.length * 2;
    
    // Abstract concepts
    const abstractTerms = text.match(/\b(concept|theory|principle|framework|paradigm)\b/gi);
    if (abstractTerms) score += abstractTerms.length * 3;
    
    // Negatives (processing complexity)
    const negatives = text.match(/\b(not|no|never|nothing|none|neither)\b/gi);
    if (negatives) score += negatives.length;
    
    return Math.min(100, score);
  }

  private calculateWorkflowComplexity(text: string, domain?: string): number {
    let score = 5;
    
    // Multi-step processes
    const stepIndicators = text.match(/\b(step|phase|stage|part|section)\b/gi);
    if (stepIndicators) score += stepIndicators.length * 2;
    
    // Decision points
    const decisionIndicators = text.match(/\b(if|when|unless|choose|select|decide)\b/gi);
    if (decisionIndicators) score += decisionIndicators.length * 3;
    
    // Time pressure indicators
    const urgencyIndicators = text.match(/\b(urgent|immediate|asap|deadline|time-sensitive)\b/gi);
    if (urgencyIndicators) score += urgencyIndicators.length * 4;
    
    // Coordination requirements
    const coordinationTerms = text.match(/\b(team|collaborate|coordinate|meeting|discussion)\b/gi);
    if (coordinationTerms) score += coordinationTerms.length * 2;
    
    return Math.min(100, score);
  }

  private generateRecommendations(cognitive: number, visual: number, language: number, workflow: number): string[] {
    const recommendations = [];
    
    if (cognitive > 50) {
      recommendations.push("Break content into smaller, digestible sections");
      recommendations.push("Provide ASL-friendly summaries for complex concepts");
    }
    
    if (visual > 30) {
      recommendations.push("Ensure all visual information has text alternatives");
      recommendations.push("Use high contrast and clear visual hierarchy");
    }
    
    if (language > 40) {
      recommendations.push("Simplify sentence structure for ASL compatibility");
      recommendations.push("Use active voice and concrete examples");
    }
    
    if (workflow > 25) {
      recommendations.push("Create step-by-step visual guides");
      recommendations.push("Allow flexible pacing for each workflow stage");
    }
    
    return recommendations;
  }

  private identifyRiskFactors(cognitive: number, visual: number, language: number, workflow: number): string[] {
    const risks = [];
    
    if (cognitive > 60) risks.push("High cognitive load may overwhelm Deaf users");
    if (visual > 40) risks.push("Visual dependency creates accessibility barriers");
    if (language > 50) risks.push("Complex language structure incompatible with ASL");
    if (workflow > 35) risks.push("Workflow complexity may cause task abandonment");
    
    return risks;
  }
}

const estimator = new DeafFirstNeuralEstimator();

// Project discovery endpoint
router.get('/scan-projects', async (req, res) => {
  try {
    const pythonScript = path.join(process.cwd(), 'python-worker', 'project_scanner.py');
    
    // Run Python scanner
    const scanProcess = spawn('python', [pythonScript], {
      cwd: path.join(process.cwd(), 'python-worker')
    });
    
    let stdout = '';
    let stderr = '';
    
    scanProcess.stdout.on('data', (data) => {
      stdout += data.toString();
    });
    
    scanProcess.stderr.on('data', (data) => {
      stderr += data.toString();
    });
    
    scanProcess.on('close', async (code) => {
      if (code === 0) {
        try {
          // Read scan results
          const resultsPath = path.join(process.cwd(), 'python-worker', 'project_scan_results.json');
          const resultsData = await fs.readFile(resultsPath, 'utf8');
          const scanResults = JSON.parse(resultsData);
          
          res.json({
            success: true,
            scan_output: stdout,
            projects: scanResults.projects,
            complexity_report: scanResults.complexity_report,
            timestamp: scanResults.scan_timestamp
          });
        } catch (error) {
          console.error('Error reading scan results:', error);
          res.status(500).json({ error: 'Failed to read scan results' });
        }
      } else {
        console.error('Python scanner failed:', stderr);
        res.status(500).json({ error: 'Project scanning failed', details: stderr });
      }
    });
  } catch (error) {
    console.error('Scan error:', error);
    res.status(500).json({ error: 'Failed to start project scan' });
  }
});

// Batch analyze projects endpoint
router.post('/analyze-projects-batch', async (req, res) => {
  try {
    const { projects } = req.body;
    
    if (!projects || !Array.isArray(projects)) {
      return res.status(400).json({ error: 'Projects array is required' });
    }
    
    const results = [];
    
    for (const project of projects) {
      const analysis = estimator.analyzeComplexity({
        title: project.name || '',
        description: project.description || '',
        content: `Project: ${project.name}. Technologies: ${project.technologies?.join(', ')}. Files: ${project.file_count}. Size: ${project.estimated_size}.`,
        domain: project.type === 'nodejs' ? 'technical' : 'general'
      });
      
      results.push({
        project_name: project.name,
        project_path: project.path,
        project_type: project.type,
        file_count: project.file_count,
        estimated_size: project.estimated_size,
        complexity_analysis: analysis,
        scan_indicators: project.complexity_indicators
      });
    }
    
    // Calculate aggregate insights
    const totalProjects = results.length;
    const avgCognitive = results.reduce((sum, r) => sum + r.complexity_analysis.cognitiveLoad, 0) / totalProjects;
    const avgVisual = results.reduce((sum, r) => sum + r.complexity_analysis.visualAccessibility, 0) / totalProjects;
    const avgLanguage = results.reduce((sum, r) => sum + r.complexity_analysis.languageComplexity, 0) / totalProjects;
    const avgWorkflow = results.reduce((sum, r) => sum + r.complexity_analysis.workflowComplexity, 0) / totalProjects;
    
    const highComplexityProjects = results.filter(r => r.complexity_analysis.overallScore > 60);
    
    res.json({
      success: true,
      total_projects: totalProjects,
      analysis_results: results,
      aggregate_insights: {
        average_cognitive_load: Math.round(avgCognitive),
        average_visual_accessibility: Math.round(avgVisual),
        average_language_complexity: Math.round(avgLanguage),
        average_workflow_complexity: Math.round(avgWorkflow),
        high_complexity_projects: highComplexityProjects.length,
        complexity_distribution: {
          low: results.filter(r => r.complexity_analysis.overallScore < 40).length,
          medium: results.filter(r => r.complexity_analysis.overallScore >= 40 && r.complexity_analysis.overallScore < 70).length,
          high: results.filter(r => r.complexity_analysis.overallScore >= 70).length
        }
      },
      deaf_accessibility_recommendations: [
        ...new Set(results.flatMap(r => r.complexity_analysis.recommendations))
      ].slice(0, 10)
    });
  } catch (error) {
    console.error('Batch analysis error:', error);
    res.status(500).json({ error: 'Batch analysis failed' });
  }
});

// GitHub repository discovery endpoint
router.get('/github-repositories', async (req, res) => {
  try {
    const { username, org } = req.query;
    
    const pythonScript = path.join(process.cwd(), 'python-worker', 'github_sync.py');
    
    const syncProcess = spawn('python', [pythonScript], {
      cwd: path.join(process.cwd(), 'python-worker'),
      env: { ...process.env }
    });
    
    let stdout = '';
    let stderr = '';
    
    syncProcess.stdout.on('data', (data) => {
      stdout += data.toString();
    });
    
    syncProcess.stderr.on('data', (data) => {
      stderr += data.toString();
    });
    
    syncProcess.on('close', async (code) => {
      if (code === 0) {
        try {
          const resultsPath = path.join(process.cwd(), 'python-worker', 'github_repositories.json');
          const resultsData = await fs.readFile(resultsPath, 'utf8');
          const githubResults = JSON.parse(resultsData);
          
          res.json({
            success: true,
            repositories: githubResults.repositories,
            total_repositories: githubResults.total_count,
            discovery_timestamp: githubResults.discovery_timestamp,
            sync_output: stdout
          });
        } catch (error) {
          res.json({
            success: true,
            repositories: [],
            message: 'GitHub discovery completed but no repositories file found',
            sync_output: stdout
          });
        }
      } else {
        res.status(500).json({ 
          error: 'GitHub repository discovery failed', 
          details: stderr,
          message: 'Ensure GITHUB_TOKEN environment variable is set for full functionality'
        });
      }
    });
  } catch (error) {
    console.error('GitHub sync error:', error);
    res.status(500).json({ error: 'Failed to start GitHub repository discovery' });
  }
});

// File system sync status endpoint
router.get('/sync-status', async (req, res) => {
  try {
    const syncStatusPath = path.join(process.cwd(), 'python-worker', 'sync_report.json');
    
    try {
      const statusData = await fs.readFile(syncStatusPath, 'utf8');
      const syncStatus = JSON.parse(statusData);
      
      res.json({
        success: true,
        sync_status: syncStatus,
        message: 'File system sync status retrieved'
      });
    } catch (fileError) {
      // If no sync report exists, provide basic status
      res.json({
        success: true,
        sync_status: {
          monitoring_active: false,
          last_scan_time: null,
          projects_cached: 0,
          pending_queue: 0,
          recent_changes: 0
        },
        message: 'No active sync monitoring detected'
      });
    }
  } catch (error) {
    console.error('Sync status error:', error);
    res.status(500).json({ error: 'Failed to retrieve sync status' });
  }
});

// Start file system monitoring endpoint
router.post('/start-sync-monitoring', async (req, res) => {
  try {
    const pythonScript = path.join(process.cwd(), 'python-worker', 'file_system_sync.py');
    
    // Start file system monitoring in background
    const syncProcess = spawn('python', [pythonScript], {
      cwd: path.join(process.cwd(), 'python-worker'),
      detached: true,
      stdio: 'ignore'
    });
    
    syncProcess.unref(); // Allow process to continue independently
    
    res.json({
      success: true,
      message: 'File system monitoring started',
      process_id: syncProcess.pid
    });
  } catch (error) {
    console.error('Start sync monitoring error:', error);
    res.status(500).json({ error: 'Failed to start file system monitoring' });
  }
});

// Analyze complexity endpoint
router.post('/analyze-complexity', (req, res) => {
  try {
    const { title, description, content, domain } = req.body;
    
    if (!title && !description && !content) {
      return res.status(400).json({ error: 'At least one of title, description, or content is required' });
    }
    
    const analysis = estimator.analyzeComplexity({
      title: title || '',
      description: description || '',
      content: content || '',
      domain: domain || 'general'
    });
    
    res.json({
      success: true,
      analysis,
      timestamp: new Date().toISOString(),
      version: '1.0.0'
    });
  } catch (error) {
    console.error('Analysis error:', error);
    res.status(500).json({ error: 'Analysis failed' });
  }
});

export default router;