#!/usr/bin/env python3
"""
GitHub Sync for Neural Complexity Estimator
Automated repository syncing and project discovery from GitHub sources
"""

import os
import json
import subprocess
import requests
from typing import Dict, List, Optional
from pathlib import Path
from datetime import datetime
import tempfile
import shutil

class GitHubSync:
    def __init__(self, github_token: Optional[str] = None):
        self.github_token = github_token or os.getenv('GITHUB_TOKEN')
        self.base_url = 'https://api.github.com'
        self.workspace_path = Path('/home/runner/workspace')
        self.sync_log = []
        
    def discover_repositories(self, username: str = None, org: str = None) -> List[Dict]:
        """Discover repositories for complexity analysis"""
        if not self.github_token:
            raise ValueError("GitHub token required for repository discovery")
        
        headers = {
            'Authorization': f'token {self.github_token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        repositories = []
        
        # Get user repositories
        if username:
            url = f"{self.base_url}/users/{username}/repos"
            repos = self._fetch_repositories(url, headers)
            repositories.extend(repos)
        
        # Get organization repositories
        if org:
            url = f"{self.base_url}/orgs/{org}/repos"
            repos = self._fetch_repositories(url, headers)
            repositories.extend(repos)
        
        # Get authenticated user's repositories if no specific user/org
        if not username and not org:
            url = f"{self.base_url}/user/repos"
            repos = self._fetch_repositories(url, headers)
            repositories.extend(repos)
        
        return self._analyze_repositories(repositories)
    
    def _fetch_repositories(self, url: str, headers: Dict) -> List[Dict]:
        """Fetch repositories from GitHub API with pagination"""
        repositories = []
        page = 1
        
        while True:
            response = requests.get(f"{url}?page={page}&per_page=100", headers=headers)
            
            if response.status_code != 200:
                print(f"Error fetching repositories: {response.status_code}")
                break
            
            page_repos = response.json()
            if not page_repos:
                break
            
            repositories.extend(page_repos)
            page += 1
        
        return repositories
    
    def _analyze_repositories(self, repositories: List[Dict]) -> List[Dict]:
        """Analyze repositories for Neural Complexity Estimator metrics"""
        analyzed_repos = []
        
        for repo in repositories:
            if repo.get('fork', False):
                continue  # Skip forks for now
            
            analysis = {
                'name': repo['name'],
                'full_name': repo['full_name'],
                'description': repo.get('description', ''),
                'language': repo.get('language', 'unknown'),
                'size': repo.get('size', 0),
                'stars': repo.get('stargazers_count', 0),
                'forks': repo.get('forks_count', 0),
                'open_issues': repo.get('open_issues_count', 0),
                'created_at': repo.get('created_at'),
                'updated_at': repo.get('updated_at'),
                'clone_url': repo.get('clone_url'),
                'ssh_url': repo.get('ssh_url'),
                'topics': repo.get('topics', []),
                'complexity_indicators': self._estimate_repo_complexity(repo),
                'accessibility_concerns': self._identify_accessibility_concerns(repo)
            }
            
            analyzed_repos.append(analysis)
        
        return analyzed_repos
    
    def _estimate_repo_complexity(self, repo: Dict) -> Dict:
        """Estimate repository complexity for Deaf-first analysis"""
        complexity = {
            'cognitive_load': 10,  # Base score
            'visual_dependency': 5,
            'language_complexity': 5,
            'workflow_complexity': 5
        }
        
        # Size-based complexity
        size = repo.get('size', 0)
        if size > 10000:  # Large repository
            complexity['cognitive_load'] += 20
            complexity['workflow_complexity'] += 15
        elif size > 1000:  # Medium repository
            complexity['cognitive_load'] += 10
            complexity['workflow_complexity'] += 8
        
        # Language-based complexity
        language = repo.get('language', '').lower()
        complex_languages = ['c++', 'rust', 'haskell', 'scala', 'assembly']
        visual_languages = ['html', 'css', 'javascript', 'typescript', 'vue', 'react']
        
        if language in complex_languages:
            complexity['cognitive_load'] += 15
            complexity['language_complexity'] += 20
        
        if language in visual_languages:
            complexity['visual_dependency'] += 15
        
        # Issue-based complexity (indicates maintenance burden)
        open_issues = repo.get('open_issues_count', 0)
        if open_issues > 50:
            complexity['workflow_complexity'] += 15
        elif open_issues > 10:
            complexity['workflow_complexity'] += 8
        
        # Topic-based complexity
        topics = repo.get('topics', [])
        complex_topics = ['machine-learning', 'ai', 'blockchain', 'cryptocurrency', 'computer-vision']
        accessibility_topics = ['accessibility', 'a11y', 'wcag', 'screen-reader', 'deaf', 'sign-language']
        
        for topic in topics:
            if topic in complex_topics:
                complexity['cognitive_load'] += 10
            if topic in accessibility_topics:
                complexity['visual_dependency'] -= 5  # Positive indicator
        
        return complexity
    
    def _identify_accessibility_concerns(self, repo: Dict) -> List[str]:
        """Identify potential accessibility concerns in repository"""
        concerns = []
        
        language = repo.get('language', '').lower()
        description = repo.get('description', '').lower()
        topics = repo.get('topics', [])
        
        # Visual-heavy technologies
        if language in ['css', 'scss', 'less'] or 'frontend' in topics:
            concerns.append("Frontend project may have visual dependencies")
        
        # Game development (often visually complex)
        if 'game' in description or 'unity' in topics or language in ['c#', 'c++']:
            concerns.append("Gaming/graphics project likely has high visual complexity")
        
        # Data visualization
        if any(term in description for term in ['chart', 'graph', 'visualization', 'dashboard']):
            concerns.append("Data visualization may not be accessible to Deaf users")
        
        # Audio/video processing
        if any(term in description for term in ['audio', 'video', 'sound', 'music']):
            concerns.append("Audio/video content needs alternative access methods")
        
        # Complex documentation
        if repo.get('size', 0) > 5000 and not any(topic in topics for topic in ['accessibility', 'a11y']):
            concerns.append("Large project may lack accessibility documentation")
        
        return concerns
    
    def sync_repository(self, repo_url: str, local_path: Optional[str] = None) -> Dict:
        """Sync a specific repository for analysis"""
        if not local_path:
            repo_name = repo_url.split('/')[-1].replace('.git', '')
            local_path = self.workspace_path / 'synced_repos' / repo_name
        
        sync_result = {
            'repo_url': repo_url,
            'local_path': str(local_path),
            'status': 'pending',
            'timestamp': datetime.now().isoformat(),
            'files_synced': 0,
            'errors': []
        }
        
        try:
            # Create local directory
            local_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Clone or pull repository
            if local_path.exists():
                # Pull latest changes
                result = subprocess.run(
                    ['git', 'pull'],
                    cwd=local_path,
                    capture_output=True,
                    text=True
                )
                
                if result.returncode == 0:
                    sync_result['status'] = 'updated'
                else:
                    sync_result['errors'].append(f"Git pull failed: {result.stderr}")
                    sync_result['status'] = 'error'
            else:
                # Clone repository
                result = subprocess.run(
                    ['git', 'clone', repo_url, str(local_path)],
                    capture_output=True,
                    text=True
                )
                
                if result.returncode == 0:
                    sync_result['status'] = 'cloned'
                else:
                    sync_result['errors'].append(f"Git clone failed: {result.stderr}")
                    sync_result['status'] = 'error'
                    return sync_result
            
            # Count synced files
            if local_path.exists():
                file_count = sum(1 for _ in local_path.rglob('*') if _.is_file())
                sync_result['files_synced'] = file_count
            
        except Exception as e:
            sync_result['errors'].append(f"Sync error: {str(e)}")
            sync_result['status'] = 'error'
        
        self.sync_log.append(sync_result)
        return sync_result
    
    def batch_sync_repositories(self, repositories: List[Dict]) -> Dict:
        """Sync multiple repositories for batch analysis"""
        sync_results = []
        
        for repo in repositories:
            if 'clone_url' in repo:
                result = self.sync_repository(repo['clone_url'])
                result['repo_name'] = repo['name']
                result['repo_language'] = repo.get('language', 'unknown')
                sync_results.append(result)
        
        summary = {
            'total_repositories': len(repositories),
            'successful_syncs': len([r for r in sync_results if r['status'] in ['cloned', 'updated']]),
            'failed_syncs': len([r for r in sync_results if r['status'] == 'error']),
            'sync_results': sync_results,
            'timestamp': datetime.now().isoformat()
        }
        
        return summary
    
    def generate_sync_report(self) -> Dict:
        """Generate comprehensive sync and analysis report"""
        if not self.sync_log:
            return {'message': 'No sync operations performed'}
        
        successful_syncs = [s for s in self.sync_log if s['status'] in ['cloned', 'updated']]
        failed_syncs = [s for s in self.sync_log if s['status'] == 'error']
        
        total_files = sum(s.get('files_synced', 0) for s in successful_syncs)
        
        report = {
            'sync_summary': {
                'total_operations': len(self.sync_log),
                'successful': len(successful_syncs),
                'failed': len(failed_syncs),
                'total_files_synced': total_files
            },
            'successful_syncs': successful_syncs,
            'failed_syncs': failed_syncs,
            'recommendations': self._generate_sync_recommendations(),
            'generated_at': datetime.now().isoformat()
        }
        
        return report
    
    def _generate_sync_recommendations(self) -> List[str]:
        """Generate recommendations based on sync patterns"""
        recommendations = []
        
        if not self.sync_log:
            return ["No sync operations to analyze"]
        
        failed_count = len([s for s in self.sync_log if s['status'] == 'error'])
        total_count = len(self.sync_log)
        
        if failed_count > total_count * 0.3:
            recommendations.append("High failure rate detected - check network connectivity and credentials")
        
        large_repos = [s for s in self.sync_log if s.get('files_synced', 0) > 1000]
        if large_repos:
            recommendations.append("Large repositories detected - consider selective syncing for performance")
        
        if total_count > 10:
            recommendations.append("Consider implementing incremental sync for better performance")
        
        return recommendations

def main():
    """Main function for GitHub sync operations"""
    sync = GitHubSync()
    
    # Check for GitHub token
    if not sync.github_token:
        print("Warning: No GitHub token found. Repository discovery will be limited.")
        print("Set GITHUB_TOKEN environment variable for full functionality.")
        return
    
    print("🔗 Starting GitHub sync for Neural Complexity Estimator...")
    
    # Discover repositories
    try:
        repositories = sync.discover_repositories()
        print(f"📊 Discovered {len(repositories)} repositories")
        
        # Save repository analysis
        output_file = Path(__file__).parent / 'github_repositories.json'
        with open(output_file, 'w') as f:
            json.dump({
                'discovery_timestamp': datetime.now().isoformat(),
                'repositories': repositories,
                'total_count': len(repositories)
            }, f, indent=2)
        
        print(f"✅ Repository analysis saved to {output_file}")
        
        # Generate summary
        languages = {}
        total_complexity = {'cognitive_load': 0, 'visual_dependency': 0, 'language_complexity': 0, 'workflow_complexity': 0}
        
        for repo in repositories:
            lang = repo.get('language', 'unknown')
            languages[lang] = languages.get(lang, 0) + 1
            
            for key, value in repo['complexity_indicators'].items():
                total_complexity[key] += value
        
        avg_complexity = {k: round(v / len(repositories), 2) for k, v in total_complexity.items()}
        
        print(f"\n📈 Repository Analysis Summary:")
        print(f"  • Languages: {dict(sorted(languages.items(), key=lambda x: x[1], reverse=True))}")
        print(f"  • Average Complexity: {avg_complexity}")
        
        # Show accessibility concerns
        all_concerns = []
        for repo in repositories:
            all_concerns.extend(repo.get('accessibility_concerns', []))
        
        if all_concerns:
            unique_concerns = list(set(all_concerns))
            print(f"  • Accessibility Concerns: {len(unique_concerns)} unique issues identified")
        
    except Exception as e:
        print(f"❌ Repository discovery failed: {e}")

if __name__ == "__main__":
    main()