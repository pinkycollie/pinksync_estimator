"""
Xano API Connector for PinkSync Python Workers

Handles connectivity to Xano API platforms, focusing on the Meta API
for fast-forward processing capabilities.
"""

import os
import json
import time
import logging
from typing import Dict, List, Any, Optional, Union, Tuple
import requests
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('xano_connector')

class XanoApiError(Exception):
    """Custom exception for Xano API errors"""
    def __init__(self, message: str, status_code: Optional[int] = None, data: Optional[Dict] = None):
        self.message = message
        self.status_code = status_code
        self.data = data
        super().__init__(self.message)


class XanoConnector:
    """Connector for Xano API platforms"""
    
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        """
        Initialize the Xano connector
        
        Args:
            api_key: Xano API key (default: from environment)
            base_url: Xano base URL (default: from environment)
        """
        self.api_key = api_key or os.environ.get('XANO_API_KEY')
        self.base_url = base_url or os.environ.get('XANO_BASE_URL')
        
        if not self.api_key:
            logger.warning("No Xano API key provided - running in limited mode")
        
        if not self.base_url:
            self.base_url = "https://x8ki-letl-twmt.n7.xano.io"
            logger.warning(f"No Xano base URL provided - using default: {self.base_url}")
        
        # Strip trailing slash if present
        if self.base_url and self.base_url.endswith('/'):
            self.base_url = self.base_url[:-1]
        
        # Session for connection pooling
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}' if self.api_key else ''
        })
    
    def execute_request(
        self, 
        endpoint: str, 
        method: str = 'GET', 
        data: Optional[Dict] = None,
        params: Optional[Dict] = None,
        workspace: str = 'api',
        timeout: int = 30
    ) -> Dict:
        """
        Execute a request to the Xano API
        
        Args:
            endpoint: API endpoint path
            method: HTTP method (GET, POST, etc.)
            data: Request body data
            params: Query parameters
            workspace: Xano workspace (api, dev, meta)
            timeout: Request timeout in seconds
            
        Returns:
            Response data as dictionary
        """
        # Format URL with workspace
        url = f"{self.base_url}/{workspace}/{endpoint}"
        
        try:
            start_time = time.time()
            
            # Execute request
            response = self.session.request(
                method=method.upper(),
                url=url,
                json=data,
                params=params,
                timeout=timeout
            )
            
            execution_time = time.time() - start_time
            logger.debug(f"Request to {url} completed in {execution_time:.2f}s")
            
            # Check for errors
            response.raise_for_status()
            
            # Parse JSON response
            response_data = response.json()
            
            return response_data
            
        except requests.exceptions.RequestException as e:
            # Handle request errors
            status_code = e.response.status_code if hasattr(e, 'response') else None
            error_data = None
            
            # Try to parse error response
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_data = e.response.json()
                except:
                    error_data = {'raw': e.response.text}
            
            error_message = f"Xano API error: {str(e)}"
            logger.error(error_message, exc_info=True)
            
            raise XanoApiError(error_message, status_code, error_data)
    
    def execute_meta(
        self, 
        operation: str, 
        data: Dict,
        timeout: int = 60
    ) -> Dict:
        """
        Execute a request to the Xano Meta API
        
        Args:
            operation: Meta API operation
            data: Operation data
            timeout: Request timeout in seconds
            
        Returns:
            Meta API result
        """
        try:
            # Execute through meta API
            result = self.execute_request(
                endpoint=operation,
                method='POST',
                data=data,
                workspace='api:meta',
                timeout=timeout
            )
            
            return result
        except Exception as e:
            logger.error(f"Meta API error for operation {operation}: {str(e)}", exc_info=True)
            raise
    
    def fast_forward(
        self, 
        operation: str, 
        data: Dict,
        priority: str = 'normal',
        timeout: int = 60
    ) -> Dict:
        """
        Use the Fast Forward facility for accelerated Meta API processing
        
        Args:
            operation: Fast Forward operation
            data: Operation data
            priority: Priority level (high, normal, low)
            timeout: Request timeout in seconds
            
        Returns:
            Operation result
        """
        # Add priority and timestamp to data
        payload = {
            **data,
            "_meta": {
                "priority": priority,
                "timestamp": datetime.now().isoformat()
            }
        }
        
        # Path for fast forward
        path = f"fast-forward/{operation}"
        
        # Execute through meta API
        return self.execute_meta(path, payload, timeout)
    
    def generate_code(
        self,
        spec: Dict,
        language: str = 'typescript',
        framework: Optional[str] = None,
        timeout: int = 120
    ) -> Dict:
        """
        Generate code using the Meta API
        
        Args:
            spec: Code specification
            language: Programming language
            framework: Optional framework
            timeout: Request timeout in seconds
            
        Returns:
            Generated code result
        """
        payload = {
            "spec": spec,
            "language": language,
            "framework": framework
        }
        
        return self.fast_forward("generate-code", payload, priority="high", timeout=timeout)
    
    def create_api(
        self,
        definition: Dict,
        deploy: bool = False,
        timeout: int = 180
    ) -> Dict:
        """
        Create a new API in Xano using the Meta API
        
        Args:
            definition: API definition
            deploy: Whether to deploy the API immediately
            timeout: Request timeout in seconds
            
        Returns:
            API creation result
        """
        payload = {
            "definition": definition,
            "deploy": deploy
        }
        
        return self.fast_forward("create-api", payload, priority="high", timeout=timeout)
    
    def analyze_data(
        self,
        data: Union[Dict, List],
        analysis_type: str = 'general',
        timeout: int = 90
    ) -> Dict:
        """
        Analyze data using the Meta API
        
        Args:
            data: Data to analyze
            analysis_type: Type of analysis (general, security, performance)
            timeout: Request timeout in seconds
            
        Returns:
            Analysis result
        """
        payload = {
            "data": data,
            "analysis_type": analysis_type
        }
        
        return self.fast_forward("analyze-data", payload, timeout=timeout)

    def generate_webhooks(
        self,
        sources: List[Dict],
        destinations: List[Dict],
        mappings: List[Dict],
        timeout: int = 120
    ) -> Dict:
        """
        Generate webhook configurations using the Meta API
        
        Args:
            sources: Source system configurations
            destinations: Destination system configurations
            mappings: Data mapping configurations
            timeout: Request timeout in seconds
            
        Returns:
            Webhook generation results
        """
        payload = {
            "sources": sources,
            "destinations": destinations,
            "mappings": mappings
        }
        
        return self.fast_forward("generate-webhooks", payload, timeout=timeout)


# Helper function to create connector from environment
def create_connector_from_env() -> XanoConnector:
    """Create a Xano connector using environment variables"""
    api_key = os.environ.get('XANO_API_KEY')
    base_url = os.environ.get('XANO_BASE_URL')
    
    if not api_key:
        logger.warning("XANO_API_KEY not found in environment variables")
    
    return XanoConnector(api_key=api_key, base_url=base_url)


if __name__ == "__main__":
    # Simple test if run directly
    try:
        connector = create_connector_from_env()
        result = connector.execute_request("ping", method="GET", workspace="api")
        print(f"Ping result: {json.dumps(result, indent=2)}")
    except Exception as e:
        print(f"Error: {str(e)}")