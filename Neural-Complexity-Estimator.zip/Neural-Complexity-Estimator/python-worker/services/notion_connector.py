"""
Notion Connector for PinkSync Python Workers

Retrieves task definitions, project specifications, and other data from Notion.
Allows Python workers to process and execute tasks defined in Notion databases.
"""

import os
import json
import logging
from typing import Dict, List, Any, Optional, Union, Tuple
import requests
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('notion_connector')

class NotionApiError(Exception):
    """Custom exception for Notion API errors"""
    def __init__(self, message: str, status_code: Optional[int] = None, data: Optional[Dict] = None):
        self.message = message
        self.status_code = status_code
        self.data = data
        super().__init__(self.message)


class NotionConnector:
    """Connector for Notion API"""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the Notion connector
        
        Args:
            api_key: Notion API key (default: from environment)
        """
        self.api_key = api_key or os.environ.get('NOTION_API_KEY')
        self.base_url = "https://api.notion.com/v1"
        
        if not self.api_key:
            logger.warning("No Notion API key provided - running in limited mode")
        
        # Session for connection pooling
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Bearer {self.api_key}' if self.api_key else '',
            'Notion-Version': '2022-06-28',
            'Content-Type': 'application/json'
        })
    
    def execute_request(
        self, 
        endpoint: str, 
        method: str = 'GET', 
        data: Optional[Dict] = None,
        params: Optional[Dict] = None,
        timeout: int = 30
    ) -> Dict:
        """
        Execute a request to the Notion API
        
        Args:
            endpoint: API endpoint path
            method: HTTP method (GET, POST, etc.)
            data: Request body data
            params: Query parameters
            timeout: Request timeout in seconds
            
        Returns:
            Response data as dictionary
        """
        # Format URL
        url = f"{self.base_url}/{endpoint}"
        
        try:
            # Execute request
            response = self.session.request(
                method=method.upper(),
                url=url,
                json=data,
                params=params,
                timeout=timeout
            )
            
            # Check for errors
            response.raise_for_status()
            
            # Parse JSON response
            response_data = response.json()
            
            return response_data
            
        except requests.exceptions.RequestException as e:
            # Handle request errors
            status_code = e.response.status_code if hasattr(e, 'response') else None
            error_data = None
            
            # Try to parse error response
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_data = e.response.json()
                except:
                    error_data = {'raw': e.response.text}
            
            error_message = f"Notion API error: {str(e)}"
            logger.error(error_message, exc_info=True)
            
            raise NotionApiError(error_message, status_code, error_data)
    
    def get_database(self, database_id: str) -> Dict:
        """
        Get a database by ID
        
        Args:
            database_id: Notion database ID
            
        Returns:
            Database object
        """
        return self.execute_request(f"databases/{database_id}")
    
    def query_database(
        self, 
        database_id: str, 
        filter_obj: Optional[Dict] = None, 
        sorts: Optional[List[Dict]] = None,
        page_size: int = 100
    ) -> Dict:
        """
        Query a database
        
        Args:
            database_id: Notion database ID
            filter_obj: Filter object
            sorts: Sort specifications
            page_size: Page size
            
        Returns:
            Query results
        """
        data = {
            "page_size": page_size
        }
        
        if filter_obj:
            data["filter"] = filter_obj
            
        if sorts:
            data["sorts"] = sorts
        
        return self.execute_request(
            endpoint=f"databases/{database_id}/query",
            method="POST",
            data=data
        )
    
    def get_all_pages(self, database_id: str, filter_obj: Optional[Dict] = None) -> List[Dict]:
        """
        Get all pages from a database (handles pagination)
        
        Args:
            database_id: Notion database ID
            filter_obj: Filter object
            
        Returns:
            List of pages
        """
        all_pages = []
        has_more = True
        start_cursor = None
        
        while has_more:
            data = {
                "page_size": 100
            }
            
            if filter_obj:
                data["filter"] = filter_obj
                
            if start_cursor:
                data["start_cursor"] = start_cursor
            
            response = self.execute_request(
                endpoint=f"databases/{database_id}/query",
                method="POST",
                data=data
            )
            
            all_pages.extend(response.get("results", []))
            has_more = response.get("has_more", False)
            start_cursor = response.get("next_cursor")
        
        return all_pages
    
    def get_page(self, page_id: str) -> Dict:
        """
        Get a page by ID
        
        Args:
            page_id: Notion page ID
            
        Returns:
            Page object
        """
        return self.execute_request(f"pages/{page_id}")
    
    def update_page(self, page_id: str, properties: Dict) -> Dict:
        """
        Update a page's properties
        
        Args:
            page_id: Notion page ID
            properties: Page properties to update
            
        Returns:
            Updated page object
        """
        return self.execute_request(
            endpoint=f"pages/{page_id}",
            method="PATCH",
            data={"properties": properties}
        )
    
    def create_page(self, parent_id: str, properties: Dict, is_database: bool = True) -> Dict:
        """
        Create a new page
        
        Args:
            parent_id: Parent database or page ID
            properties: Page properties
            is_database: Whether parent is a database (True) or page (False)
            
        Returns:
            Created page object
        """
        parent_type = "database_id" if is_database else "page_id"
        
        data = {
            "parent": {
                parent_type: parent_id
            },
            "properties": properties
        }
        
        return self.execute_request(
            endpoint="pages",
            method="POST",
            data=data
        )
    
    def get_block_children(self, block_id: str) -> List[Dict]:
        """
        Get a block's children
        
        Args:
            block_id: Block ID
            
        Returns:
            List of child blocks
        """
        response = self.execute_request(f"blocks/{block_id}/children")
        return response.get("results", [])
    
    def append_block_children(self, block_id: str, children: List[Dict]) -> Dict:
        """
        Append children to a block
        
        Args:
            block_id: Block ID
            children: List of block objects to append
            
        Returns:
            Response object
        """
        return self.execute_request(
            endpoint=f"blocks/{block_id}/children",
            method="PATCH",
            data={"children": children}
        )
    
    def get_task_definitions(self, database_id: str, status: Optional[str] = None) -> List[Dict]:
        """
        Get task definitions from a database, optionally filtered by status
        
        Args:
            database_id: Notion database ID
            status: Filter tasks by status
            
        Returns:
            List of task definitions
        """
        filter_obj = None
        
        if status:
            filter_obj = {
                "property": "Status",
                "select": {
                    "equals": status
                }
            }
        
        pages = self.get_all_pages(database_id, filter_obj)
        tasks = []
        
        for page in pages:
            task = self.convert_page_to_task(page)
            tasks.append(task)
        
        return tasks
    
    def convert_page_to_task(self, page: Dict) -> Dict:
        """
        Convert a Notion page to a task definition
        
        Args:
            page: Notion page object
            
        Returns:
            Task definition
        """
        properties = page.get("properties", {})
        
        # Extract title
        title = ""
        if "Name" in properties and properties["Name"].get("title"):
            title = "".join([text.get("plain_text", "") for text in properties["Name"].get("title", [])])
        elif "Title" in properties and properties["Title"].get("title"):
            title = "".join([text.get("plain_text", "") for text in properties["Title"].get("title", [])])
        
        # Extract status
        status = ""
        if "Status" in properties and properties["Status"].get("select"):
            status = properties["Status"].get("select", {}).get("name", "")
        
        # Extract priority
        priority = ""
        if "Priority" in properties and properties["Priority"].get("select"):
            priority = properties["Priority"].get("select", {}).get("name", "")
        
        # Extract description
        description = ""
        if "Description" in properties and properties["Description"].get("rich_text"):
            description = "".join([text.get("plain_text", "") for text in properties["Description"].get("rich_text", [])])
        
        # Extract tags
        tags = []
        if "Tags" in properties and properties["Tags"].get("multi_select"):
            tags = [tag.get("name", "") for tag in properties["Tags"].get("multi_select", [])]
        
        # Extract due date
        due_date = None
        if "Due Date" in properties and properties["Due Date"].get("date"):
            due_date = properties["Due Date"].get("date", {}).get("start")
        
        return {
            "id": page.get("id", ""),
            "title": title,
            "status": status,
            "priority": priority,
            "description": description,
            "tags": tags,
            "due_date": due_date,
            "raw_properties": properties
        }
    
    def update_task_status(self, task_id: str, status: str) -> Dict:
        """
        Update a task's status
        
        Args:
            task_id: Task (page) ID
            status: New status
            
        Returns:
            Updated page
        """
        properties = {
            "Status": {
                "select": {
                    "name": status
                }
            }
        }
        
        return self.update_page(task_id, properties)
    
    def update_task_progress(self, task_id: str, progress: int) -> Dict:
        """
        Update a task's progress
        
        Args:
            task_id: Task (page) ID
            progress: Progress percentage (0-100)
            
        Returns:
            Updated page
        """
        properties = {
            "Progress": {
                "number": progress
            }
        }
        
        return self.update_page(task_id, properties)
    
    def add_task_comment(self, task_id: str, comment: str) -> Dict:
        """
        Add a comment to a task by appending a text block
        
        Args:
            task_id: Task (page) ID
            comment: Comment text
            
        Returns:
            Response from appending block
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        comment_with_timestamp = f"[{timestamp}] {comment}"
        
        children = [
            {
                "object": "block",
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [
                        {
                            "type": "text",
                            "text": {
                                "content": comment_with_timestamp
                            }
                        }
                    ]
                }
            }
        ]
        
        return self.append_block_children(task_id, children)


# Helper function to create connector from environment
def create_connector_from_env() -> NotionConnector:
    """Create a Notion connector using environment variables"""
    api_key = os.environ.get('NOTION_API_KEY')
    
    if not api_key:
        logger.warning("NOTION_API_KEY not found in environment variables")
    
    return NotionConnector(api_key=api_key)


if __name__ == "__main__":
    # Simple test if run directly
    try:
        connector = create_connector_from_env()
        database_id = os.environ.get('NOTION_DATABASE_ID')
        
        if database_id:
            print(f"Querying database {database_id}...")
            results = connector.query_database(database_id)
            print(f"Found {len(results.get('results', []))} items")
        else:
            print("No NOTION_DATABASE_ID found in environment variables")
    except Exception as e:
        print(f"Error: {str(e)}")