#!/usr/bin/env python3
"""
Project Scanner for Neural Complexity Estimator
Scans file system to discover and gather project information for cognitive complexity analysis
"""

import os
import json
import re
from typing import Dict, List, Optional, Tuple
from pathlib import Path
import mimetypes
from datetime import datetime

class ProjectScanner:
    def __init__(self, base_path: str = "/home/runner/workspace"):
        self.base_path = Path(base_path)
        self.project_indicators = {
            'package.json': 'nodejs',
            'requirements.txt': 'python',
            'pyproject.toml': 'python',
            'Cargo.toml': 'rust',
            'pom.xml': 'java',
            'build.gradle': 'java',
            'composer.json': 'php',
            'Gemfile': 'ruby',
            'go.mod': 'go',
            '.csproj': 'csharp',
            'Dockerfile': 'docker',
            'docker-compose.yml': 'docker',
            'README.md': 'documentation'
        }
        
        self.complexity_patterns = {
            'high_cognitive_load': [
                r'\b(algorithm|implementation|architecture|infrastructure|methodology)\b',
                r'\b(async|await|promise|callback|threading|concurrency)\b',
                r'\b(encryption|authentication|authorization|security)\b'
            ],
            'visual_dependency': [
                r'\b(chart|graph|diagram|visualization|canvas|svg)\b',
                r'\b(color|rgb|hex|css|style|theme)\b',
                r'\b(image|photo|picture|icon|logo)\b'
            ],
            'language_complexity': [
                r'\b(abstract|interface|generic|template|inheritance)\b',
                r'\b(lambda|closure|decorator|annotation)\b',
                r'\b(polymorphism|encapsulation|abstraction)\b'
            ],
            'workflow_complexity': [
                r'\b(pipeline|workflow|automation|schedule|cron)\b',
                r'\b(deploy|build|test|integration|continuous)\b',
                r'\b(coordinate|synchronize|orchestrate|manage)\b'
            ]
        }

    def scan_projects(self) -> List[Dict]:
        """Scan the file system for projects and analyze their complexity indicators"""
        projects = []
        
        # Scan immediate directories
        for item in self.base_path.iterdir():
            if item.is_dir() and not item.name.startswith('.'):
                project_info = self._analyze_project(item)
                if project_info:
                    projects.append(project_info)
        
        return projects

    def _analyze_project(self, project_path: Path) -> Optional[Dict]:
        """Analyze a single project directory for complexity indicators"""
        project_info = {
            'name': project_path.name,
            'path': str(project_path),
            'type': 'unknown',
            'description': '',
            'files': [],
            'complexity_indicators': {
                'cognitive_load': 0,
                'visual_dependency': 0,
                'language_complexity': 0,
                'workflow_complexity': 0
            },
            'technologies': [],
            'documentation': [],
            'estimated_size': 'small',
            'last_modified': datetime.fromtimestamp(project_path.stat().st_mtime).isoformat()
        }

        # Detect project type and gather basic info
        self._detect_project_type(project_path, project_info)
        
        # Analyze files for complexity patterns
        self._analyze_project_files(project_path, project_info)
        
        # Extract description from README or package files
        self._extract_description(project_path, project_info)
        
        # Estimate project size
        self._estimate_project_size(project_path, project_info)
        
        return project_info

    def _detect_project_type(self, project_path: Path, project_info: Dict):
        """Detect project type based on indicator files"""
        for file_name, project_type in self.project_indicators.items():
            indicator_file = project_path / file_name
            if indicator_file.exists():
                project_info['type'] = project_type
                project_info['technologies'].append(project_type)
                
                # Extract additional info from specific files
                if file_name == 'package.json':
                    self._parse_package_json(indicator_file, project_info)
                elif file_name == 'pyproject.toml':
                    self._parse_pyproject_toml(indicator_file, project_info)
                elif file_name == 'requirements.txt':
                    self._parse_requirements_txt(indicator_file, project_info)

    def _analyze_project_files(self, project_path: Path, project_info: Dict):
        """Analyze project files for complexity patterns"""
        file_count = 0
        total_lines = 0
        
        for file_path in project_path.rglob('*'):
            if file_path.is_file() and not self._should_skip_file(file_path):
                file_count += 1
                
                # Analyze text files for complexity patterns
                if self._is_text_file(file_path):
                    try:
                        content = file_path.read_text(encoding='utf-8', errors='ignore')
                        lines = len(content.splitlines())
                        total_lines += lines
                        
                        # Analyze content for complexity patterns
                        self._analyze_content_complexity(content, project_info)
                        
                        # Track significant files
                        if lines > 50 or file_path.suffix in ['.md', '.rst', '.txt']:
                            project_info['files'].append({
                                'name': file_path.name,
                                'path': str(file_path.relative_to(project_path)),
                                'lines': lines,
                                'type': file_path.suffix
                            })
                    except Exception:
                        continue
        
        project_info['file_count'] = file_count
        project_info['total_lines'] = total_lines

    def _analyze_content_complexity(self, content: str, project_info: Dict):
        """Analyze text content for Deaf-specific complexity patterns"""
        content_lower = content.lower()
        
        for category, patterns in self.complexity_patterns.items():
            for pattern in patterns:
                matches = len(re.findall(pattern, content_lower, re.IGNORECASE))
                project_info['complexity_indicators'][category] += matches

    def _extract_description(self, project_path: Path, project_info: Dict):
        """Extract project description from README or package files"""
        # Try README files first
        readme_files = ['README.md', 'README.rst', 'README.txt', 'README']
        for readme_name in readme_files:
            readme_path = project_path / readme_name
            if readme_path.exists():
                try:
                    content = readme_path.read_text(encoding='utf-8', errors='ignore')
                    # Extract first meaningful paragraph
                    lines = content.splitlines()
                    description_lines = []
                    for line in lines:
                        line = line.strip()
                        if line and not line.startswith('#') and len(line) > 20:
                            description_lines.append(line)
                            if len(' '.join(description_lines)) > 200:
                                break
                    
                    if description_lines:
                        project_info['description'] = ' '.join(description_lines)[:500]
                        project_info['documentation'].append({
                            'file': readme_name,
                            'type': 'readme'
                        })
                        break
                except Exception:
                    continue

    def _estimate_project_size(self, project_path: Path, project_info: Dict):
        """Estimate project size based on files and complexity"""
        file_count = project_info.get('file_count', 0)
        total_lines = project_info.get('total_lines', 0)
        complexity_score = sum(project_info['complexity_indicators'].values())
        
        if file_count > 100 or total_lines > 10000 or complexity_score > 50:
            project_info['estimated_size'] = 'large'
        elif file_count > 20 or total_lines > 2000 or complexity_score > 20:
            project_info['estimated_size'] = 'medium'
        else:
            project_info['estimated_size'] = 'small'

    def _parse_package_json(self, file_path: Path, project_info: Dict):
        """Parse package.json for project information"""
        try:
            content = json.loads(file_path.read_text())
            if 'name' in content:
                project_info['name'] = content['name']
            if 'description' in content:
                project_info['description'] = content['description']
            if 'dependencies' in content:
                project_info['technologies'].extend(list(content['dependencies'].keys())[:10])
        except Exception:
            pass

    def _parse_pyproject_toml(self, file_path: Path, project_info: Dict):
        """Parse pyproject.toml for project information"""
        try:
            content = file_path.read_text()
            # Simple regex-based parsing for basic info
            name_match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', content)
            if name_match:
                project_info['name'] = name_match.group(1)
            
            desc_match = re.search(r'description\s*=\s*["\']([^"\']+)["\']', content)
            if desc_match:
                project_info['description'] = desc_match.group(1)
        except Exception:
            pass

    def _parse_requirements_txt(self, file_path: Path, project_info: Dict):
        """Parse requirements.txt for dependencies"""
        try:
            content = file_path.read_text()
            deps = []
            for line in content.splitlines():
                line = line.strip()
                if line and not line.startswith('#'):
                    dep = line.split('==')[0].split('>=')[0].split('<=')[0].strip()
                    deps.append(dep)
            project_info['technologies'].extend(deps[:10])
        except Exception:
            pass

    def _should_skip_file(self, file_path: Path) -> bool:
        """Check if file should be skipped during analysis"""
        skip_dirs = {
            'node_modules', '.git', '__pycache__', '.venv', 'venv',
            'dist', 'build', '.next', '.nuxt', 'coverage', '.pytest_cache'
        }
        
        skip_extensions = {
            '.pyc', '.pyo', '.class', '.o', '.so', '.dylib',
            '.exe', '.dll', '.bin', '.log', '.tmp'
        }
        
        # Skip if in skip directories
        for part in file_path.parts:
            if part in skip_dirs:
                return True
        
        # Skip if has skip extension
        if file_path.suffix in skip_extensions:
            return True
        
        # Skip very large files (>1MB)
        try:
            if file_path.stat().st_size > 1024 * 1024:
                return True
        except Exception:
            return True
        
        return False

    def _is_text_file(self, file_path: Path) -> bool:
        """Check if file is a text file suitable for analysis"""
        text_extensions = {
            '.py', '.js', '.ts', '.jsx', '.tsx', '.html', '.css', '.scss',
            '.md', '.rst', '.txt', '.json', '.yaml', '.yml', '.toml',
            '.xml', '.sql', '.sh', '.bash', '.zsh', '.fish', '.ps1',
            '.php', '.rb', '.go', '.rs', '.java', '.cpp', '.c', '.h',
            '.cs', '.vb', '.swift', '.kt', '.dart', '.r', '.m', '.mm'
        }
        
        if file_path.suffix.lower() in text_extensions:
            return True
        
        # Check MIME type for files without clear extensions
        mime_type, _ = mimetypes.guess_type(str(file_path))
        if mime_type and mime_type.startswith('text/'):
            return True
        
        return False

    def generate_complexity_report(self, projects: List[Dict]) -> Dict:
        """Generate a comprehensive complexity report for all projects"""
        total_projects = len(projects)
        
        if total_projects == 0:
            return {
                'summary': 'No projects found',
                'total_projects': 0,
                'complexity_distribution': {},
                'recommendations': []
            }
        
        # Calculate aggregate complexity scores
        total_cognitive = sum(p['complexity_indicators']['cognitive_load'] for p in projects)
        total_visual = sum(p['complexity_indicators']['visual_dependency'] for p in projects)
        total_language = sum(p['complexity_indicators']['language_complexity'] for p in projects)
        total_workflow = sum(p['complexity_indicators']['workflow_complexity'] for p in projects)
        
        avg_cognitive = total_cognitive / total_projects
        avg_visual = total_visual / total_projects
        avg_language = total_language / total_projects
        avg_workflow = total_workflow / total_projects
        
        # Project size distribution
        size_distribution = {'small': 0, 'medium': 0, 'large': 0}
        for project in projects:
            size_distribution[project['estimated_size']] += 1
        
        # Technology distribution
        tech_count = {}
        for project in projects:
            for tech in project['technologies']:
                tech_count[tech] = tech_count.get(tech, 0) + 1
        
        # Generate recommendations based on complexity patterns
        recommendations = []
        if avg_cognitive > 15:
            recommendations.append("High cognitive load detected across projects - consider implementing ASL-friendly documentation")
        if avg_visual > 10:
            recommendations.append("Visual dependency concerns - ensure alternative text descriptions for all visual elements")
        if avg_language > 12:
            recommendations.append("Complex language patterns detected - simplify technical terminology for Deaf accessibility")
        if avg_workflow > 8:
            recommendations.append("Workflow complexity may create barriers - implement step-by-step visual guides")
        
        return {
            'summary': f'Analyzed {total_projects} projects for Deaf-first cognitive complexity',
            'total_projects': total_projects,
            'average_complexity': {
                'cognitive_load': round(avg_cognitive, 2),
                'visual_dependency': round(avg_visual, 2),
                'language_complexity': round(avg_language, 2),
                'workflow_complexity': round(avg_workflow, 2)
            },
            'size_distribution': size_distribution,
            'top_technologies': sorted(tech_count.items(), key=lambda x: x[1], reverse=True)[:10],
            'recommendations': recommendations,
            'high_complexity_projects': [
                p['name'] for p in projects 
                if sum(p['complexity_indicators'].values()) > 30
            ]
        }

def main():
    """Main function to run project scanning and analysis"""
    scanner = ProjectScanner()
    
    print("🔍 Scanning projects for Neural Complexity Estimator...")
    projects = scanner.scan_projects()
    
    print(f"📊 Found {len(projects)} projects")
    
    # Generate complexity report
    report = scanner.generate_complexity_report(projects)
    
    # Save results
    output_file = Path(__file__).parent / 'project_scan_results.json'
    with open(output_file, 'w') as f:
        json.dump({
            'scan_timestamp': datetime.now().isoformat(),
            'projects': projects,
            'complexity_report': report
        }, f, indent=2)
    
    print(f"✅ Analysis complete. Results saved to {output_file}")
    print(f"📈 {report['summary']}")
    
    # Print summary
    if report['recommendations']:
        print("\n🎯 Key Recommendations:")
        for rec in report['recommendations']:
            print(f"  • {rec}")
    
    return projects, report

if __name__ == "__main__":
    main()