#!/usr/bin/env python3
"""
File System Sync for Neural Complexity Estimator
Real-time file monitoring and automated project synchronization
"""

import os
import json
import time
import hashlib
from typing import Dict, List, Set, Optional
from pathlib import Path
from datetime import datetime
import threading
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class ProjectChangeHandler(FileSystemEventHandler):
    def __init__(self, sync_manager):
        self.sync_manager = sync_manager
        self.debounce_time = 2.0  # seconds
        self.pending_changes = {}
        
    def on_modified(self, event):
        if event.is_directory:
            return
        
        file_path = Path(event.src_path)
        
        # Skip temporary and system files
        if self._should_ignore(file_path):
            return
        
        # Debounce rapid changes
        current_time = time.time()
        self.pending_changes[str(file_path)] = current_time
        
        # Schedule delayed processing
        threading.Timer(self.debounce_time, self._process_change, [file_path]).start()
    
    def on_created(self, event):
        self.on_modified(event)
    
    def on_deleted(self, event):
        if not event.is_directory:
            file_path = Path(event.src_path)
            self.sync_manager.handle_file_deletion(file_path)
    
    def _should_ignore(self, file_path: Path) -> bool:
        """Check if file should be ignored for sync"""
        ignore_patterns = {
            '.git', '__pycache__', 'node_modules', '.venv', 'venv',
            '.DS_Store', '.tmp', '.log', '.cache', 'dist', 'build'
        }
        
        # Check if any part of path contains ignore patterns
        for part in file_path.parts:
            if part in ignore_patterns:
                return True
        
        # Check file extensions to ignore
        ignore_extensions = {'.pyc', '.pyo', '.class', '.o', '.so', '.tmp'}
        if file_path.suffix in ignore_extensions:
            return True
        
        return False
    
    def _process_change(self, file_path: Path):
        """Process file change after debounce period"""
        path_str = str(file_path)
        
        # Check if this change is still pending (not superseded by newer change)
        if path_str in self.pending_changes:
            change_time = self.pending_changes[path_str]
            if time.time() - change_time >= self.debounce_time:
                self.sync_manager.handle_file_change(file_path)
                del self.pending_changes[path_str]

class FileSystemSync:
    def __init__(self, workspace_path: str = "/home/runner/workspace"):
        self.workspace_path = Path(workspace_path)
        self.observer = None
        self.change_handler = ProjectChangeHandler(self)
        self.project_cache = {}
        self.sync_queue = []
        self.last_scan_time = None
        self.change_log = []
        
    def start_monitoring(self):
        """Start real-time file system monitoring"""
        if self.observer and self.observer.is_alive():
            print("File system monitoring already active")
            return
        
        self.observer = Observer()
        self.observer.schedule(
            self.change_handler,
            str(self.workspace_path),
            recursive=True
        )
        
        self.observer.start()
        print(f"Started monitoring file system at {self.workspace_path}")
        
        # Initial scan to establish baseline
        self.perform_full_scan()
    
    def stop_monitoring(self):
        """Stop file system monitoring"""
        if self.observer and self.observer.is_alive():
            self.observer.stop()
            self.observer.join()
            print("Stopped file system monitoring")
    
    def perform_full_scan(self) -> Dict:
        """Perform comprehensive file system scan"""
        scan_start = time.time()
        scan_results = {
            'scan_timestamp': datetime.now().isoformat(),
            'projects_discovered': [],
            'file_changes': [],
            'sync_operations': [],
            'performance_metrics': {}
        }
        
        # Import project scanner for full analysis
        try:
            from project_scanner import ProjectScanner
            scanner = ProjectScanner(str(self.workspace_path))
            projects = scanner.scan_projects()
            
            scan_results['projects_discovered'] = projects
            scan_results['complexity_report'] = scanner.generate_complexity_report(projects)
            
            # Update project cache
            self._update_project_cache(projects)
            
        except Exception as e:
            scan_results['errors'] = [f"Project scanning failed: {str(e)}"]
        
        # Calculate performance metrics
        scan_duration = time.time() - scan_start
        scan_results['performance_metrics'] = {
            'scan_duration': round(scan_duration, 2),
            'projects_per_second': round(len(scan_results['projects_discovered']) / scan_duration, 2),
            'total_files_scanned': sum(p.get('file_count', 0) for p in scan_results['projects_discovered'])
        }
        
        self.last_scan_time = datetime.now()
        
        # Save scan results
        self._save_scan_results(scan_results)
        
        return scan_results
    
    def handle_file_change(self, file_path: Path):
        """Handle individual file changes"""
        change_record = {
            'file_path': str(file_path),
            'change_type': 'modified',
            'timestamp': datetime.now().isoformat(),
            'project_affected': self._identify_affected_project(file_path),
            'complexity_impact': self._estimate_complexity_impact(file_path)
        }
        
        self.change_log.append(change_record)
        
        # Trigger incremental analysis if significant change
        if change_record['complexity_impact'] > 5:
            self._queue_incremental_analysis(file_path)
        
        print(f"File changed: {file_path.name} (impact: {change_record['complexity_impact']})")
    
    def handle_file_deletion(self, file_path: Path):
        """Handle file deletions"""
        change_record = {
            'file_path': str(file_path),
            'change_type': 'deleted',
            'timestamp': datetime.now().isoformat(),
            'project_affected': self._identify_affected_project(file_path)
        }
        
        self.change_log.append(change_record)
        print(f"File deleted: {file_path.name}")
    
    def _identify_affected_project(self, file_path: Path) -> Optional[str]:
        """Identify which project is affected by file change"""
        # Find the closest project root by looking for project indicators
        current_path = file_path.parent
        
        while current_path != self.workspace_path.parent:
            project_indicators = [
                'package.json', 'requirements.txt', 'pyproject.toml',
                'Cargo.toml', 'pom.xml', '.git'
            ]
            
            for indicator in project_indicators:
                if (current_path / indicator).exists():
                    return current_path.name
            
            current_path = current_path.parent
        
        return None
    
    def _estimate_complexity_impact(self, file_path: Path) -> int:
        """Estimate complexity impact of file change"""
        impact_score = 1  # Base impact
        
        # File extension based impact
        high_impact_extensions = {'.py', '.js', '.ts', '.jsx', '.tsx', '.java', '.cpp', '.c'}
        medium_impact_extensions = {'.html', '.css', '.scss', '.json', '.yaml', '.yml'}
        
        if file_path.suffix in high_impact_extensions:
            impact_score += 5
        elif file_path.suffix in medium_impact_extensions:
            impact_score += 3
        
        # File name based impact
        important_files = {'README.md', 'package.json', 'requirements.txt', 'Dockerfile'}
        if file_path.name in important_files:
            impact_score += 4
        
        # File size based impact (rough estimate)
        try:
            if file_path.exists():
                file_size = file_path.stat().st_size
                if file_size > 10000:  # Large file
                    impact_score += 3
                elif file_size > 1000:  # Medium file
                    impact_score += 1
        except:
            pass
        
        return min(impact_score, 10)  # Cap at 10
    
    def _queue_incremental_analysis(self, file_path: Path):
        """Queue file for incremental complexity analysis"""
        project_name = self._identify_affected_project(file_path)
        if project_name:
            analysis_task = {
                'project_name': project_name,
                'file_path': str(file_path),
                'queued_at': datetime.now().isoformat(),
                'priority': 'high' if file_path.name in ['README.md', 'package.json'] else 'normal'
            }
            
            self.sync_queue.append(analysis_task)
    
    def _update_project_cache(self, projects: List[Dict]):
        """Update internal project cache"""
        self.project_cache = {p['name']: p for p in projects}
    
    def _save_scan_results(self, results: Dict):
        """Save scan results to file"""
        output_file = Path(__file__).parent / 'file_sync_results.json'
        with open(output_file, 'w') as f:
            json.dump(results, f, indent=2)
    
    def get_sync_status(self) -> Dict:
        """Get current synchronization status"""
        return {
            'monitoring_active': self.observer and self.observer.is_alive(),
            'last_scan_time': self.last_scan_time.isoformat() if self.last_scan_time else None,
            'projects_cached': len(self.project_cache),
            'pending_queue': len(self.sync_queue),
            'recent_changes': len([c for c in self.change_log if self._is_recent_change(c)]),
            'workspace_path': str(self.workspace_path)
        }
    
    def _is_recent_change(self, change: Dict) -> bool:
        """Check if change occurred in last 10 minutes"""
        try:
            change_time = datetime.fromisoformat(change['timestamp'])
            time_diff = datetime.now() - change_time
            return time_diff.total_seconds() < 600  # 10 minutes
        except:
            return False
    
    def generate_sync_report(self) -> Dict:
        """Generate comprehensive sync report"""
        return {
            'sync_status': self.get_sync_status(),
            'change_summary': {
                'total_changes': len(self.change_log),
                'recent_changes': len([c for c in self.change_log if self._is_recent_change(c)]),
                'change_types': self._analyze_change_types(),
                'most_active_projects': self._get_most_active_projects()
            },
            'performance_metrics': self._calculate_performance_metrics(),
            'recommendations': self._generate_sync_recommendations(),
            'generated_at': datetime.now().isoformat()
        }
    
    def _analyze_change_types(self) -> Dict:
        """Analyze types of changes"""
        change_types = {}
        for change in self.change_log:
            change_type = change.get('change_type', 'unknown')
            change_types[change_type] = change_types.get(change_type, 0) + 1
        return change_types
    
    def _get_most_active_projects(self) -> List[Dict]:
        """Get projects with most file changes"""
        project_activity = {}
        
        for change in self.change_log:
            project = change.get('project_affected')
            if project:
                project_activity[project] = project_activity.get(project, 0) + 1
        
        # Sort by activity and return top 5
        sorted_projects = sorted(project_activity.items(), key=lambda x: x[1], reverse=True)
        return [{'project': p[0], 'changes': p[1]} for p in sorted_projects[:5]]
    
    def _calculate_performance_metrics(self) -> Dict:
        """Calculate sync performance metrics"""
        if not self.change_log:
            return {'message': 'No change data available'}
        
        recent_changes = [c for c in self.change_log if self._is_recent_change(c)]
        
        return {
            'changes_per_minute': round(len(recent_changes) / 10, 2),  # Last 10 minutes
            'average_complexity_impact': round(
                sum(c.get('complexity_impact', 0) for c in self.change_log) / len(self.change_log), 2
            ),
            'sync_efficiency': 'high' if len(self.sync_queue) < 5 else 'moderate'
        }
    
    def _generate_sync_recommendations(self) -> List[str]:
        """Generate sync optimization recommendations"""
        recommendations = []
        
        if len(self.sync_queue) > 10:
            recommendations.append("High queue backlog - consider increasing sync frequency")
        
        if len(self.change_log) > 100:
            recommendations.append("High change volume - implement change batching for efficiency")
        
        recent_high_impact = len([
            c for c in self.change_log 
            if self._is_recent_change(c) and c.get('complexity_impact', 0) > 7
        ])
        
        if recent_high_impact > 5:
            recommendations.append("Multiple high-impact changes detected - trigger full re-analysis")
        
        if not recommendations:
            recommendations.append("File system sync operating efficiently")
        
        return recommendations

def main():
    """Main function for file system sync"""
    sync = FileSystemSync()
    
    print("🔄 Starting File System Sync for Neural Complexity Estimator...")
    
    try:
        # Perform initial scan
        scan_results = sync.perform_full_scan()
        print(f"📊 Initial scan completed: {len(scan_results['projects_discovered'])} projects discovered")
        
        # Start monitoring
        sync.start_monitoring()
        
        # Generate initial report
        report = sync.generate_sync_report()
        
        # Save report
        report_file = Path(__file__).parent / 'sync_report.json'
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"✅ File system sync active. Report saved to {report_file}")
        print("📈 Monitoring file changes in real-time...")
        
        # Keep monitoring (in production, this would be a service)
        print("Press Ctrl+C to stop monitoring")
        try:
            while True:
                time.sleep(10)
                # Print periodic status
                status = sync.get_sync_status()
                if status['recent_changes'] > 0:
                    print(f"🔄 {status['recent_changes']} recent changes detected")
        except KeyboardInterrupt:
            print("\n⏹️  Stopping file system monitoring...")
            sync.stop_monitoring()
            
    except Exception as e:
        print(f"❌ File system sync failed: {e}")

if __name__ == "__main__":
    main()