"""
PinkSync Task Processor

Main entry point for the Python worker that processes tasks from Notion,
interacts with Xano API, and handles the full development automation workflow.
"""

import os
import sys
import time
import json
import logging
import argparse
import traceback
from typing import Dict, List, Any, Optional, Union, Tuple
from datetime import datetime, timedelta

# Import service connectors
from services.notion_connector import NotionConnector, create_connector_from_env as create_notion_connector
from services.xano_connector import XanoConnector, create_connector_from_env as create_xano_connector

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('task_processor.log')
    ]
)
logger = logging.getLogger('task_processor')

# Task processor configuration
DEFAULT_TASK_CHECK_INTERVAL = 300  # seconds (5 minutes)
DEFAULT_MAX_CONCURRENT_TASKS = 3
DEFAULT_TASK_TIMEOUT = 3600  # seconds (1 hour)

class TaskProcessor:
    """Main task processor for PinkSync Python worker"""
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize the task processor
        
        Args:
            config: Configuration dictionary
        """
        self.config = config or {}
        self.running = False
        self.current_tasks = {}
        
        # Initialize connectors
        self.notion = create_notion_connector()
        self.xano = create_xano_connector()
        
        # Extract configuration
        self.database_id = self.config.get('database_id') or os.environ.get('NOTION_DATABASE_ID')
        self.check_interval = self.config.get('check_interval', DEFAULT_TASK_CHECK_INTERVAL)
        self.max_concurrent_tasks = self.config.get('max_concurrent_tasks', DEFAULT_MAX_CONCURRENT_TASKS)
        self.task_timeout = self.config.get('task_timeout', DEFAULT_TASK_TIMEOUT)
        
        if not self.database_id:
            logger.warning("No Notion database ID provided - task processing will not work!")
    
    def start(self):
        """Start the task processor"""
        if self.running:
            logger.warning("Task processor is already running")
            return
        
        logger.info("Starting PinkSync task processor")
        self.running = True
        
        # Check for valid configuration
        if not self.database_id:
            logger.error("Cannot start task processor: No Notion database ID")
            self.running = False
            return
        
        try:
            # Main processing loop
            while self.running:
                try:
                    self.process_pending_tasks()
                except Exception as e:
                    logger.error(f"Error processing tasks: {str(e)}")
                    logger.error(traceback.format_exc())
                
                # Check for completed tasks
                self.check_task_completion()
                
                # Wait for next cycle
                time.sleep(self.check_interval)
        except KeyboardInterrupt:
            logger.info("Task processor stopped by user")
        finally:
            self.running = False
            logger.info("Task processor stopped")
    
    def stop(self):
        """Stop the task processor"""
        logger.info("Stopping task processor...")
        self.running = False
    
    def process_pending_tasks(self):
        """Process pending tasks from Notion database"""
        # Check if we can process more tasks
        if len(self.current_tasks) >= self.max_concurrent_tasks:
            logger.debug(f"Already processing {len(self.current_tasks)} tasks (max: {self.max_concurrent_tasks})")
            return
        
        # Get pending tasks
        tasks = self.get_pending_tasks()
        logger.info(f"Found {len(tasks)} pending tasks")
        
        # Process tasks up to the concurrent limit
        available_slots = self.max_concurrent_tasks - len(self.current_tasks)
        tasks_to_process = tasks[:available_slots]
        
        for task in tasks_to_process:
            self.start_task_processing(task)
    
    def get_pending_tasks(self) -> List[Dict]:
        """
        Get pending tasks from Notion database
        
        Returns:
            List of pending tasks
        """
        # Define filter for pending tasks
        filter_obj = {
            "property": "Status",
            "select": {
                "equals": "Ready to Process"
            }
        }
        
        # Get tasks from Notion
        return self.notion.get_task_definitions(self.database_id, "Ready to Process")
    
    def start_task_processing(self, task: Dict):
        """
        Start processing a task
        
        Args:
            task: Task definition
        """
        task_id = task['id']
        
        # Update task status to In Progress
        logger.info(f"Starting task {task_id}: {task['title']}")
        self.notion.update_task_status(task_id, "In Progress")
        self.notion.update_task_progress(task_id, 10)
        self.notion.add_task_comment(task_id, "Task processing started")
        
        # Store task in current tasks with timestamp
        self.current_tasks[task_id] = {
            'task': task,
            'start_time': datetime.now(),
            'progress': 10
        }
        
        # Start task processing in background
        # In a real implementation, this would use a thread or process
        # For this demo, we'll just process sequentially
        try:
            self.process_task(task_id)
        except Exception as e:
            logger.error(f"Error processing task {task_id}: {str(e)}")
            logger.error(traceback.format_exc())
            self.mark_task_failed(task_id, str(e))
    
    def process_task(self, task_id: str):
        """
        Process a task
        
        Args:
            task_id: Task ID
        """
        if task_id not in self.current_tasks:
            logger.error(f"Task {task_id} not found in current tasks")
            return
        
        task_data = self.current_tasks[task_id]
        task = task_data['task']
        
        # Update progress
        self.update_task_progress(task_id, 20, "Analyzing task requirements")
        
        # Determine task type
        task_type = self.determine_task_type(task)
        
        if task_type == 'code_generation':
            self.process_code_generation_task(task_id)
        elif task_type == 'api_creation':
            self.process_api_creation_task(task_id)
        elif task_type == 'data_analysis':
            self.process_data_analysis_task(task_id)
        elif task_type == 'webhook_generation':
            self.process_webhook_generation_task(task_id)
        else:
            self.update_task_progress(task_id, 100, f"Unknown task type: {task_type}")
            self.mark_task_completed(task_id)
    
    def determine_task_type(self, task: Dict) -> str:
        """
        Determine the type of task
        
        Args:
            task: Task definition
            
        Returns:
            Task type
        """
        # Check tags
        tags = task.get('tags', [])
        
        if 'code-generation' in tags:
            return 'code_generation'
        elif 'api-creation' in tags:
            return 'api_creation'
        elif 'data-analysis' in tags:
            return 'data_analysis'
        elif 'webhook' in tags:
            return 'webhook_generation'
        
        # Check title
        title = task.get('title', '').lower()
        
        if 'code' in title or 'generate' in title:
            return 'code_generation'
        elif 'api' in title:
            return 'api_creation'
        elif 'analyze' in title or 'analysis' in title:
            return 'data_analysis'
        elif 'webhook' in title:
            return 'webhook_generation'
        
        # Default to code generation
        return 'code_generation'
    
    def process_code_generation_task(self, task_id: str):
        """
        Process a code generation task
        
        Args:
            task_id: Task ID
        """
        task_data = self.current_tasks[task_id]
        task = task_data['task']
        
        self.update_task_progress(task_id, 30, "Preparing code generation request")
        
        # Extract code specification from task description
        description = task.get('description', '')
        
        # Create code specification
        spec = {
            "title": task.get('title', ''),
            "description": description,
            "language": "typescript",  # Default to TypeScript
            "framework": "react"       # Default to React
        }
        
        # Check for language or framework in tags
        tags = task.get('tags', [])
        for tag in tags:
            tag_lower = tag.lower()
            
            # Check for language
            if tag_lower in ['typescript', 'javascript', 'python', 'go', 'rust']:
                spec['language'] = tag_lower
            
            # Check for framework
            if tag_lower in ['react', 'vue', 'angular', 'express', 'nextjs', 'flask', 'django']:
                spec['framework'] = tag_lower
        
        self.update_task_progress(task_id, 40, f"Generating code with Xano Meta API")
        
        try:
            # Call Xano Meta API for code generation
            result = self.xano.generate_code(
                spec=spec,
                language=spec['language'],
                framework=spec.get('framework')
            )
            
            # Update task with results
            self.update_task_progress(task_id, 80, "Processing code generation results")
            
            # Add results as comments
            if result.get('files'):
                files_count = len(result.get('files', []))
                self.notion.add_task_comment(
                    task_id, 
                    f"Generated {files_count} files using Xano Meta API"
                )
                
                # In a real implementation, we might:
                # 1. Create files in a GitHub repository
                # 2. Create a pull request
                # 3. Set up CI/CD pipeline
                
                self.notion.update_task_progress(task_id, 100)
                self.mark_task_completed(task_id)
            else:
                self.mark_task_failed(task_id, "No files generated")
        except Exception as e:
            self.mark_task_failed(task_id, f"Code generation failed: {str(e)}")
    
    def process_api_creation_task(self, task_id: str):
        """
        Process an API creation task
        
        Args:
            task_id: Task ID
        """
        task_data = self.current_tasks[task_id]
        task = task_data['task']
        
        self.update_task_progress(task_id, 30, "Preparing API creation request")
        
        # Extract API definition from task description
        description = task.get('description', '')
        
        # Create API definition
        definition = {
            "name": task.get('title', ''),
            "description": description,
            "endpoints": []
        }
        
        self.update_task_progress(task_id, 40, f"Creating API with Xano Meta API")
        
        try:
            # Call Xano Meta API for API creation
            result = self.xano.create_api(
                definition=definition,
                deploy=False  # Don't deploy automatically
            )
            
            # Update task with results
            self.update_task_progress(task_id, 80, "Processing API creation results")
            
            if result.get('api_id'):
                self.notion.add_task_comment(
                    task_id, 
                    f"Created API in Xano with ID: {result.get('api_id')}"
                )
                
                self.notion.update_task_progress(task_id, 100)
                self.mark_task_completed(task_id)
            else:
                self.mark_task_failed(task_id, "API creation failed: No API ID returned")
        except Exception as e:
            self.mark_task_failed(task_id, f"API creation failed: {str(e)}")
    
    def process_data_analysis_task(self, task_id: str):
        """
        Process a data analysis task
        
        Args:
            task_id: Task ID
        """
        task_data = self.current_tasks[task_id]
        task = task_data['task']
        
        self.update_task_progress(task_id, 30, "Preparing data analysis request")
        
        # Extract data from task description or properties
        properties = task.get('raw_properties', {})
        
        # Mock data for demo
        data = {
            "task_id": task_id,
            "task_title": task.get('title', ''),
            "task_description": task.get('description', '')
        }
        
        self.update_task_progress(task_id, 40, f"Analyzing data with Xano Meta API")
        
        try:
            # Call Xano Meta API for data analysis
            result = self.xano.analyze_data(
                data=data,
                analysis_type='general'
            )
            
            # Update task with results
            self.update_task_progress(task_id, 80, "Processing data analysis results")
            
            if result:
                self.notion.add_task_comment(
                    task_id, 
                    f"Data analysis completed successfully"
                )
                
                self.notion.update_task_progress(task_id, 100)
                self.mark_task_completed(task_id)
            else:
                self.mark_task_failed(task_id, "Data analysis failed: No results returned")
        except Exception as e:
            self.mark_task_failed(task_id, f"Data analysis failed: {str(e)}")
    
    def process_webhook_generation_task(self, task_id: str):
        """
        Process a webhook generation task
        
        Args:
            task_id: Task ID
        """
        task_data = self.current_tasks[task_id]
        task = task_data['task']
        
        self.update_task_progress(task_id, 30, "Preparing webhook generation request")
        
        # Create mock webhook configuration for demo
        sources = [{
            "name": "Source System",
            "type": "notion",
            "config": {"database_id": self.database_id}
        }]
        
        destinations = [{
            "name": "Target System",
            "type": "xano",
            "config": {"api_url": "https://x8ki-letl-twmt.n7.xano.io/api:meta"}
        }]
        
        mappings = [{
            "source_field": "title",
            "destination_field": "name",
            "transform": "identity"
        }]
        
        self.update_task_progress(task_id, 40, f"Generating webhooks with Xano Meta API")
        
        try:
            # Call Xano Meta API for webhook generation
            result = self.xano.generate_webhooks(
                sources=sources,
                destinations=destinations,
                mappings=mappings
            )
            
            # Update task with results
            self.update_task_progress(task_id, 80, "Processing webhook generation results")
            
            if result:
                self.notion.add_task_comment(
                    task_id, 
                    f"Webhook generation completed successfully"
                )
                
                self.notion.update_task_progress(task_id, 100)
                self.mark_task_completed(task_id)
            else:
                self.mark_task_failed(task_id, "Webhook generation failed: No results returned")
        except Exception as e:
            self.mark_task_failed(task_id, f"Webhook generation failed: {str(e)}")
    
    def update_task_progress(self, task_id: str, progress: int, message: Optional[str] = None):
        """
        Update a task's progress
        
        Args:
            task_id: Task ID
            progress: Progress percentage (0-100)
            message: Optional progress message
        """
        if task_id not in self.current_tasks:
            logger.error(f"Task {task_id} not found in current tasks")
            return
        
        # Update progress in our tracking
        self.current_tasks[task_id]['progress'] = progress
        
        # Update in Notion
        self.notion.update_task_progress(task_id, progress)
        
        # Add comment if message provided
        if message:
            self.notion.add_task_comment(task_id, message)
    
    def mark_task_completed(self, task_id: str):
        """
        Mark a task as completed
        
        Args:
            task_id: Task ID
        """
        if task_id not in self.current_tasks:
            logger.error(f"Task {task_id} not found in current tasks")
            return
        
        logger.info(f"Task {task_id} completed")
        
        # Update status and add comment
        self.notion.update_task_status(task_id, "Completed")
        self.notion.update_task_progress(task_id, 100)
        self.notion.add_task_comment(task_id, "Task processing completed successfully")
        
        # Remove from current tasks
        del self.current_tasks[task_id]
    
    def mark_task_failed(self, task_id: str, error_message: str):
        """
        Mark a task as failed
        
        Args:
            task_id: Task ID
            error_message: Error message
        """
        if task_id not in self.current_tasks:
            logger.error(f"Task {task_id} not found in current tasks")
            return
        
        logger.error(f"Task {task_id} failed: {error_message}")
        
        # Update status and add comment
        self.notion.update_task_status(task_id, "Failed")
        self.notion.add_task_comment(task_id, f"Task processing failed: {error_message}")
        
        # Remove from current tasks
        del self.current_tasks[task_id]
    
    def check_task_completion(self):
        """Check for task completion and timeouts"""
        current_time = datetime.now()
        tasks_to_remove = []
        
        for task_id, task_data in self.current_tasks.items():
            start_time = task_data['start_time']
            
            # Check for timeout
            elapsed_seconds = (current_time - start_time).total_seconds()
            if elapsed_seconds > self.task_timeout:
                logger.warning(f"Task {task_id} timed out after {elapsed_seconds:.1f} seconds")
                self.mark_task_failed(task_id, f"Task timed out after {elapsed_seconds:.1f} seconds")
                tasks_to_remove.append(task_id)
        
        # Remove completed tasks
        for task_id in tasks_to_remove:
            if task_id in self.current_tasks:
                del self.current_tasks[task_id]


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='PinkSync Task Processor')
    parser.add_argument('--database', help='Notion database ID')
    parser.add_argument('--interval', type=int, default=DEFAULT_TASK_CHECK_INTERVAL, 
                        help='Task check interval in seconds')
    parser.add_argument('--max-tasks', type=int, default=DEFAULT_MAX_CONCURRENT_TASKS,
                        help='Maximum concurrent tasks')
    parser.add_argument('--timeout', type=int, default=DEFAULT_TASK_TIMEOUT,
                        help='Task timeout in seconds')
    parser.add_argument('--once', action='store_true', 
                        help='Process pending tasks once and exit')
    
    args = parser.parse_args()
    
    # Create configuration
    config = {
        'database_id': args.database,
        'check_interval': args.interval,
        'max_concurrent_tasks': args.max_tasks,
        'task_timeout': args.timeout
    }
    
    # Create and start task processor
    processor = TaskProcessor(config)
    
    if args.once:
        # Process tasks once
        processor.process_pending_tasks()
    else:
        # Start continuous processing
        processor.start()


if __name__ == "__main__":
    main()