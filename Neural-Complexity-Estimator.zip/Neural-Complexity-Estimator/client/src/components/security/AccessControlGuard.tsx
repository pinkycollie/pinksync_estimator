import React, { ReactNode } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ShieldAlert } from 'lucide-react';

interface AccessControlGuardProps {
  /**
   * The permission key required to access the content
   */
  permission?: string;
  
  /**
   * The role ID required to access the content
   */
  role?: string;
  
  /**
   * Multiple permission keys (any one is sufficient if anyPermission=true)
   */
  permissions?: string[];
  
  /**
   * Multiple role IDs (any one is sufficient if anyRole=true)
   */
  roles?: string[];
  
  /**
   * If true, any one of the permissions is sufficient (OR logic)
   * If false, all permissions are required (AND logic)
   */
  anyPermission?: boolean;
  
  /**
   * If true, any one of the roles is sufficient (OR logic)
   * If false, all roles are required (AND logic)
   */
  anyRole?: boolean;
  
  /**
   * The content to display if the user has the required permission/role
   */
  children: ReactNode;
  
  /**
   * Optional content to display if the user lacks permission
   * If not provided, a default access denied message is shown
   */
  fallback?: ReactNode;
  
  /**
   * Whether to hide the component completely when access is denied
   */
  hideOnDenied?: boolean;
}

export const AccessControlGuard: React.FC<AccessControlGuardProps> = ({
  permission,
  role,
  permissions = [],
  roles = [],
  anyPermission = true,
  anyRole = true,
  children,
  fallback,
  hideOnDenied = false
}) => {
  const { hasPermission, hasRole, isAuthenticated, isLoading } = useAuth();
  
  // Add single permission/role to arrays if provided
  if (permission) {
    permissions = [...permissions, permission];
  }
  
  if (role) {
    roles = [...roles, role];
  }
  
  // Don't render anything while still loading auth state
  if (isLoading) {
    return null;
  }
  
  // Check authentication first
  if (!isAuthenticated) {
    if (hideOnDenied) {
      return null;
    }
    
    return fallback || (
      <Alert variant="destructive">
        <ShieldAlert className="h-4 w-4" />
        <AlertTitle>Authentication Required</AlertTitle>
        <AlertDescription>
          You need to be logged in to access this content.
        </AlertDescription>
      </Alert>
    );
  }
  
  // Check permissions
  let hasRequiredPermissions = false;
  if (permissions.length > 0) {
    if (anyPermission) {
      // OR logic - any permission is sufficient
      hasRequiredPermissions = permissions.some(p => hasPermission(p));
    } else {
      // AND logic - all permissions are required
      hasRequiredPermissions = permissions.every(p => hasPermission(p));
    }
  } else {
    // No permissions specified, so this check passes
    hasRequiredPermissions = true;
  }
  
  // Check roles
  let hasRequiredRoles = false;
  if (roles.length > 0) {
    if (anyRole) {
      // OR logic - any role is sufficient
      hasRequiredRoles = roles.some(r => hasRole(r));
    } else {
      // AND logic - all roles are required
      hasRequiredRoles = roles.every(r => hasRole(r));
    }
  } else {
    // No roles specified, so this check passes
    hasRequiredRoles = true;
  }
  
  // Determine if access is granted
  const hasAccess = hasRequiredPermissions && hasRequiredRoles;
  
  if (hasAccess) {
    return <>{children}</>;
  }
  
  if (hideOnDenied) {
    return null;
  }
  
  return fallback || (
    <Alert variant="destructive">
      <ShieldAlert className="h-4 w-4" />
      <AlertTitle>Access Denied</AlertTitle>
      <AlertDescription>
        You don't have sufficient permissions to access this content.
      </AlertDescription>
    </Alert>
  );
};

export default AccessControlGuard;