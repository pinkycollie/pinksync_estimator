import { Button } from '@/components/ui/button';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useState } from 'react';

interface NotionDatabase {
  id: string;
  type: string;
  name: string;
  description?: string;
  schema?: Record<string, any>;
  customMapping?: Record<string, string>;
}

interface NotionDatabaseListProps {
  databases: NotionDatabase[];
  connectionId: string;
  defaultDatabase?: string;
  onRemove: (connectionId: string, databaseId: string) => void;
  onSetDefault: (connectionId: string, databaseId: string) => void;
  isLoading: boolean;
}

export function NotionDatabaseList({
  databases,
  connectionId,
  defaultDatabase,
  onRemove,
  onSetDefault,
  isLoading
}: NotionDatabaseListProps) {
  const [databaseToRemove, setDatabaseToRemove] = useState<string | null>(null);

  // Format the database type for display
  const formatDatabaseType = (type: string) => {
    return type.charAt(0).toUpperCase() + type.slice(1).toLowerCase();
  };

  const handleRemove = () => {
    if (databaseToRemove) {
      onRemove(connectionId, databaseToRemove);
      setDatabaseToRemove(null);
    }
  };

  if (databases.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>No Databases</CardTitle>
          <CardDescription>
            No databases have been added to this connection yet.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Add a database to start syncing content between PinkSync and Notion.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {databases.map((database) => (
        <Card key={database.id} className={`transition-colors ${defaultDatabase === database.id ? 'border-primary' : ''}`}>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="truncate">{database.name}</CardTitle>
              <Badge>{formatDatabaseType(database.type)}</Badge>
            </div>
            <CardDescription>
              {database.description || 'No description provided'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {defaultDatabase === database.id && (
              <Badge variant="outline" className="bg-primary/10">Default Database</Badge>
            )}
          </CardContent>
          <CardFooter className="flex justify-between">
            {defaultDatabase !== database.id ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onSetDefault(connectionId, database.id)}
              >
                Set as Default
              </Button>
            ) : (
              <div />
            )}
            <AlertDialog open={databaseToRemove === database.id} onOpenChange={(open) => !open && setDatabaseToRemove(null)}>
              <AlertDialogTrigger asChild>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => setDatabaseToRemove(database.id)}
                  disabled={isLoading}
                >
                  Remove
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Remove Database</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to remove the "{database.name}" database?
                    This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleRemove}>
                    Remove
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardFooter>
        </Card>
      ))}

      {/* Confirmation Dialog for Removing Database */}
      <AlertDialog open={!!databaseToRemove} onOpenChange={(open) => !open && setDatabaseToRemove(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Database</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove this database?
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleRemove}>
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}