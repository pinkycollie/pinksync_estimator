import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { DialogFooter } from '@/components/ui/dialog';

// Form schema for adding Notion connection
const connectionSchema = z.object({
  name: z.string().min(1, { message: 'Name is required' }),
  authToken: z.string().min(1, { message: 'Auth token is required' }),
  workspaceId: z.string().optional(),
  webhookUrl: z.string().url({ message: 'Must be a valid URL' }).optional().or(z.literal('')),
  isActive: z.boolean().default(true),
});

type ConnectionFormValues = z.infer<typeof connectionSchema>;

interface NotionConnectionFormProps {
  onSubmit: (data: ConnectionFormValues) => void;
  isLoading: boolean;
  initialData?: Partial<ConnectionFormValues>;
}

export function NotionConnectionForm({ onSubmit, isLoading, initialData }: NotionConnectionFormProps) {
  const form = useForm<ConnectionFormValues>({
    resolver: zodResolver(connectionSchema),
    defaultValues: {
      name: initialData?.name || '',
      authToken: initialData?.authToken || '',
      workspaceId: initialData?.workspaceId || '',
      webhookUrl: initialData?.webhookUrl || '',
      isActive: initialData?.isActive !== undefined ? initialData.isActive : true,
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Connection Name</FormLabel>
              <FormControl>
                <Input placeholder="My Notion Connection" {...field} />
              </FormControl>
              <FormDescription>
                A descriptive name for this Notion connection
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="authToken"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Auth Token</FormLabel>
              <FormControl>
                <Input type="password" placeholder="secret_..." {...field} />
              </FormControl>
              <FormDescription>
                Your Notion integration API token
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="workspaceId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Workspace ID (Optional)</FormLabel>
              <FormControl>
                <Input placeholder="Notion workspace ID" {...field} />
              </FormControl>
              <FormDescription>
                Your Notion workspace ID if you want to limit this connection to a specific workspace
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="webhookUrl"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Webhook URL (Optional)</FormLabel>
              <FormControl>
                <Input placeholder="https://your-webhook-url.com" {...field} />
              </FormControl>
              <FormDescription>
                URL where Notion will send webhook events
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="isActive"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <FormLabel className="text-base">Active</FormLabel>
                <FormDescription>
                  Whether this connection is active and should be used for syncing
                </FormDescription>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <DialogFooter>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? 'Adding...' : 'Add Connection'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}