import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { DialogFooter } from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

// Form schema for adding Notion database
const databaseSchema = z.object({
  type: z.string().min(1, { message: 'Database type is required' }),
  name: z.string().min(1, { message: 'Name is required' }),
  description: z.string().optional(),
});

type DatabaseFormValues = z.infer<typeof databaseSchema>;

interface NotionDatabaseType {
  id: string;
  name: string;
  description: string;
}

interface NotionDatabaseFormProps {
  connectionId: string;
  databaseTypes: NotionDatabaseType[];
  onSubmit: (connectionId: string, data: DatabaseFormValues) => void;
  isLoading: boolean;
  initialData?: Partial<DatabaseFormValues>;
}

export function NotionDatabaseForm({ 
  connectionId, 
  databaseTypes, 
  onSubmit, 
  isLoading, 
  initialData 
}: NotionDatabaseFormProps) {
  const form = useForm<DatabaseFormValues>({
    resolver: zodResolver(databaseSchema),
    defaultValues: {
      type: initialData?.type || '',
      name: initialData?.name || '',
      description: initialData?.description || '',
    },
  });

  const handleSubmit = (data: DatabaseFormValues) => {
    onSubmit(connectionId, data);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="type"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Database Type</FormLabel>
              <Select 
                onValueChange={field.onChange} 
                defaultValue={field.value}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a database type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {databaseTypes.map((type) => (
                    <SelectItem 
                      key={type.id} 
                      value={type.id}
                    >
                      {type.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormDescription>
                The type of content this database will store
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Database Name</FormLabel>
              <FormControl>
                <Input placeholder="Ideas Database" {...field} />
              </FormControl>
              <FormDescription>
                A descriptive name for this database
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description (Optional)</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Database for storing entrepreneurial ideas..." 
                  {...field} 
                />
              </FormControl>
              <FormDescription>
                A brief description of this database's purpose
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <DialogFooter>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? 'Adding...' : 'Add Database'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}