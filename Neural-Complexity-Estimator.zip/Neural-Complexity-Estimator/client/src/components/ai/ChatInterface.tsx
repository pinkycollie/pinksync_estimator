import React, { useState, useRef, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Send, Trash, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/hooks/useAuth';

// Define message type
interface ChatMessage {
  role: 'system' | 'user' | 'assistant' | 'function';
  content: string;
  name?: string;
}

interface ChatInterfaceProps {
  systemPrompt?: string;
  placeholder?: string;
  modelId?: string;
  showControls?: boolean;
  maxHeight?: string;
}

export function ChatInterface({
  systemPrompt = "You're a helpful AI assistant. Provide concise, accurate responses.",
  placeholder = "Type your message here...",
  modelId = "gpt-4o",
  showControls = true,
  maxHeight = "600px"
}: ChatInterfaceProps) {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isFirstMessage, setIsFirstMessage] = useState(true);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  
  // Scroll to bottom whenever messages change
  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  // Add system message if it doesn't exist
  useEffect(() => {
    if (isFirstMessage && systemPrompt) {
      const hasSystemMessage = messages.some(msg => msg.role === 'system');
      if (!hasSystemMessage) {
        setMessages([{ role: 'system', content: systemPrompt }]);
      }
      setIsFirstMessage(false);
    }
  }, [isFirstMessage, messages, systemPrompt]);

  // Query for AI models
  const { data: aiModels } = useQuery({
    queryKey: ['/api/ai/models'],
    retry: false,
  });

  // Chat message mutation
  const chatMutation = useMutation({
    mutationFn: async (newMessages: ChatMessage[]) => {
      return await apiRequest('/api/ai/generate', 'POST', {
        messages: newMessages.filter(msg => msg.role !== 'system'),
        model: modelId,
      });
    },
    onSuccess: (data) => {
      setMessages(prev => [
        ...prev,
        { role: 'assistant', content: data.content }
      ]);
      queryClient.invalidateQueries({ queryKey: ['/api/ai/models'] });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to get AI response. Please try again.',
        variant: 'destructive',
      });
    }
  });

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    const userMessage: ChatMessage = { role: 'user', content: input };
    const newMessages = [...messages, userMessage];
    
    setMessages(newMessages);
    setInput('');
    
    // Filter out system messages for the API request and send
    const apiMessages = newMessages.filter(msg => msg.role !== 'system');
    
    // If there's a system message, add it as the first message in the API request
    const systemMsg = messages.find(msg => msg.role === 'system');
    if (systemMsg) {
      apiMessages.unshift(systemMsg);
    }
    
    chatMutation.mutate(newMessages);
  };

  // Clear chat history
  const handleClearChat = () => {
    setMessages(systemPrompt ? [{ role: 'system', content: systemPrompt }] : []);
    setIsFirstMessage(true);
  };

  return (
    <Card className="flex flex-col w-full h-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Avatar className="h-6 w-6">
              <AvatarImage src="/logo.png" alt="AI" />
              <AvatarFallback>AI</AvatarFallback>
            </Avatar>
            <span>AI Chat</span>
          </div>
          
          {showControls && (
            <Button variant="ghost" size="icon" onClick={handleClearChat}>
              <Trash className="h-4 w-4" />
            </Button>
          )}
        </CardTitle>
      </CardHeader>
      
      <Separator />
      
      <ScrollArea 
        ref={scrollAreaRef} 
        className="flex-1 p-4"
        style={{ maxHeight }}
      >
        <div className="flex flex-col gap-4">
          {messages.filter(msg => msg.role !== 'system').map((message, index) => (
            <div
              key={index}
              className={`flex ${
                message.role === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.role === 'user'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted'
                }`}
              >
                <p className="whitespace-pre-wrap">{message.content}</p>
              </div>
            </div>
          ))}
          
          {chatMutation.isPending && (
            <div className="flex justify-start">
              <div className="max-w-[80%] rounded-lg p-3 bg-muted flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                <p>Thinking...</p>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>
      
      <Separator />
      
      <CardContent className="pt-4">
        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={placeholder}
            disabled={chatMutation.isPending}
            className="flex-1"
          />
          <Button 
            type="submit" 
            size="icon"
            disabled={chatMutation.isPending || !input.trim()}
          >
            {chatMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

export default ChatInterface;