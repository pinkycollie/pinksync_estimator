import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Loader2, FileText, AlertCircle, Check } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface TextEmbedderProps {
  title?: string;
}

export function TextEmbedder({
  title = "Text Embeddings Generator",
}: TextEmbedderProps) {
  const [inputText, setInputText] = useState('');
  const [embedding, setEmbedding] = useState<number[] | null>(null);
  const { toast } = useToast();

  // Text embedding mutation
  const embeddingMutation = useMutation({
    mutationFn: async (text: string) => {
      return await apiRequest('/api/ai/embeddings', 'POST', {
        text: text,
      });
    },
    onSuccess: (data) => {
      setEmbedding(data.embeddings);
      toast({
        title: 'Embeddings Generated',
        description: `Successfully generated ${data.embeddings.length} dimensional vector embedding.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to Generate Embeddings',
        description: error.message || 'An error occurred. Please try again.',
        variant: 'destructive',
      });
    }
  });

  // Handle generate embeddings
  const handleGenerateEmbeddings = () => {
    if (!inputText.trim()) {
      toast({
        title: 'Empty Text',
        description: 'Please enter some text to generate embeddings for.',
        variant: 'destructive',
      });
      return;
    }

    embeddingMutation.mutate(inputText.trim());
  };

  // Format embedding for display
  const formatEmbedding = (emb: number[] | null): string => {
    if (!emb) return '';
    
    // If embedding is very large, truncate it
    if (emb.length > 20) {
      const firstPart = emb.slice(0, 10).map(n => n.toFixed(6)).join(', ');
      const lastPart = emb.slice(-10).map(n => n.toFixed(6)).join(', ');
      return `[${firstPart}, ... (${emb.length - 20} more values) ..., ${lastPart}]`;
    }
    
    return '[' + emb.map(n => n.toFixed(6)).join(', ') + ']';
  };

  // Copy embeddings to clipboard
  const copyEmbeddings = () => {
    if (!embedding) return;
    
    navigator.clipboard.writeText(JSON.stringify(embedding))
      .then(() => {
        toast({
          title: 'Copied to Clipboard',
          description: 'The embedding vector has been copied to your clipboard.',
        });
      })
      .catch(() => {
        toast({
          title: 'Copy Failed',
          description: 'Failed to copy embeddings to clipboard.',
          variant: 'destructive',
        });
      });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      
      <Separator />
      
      <CardContent className="pt-4">
        <div className="flex flex-col gap-4">
          {/* Text input */}
          <div>
            <label className="text-sm font-medium mb-1 block">Input Text</label>
            <Textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Enter text to generate embeddings for..."
              rows={5}
              disabled={embeddingMutation.isPending}
            />
          </div>
          
          {/* Generate button */}
          <Button 
            onClick={handleGenerateEmbeddings} 
            disabled={!inputText.trim() || embeddingMutation.isPending}
            className="w-full"
          >
            {embeddingMutation.isPending ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <FileText className="h-4 w-4 mr-2" />
                Generate Embeddings
              </>
            )}
          </Button>
          
          {/* Results section */}
          {(embedding || embeddingMutation.isPending) && (
            <div className="mt-2">
              <div className="flex justify-between items-center mb-1">
                <div className="text-sm font-medium">Embedding Vector</div>
                {embedding && (
                  <div className="flex items-center gap-2">
                    <div className="text-sm text-muted-foreground">
                      {embedding.length} dimensions
                    </div>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button 
                            size="sm" 
                            variant="outline" 
                            onClick={copyEmbeddings}
                          >
                            <Check className="h-3 w-3 mr-1" />
                            Copy
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Copy full embedding to clipboard</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                )}
              </div>
              
              {embeddingMutation.isPending ? (
                <div className="flex items-center justify-center p-8 border rounded-md">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <pre className="p-4 border rounded-md bg-muted/30 overflow-x-auto text-sm">
                  {formatEmbedding(embedding)}
                </pre>
              )}
            </div>
          )}
          
          {embeddingMutation.isError && (
            <div className="p-4 border rounded-md bg-destructive/10 text-destructive flex gap-2 items-start">
              <AlertCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">Failed to generate embeddings</p>
                <p className="text-sm">
                  {(embeddingMutation.error as any)?.message || 
                    'There was an error generating embeddings. Please try again.'}
                </p>
              </div>
            </div>
          )}
          
          {/* Information about embeddings */}
          <div className="mt-2 p-4 border rounded-md bg-muted/30 text-sm">
            <p className="font-medium mb-1">About Vector Embeddings</p>
            <p>
              Vector embeddings represent text as numerical vectors that capture semantic meaning.
              They can be used for semantic search, clustering similar content, and building 
              recommendation systems.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default TextEmbedder;