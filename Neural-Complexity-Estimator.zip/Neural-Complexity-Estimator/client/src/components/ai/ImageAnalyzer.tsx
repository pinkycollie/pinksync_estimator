import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Loader2, Upload, Image as ImageIcon, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface ImageAnalyzerProps {
  title?: string;
  defaultPrompt?: string;
}

export function ImageAnalyzer({
  title = "AI Image Analysis",
  defaultPrompt = "Analyze this image in detail. What do you see?"
}: ImageAnalyzerProps) {
  const [image, setImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState(defaultPrompt);
  const [description, setDescription] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Image analysis mutation
  const analysisMutation = useMutation({
    mutationFn: async ({imageBase64, promptText}: {imageBase64: string, promptText: string}) => {
      return await apiRequest('/api/ai/analyze-image', 'POST', {
        image: imageBase64,
        prompt: promptText
      });
    },
    onSuccess: (data) => {
      setDescription(data.description);
    },
    onError: (error: any) => {
      toast({
        title: 'Analysis Failed',
        description: error.message || 'Failed to analyze image. Please try again.',
        variant: 'destructive',
      });
    }
  });

  // Handle file upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Only allow image files
    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Invalid File',
        description: 'Please upload an image file (JPG, PNG, etc.)',
        variant: 'destructive',
      });
      return;
    }

    // Check file size (limit to 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: 'File Too Large',
        description: 'Please upload an image smaller than 5MB',
        variant: 'destructive',
      });
      return;
    }

    // Read the file and convert to base64
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setImage(event.target.result.toString());
      }
    };
    reader.readAsDataURL(file);
  };

  // Handle analyze button click
  const handleAnalyze = () => {
    if (!image) {
      toast({
        title: 'No Image',
        description: 'Please upload an image first',
        variant: 'destructive',
      });
      return;
    }

    analysisMutation.mutate({
      imageBase64: image.split(',')[1], // Remove the data URL prefix
      promptText: prompt
    });
  };

  // Handle reset
  const handleReset = () => {
    setImage(null);
    setDescription('');
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      
      <Separator />
      
      <CardContent className="pt-4">
        <div className="flex flex-col gap-4">
          {/* Image upload/preview area */}
          <div 
            className={`border-2 border-dashed rounded-lg p-4 flex items-center justify-center 
              ${image ? 'border-primary' : 'border-muted-foreground'}`}
            style={{ minHeight: '200px' }}
          >
            {image ? (
              <div className="relative w-full h-full">
                <img 
                  src={image} 
                  alt="Preview" 
                  className="max-w-full max-h-[300px] mx-auto object-contain rounded-md"
                />
                <Button 
                  variant="destructive" 
                  size="sm" 
                  className="absolute top-2 right-2 opacity-80"
                  onClick={handleReset}
                >
                  Clear
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 text-muted-foreground p-8">
                <ImageIcon className="h-12 w-12" />
                <p>Drag & drop an image or click to upload</p>
                <Button 
                  variant="outline" 
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Select Image
                </Button>
              </div>
            )}
            <Input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
              disabled={analysisMutation.isPending}
            />
          </div>
          
          {/* Prompt input */}
          <div>
            <label className="text-sm font-medium mb-1 block">Analysis Prompt</label>
            <Textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="What would you like to know about this image?"
              rows={2}
              disabled={analysisMutation.isPending}
            />
          </div>
          
          {/* Analyze button */}
          <Button 
            onClick={handleAnalyze} 
            disabled={!image || analysisMutation.isPending}
            className="w-full"
          >
            {analysisMutation.isPending ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Analyzing...
              </>
            ) : (
              'Analyze Image'
            )}
          </Button>
          
          {/* Analysis results */}
          {(description || analysisMutation.isPending) && (
            <div className="mt-4">
              <div className="text-sm font-medium mb-1">Analysis Results</div>
              {analysisMutation.isPending ? (
                <div className="flex items-center justify-center p-8 border rounded-md">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <div className="p-4 border rounded-md bg-muted/30">
                  <p className="whitespace-pre-wrap">{description}</p>
                </div>
              )}
            </div>
          )}
          
          {analysisMutation.isError && (
            <div className="p-4 border rounded-md bg-destructive/10 text-destructive flex gap-2 items-start">
              <AlertCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">Analysis failed</p>
                <p className="text-sm">
                  {(analysisMutation.error as any)?.message || 
                    'There was an error analyzing the image. Please try again.'}
                </p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export default ImageAnalyzer;