import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Brain, Eye, MessageSquare, Workflow, Folder, Search, BarChart3, Github, Monitor, Play, RefreshCw } from 'lucide-react';

interface AnalysisResult {
  cognitiveLoad: number;
  visualAccessibility: number;
  languageComplexity: number;
  workflowComplexity: number;
  overallScore: number;
  recommendations: string[];
  riskFactors: string[];
}

interface Project {
  name: string;
  path: string;
  type: string;
  description: string;
  file_count: number;
  estimated_size: string;
  technologies: string[];
  complexity_indicators: {
    cognitive_load: number;
    visual_dependency: number;
    language_complexity: number;
    workflow_complexity: number;
  };
}

interface BatchAnalysisResult {
  total_projects: number;
  analysis_results: Array<{
    project_name: string;
    project_type: string;
    file_count: number;
    estimated_size: string;
    complexity_analysis: AnalysisResult;
  }>;
  aggregate_insights: {
    average_cognitive_load: number;
    average_visual_accessibility: number;
    average_language_complexity: number;
    average_workflow_complexity: number;
    complexity_distribution: {
      low: number;
      medium: number;
      high: number;
    };
  };
  deaf_accessibility_recommendations: string[];
}

interface GitHubRepository {
  name: string;
  full_name: string;
  description: string;
  language: string;
  size: number;
  stars: number;
  forks: number;
  complexity_indicators: {
    cognitive_load: number;
    visual_dependency: number;
    language_complexity: number;
    workflow_complexity: number;
  };
  accessibility_concerns: string[];
}

interface SyncStatus {
  monitoring_active: boolean;
  last_scan_time: string | null;
  projects_cached: number;
  pending_queue: number;
  recent_changes: number;
  workspace_path: string;
}

export default function NCEDashboard() {
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [batchAnalysis, setBatchAnalysis] = useState<BatchAnalysisResult | null>(null);
  const [githubRepos, setGithubRepos] = useState<GitHubRepository[]>([]);
  const [syncStatus, setSyncStatus] = useState<SyncStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [scanningProjects, setScanningProjects] = useState(false);
  const [discoveringGithub, setDiscoveringGithub] = useState(false);
  const [startingSync, setStartingSync] = useState(false);
  const [error, setError] = useState('');
  
  // Input form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [content, setContent] = useState('');
  const [domain, setDomain] = useState('general');

  const scanProjects = async () => {
    setScanningProjects(true);
    setError('');
    
    try {
      const response = await fetch('/api/scan-projects');
      
      if (!response.ok) throw new Error('Project scanning failed');
      
      const result = await response.json();
      setProjects(result.projects);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Project scanning failed');
    } finally {
      setScanningProjects(false);
    }
  };

  const discoverGithubRepos = async () => {
    setDiscoveringGithub(true);
    setError('');
    
    try {
      const response = await fetch('/api/github-repositories');
      
      if (!response.ok) throw new Error('GitHub repository discovery failed');
      
      const result = await response.json();
      setGithubRepos(result.repositories || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'GitHub repository discovery failed');
    } finally {
      setDiscoveringGithub(false);
    }
  };

  const startSyncMonitoring = async () => {
    setStartingSync(true);
    setError('');
    
    try {
      const response = await fetch('/api/start-sync-monitoring', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (!response.ok) throw new Error('Failed to start sync monitoring');
      
      const result = await response.json();
      // Refresh sync status after starting
      setTimeout(checkSyncStatus, 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to start sync monitoring');
    } finally {
      setStartingSync(false);
    }
  };

  const checkSyncStatus = async () => {
    try {
      const response = await fetch('/api/sync-status');
      
      if (response.ok) {
        const result = await response.json();
        setSyncStatus(result.sync_status);
      }
    } catch (err) {
      console.error('Failed to check sync status:', err);
    }
  };

  const analyzeBatchProjects = async () => {
    if (projects.length === 0) {
      setError('No projects found. Please scan for projects first.');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const response = await fetch('/api/analyze-projects-batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projects })
      });
      
      if (!response.ok) throw new Error('Batch analysis failed');
      
      const result = await response.json();
      setBatchAnalysis(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Batch analysis failed');
    } finally {
      setLoading(false);
    }
  };

  const analyzeComplexity = async () => {
    if (!title && !description && !content) {
      setError('Please provide at least a title, description, or content to analyze');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const response = await fetch('/api/analyze-complexity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          description,
          content,
          domain
        })
      });
      
      if (!response.ok) throw new Error('Analysis failed');
      
      const result = await response.json();
      setAnalysis(result.analysis);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Analysis failed');
    } finally {
      setLoading(false);
    }
  };

  const loadExampleData = () => {
    setTitle('Legal Document Platform');
    setDescription('A comprehensive platform for processing and managing legal documents with multi-step workflows');
    setContent('This platform requires users to upload legal documents, review complex terms and conditions, navigate through multi-step approval processes, coordinate with multiple stakeholders, and understand detailed legal terminology. The system includes visual diagrams, color-coded status indicators, and requires sequential processing of information with strict deadlines.');
    setDomain('legal');
  };

  const getScoreColor = (score: number) => {
    if (score < 30) return 'text-green-600';
    if (score < 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreLabel = (score: number) => {
    if (score < 30) return 'Low';
    if (score < 60) return 'Moderate';
    return 'High';
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Neural Complexity Estimator
        </h1>
        <p className="text-lg text-gray-600">
          Deaf-first cognitive modeling for accessibility analysis
        </p>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="single" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="single" className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4" />
            Single Analysis
          </TabsTrigger>
          <TabsTrigger value="projects" className="flex items-center gap-2">
            <Folder className="w-4 h-4" />
            Local Projects
          </TabsTrigger>
          <TabsTrigger value="github" className="flex items-center gap-2">
            <Github className="w-4 h-4" />
            GitHub Repos
          </TabsTrigger>
          <TabsTrigger value="sync" className="flex items-center gap-2">
            <Monitor className="w-4 h-4" />
            File Sync
          </TabsTrigger>
          <TabsTrigger value="batch" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Batch Analysis
          </TabsTrigger>
        </TabsList>

        <TabsContent value="single" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Content Analysis</CardTitle>
                <CardDescription>
                  Analyze content complexity for Deaf and hard-of-hearing accessibility
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Title</label>
                  <Input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Enter content title"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Description</label>
                  <Textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Enter content description"
                    rows={3}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Content</label>
                  <Textarea
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="Enter detailed content for analysis"
                    rows={5}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Domain</label>
                  <Select value={domain} onValueChange={setDomain}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">General</SelectItem>
                      <SelectItem value="legal">Legal</SelectItem>
                      <SelectItem value="technical">Technical</SelectItem>
                      <SelectItem value="medical">Medical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex gap-2">
                  <Button onClick={analyzeComplexity} disabled={loading} className="flex-1">
                    {loading ? 'Analyzing...' : 'Analyze Complexity'}
                  </Button>
                  <Button onClick={loadExampleData} variant="outline">
                    Load Example
                  </Button>
                </div>
              </CardContent>
            </Card>

            {analysis && (
              <Card>
                <CardHeader>
                  <CardTitle>Analysis Results</CardTitle>
                  <CardDescription>
                    Deaf-first cognitive complexity assessment
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-3xl font-bold text-gray-900 mb-1">
                      {analysis.overallScore}
                    </div>
                    <div className="text-sm text-gray-600">Overall Complexity Score</div>
                    <Badge variant="secondary" className="mt-2">
                      {getScoreLabel(analysis.overallScore)} Complexity
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center gap-3 p-3 border rounded-lg">
                      <Brain className="w-5 h-5 text-purple-600" />
                      <div>
                        <div className={`font-semibold ${getScoreColor(analysis.cognitiveLoad)}`}>
                          {analysis.cognitiveLoad}
                        </div>
                        <div className="text-xs text-gray-600">Cognitive Load</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 border rounded-lg">
                      <Eye className="w-5 h-5 text-blue-600" />
                      <div>
                        <div className={`font-semibold ${getScoreColor(analysis.visualAccessibility)}`}>
                          {analysis.visualAccessibility}
                        </div>
                        <div className="text-xs text-gray-600">Visual Access</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 border rounded-lg">
                      <MessageSquare className="w-5 h-5 text-green-600" />
                      <div>
                        <div className={`font-semibold ${getScoreColor(analysis.languageComplexity)}`}>
                          {analysis.languageComplexity}
                        </div>
                        <div className="text-xs text-gray-600">Language</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 border rounded-lg">
                      <Workflow className="w-5 h-5 text-orange-600" />
                      <div>
                        <div className={`font-semibold ${getScoreColor(analysis.workflowComplexity)}`}>
                          {analysis.workflowComplexity}
                        </div>
                        <div className="text-xs text-gray-600">Workflow</div>
                      </div>
                    </div>
                  </div>

                  {analysis.recommendations.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">ASL-Compatible Recommendations</h4>
                      <ul className="space-y-1">
                        {analysis.recommendations.map((rec, index) => (
                          <li key={index} className="text-sm text-gray-700 flex items-start gap-2">
                            <span className="text-green-600 mt-0.5">•</span>
                            {rec}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {analysis.riskFactors.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Risk Factors</h4>
                      <ul className="space-y-1">
                        {analysis.riskFactors.map((risk, index) => (
                          <li key={index} className="text-sm text-gray-700 flex items-start gap-2">
                            <span className="text-red-600 mt-0.5">•</span>
                            {risk}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="github" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Github className="w-5 h-5" />
                GitHub Repository Discovery
              </CardTitle>
              <CardDescription>
                Discover and analyze GitHub repositories for Deaf-first accessibility
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button 
                onClick={discoverGithubRepos} 
                disabled={discoveringGithub}
                className="w-full"
              >
                {discoveringGithub ? 'Discovering Repositories...' : 'Discover GitHub Repositories'}
              </Button>

              {githubRepos.length > 0 && (
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">
                    Found {githubRepos.length} GitHub Repositories
                  </h3>
                  
                  <div className="grid gap-4 max-h-96 overflow-y-auto">
                    {githubRepos.slice(0, 20).map((repo, index) => (
                      <div key={index} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium">{repo.name}</h4>
                          <div className="flex gap-2">
                            <Badge variant="outline">{repo.language}</Badge>
                            <Badge variant="secondary">{repo.stars} ⭐</Badge>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">
                          {repo.description || 'No description available'}
                        </p>
                        <div className="grid grid-cols-4 gap-2 text-xs mb-2">
                          <div>Cognitive: {repo.complexity_indicators.cognitive_load}</div>
                          <div>Visual: {repo.complexity_indicators.visual_dependency}</div>
                          <div>Language: {repo.complexity_indicators.language_complexity}</div>
                          <div>Workflow: {repo.complexity_indicators.workflow_complexity}</div>
                        </div>
                        {repo.accessibility_concerns.length > 0 && (
                          <div className="mt-2">
                            <div className="text-xs font-medium text-red-600 mb-1">Accessibility Concerns:</div>
                            <div className="text-xs text-red-600">
                              {repo.accessibility_concerns.slice(0, 2).join(', ')}
                              {repo.accessibility_concerns.length > 2 && '...'}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sync" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Monitor className="w-5 h-5" />
                File System Synchronization
              </CardTitle>
              <CardDescription>
                Real-time file monitoring and project synchronization
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Button 
                  onClick={startSyncMonitoring} 
                  disabled={startingSync}
                  variant="default"
                >
                  {startingSync ? <RefreshCw className="w-4 h-4 animate-spin mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                  {startingSync ? 'Starting...' : 'Start Monitoring'}
                </Button>
                <Button 
                  onClick={checkSyncStatus} 
                  variant="outline"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Check Status
                </Button>
              </div>

              {syncStatus && (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="text-center p-3 border rounded-lg">
                    <div className={`text-lg font-bold ${syncStatus.monitoring_active ? 'text-green-600' : 'text-gray-600'}`}>
                      {syncStatus.monitoring_active ? 'Active' : 'Inactive'}
                    </div>
                    <div className="text-sm text-gray-600">Monitoring Status</div>
                  </div>
                  <div className="text-center p-3 border rounded-lg">
                    <div className="text-lg font-bold text-blue-600">
                      {syncStatus.projects_cached}
                    </div>
                    <div className="text-sm text-gray-600">Projects Cached</div>
                  </div>
                  <div className="text-center p-3 border rounded-lg">
                    <div className="text-lg font-bold text-orange-600">
                      {syncStatus.recent_changes}
                    </div>
                    <div className="text-sm text-gray-600">Recent Changes</div>
                  </div>
                </div>
              )}

              {syncStatus?.last_scan_time && (
                <div className="text-sm text-gray-600">
                  Last scan: {new Date(syncStatus.last_scan_time).toLocaleString()}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="projects" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="w-5 h-5" />
                Local Project Discovery
              </CardTitle>
              <CardDescription>
                Scan local file system to discover projects for complexity analysis
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button 
                onClick={scanProjects} 
                disabled={scanningProjects}
                className="w-full"
              >
                {scanningProjects ? 'Scanning Projects...' : 'Scan File System'}
              </Button>

              {projects.length > 0 && (
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">
                    Found {projects.length} Projects
                  </h3>
                  
                  <div className="grid gap-4">
                    {projects.slice(0, 10).map((project, index) => (
                      <div key={index} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium">{project.name}</h4>
                          <Badge variant="outline">{project.type}</Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">
                          {project.description || 'No description available'}
                        </p>
                        <div className="flex gap-4 text-xs text-gray-500">
                          <span>{project.file_count} files</span>
                          <span>{project.estimated_size} size</span>
                          <span>{project.technologies.slice(0, 3).join(', ')}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Button 
                    onClick={analyzeBatchProjects}
                    disabled={loading}
                    className="w-full"
                    variant="default"
                  >
                    {loading ? 'Analyzing Projects...' : 'Analyze All Projects'}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="batch" className="mt-6">
          {batchAnalysis ? (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    Batch Analysis Results
                  </CardTitle>
                  <CardDescription>
                    Cognitive complexity analysis for {batchAnalysis.total_projects} projects
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">
                        {batchAnalysis.aggregate_insights.average_cognitive_load}
                      </div>
                      <div className="text-sm text-gray-600">Avg Cognitive Load</div>
                    </div>
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">
                        {batchAnalysis.aggregate_insights.average_visual_accessibility}
                      </div>
                      <div className="text-sm text-gray-600">Avg Visual Access</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        {batchAnalysis.aggregate_insights.average_language_complexity}
                      </div>
                      <div className="text-sm text-gray-600">Avg Language</div>
                    </div>
                    <div className="text-center p-4 bg-orange-50 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">
                        {batchAnalysis.aggregate_insights.average_workflow_complexity}
                      </div>
                      <div className="text-sm text-gray-600">Avg Workflow</div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-3">Complexity Distribution</h4>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center p-3 border rounded-lg">
                        <div className="text-xl font-bold text-green-600">
                          {batchAnalysis.aggregate_insights.complexity_distribution.low}
                        </div>
                        <div className="text-sm text-gray-600">Low Complexity</div>
                      </div>
                      <div className="text-center p-3 border rounded-lg">
                        <div className="text-xl font-bold text-yellow-600">
                          {batchAnalysis.aggregate_insights.complexity_distribution.medium}
                        </div>
                        <div className="text-sm text-gray-600">Medium Complexity</div>
                      </div>
                      <div className="text-center p-3 border rounded-lg">
                        <div className="text-xl font-bold text-red-600">
                          {batchAnalysis.aggregate_insights.complexity_distribution.high}
                        </div>
                        <div className="text-sm text-gray-600">High Complexity</div>
                      </div>
                    </div>
                  </div>

                  {batchAnalysis.deaf_accessibility_recommendations.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-3">ASL-Compatible Recommendations</h4>
                      <ul className="space-y-2">
                        {batchAnalysis.deaf_accessibility_recommendations.map((rec, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <span className="text-green-600 mt-0.5">•</span>
                            {rec}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div>
                    <h4 className="font-semibold mb-3">Individual Project Analysis</h4>
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {batchAnalysis.analysis_results.map((result, index) => (
                        <div key={index} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-medium">{result.project_name}</h5>
                            <Badge variant={result.complexity_analysis.overallScore > 60 ? 'destructive' : 'secondary'}>
                              {result.complexity_analysis.overallScore} complexity
                            </Badge>
                          </div>
                          <div className="grid grid-cols-4 gap-2 text-xs">
                            <div>Cognitive: {result.complexity_analysis.cognitiveLoad}</div>
                            <div>Visual: {result.complexity_analysis.visualAccessibility}</div>
                            <div>Language: {result.complexity_analysis.languageComplexity}</div>
                            <div>Workflow: {result.complexity_analysis.workflowComplexity}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Batch Analysis</CardTitle>
                <CardDescription>
                  Run project discovery first to analyze multiple projects
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Switch to the Project Discovery tab to scan for projects, then return here to view batch analysis results.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}