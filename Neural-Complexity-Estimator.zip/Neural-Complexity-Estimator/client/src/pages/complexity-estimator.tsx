import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Loader2, Brain, Clock, Users, DollarSign, AlertTriangle, CheckCircle } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

const projectRequirementsSchema = z.object({
  title: z.string().min(1, 'Project title is required'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  features: z.string().min(1, 'At least one feature is required'),
  techStack: z.string().optional(),
  targetPlatforms: z.string().optional(),
  teamSize: z.coerce.number().optional(),
  budget: z.coerce.number().optional(),
  deadline: z.string().optional(),
  existingAssets: z.string().optional()
});

type ProjectRequirements = z.infer<typeof projectRequirementsSchema>;

interface ComplexityAnalysis {
  overallComplexity: 'low' | 'medium' | 'high' | 'very-high';
  complexityScore: number;
  estimatedTimelineWeeks: number;
  confidenceLevel: number;
  breakdown: {
    technicalComplexity: number;
    integrationComplexity: number;
    uiUxComplexity: number;
    dataComplexity: number;
    securityComplexity: number;
  };
  recommendations: {
    suggestedTechStack: string[];
    phaseBreakdown: Array<{
      name: string;
      description: string;
      estimatedWeeks: number;
      dependencies: string[];
      deliverables: string[];
      riskLevel: 'low' | 'medium' | 'high';
    }>;
    riskFactors: Array<{
      factor: string;
      impact: 'low' | 'medium' | 'high';
      probability: 'low' | 'medium' | 'high';
      mitigation: string;
    }>;
    resourceRequirements: {
      developers: {
        frontend: number;
        backend: number;
        fullstack: number;
        mobile?: number;
        devops?: number;
      };
      designers: number;
      projectManagers: number;
      estimatedBudgetRange: {
        min: number;
        max: number;
      };
    };
  };
  similarProjects: string[];
  estimationReasoning: string;
}

export default function ComplexityEstimator() {
  const [analysis, setAnalysis] = useState<ComplexityAnalysis | null>(null);

  const form = useForm<ProjectRequirements>({
    resolver: zodResolver(projectRequirementsSchema),
    defaultValues: {
      title: '',
      description: '',
      features: '',
      techStack: '',
      targetPlatforms: '',
      teamSize: undefined,
      budget: undefined,
      deadline: '',
      existingAssets: ''
    }
  });

  const analyzeComplexity = useMutation({
    mutationFn: async (data: ProjectRequirements) => {
      const payload = {
        ...data,
        features: data.features.split('\n').filter(f => f.trim()),
        techStack: data.techStack ? data.techStack.split(',').map(t => t.trim()) : undefined,
        targetPlatforms: data.targetPlatforms ? data.targetPlatforms.split(',').map(p => p.trim()) : undefined,
        existingAssets: data.existingAssets ? data.existingAssets.split(',').map(a => a.trim()) : undefined
      };

      return await apiRequest('/api/complexity/analyze', {
        method: 'POST',
        data: payload
      });
    },
    onSuccess: (data) => {
      setAnalysis(data.analysis);
    }
  });

  const onSubmit = (data: ProjectRequirements) => {
    analyzeComplexity.mutate(data);
  };

  const getComplexityColor = (complexity: string) => {
    switch (complexity) {
      case 'low': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      case 'high': return 'bg-orange-500';
      case 'very-high': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-600 bg-green-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'high': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="container mx-auto py-8 px-4 max-w-6xl">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2 flex items-center justify-center gap-2">
          <Brain className="h-8 w-8 text-primary" />
          AI-Powered Project Complexity Estimator
        </h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Get intelligent estimates for your project's complexity, timeline, and resource requirements using advanced AI analysis.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Input Form */}
        <Card>
          <CardHeader>
            <CardTitle>Project Requirements</CardTitle>
            <CardDescription>
              Provide details about your project to get accurate complexity analysis
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Project Title</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., E-commerce Platform with AI Recommendations" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Project Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe what your project does, its main goals, and key functionality..."
                          className="min-h-[100px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="features"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Features (one per line)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder={`User authentication
Product catalog
Shopping cart
Payment processing
Admin dashboard
Mobile app`}
                          className="min-h-[120px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="teamSize"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Team Size</FormLabel>
                        <FormControl>
                          <Input type="number" placeholder="5" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="budget"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Budget ($)</FormLabel>
                        <FormControl>
                          <Input type="number" placeholder="50000" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="techStack"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Preferred Tech Stack (comma-separated)</FormLabel>
                      <FormControl>
                        <Input placeholder="React, Node.js, PostgreSQL, AWS" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="targetPlatforms"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Target Platforms (comma-separated)</FormLabel>
                      <FormControl>
                        <Input placeholder="Web, iOS, Android" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="deadline"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Desired Deadline</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., 6 months, Q2 2024" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={analyzeComplexity.isPending}
                >
                  {analyzeComplexity.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing Complexity...
                    </>
                  ) : (
                    <>
                      <Brain className="mr-2 h-4 w-4" />
                      Analyze Project Complexity
                    </>
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Analysis Results */}
        <div className="space-y-6">
          {analyzeComplexity.error && (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 text-red-600">
                  <AlertTriangle className="h-5 w-5" />
                  <span className="font-medium">Analysis Failed</span>
                </div>
                <p className="text-red-600 mt-1">
                  {analyzeComplexity.error instanceof Error ? analyzeComplexity.error.message : 'An error occurred'}
                </p>
              </CardContent>
            </Card>
          )}

          {analysis && (
            <>
              {/* Overall Complexity */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    Complexity Analysis Complete
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">Overall Complexity</span>
                      <Badge className={`${getComplexityColor(analysis.overallComplexity)} text-white`}>
                        {analysis.overallComplexity.toUpperCase()}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Complexity Score</span>
                        <span className="font-medium">{analysis.complexityScore}/10</span>
                      </div>
                      <Progress value={analysis.complexityScore * 10} className="h-2" />
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-4">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm text-muted-foreground">Timeline</p>
                          <p className="font-medium">{analysis.estimatedTimelineWeeks} weeks</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm text-muted-foreground">Confidence</p>
                          <p className="font-medium">{Math.round(analysis.confidenceLevel * 100)}%</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Complexity Breakdown */}
              <Card>
                <CardHeader>
                  <CardTitle>Complexity Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(analysis.breakdown).map(([key, value]) => (
                      <div key={key} className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span className="capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                          <span className="font-medium">{value}/10</span>
                        </div>
                        <Progress value={value * 10} className="h-1" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Resource Requirements */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Resource Requirements
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Development Team</h4>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Frontend: {analysis.recommendations.resourceRequirements.developers.frontend}</div>
                        <div>Backend: {analysis.recommendations.resourceRequirements.developers.backend}</div>
                        <div>Full-stack: {analysis.recommendations.resourceRequirements.developers.fullstack}</div>
                        {analysis.recommendations.resourceRequirements.developers.mobile && (
                          <div>Mobile: {analysis.recommendations.resourceRequirements.developers.mobile}</div>
                        )}
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="text-sm text-muted-foreground">Designers</span>
                        <p className="font-medium">{analysis.recommendations.resourceRequirements.designers}</p>
                      </div>
                      <div>
                        <span className="text-sm text-muted-foreground">Project Managers</span>
                        <p className="font-medium">{analysis.recommendations.resourceRequirements.projectManagers}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm text-muted-foreground">Estimated Budget Range</p>
                        <p className="font-medium">
                          ${analysis.recommendations.resourceRequirements.estimatedBudgetRange.min.toLocaleString()} - 
                          ${analysis.recommendations.resourceRequirements.estimatedBudgetRange.max.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Risk Factors */}
              {analysis.recommendations.riskFactors.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5" />
                      Risk Factors
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {analysis.recommendations.riskFactors.slice(0, 3).map((risk, index) => (
                        <div key={index} className="p-3 border rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={getRiskColor(risk.impact)} variant="secondary">
                              {risk.impact} impact
                            </Badge>
                            <Badge className={getRiskColor(risk.probability)} variant="secondary">
                              {risk.probability} probability
                            </Badge>
                          </div>
                          <p className="font-medium text-sm mb-1">{risk.factor}</p>
                          <p className="text-xs text-muted-foreground">{risk.mitigation}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Suggested Tech Stack */}
              {analysis.recommendations.suggestedTechStack.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Suggested Tech Stack</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {analysis.recommendations.suggestedTechStack.map((tech, index) => (
                        <Badge key={index} variant="outline">{tech}</Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}