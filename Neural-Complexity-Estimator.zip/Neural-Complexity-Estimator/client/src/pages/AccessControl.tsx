import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, ShieldCheck, Key, Lock, FileCheck, Cpu, BarChart3, Settings } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';

const AccessControl: React.FC = () => {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  // Fetch user roles
  const { data: rolesData, isLoading: rolesLoading } = useQuery({
    queryKey: ['/api/access/roles'],
    enabled: isAuthenticated,
  });

  // Request file watcher role mutation
  const requestFileWatcherMutation = useMutation({
    mutationFn: async () => {
      setLoading(true);
      const response = await fetch('/api/access/roles/request-file-watcher', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to request file watcher role');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Access Granted',
        description: 'File watcher role has been assigned successfully.',
        variant: 'default',
      });
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/access/roles'] });
      queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
    onSettled: () => {
      setLoading(false);
    },
  });
  
  // Request AI access role mutation
  const requestAIAccessMutation = useMutation({
    mutationFn: async () => {
      setLoading(true);
      const response = await fetch('/api/access/roles/request-ai-access', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to request AI access role');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Access Granted',
        description: 'AI access has been granted successfully.',
        variant: 'default',
      });
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/access/roles'] });
      queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
    onSettled: () => {
      setLoading(false);
    },
  });

  // Check if user has specific permissions
  const hasFileWatcherAccess = user?.accessControl?.permissions?.fileWatcher || false;
  const hasFileAutomationAccess = user?.accessControl?.permissions?.fileAutomation || false;
  const hasAccessControlAccess = user?.accessControl?.permissions?.accessControl || false;
  const hasAIAccess = user?.accessControl?.permissions?.useAI || false;
  const hasAIAdminAccess = user?.accessControl?.permissions?.aiAdmin || false;
  const hasAIAnalyticsAccess = user?.accessControl?.permissions?.aiAnalytics || false;

  if (isLoading || rolesLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="animate-pulse">
          <div className="bg-muted h-8 w-1/4 mb-4 rounded"></div>
          <div className="bg-muted h-32 w-full rounded"></div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="container mx-auto p-6">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Authentication Required</AlertTitle>
          <AlertDescription>
            You need to be logged in to access this page. Please log in to continue.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Access Control</h1>
          <p className="text-muted-foreground mt-2">
            Manage your access permissions and security roles
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5" />
                <span>Your Access Roles</span>
              </CardTitle>
              <CardDescription>
                Roles determine what operations you can perform in the system
              </CardDescription>
            </CardHeader>
            <CardContent>
              {user?.accessControl?.roles && user.accessControl.roles.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {user.accessControl.roles.map((role: any) => (
                    <Badge key={role.id} variant="secondary" className="text-sm py-1">
                      {role.description}
                    </Badge>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  You don't have any specific roles assigned yet.
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="h-5 w-5" />
                <span>Permissions</span>
              </CardTitle>
              <CardDescription>
                Your current access permissions in the system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileCheck className="h-4 w-4 text-muted-foreground" />
                    <span>File Watching</span>
                  </div>
                  <Badge variant={hasFileWatcherAccess ? "default" : "outline"}>
                    {hasFileWatcherAccess ? "Granted" : "Not Granted"}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                      className="h-4 w-4 text-muted-foreground"
                    >
                      <path d="M12 19c0-4.2-2.8-7-7-7m14 0c-4.2 0-7 2.8-7 7M8 12V4m4 8V4m4 8V4" />
                    </svg>
                    <span>File Automation</span>
                  </div>
                  <Badge variant={hasFileAutomationAccess ? "default" : "outline"}>
                    {hasFileAutomationAccess ? "Granted" : "Not Granted"}
                  </Badge>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Lock className="h-4 w-4 text-muted-foreground" />
                    <span>Access Control Admin</span>
                  </div>
                  <Badge variant={hasAccessControlAccess ? "default" : "outline"}>
                    {hasAccessControlAccess ? "Granted" : "Not Granted"}
                  </Badge>
                </div>

                <Separator className="my-2" />

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Cpu className="h-4 w-4 text-muted-foreground" />
                    <span>AI Hub Access</span>
                  </div>
                  <Badge variant={hasAIAccess ? "default" : "outline"}>
                    {hasAIAccess ? "Granted" : "Not Granted"}
                  </Badge>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Settings className="h-4 w-4 text-muted-foreground" />
                    <span>AI Administration</span>
                  </div>
                  <Badge variant={hasAIAdminAccess ? "default" : "outline"}>
                    {hasAIAdminAccess ? "Granted" : "Not Granted"}
                  </Badge>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <BarChart3 className="h-4 w-4 text-muted-foreground" />
                    <span>AI Analytics</span>
                  </div>
                  <Badge variant={hasAIAnalyticsAccess ? "default" : "outline"}>
                    {hasAIAnalyticsAccess ? "Granted" : "Not Granted"}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {!hasFileWatcherAccess && (
            <Card>
              <CardHeader>
                <CardTitle>File Watcher Access</CardTitle>
                <CardDescription>
                  Monitor file changes across platforms
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  File watcher access allows you to monitor file changes across your devices and set up 
                  automated actions based on file events.
                </p>
              </CardContent>
              <CardFooter>
                <Button 
                  onClick={() => requestFileWatcherMutation.mutate()}
                  disabled={loading || requestFileWatcherMutation.isPending}
                >
                  {loading || requestFileWatcherMutation.isPending ? 
                    'Requesting...' : 'Request Access'}
                </Button>
              </CardFooter>
            </Card>
          )}

          {!hasAIAccess && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cpu className="h-5 w-5" />
                  <span>AI Hub Access</span>
                </CardTitle>
                <CardDescription>
                  Use AI features for productivity
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  AI Hub access lets you use AI capabilities including document analysis, 
                  content generation, and personal assistant features.
                </p>
              </CardContent>
              <CardFooter>
                <Button 
                  onClick={() => requestAIAccessMutation.mutate()}
                  disabled={loading || requestAIAccessMutation.isPending}
                >
                  {loading || requestAIAccessMutation.isPending ? 
                    'Requesting...' : 'Request AI Access'}
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default AccessControl;