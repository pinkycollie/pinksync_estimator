import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

const AstraDocumentManager: React.FC = () => {
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('upload');
  const [collection, setCollection] = useState('');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  
  // Fetch collections
  const { data: collections = [], isLoading: isLoadingCollections, refetch: refetchCollections } = 
    useQuery<string[]>({
      queryKey: ['/api/astra/collections'],
      enabled: isAuthenticated
    });
  
  // Handle file change
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setUploadFile(e.target.files[0]);
    }
  };
  
  // Create a new collection
  const createCollection = async () => {
    if (!collection) {
      toast({
        title: 'Error',
        description: 'Please enter a collection name',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      const response = await fetch('/api/astra/collections', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ collection }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to create collection');
      }
      
      toast({
        title: 'Success',
        description: `Collection "${collection}" created successfully`,
      });
      
      refetchCollections();
      setCollection('');
    } catch (error) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create collection',
        variant: 'destructive',
      });
    }
  };
  
  // Upload file
  const uploadDocument = async () => {
    if (!uploadFile || !collection) {
      toast({
        title: 'Error',
        description: 'Please select a file and collection',
        variant: 'destructive',
      });
      return;
    }
    
    setIsUploading(true);
    setUploadProgress(0);
    
    try {
      const formData = new FormData();
      formData.append('file', uploadFile);
      formData.append('collection', collection);
      formData.append('generateIds', 'true');
      
      const response = await fetch('/api/astra/upload-file', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to upload document');
      }
      
      const result = await response.json();
      
      toast({
        title: 'Upload Successful',
        description: `Uploaded ${result.success} documents to "${collection}"`,
      });
      
      setUploadFile(null);
      if (document.getElementById('file-upload') as HTMLInputElement) {
        (document.getElementById('file-upload') as HTMLInputElement).value = '';
      }
    } catch (error) {
      toast({
        title: 'Upload Failed',
        description: error.message || 'Failed to upload document',
        variant: 'destructive',
      });
    } finally {
      setIsUploading(false);
      setUploadProgress(100);
      
      // Reset progress after a delay
      setTimeout(() => {
        setUploadProgress(0);
      }, 1000);
    }
  };
  
  // Search documents
  const searchDocuments = async () => {
    if (!collection) {
      toast({
        title: 'Error',
        description: 'Please select a collection',
        variant: 'destructive',
      });
      return;
    }
    
    setIsSearching(true);
    
    try {
      // Create a basic query
      let query = {};
      
      // If search query is provided, try to parse it as JSON
      if (searchQuery) {
        try {
          query = JSON.parse(searchQuery);
        } catch (e) {
          // If not valid JSON, search for text in any field
          query = { $text: { $search: searchQuery } };
        }
      }
      
      const response = await fetch('/api/astra/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          collection,
          query,
          limit: 50,
        }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to search documents');
      }
      
      const results = await response.json();
      setSearchResults(results);
      
      toast({
        title: 'Search Complete',
        description: `Found ${results.length} document(s)`,
      });
    } catch (error) {
      toast({
        title: 'Search Failed',
        description: error.message || 'Failed to search documents',
        variant: 'destructive',
      });
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };
  
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Astra DB Document Manager</h1>
      
      {!isAuthenticated ? (
        <Card>
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>
              Please log in to access the document manager.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => window.location.href = '/api/login'}>
              Log in with Replit
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="upload">Upload Documents</TabsTrigger>
              <TabsTrigger value="search">Search Documents</TabsTrigger>
              <TabsTrigger value="collections">Manage Collections</TabsTrigger>
            </TabsList>
            
            {/* Upload Tab */}
            <TabsContent value="upload">
              <Card>
                <CardHeader>
                  <CardTitle>Upload Documents</CardTitle>
                  <CardDescription>
                    Upload JSON, CSV, or TXT files to your Astra DB collections.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="collection-select">Collection</Label>
                    <select
                      id="collection-select"
                      className="w-full p-2 border rounded"
                      value={collection}
                      onChange={(e) => setCollection(e.target.value)}
                      disabled={isUploading}
                    >
                      <option value="">Select a collection</option>
                      {collections.map((col) => (
                        <option key={col} value={col}>{col}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="file-upload">File (.json, .csv, .txt)</Label>
                    <Input
                      id="file-upload"
                      type="file"
                      accept=".json,.csv,.txt"
                      onChange={handleFileChange}
                      disabled={isUploading}
                    />
                  </div>
                  
                  {uploadProgress > 0 && (
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div
                        className="bg-blue-600 h-2.5 rounded-full"
                        style={{ width: `${uploadProgress}%` }}
                      ></div>
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button 
                    onClick={uploadDocument} 
                    disabled={!uploadFile || !collection || isUploading}
                  >
                    {isUploading ? 'Uploading...' : 'Upload File'}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            {/* Search Tab */}
            <TabsContent value="search">
              <Card>
                <CardHeader>
                  <CardTitle>Search Documents</CardTitle>
                  <CardDescription>
                    Search for documents in your Astra DB collections.
                    You can enter simple text or a JSON query.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="search-collection">Collection</Label>
                    <select
                      id="search-collection"
                      className="w-full p-2 border rounded"
                      value={collection}
                      onChange={(e) => setCollection(e.target.value)}
                      disabled={isSearching}
                    >
                      <option value="">Select a collection</option>
                      {collections.map((col) => (
                        <option key={col} value={col}>{col}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="search-query">
                      Search Query (text or JSON)
                    </Label>
                    <Input
                      id="search-query"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder='e.g. "customer" or {"field": "value"}'
                      disabled={isSearching}
                    />
                  </div>
                  
                  <Button 
                    onClick={searchDocuments} 
                    disabled={!collection || isSearching}
                    className="w-full"
                  >
                    {isSearching ? 'Searching...' : 'Search'}
                  </Button>
                  
                  {searchResults.length > 0 && (
                    <div className="mt-4">
                      <h3 className="text-lg font-medium mb-2">
                        Search Results ({searchResults.length})
                      </h3>
                      <ScrollArea className="h-[400px] rounded border p-4">
                        {searchResults.map((result, index) => (
                          <div key={index} className="mb-4 pb-4 border-b">
                            <div className="flex justify-between items-start">
                              <h4 className="font-medium">
                                Document ID: {result._id}
                              </h4>
                              {result._tags && result._tags.length > 0 && (
                                <div className="flex flex-wrap gap-1">
                                  {result._tags.map((tag: string, i: number) => (
                                    <Badge key={i} variant="outline">{tag}</Badge>
                                  ))}
                                </div>
                              )}
                            </div>
                            <pre className="mt-2 text-sm bg-gray-100 p-2 rounded overflow-x-auto">
                              {JSON.stringify(result, null, 2)}
                            </pre>
                          </div>
                        ))}
                      </ScrollArea>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Collections Tab */}
            <TabsContent value="collections">
              <Card>
                <CardHeader>
                  <CardTitle>Manage Collections</CardTitle>
                  <CardDescription>
                    Create and manage your Astra DB collections.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-end gap-4">
                    <div className="flex-1 space-y-2">
                      <Label htmlFor="new-collection">New Collection Name</Label>
                      <Input
                        id="new-collection"
                        value={collection}
                        onChange={(e) => setCollection(e.target.value)}
                        placeholder="Enter collection name"
                      />
                    </div>
                    <Button onClick={createCollection}>
                      Create Collection
                    </Button>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <div>
                    <h3 className="text-lg font-medium mb-2">Your Collections</h3>
                    {isLoadingCollections ? (
                      <p>Loading collections...</p>
                    ) : collections.length === 0 ? (
                      <p>No collections found. Create one to get started.</p>
                    ) : (
                      <ul className="space-y-2">
                        {collections.map((col) => (
                          <li 
                            key={col} 
                            className="p-2 border rounded flex justify-between items-center"
                          >
                            <span>{col}</span>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => {
                                setCollection(col);
                                setActiveTab('search');
                              }}
                            >
                              View Documents
                            </Button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
};

export default AstraDocumentManager;