import React, { useState, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { Camera, Hand, Eye, Shield, Users, Globe, Mic, MessageSquare } from 'lucide-react';

interface BiometricData {
  motionData: number[][];
  handPositions: number[][];
  facialExpressions?: number[];
  confidence?: number;
}

interface AuthResult {
  success: boolean;
  confidence: number;
  sessionId?: string;
  error?: string;
}

export default function SignLanguageAuth() {
  const [activeTab, setActiveTab] = useState('overview');
  const [isCapturing, setIsCapturing] = useState(false);
  const [biometricData, setBiometricData] = useState<BiometricData | null>(null);
  const [authResult, setAuthResult] = useState<AuthResult | null>(null);
  const [selectedLanguage, setSelectedLanguage] = useState('ASL');
  const [isEnrolling, setIsEnrolling] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const { toast } = useToast();

  const signLanguages = [
    { code: 'ASL', name: 'American Sign Language', region: 'US/CA' },
    { code: 'BSL', name: 'British Sign Language', region: 'UK' },
    { code: 'Auslan', name: 'Australian Sign Language', region: 'AU' },
    { code: 'NZSL', name: 'New Zealand Sign Language', region: 'NZ' },
    { code: 'JSL', name: 'Japanese Sign Language', region: 'JP' },
    { code: 'CSL', name: 'Chinese Sign Language', region: 'CN' }
  ];

  const startCapture = useCallback(async () => {
    try {
      setIsCapturing(true);
      
      // Request camera access
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480 } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }

      // Simulate motion capture for demonstration
      setTimeout(() => {
        const mockData: BiometricData = {
          motionData: Array.from({ length: 50 }, () => 
            Array.from({ length: 3 }, () => Math.random() * 100)
          ),
          handPositions: Array.from({ length: 20 }, () => 
            Array.from({ length: 2 }, () => Math.random() * 640)
          ),
          facialExpressions: Array.from({ length: 10 }, () => Math.random()),
          confidence: 0.85 + Math.random() * 0.1
        };
        
        setBiometricData(mockData);
        setIsCapturing(false);
        
        // Stop camera
        stream.getTracks().forEach(track => track.stop());
        
        toast({
          title: "Motion Captured",
          description: "Sign language biometric data captured successfully",
        });
      }, 3000);

    } catch (error) {
      console.error('Camera access error:', error);
      setIsCapturing(false);
      toast({
        title: "Camera Error",
        description: "Unable to access camera. Please check permissions.",
        variant: "destructive"
      });
    }
  }, [toast]);

  const authenticateWithBiometrics = async () => {
    if (!biometricData) {
      toast({
        title: "No Data",
        description: "Please capture biometric data first",
        variant: "destructive"
      });
      return;
    }

    try {
      const response = await fetch('/api/v1/auth/sign-biometric', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          signData: {
            id: `bio_${Date.now()}`,
            signaturePoints: biometricData.handPositions,
            motionPattern: biometricData.motionData.flat(),
            spatialCoordinates: biometricData.handPositions,
            timestamp: Date.now(),
            confidence: biometricData.confidence || 0.8
          },
          deviceInfo: {
            deviceId: 'demo_device',
            ipAddress: '127.0.0.1',
            userAgent: navigator.userAgent
          }
        })
      });

      const result = await response.json();
      setAuthResult(result);

      if (result.success) {
        toast({
          title: "Authentication Successful",
          description: `Confidence: ${(result.confidence * 100).toFixed(1)}%`,
        });
      } else {
        toast({
          title: "Authentication Failed",
          description: result.error || "Biometric verification failed",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Authentication error:', error);
      toast({
        title: "Authentication Error",
        description: "Service temporarily unavailable",
        variant: "destructive"
      });
    }
  };

  const enrollBiometrics = async () => {
    if (!biometricData) {
      toast({
        title: "No Data",
        description: "Please capture biometric data first",
        variant: "destructive"
      });
      return;
    }

    setIsEnrolling(true);

    try {
      const templates = [{
        id: `template_${Date.now()}`,
        signaturePoints: biometricData.handPositions,
        motionPattern: biometricData.motionData.flat(),
        spatialCoordinates: biometricData.handPositions,
        timestamp: Date.now(),
        confidence: biometricData.confidence || 0.8
      }];

      const response = await fetch('/api/v1/users/1/biometrics/enroll', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ templates })
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: "Enrollment Successful",
          description: "Biometric template saved securely",
        });
      } else {
        toast({
          title: "Enrollment Failed",
          description: "Failed to save biometric template",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Enrollment error:', error);
      toast({
        title: "Enrollment Error",
        description: "Service temporarily unavailable",
        variant: "destructive"
      });
    } finally {
      setIsEnrolling(false);
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-primary">Sign Language Authentication</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Advanced biometric authentication system designed specifically for the Deaf community, 
          featuring sign language recognition and cultural adaptation.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="biometric">Biometric Auth</TabsTrigger>
          <TabsTrigger value="translation">Translation</TabsTrigger>
          <TabsTrigger value="cultural">Cultural</TabsTrigger>
          <TabsTrigger value="developer">Developer</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <Hand className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Sign Biometric Auth</CardTitle>
                <CardDescription>
                  Secure authentication using unique signing patterns and hand movements
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Badge variant="secondary">Real-time Recognition</Badge>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Globe className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Multi-Language Support</CardTitle>
                <CardDescription>
                  Support for ASL, BSL, Auslan, and other major sign languages
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Badge variant="secondary">{signLanguages.length} Languages</Badge>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Users className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Cultural Integration</CardTitle>
                <CardDescription>
                  Regional variants and community-specific terminology support
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Badge variant="secondary">Community Driven</Badge>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <MessageSquare className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Translation Engine</CardTitle>
                <CardDescription>
                  Bidirectional translation between sign and spoken languages
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Badge variant="secondary">AI Powered</Badge>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Shield className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Security & Privacy</CardTitle>
                <CardDescription>
                  End-to-end encryption with zero-knowledge architecture
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Badge variant="secondary">Military Grade</Badge>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Eye className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Accessibility First</CardTitle>
                <CardDescription>
                  Designed with Deaf community needs and feedback at the core
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Badge variant="secondary">WCAG 2.2 AAA</Badge>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="biometric" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Sign Language Biometric Authentication</CardTitle>
              <CardDescription>
                Capture and authenticate using your unique signing patterns
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <Label htmlFor="language">Preferred Sign Language</Label>
                  <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your sign language" />
                    </SelectTrigger>
                    <SelectContent>
                      {signLanguages.map((lang) => (
                        <SelectItem key={lang.code} value={lang.code}>
                          {lang.name} ({lang.region})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <div className="relative">
                    <video
                      ref={videoRef}
                      className="w-full h-64 bg-gray-100 rounded-lg"
                      playsInline
                      muted
                    />
                    {isCapturing && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-lg">
                        <div className="text-center text-white">
                          <Camera className="h-12 w-12 mx-auto mb-2 animate-pulse" />
                          <p>Capturing motion data...</p>
                          <Progress value={66} className="w-32 mx-auto mt-2" />
                        </div>
                      </div>
                    )}
                  </div>

                  <Button
                    onClick={startCapture}
                    disabled={isCapturing}
                    className="w-full"
                  >
                    {isCapturing ? 'Capturing...' : 'Start Motion Capture'}
                  </Button>
                </div>

                <div className="space-y-4">
                  {biometricData && (
                    <Alert>
                      <Hand className="h-4 w-4" />
                      <AlertDescription>
                        Motion data captured: {biometricData.motionData.length} frames, 
                        Confidence: {((biometricData.confidence || 0) * 100).toFixed(1)}%
                      </AlertDescription>
                    </Alert>
                  )}

                  <div className="space-y-3">
                    <Button
                      onClick={authenticateWithBiometrics}
                      disabled={!biometricData}
                      className="w-full"
                      variant="default"
                    >
                      Authenticate with Biometrics
                    </Button>

                    <Button
                      onClick={enrollBiometrics}
                      disabled={!biometricData || isEnrolling}
                      className="w-full"
                      variant="outline"
                    >
                      {isEnrolling ? 'Enrolling...' : 'Enroll Biometric Template'}
                    </Button>
                  </div>

                  {authResult && (
                    <Alert className={authResult.success ? 'border-green-500' : 'border-red-500'}>
                      <Shield className="h-4 w-4" />
                      <AlertDescription>
                        {authResult.success 
                          ? `Authentication successful! Confidence: ${(authResult.confidence * 100).toFixed(1)}%`
                          : `Authentication failed: ${authResult.error}`
                        }
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="translation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Sign Language Translation</CardTitle>
              <CardDescription>
                Translate between sign language and text/voice
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center text-muted-foreground py-8">
                <MessageSquare className="h-16 w-16 mx-auto mb-4" />
                <p>Translation interface will be available in the next update</p>
                <p className="text-sm mt-2">Features: Sign-to-text, Text-to-sign, Voice integration</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cultural" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Cultural Adaptation</CardTitle>
              <CardDescription>
                Regional variants and community-specific terminology
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center text-muted-foreground py-8">
                <Users className="h-16 w-16 mx-auto mb-4" />
                <p>Cultural integration features will be available in the next update</p>
                <p className="text-sm mt-2">Features: Regional variants, Community contributions, Cultural context</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="developer" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Developer API</CardTitle>
              <CardDescription>
                Integration endpoints for third-party applications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-medium">Authentication Endpoints</h4>
                  <code className="text-sm bg-muted p-2 rounded block">POST /api/v1/auth/sign-biometric</code>
                  <code className="text-sm bg-muted p-2 rounded block">POST /api/v1/auth/motion-password</code>
                  <code className="text-sm bg-muted p-2 rounded block">GET /api/v1/auth/sessions/:id</code>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">Translation Endpoints</h4>
                  <code className="text-sm bg-muted p-2 rounded block">POST /api/v1/translate/sign-to-text</code>
                  <code className="text-sm bg-muted p-2 rounded block">POST /api/v1/translate/text-to-sign</code>
                  <code className="text-sm bg-muted p-2 rounded block">GET /api/v1/translate/supported-languages</code>
                </div>
              </div>
              
              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  All API endpoints require proper authentication and follow strict rate limiting policies.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}