import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useParams, Link } from 'wouter';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { Trash2, Plus, ArrowLeft, Edit2, FileText, AlertTriangle, Check, X, Settings, Pause, Play } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { apiRequest } from '@/lib/queryClient';

// Define validation schemas
const automationRuleSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters'),
  description: z.string().optional(),
  eventType: z.enum(['add', 'change', 'unlink', 'addDir', 'unlinkDir', 'all']),
  filePattern: z.string().min(1, 'File pattern is required'),
  active: z.boolean().default(true)
});

const automationActionSchema = z.object({
  type: z.enum(['notify', 'move', 'copy', 'delete', 'rename', 'sync', 'extract', 'execute', 'googleSheets']),
  config: z.record(z.any()).default({}),
  active: z.boolean().default(true)
});

const notifyConfigSchema = z.object({
  message: z.string().optional()
});

const moveConfigSchema = z.object({
  destinationPath: z.string().min(1, 'Destination path is required'),
  createDirectories: z.boolean().default(true),
  overwrite: z.boolean().default(false)
});

const copyConfigSchema = z.object({
  destinationPath: z.string().min(1, 'Destination path is required'),
  createDirectories: z.boolean().default(true),
  overwrite: z.boolean().default(false)
});

const renameConfigSchema = z.object({
  pattern: z.string().min(1, 'Pattern is required'),
  replacement: z.string().min(1, 'Replacement is required'),
  overwrite: z.boolean().default(false)
});

const deleteConfigSchema = z.object({
  confirmation: z.boolean().refine(val => val === true, {
    message: 'You must confirm deletion'
  })
});

const googleSheetsConfigSchema = z.object({
  eventType: z.string().min(1, 'Event type is required'),
  data: z.record(z.any()).optional()
});

// Interface types based on the backend
interface WatchConfig {
  id: string;
  name: string;
  path: string;
  excludePaths: string[];
  isRecursive: boolean;
  watchForPatterns: string[];
  ignorePatterns: string[];
  active: boolean;
  createdAt: string;
  automationRules: AutomationRule[];
}

interface AutomationRule {
  id: string;
  name: string;
  description?: string;
  eventType: 'add' | 'change' | 'unlink' | 'addDir' | 'unlinkDir' | 'all';
  filePattern: string;
  actions: AutomationAction[];
  active: boolean;
}

interface AutomationAction {
  id: string;
  type: 'notify' | 'move' | 'copy' | 'delete' | 'rename' | 'sync' | 'extract' | 'execute' | 'googleSheets';
  config: Record<string, any>;
  active: boolean;
}

interface FileEvent {
  id: string;
  watchId: string;
  eventType: string;
  filePath: string;
  relativePath: string;
  timestamp: string;
  fileStats?: any;
  automationResults?: AutomationResult[];
}

interface AutomationResult {
  id: string;
  ruleId: string;
  ruleName: string;
  successful: boolean;
  actions: {
    id: string;
    type: string;
    successful: boolean;
    message?: string;
    details?: any;
  }[];
  timestamp: string;
}

// Add rule form component
const AddRuleForm = ({ configId, onClose }: { configId: string; onClose: () => void }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<z.infer<typeof automationRuleSchema>>({
    resolver: zodResolver(automationRuleSchema),
    defaultValues: {
      name: '',
      description: '',
      eventType: 'all',
      filePattern: '*',
      active: true
    }
  });
  
  const { mutate: addRule, isPending } = useMutation({
    mutationFn: (data: z.infer<typeof automationRuleSchema>) => 
      apiRequest(`/api/file-watch/configs/${configId}/rules`, {
        method: 'POST',
        data
      }),
    onSuccess: () => {
      toast({
        title: 'Rule added',
        description: 'Automation rule has been added successfully.'
      });
      queryClient.invalidateQueries({ queryKey: [`/api/file-watch/configs/${configId}`] });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to add rule',
        description: error.message || 'An error occurred while adding the rule.',
        variant: 'destructive'
      });
    }
  });
  
  const onSubmit = (data: z.infer<typeof automationRuleSchema>) => {
    addRule(data);
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Rule Name</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Move PDF Files" />
              </FormControl>
              <FormDescription>
                A descriptive name for this automation rule.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description (Optional)</FormLabel>
              <FormControl>
                <Textarea 
                  {...field} 
                  placeholder="This rule moves all PDF files to the archive folder"
                  className="resize-none"
                  rows={3}
                />
              </FormControl>
              <FormDescription>
                A detailed description of what this rule does.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="eventType"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Event Type</FormLabel>
              <Select 
                onValueChange={field.onChange} 
                defaultValue={field.value}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select an event type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="all">All Events</SelectItem>
                  <SelectItem value="add">File Added</SelectItem>
                  <SelectItem value="change">File Changed</SelectItem>
                  <SelectItem value="unlink">File Deleted</SelectItem>
                  <SelectItem value="addDir">Directory Added</SelectItem>
                  <SelectItem value="unlinkDir">Directory Deleted</SelectItem>
                </SelectContent>
              </Select>
              <FormDescription>
                The type of file event that will trigger this rule.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="filePattern"
          render={({ field }) => (
            <FormItem>
              <FormLabel>File Pattern</FormLabel>
              <FormControl>
                <Input {...field} placeholder="*.pdf" />
              </FormControl>
              <FormDescription>
                Pattern to match file paths (e.g., "*.pdf", "documents/*")
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="active"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <FormLabel className="text-base">Active</FormLabel>
                <FormDescription>
                  Whether this rule is active.
                </FormDescription>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <DialogFooter>
          <Button 
            type="button" 
            variant="outline" 
            onClick={onClose}
            disabled={isPending}
          >
            Cancel
          </Button>
          <Button type="submit" disabled={isPending}>
            {isPending ? 'Adding...' : 'Add Rule'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
};

// Add action form component
const AddActionForm = ({ configId, ruleId, onClose }: { configId: string; ruleId: string; onClose: () => void }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [actionType, setActionType] = useState<string>('notify');
  
  // Form for the basic action details
  const form = useForm<z.infer<typeof automationActionSchema>>({
    resolver: zodResolver(automationActionSchema),
    defaultValues: {
      type: 'notify',
      config: {},
      active: true
    }
  });
  
  // Form for notify action config
  const notifyForm = useForm<z.infer<typeof notifyConfigSchema>>({
    resolver: zodResolver(notifyConfigSchema),
    defaultValues: {
      message: ''
    }
  });
  
  // Form for move action config
  const moveForm = useForm<z.infer<typeof moveConfigSchema>>({
    resolver: zodResolver(moveConfigSchema),
    defaultValues: {
      destinationPath: '',
      createDirectories: true,
      overwrite: false
    }
  });
  
  // Form for copy action config
  const copyForm = useForm<z.infer<typeof copyConfigSchema>>({
    resolver: zodResolver(copyConfigSchema),
    defaultValues: {
      destinationPath: '',
      createDirectories: true,
      overwrite: false
    }
  });
  
  // Form for rename action config
  const renameForm = useForm<z.infer<typeof renameConfigSchema>>({
    resolver: zodResolver(renameConfigSchema),
    defaultValues: {
      pattern: '',
      replacement: '',
      overwrite: false
    }
  });
  
  // Form for delete action config
  const deleteForm = useForm<z.infer<typeof deleteConfigSchema>>({
    resolver: zodResolver(deleteConfigSchema),
    defaultValues: {
      confirmation: false
    }
  });
  
  // Form for Google Sheets action config
  const googleSheetsForm = useForm<z.infer<typeof googleSheetsConfigSchema>>({
    resolver: zodResolver(googleSheetsConfigSchema),
    defaultValues: {
      eventType: '',
      data: {}
    }
  });
  
  const { mutate: addAction, isPending } = useMutation({
    mutationFn: (data: any) => 
      apiRequest(`/api/file-watch/configs/${configId}/rules/${ruleId}/actions`, {
        method: 'POST',
        data
      }),
    onSuccess: () => {
      toast({
        title: 'Action added',
        description: 'Automation action has been added successfully.'
      });
      queryClient.invalidateQueries({ queryKey: [`/api/file-watch/configs/${configId}`] });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to add action',
        description: error.message || 'An error occurred while adding the action.',
        variant: 'destructive'
      });
    }
  });
  
  const getConfigForm = () => {
    switch (actionType) {
      case 'notify':
        return (
          <Form {...notifyForm}>
            <div className="space-y-4">
              <FormField
                control={notifyForm.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notification Message (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        placeholder="File has been detected"
                        className="resize-none"
                        rows={3}
                      />
                    </FormControl>
                    <FormDescription>
                      Custom message for the notification. If not provided, a default message will be used.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </Form>
        );
        
      case 'move':
        return (
          <Form {...moveForm}>
            <div className="space-y-4">
              <FormField
                control={moveForm.control}
                name="destinationPath"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Destination Path</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="./archive/{filename}" />
                    </FormControl>
                    <FormDescription>
                      Path to move the file to. You can use {'{filename}'} as a placeholder.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={moveForm.control}
                name="createDirectories"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Create Directories</FormLabel>
                      <FormDescription>
                        Create destination directories if they don't exist.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={moveForm.control}
                name="overwrite"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Overwrite Existing</FormLabel>
                      <FormDescription>
                        Overwrite files if they already exist at the destination.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </Form>
        );
        
      case 'copy':
        return (
          <Form {...copyForm}>
            <div className="space-y-4">
              <FormField
                control={copyForm.control}
                name="destinationPath"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Destination Path</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="./backup/{filename}" />
                    </FormControl>
                    <FormDescription>
                      Path to copy the file to. You can use {'{filename}'} as a placeholder.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={copyForm.control}
                name="createDirectories"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Create Directories</FormLabel>
                      <FormDescription>
                        Create destination directories if they don't exist.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={copyForm.control}
                name="overwrite"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Overwrite Existing</FormLabel>
                      <FormDescription>
                        Overwrite files if they already exist at the destination.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </Form>
        );
        
      case 'rename':
        return (
          <Form {...renameForm}>
            <div className="space-y-4">
              <FormField
                control={renameForm.control}
                name="pattern"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Pattern</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="(.*).txt" />
                    </FormControl>
                    <FormDescription>
                      Regular expression pattern to match in the filename.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={renameForm.control}
                name="replacement"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Replacement</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="$1_processed.txt" />
                    </FormControl>
                    <FormDescription>
                      Replacement string (can use regex capture groups).
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={renameForm.control}
                name="overwrite"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Overwrite Existing</FormLabel>
                      <FormDescription>
                        Overwrite files if they already exist with the new name.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </Form>
        );
        
      case 'delete':
        return (
          <Form {...deleteForm}>
            <div className="space-y-4">
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Warning</AlertTitle>
                <AlertDescription>
                  This action will permanently delete files. Use with caution.
                </AlertDescription>
              </Alert>
              
              <FormField
                control={deleteForm.control}
                name="confirmation"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Confirm Delete</FormLabel>
                      <FormDescription>
                        I understand this action will permanently delete files.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </Form>
        );
        
      case 'googleSheets':
        return (
          <Form {...googleSheetsForm}>
            <div className="space-y-4">
              <FormField
                control={googleSheetsForm.control}
                name="eventType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Event Type</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="file_event" />
                    </FormControl>
                    <FormDescription>
                      Event type to trigger in Google Sheets integration.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </Form>
        );
        
      default:
        return <div className="text-center p-4">No additional configuration needed.</div>;
    }
  };
  
  const onSubmit = async () => {
    let config = {};
    
    // Get the configuration based on the action type
    switch (actionType) {
      case 'notify':
        const notifyData = notifyForm.getValues();
        config = {
          message: notifyData.message
        };
        break;
        
      case 'move':
        const moveData = moveForm.getValues();
        
        // Validate move form
        const moveValid = await moveForm.trigger();
        if (!moveValid) return;
        
        config = {
          destinationPath: moveData.destinationPath,
          createDirectories: moveData.createDirectories,
          overwrite: moveData.overwrite
        };
        break;
        
      case 'copy':
        const copyData = copyForm.getValues();
        
        // Validate copy form
        const copyValid = await copyForm.trigger();
        if (!copyValid) return;
        
        config = {
          destinationPath: copyData.destinationPath,
          createDirectories: copyData.createDirectories,
          overwrite: copyData.overwrite
        };
        break;
        
      case 'rename':
        const renameData = renameForm.getValues();
        
        // Validate rename form
        const renameValid = await renameForm.trigger();
        if (!renameValid) return;
        
        config = {
          pattern: renameData.pattern,
          replacement: renameData.replacement,
          overwrite: renameData.overwrite
        };
        break;
        
      case 'delete':
        const deleteData = deleteForm.getValues();
        
        // Validate delete form
        const deleteValid = await deleteForm.trigger();
        if (!deleteValid) return;
        
        if (!deleteData.confirmation) {
          toast({
            title: 'Confirmation required',
            description: 'You must confirm the deletion action.',
            variant: 'destructive'
          });
          return;
        }
        
        config = {};
        break;
        
      case 'googleSheets':
        const googleSheetsData = googleSheetsForm.getValues();
        
        // Validate Google Sheets form
        const googleSheetsValid = await googleSheetsForm.trigger();
        if (!googleSheetsValid) return;
        
        config = {
          eventType: googleSheetsData.eventType,
          data: googleSheetsData.data
        };
        break;
    }
    
    // Submit the action
    addAction({
      type: actionType,
      config,
      active: form.getValues().active
    });
  };
  
  return (
    <div className="space-y-6">
      <Form {...form}>
        <div className="space-y-4">
          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Action Type</FormLabel>
                <Select 
                  onValueChange={(value) => {
                    field.onChange(value);
                    setActionType(value);
                  }} 
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select an action type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="notify">Notify</SelectItem>
                    <SelectItem value="move">Move File</SelectItem>
                    <SelectItem value="copy">Copy File</SelectItem>
                    <SelectItem value="delete">Delete File</SelectItem>
                    <SelectItem value="rename">Rename File</SelectItem>
                    <SelectItem value="extract">Extract Metadata</SelectItem>
                    <SelectItem value="sync">Sync to Platform</SelectItem>
                    <SelectItem value="googleSheets">Google Sheets Update</SelectItem>
                  </SelectContent>
                </Select>
                <FormDescription>
                  The type of action to perform when the rule is triggered.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Separator />
          
          <h3 className="font-medium">Action Configuration</h3>
          
          {getConfigForm()}
          
          <Separator />
          
          <FormField
            control={form.control}
            name="active"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                <div className="space-y-0.5">
                  <FormLabel className="text-base">Active</FormLabel>
                  <FormDescription>
                    Whether this action is active.
                  </FormDescription>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
      </Form>
      
      <DialogFooter>
        <Button 
          type="button" 
          variant="outline" 
          onClick={onClose}
          disabled={isPending}
        >
          Cancel
        </Button>
        <Button 
          type="button" 
          onClick={onSubmit} 
          disabled={isPending}
        >
          {isPending ? 'Adding...' : 'Add Action'}
        </Button>
      </DialogFooter>
    </div>
  );
};

// Config detail component
const ConfigDetail = () => {
  const params = useParams<{ id: string }>();
  const configId = params.id;
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [addRuleDialogOpen, setAddRuleDialogOpen] = useState(false);
  const [addActionDialogOpen, setAddActionDialogOpen] = useState(false);
  const [selectedRuleId, setSelectedRuleId] = useState<string | null>(null);
  
  const { data: config, isLoading, error } = useQuery({
    queryKey: [`/api/file-watch/configs/${configId}`],
    retry: false
  });
  
  const { data: events, isLoading: eventsLoading } = useQuery({
    queryKey: [`/api/file-watch/configs/${configId}/events`],
    retry: false
  });
  
  const { mutate: toggleRuleActive } = useMutation({
    mutationFn: ({ ruleId, active }: { ruleId: string; active: boolean }) => 
      apiRequest(`/api/file-watch/configs/${configId}/rules/${ruleId}`, {
        method: 'PATCH',
        data: { active }
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/file-watch/configs/${configId}`] });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to update rule',
        description: error.message || 'An error occurred while updating the rule.',
        variant: 'destructive'
      });
    }
  });
  
  const { mutate: deleteRule } = useMutation({
    mutationFn: (ruleId: string) => 
      apiRequest(`/api/file-watch/configs/${configId}/rules/${ruleId}`, {
        method: 'DELETE'
      }),
    onSuccess: () => {
      toast({
        title: 'Rule deleted',
        description: 'Automation rule has been deleted successfully.'
      });
      queryClient.invalidateQueries({ queryKey: [`/api/file-watch/configs/${configId}`] });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to delete rule',
        description: error.message || 'An error occurred while deleting the rule.',
        variant: 'destructive'
      });
    }
  });
  
  const { mutate: toggleActionActive } = useMutation({
    mutationFn: ({ ruleId, actionId, active }: { ruleId: string; actionId: string; active: boolean }) => 
      apiRequest(`/api/file-watch/configs/${configId}/rules/${ruleId}/actions/${actionId}`, {
        method: 'PATCH',
        data: { active }
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/file-watch/configs/${configId}`] });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to update action',
        description: error.message || 'An error occurred while updating the action.',
        variant: 'destructive'
      });
    }
  });
  
  const { mutate: deleteAction } = useMutation({
    mutationFn: ({ ruleId, actionId }: { ruleId: string; actionId: string }) => 
      apiRequest(`/api/file-watch/configs/${configId}/rules/${ruleId}/actions/${actionId}`, {
        method: 'DELETE'
      }),
    onSuccess: () => {
      toast({
        title: 'Action deleted',
        description: 'Automation action has been deleted successfully.'
      });
      queryClient.invalidateQueries({ queryKey: [`/api/file-watch/configs/${configId}`] });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to delete action',
        description: error.message || 'An error occurred while deleting the action.',
        variant: 'destructive'
      });
    }
  });
  
  const handleToggleRuleActive = (ruleId: string, currentActive: boolean) => {
    toggleRuleActive({ ruleId, active: !currentActive });
  };
  
  const handleDeleteRule = (ruleId: string) => {
    if (window.confirm('Are you sure you want to delete this rule?')) {
      deleteRule(ruleId);
    }
  };
  
  const handleToggleActionActive = (ruleId: string, actionId: string, currentActive: boolean) => {
    toggleActionActive({ ruleId, actionId, active: !currentActive });
  };
  
  const handleDeleteAction = (ruleId: string, actionId: string) => {
    if (window.confirm('Are you sure you want to delete this action?')) {
      deleteAction({ ruleId, actionId });
    }
  };
  
  const openAddActionDialog = (ruleId: string) => {
    setSelectedRuleId(ruleId);
    setAddActionDialogOpen(true);
  };
  
  if (isLoading) {
    return <div className="text-center p-8">Loading configuration...</div>;
  }
  
  if (error || !config) {
    return (
      <Alert variant="destructive" className="mb-4">
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          Failed to load file watch configuration. {(error as any)?.message || 'Configuration not found.'}
        </AlertDescription>
      </Alert>
    );
  }
  
  return (
    <div>
      <div className="mb-6">
        <Button variant="outline" size="sm" asChild>
          <Link href="/file-watch">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Configurations
          </Link>
        </Button>
      </div>
      
      <div className="mb-8 flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold">{config.name}</h1>
            <Badge variant={config.active ? "default" : "secondary"}>
              {config.active ? "Active" : "Inactive"}
            </Badge>
          </div>
          <p className="text-muted-foreground mt-1">Path: {config.path}</p>
        </div>
        
        <Button variant="outline" asChild>
          <Link href={`/file-watch/config/${config.id}/settings`}>
            <Settings className="mr-2 h-4 w-4" />
            Edit Configuration
          </Link>
        </Button>
      </div>
      
      <Tabs defaultValue="rules" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="rules">Automation Rules</TabsTrigger>
          <TabsTrigger value="events">Recent Events</TabsTrigger>
        </TabsList>
        
        <TabsContent value="rules">
          <div className="mb-6 flex justify-between items-center">
            <h2 className="text-2xl font-bold">Automation Rules</h2>
            
            <Dialog open={addRuleDialogOpen} onOpenChange={setAddRuleDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" /> Add Rule
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-xl">
                <DialogHeader>
                  <DialogTitle>Add Automation Rule</DialogTitle>
                  <DialogDescription>
                    Create a new automation rule to run when files match specific criteria.
                  </DialogDescription>
                </DialogHeader>
                
                <AddRuleForm 
                  configId={config.id} 
                  onClose={() => setAddRuleDialogOpen(false)} 
                />
              </DialogContent>
            </Dialog>
          </div>
          
          {config.automationRules.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <FileText className="mx-auto h-12 w-12 text-muted-foreground" />
                <h3 className="mt-4 text-lg font-medium">No rules yet</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Create your first automation rule to start processing files automatically.
                </p>
                <Button 
                  className="mt-4" 
                  onClick={() => setAddRuleDialogOpen(true)}
                >
                  <Plus className="mr-2 h-4 w-4" /> Add Rule
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {config.automationRules.map((rule) => (
                <Card key={rule.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          {rule.name}
                          <Badge variant={rule.active ? "default" : "secondary"} className="ml-2">
                            {rule.active ? "Active" : "Inactive"}
                          </Badge>
                        </CardTitle>
                        {rule.description && (
                          <CardDescription className="mt-1">
                            {rule.description}
                          </CardDescription>
                        )}
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="icon"
                          title={rule.active ? "Disable" : "Enable"}
                          onClick={() => handleToggleRuleActive(rule.id, rule.active)}
                        >
                          {rule.active ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          title="Delete"
                          onClick={() => handleDeleteRule(rule.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="flex flex-wrap gap-x-6 gap-y-2 mb-4">
                      <div className="flex items-center">
                        <span className="font-medium mr-2">Event:</span>
                        <Badge variant="outline">
                          {rule.eventType === 'all' ? 'All Events' : 
                            rule.eventType === 'add' ? 'File Added' :
                            rule.eventType === 'change' ? 'File Changed' :
                            rule.eventType === 'unlink' ? 'File Deleted' :
                            rule.eventType === 'addDir' ? 'Directory Added' :
                            rule.eventType === 'unlinkDir' ? 'Directory Deleted' : 
                            rule.eventType}
                        </Badge>
                      </div>
                      <div className="flex items-center">
                        <span className="font-medium mr-2">Pattern:</span>
                        <code className="bg-muted px-1 py-0.5 rounded text-sm">
                          {rule.filePattern}
                        </code>
                      </div>
                      <div className="flex items-center">
                        <span className="font-medium mr-2">Actions:</span>
                        <span>{rule.actions.length}</span>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h4 className="font-medium">Actions</h4>
                        
                        <Dialog open={addActionDialogOpen && selectedRuleId === rule.id} onOpenChange={(open) => {
                          if (!open) {
                            setAddActionDialogOpen(false);
                            setSelectedRuleId(null);
                          }
                        }}>
                          <DialogTrigger asChild>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => openAddActionDialog(rule.id)}
                            >
                              <Plus className="mr-2 h-4 w-4" /> Add Action
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-xl">
                            <DialogHeader>
                              <DialogTitle>Add Automation Action</DialogTitle>
                              <DialogDescription>
                                Add an action to execute when this rule is triggered.
                              </DialogDescription>
                            </DialogHeader>
                            
                            {selectedRuleId && (
                              <AddActionForm 
                                configId={config.id} 
                                ruleId={selectedRuleId}
                                onClose={() => {
                                  setAddActionDialogOpen(false);
                                  setSelectedRuleId(null);
                                }} 
                              />
                            )}
                          </DialogContent>
                        </Dialog>
                      </div>
                      
                      {rule.actions.length === 0 ? (
                        <div className="text-center p-4 border border-dashed rounded-md">
                          <p className="text-sm text-muted-foreground">
                            No actions defined. Add an action to execute when this rule is triggered.
                          </p>
                          <Button 
                            className="mt-2" 
                            size="sm" 
                            variant="outline"
                            onClick={() => openAddActionDialog(rule.id)}
                          >
                            <Plus className="mr-2 h-4 w-4" /> Add Action
                          </Button>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {rule.actions.map((action) => (
                            <div 
                              key={action.id}
                              className="flex items-center justify-between p-3 border rounded-md"
                            >
                              <div className="flex items-center">
                                <Badge className="mr-3" variant={action.active ? "default" : "outline"}>
                                  {action.type}
                                </Badge>
                                <div className="text-sm">
                                  {action.type === 'notify' && action.config.message ? (
                                    <span>Message: "{action.config.message.substring(0, 30)}{action.config.message.length > 30 ? '...' : ''}"</span>
                                  ) : action.type === 'move' || action.type === 'copy' ? (
                                    <span>Destination: {action.config.destinationPath}</span>
                                  ) : action.type === 'rename' ? (
                                    <span>Pattern: {action.config.pattern} → {action.config.replacement}</span>
                                  ) : action.type === 'googleSheets' ? (
                                    <span>Event: {action.config.eventType}</span>
                                  ) : null}
                                </div>
                              </div>
                              
                              <div className="flex space-x-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  title={action.active ? "Disable" : "Enable"}
                                  onClick={() => handleToggleActionActive(rule.id, action.id, action.active)}
                                >
                                  {action.active ? <Check className="h-4 w-4 text-green-500" /> : <X className="h-4 w-4 text-muted-foreground" />}
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  title="Delete"
                                  onClick={() => handleDeleteAction(rule.id, action.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="events">
          <h2 className="text-2xl font-bold mb-6">Recent File Events</h2>
          
          {eventsLoading ? (
            <div className="text-center p-8">Loading events...</div>
          ) : !events || events.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <h3 className="mt-2 text-lg font-medium">No events yet</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  File events will appear here when detected.
                </p>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Event Type</TableHead>
                      <TableHead>File Path</TableHead>
                      <TableHead>Timestamp</TableHead>
                      <TableHead>Actions Triggered</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {events.map((event: FileEvent) => (
                      <TableRow key={event.id}>
                        <TableCell>
                          <Badge variant={event.eventType === 'unlink' ? 'destructive' : event.eventType === 'add' ? 'default' : 'secondary'}>
                            {event.eventType}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono text-xs truncate max-w-xs" title={event.relativePath}>
                          {event.relativePath}
                        </TableCell>
                        <TableCell>{new Date(event.timestamp).toLocaleString()}</TableCell>
                        <TableCell>
                          {event.automationResults?.reduce((total, result) => total + result.actions.length, 0) || 0}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

// Main component
const FileWatchConfigDetail = () => {
  return (
    <div className="container py-8">
      <ConfigDetail />
    </div>
  );
};

export default FileWatchConfigDetail;