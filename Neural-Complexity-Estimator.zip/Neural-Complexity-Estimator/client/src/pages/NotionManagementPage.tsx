import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { NotionDatabaseList } from '../components/notion/NotionDatabaseList';
import { NotionConnectionForm } from '../components/notion/NotionConnectionForm';
import { NotionDatabaseForm } from '../components/notion/NotionDatabaseForm';
import { notionApi } from '@/lib/api/notionApi';

// Types
interface NotionConnection {
  id: string;
  name: string;
  authToken: string;
  workspaceId?: string;
  databases: NotionDatabase[];
  defaultDatabase?: string;
  webhookUrl?: string;
  lastSync?: string;
  isActive: boolean;
}

interface NotionDatabase {
  id: string;
  type: string;
  name: string;
  description?: string;
  schema?: Record<string, any>;
  customMapping?: Record<string, string>;
}

interface NotionDatabaseType {
  id: string;
  name: string;
  description: string;
}

export default function NotionManagementPage() {
  const [activeTab, setActiveTab] = useState('connections');
  const [showAddConnection, setShowAddConnection] = useState(false);
  const [selectedConnection, setSelectedConnection] = useState<NotionConnection | null>(null);
  const { toast } = useToast();

  // Fetch connections
  const {
    data: connectionsData,
    isLoading: isLoadingConnections,
    isError: isConnectionsError,
    error: connectionsError
  } = useQuery({
    queryKey: ['/api/notion/connections'],
    queryFn: async () => {
      const response = await notionApi.getConnections();
      return response.connections;
    }
  });

  // Fetch database types
  const {
    data: databaseTypes,
    isLoading: isLoadingDatabaseTypes,
  } = useQuery({
    queryKey: ['/api/notion/database-types'],
    queryFn: async () => {
      const response = await notionApi.getDatabaseTypes();
      return response.databaseTypes;
    }
  });

  // Add connection mutation
  const addConnectionMutation = useMutation({
    mutationFn: notionApi.addConnection,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notion/connections'] });
      toast({
        title: "Connection added",
        description: "Notion connection has been successfully added.",
      });
      setShowAddConnection(false);
    },
    onError: (error: any) => {
      toast({
        title: "Failed to add connection",
        description: error.message || "An error occurred while adding the connection.",
        variant: "destructive",
      });
    }
  });

  // Remove connection mutation
  const removeConnectionMutation = useMutation({
    mutationFn: notionApi.removeConnection,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notion/connections'] });
      toast({
        title: "Connection removed",
        description: "Notion connection has been successfully removed.",
      });
      setSelectedConnection(null);
    },
    onError: (error: any) => {
      toast({
        title: "Failed to remove connection",
        description: error.message || "An error occurred while removing the connection.",
        variant: "destructive",
      });
    }
  });

  // Update connection mutation
  const updateConnectionMutation = useMutation({
    mutationFn: notionApi.updateConnection,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notion/connections'] });
      toast({
        title: "Connection updated",
        description: "Notion connection has been successfully updated.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to update connection",
        description: error.message || "An error occurred while updating the connection.",
        variant: "destructive",
      });
    }
  });

  // Add database mutation
  const addDatabaseMutation = useMutation({
    mutationFn: notionApi.addDatabase,
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/notion/connections'] });
      toast({
        title: "Database added",
        description: "Notion database has been successfully added to the connection.",
      });
      
      // Update the selected connection with the new database
      if (selectedConnection && data && data.database) {
        setSelectedConnection({
          ...selectedConnection,
          databases: [...selectedConnection.databases, data.database]
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Failed to add database",
        description: error.message || "An error occurred while adding the database.",
        variant: "destructive",
      });
    }
  });

  // Remove database mutation
  const removeDatabaseMutation = useMutation({
    mutationFn: notionApi.removeDatabase,
    onSuccess: (_, variables: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/notion/connections'] });
      toast({
        title: "Database removed",
        description: "Notion database has been successfully removed from the connection.",
      });
      
      // Update the selected connection by removing the database
      if (selectedConnection && variables && variables.databaseId) {
        const updatedConnection = {
          ...selectedConnection,
          databases: selectedConnection.databases.filter(db => db.id !== variables.databaseId)
        };
        setSelectedConnection(updatedConnection);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Failed to remove database",
        description: error.message || "An error occurred while removing the database.",
        variant: "destructive",
      });
    }
  });

  const handleAddConnection = (connectionData: any) => {
    addConnectionMutation.mutate(connectionData);
  };

  const handleUpdateConnection = (id: string, updates: any) => {
    updateConnectionMutation.mutate({ id, updates });
  };

  const handleRemoveConnection = (id: string) => {
    removeConnectionMutation.mutate(id);
  };

  const handleAddDatabase = (connectionId: string, database: Omit<NotionDatabase, 'id'>) => {
    addDatabaseMutation.mutate({ connectionId, database });
  };

  const handleRemoveDatabase = (connectionId: string, databaseId: string) => {
    removeDatabaseMutation.mutate({ connectionId, databaseId });
  };

  const handleSetDefaultDatabase = (connectionId: string, databaseId: string) => {
    updateConnectionMutation.mutate({
      id: connectionId,
      updates: { defaultDatabase: databaseId }
    });
  };

  return (
    <div className="container py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Notion Integration</h1>
        <Button onClick={() => setShowAddConnection(true)}>Add Connection</Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="connections">Connections</TabsTrigger>
          <TabsTrigger value="databases">Databases</TabsTrigger>
          <TabsTrigger value="sync">Sync Ideas</TabsTrigger>
        </TabsList>

        <TabsContent value="connections" className="space-y-4">
          {isLoadingConnections ? (
            <div className="space-y-4">
              <Skeleton className="h-[150px] w-full rounded-xl" />
              <Skeleton className="h-[150px] w-full rounded-xl" />
            </div>
          ) : isConnectionsError ? (
            <Alert variant="destructive">
              <AlertTitle>Error loading connections</AlertTitle>
              <AlertDescription>
                {(connectionsError as Error)?.message || "Failed to load Notion connections. Please try again."}
              </AlertDescription>
            </Alert>
          ) : connectionsData?.length === 0 ? (
            <Alert>
              <AlertTitle>No connections found</AlertTitle>
              <AlertDescription>
                You don't have any Notion connections yet. Add a connection to start syncing with Notion.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {connectionsData?.map((connection: NotionConnection) => (
                <Card key={connection.id} className="cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={() => setSelectedConnection(connection)}>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle>{connection.name}</CardTitle>
                      <Badge variant={connection.isActive ? "default" : "outline"}>
                        {connection.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                    <CardDescription>
                      {connection.databases.length} {connection.databases.length === 1 ? 'database' : 'databases'}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-sm">
                      {connection.workspaceId && (
                        <p className="mb-1">Workspace ID: {connection.workspaceId}</p>
                      )}
                      {connection.lastSync && (
                        <p className="mb-1">Last synced: {new Date(connection.lastSync).toLocaleString()}</p>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleUpdateConnection(connection.id, { isActive: !connection.isActive });
                      }}>
                      {connection.isActive ? "Deactivate" : "Activate"}
                    </Button>
                    <Button variant="destructive" size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveConnection(connection.id);
                      }}>
                      Remove
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="databases" className="space-y-4">
          {selectedConnection ? (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-semibold">{selectedConnection.name} - Databases</h2>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>Add Database</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Notion Database</DialogTitle>
                      <DialogDescription>
                        Add a Notion database to the connection. You'll be able to sync ideas with this database.
                      </DialogDescription>
                    </DialogHeader>
                    
                    <NotionDatabaseForm 
                      connectionId={selectedConnection.id}
                      databaseTypes={databaseTypes || []}
                      onSubmit={handleAddDatabase}
                      isLoading={addDatabaseMutation.isPending}
                    />
                  </DialogContent>
                </Dialog>
              </div>

              <NotionDatabaseList
                databases={selectedConnection.databases}
                connectionId={selectedConnection.id}
                defaultDatabase={selectedConnection.defaultDatabase}
                onRemove={handleRemoveDatabase}
                onSetDefault={handleSetDefaultDatabase}
                isLoading={removeDatabaseMutation.isPending}
              />
            </div>
          ) : (
            <Alert>
              <AlertTitle>No connection selected</AlertTitle>
              <AlertDescription>
                Please select a connection from the Connections tab to manage its databases.
              </AlertDescription>
            </Alert>
          )}
        </TabsContent>

        <TabsContent value="sync" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sync Ideas with Notion</CardTitle>
              <CardDescription>
                Select ideas to sync with Notion or import content from Notion as ideas.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-center text-muted-foreground">
                Coming soon: Sync ideas with Notion
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add Connection Dialog */}
      <Dialog open={showAddConnection} onOpenChange={setShowAddConnection}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Notion Connection</DialogTitle>
            <DialogDescription>
              Connect your Notion workspace to PinkSync. You'll need a Notion API key to proceed.
            </DialogDescription>
          </DialogHeader>
          
          <NotionConnectionForm 
            onSubmit={handleAddConnection}
            isLoading={addConnectionMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* View Connection Dialog */}
      <Dialog open={!!selectedConnection} onOpenChange={(open) => !open && setSelectedConnection(null)}>
        {selectedConnection && (
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>{selectedConnection.name}</DialogTitle>
              <DialogDescription>
                Manage your Notion connection and its databases.
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="details">
              <TabsList>
                <TabsTrigger value="details">Connection Details</TabsTrigger>
                <TabsTrigger value="databases">Databases ({selectedConnection.databases.length})</TabsTrigger>
              </TabsList>
              
              <TabsContent value="details" className="space-y-4 pt-4">
                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Connection Name</Label>
                    <Input
                      id="name"
                      value={selectedConnection.name}
                      onChange={(e) => setSelectedConnection({
                        ...selectedConnection,
                        name: e.target.value
                      })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="workspaceId">Workspace ID (Optional)</Label>
                    <Input
                      id="workspaceId"
                      value={selectedConnection.workspaceId || ''}
                      onChange={(e) => setSelectedConnection({
                        ...selectedConnection,
                        workspaceId: e.target.value
                      })}
                      placeholder="Notion workspace ID"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="webhookUrl">Webhook URL (Optional)</Label>
                    <Input
                      id="webhookUrl"
                      value={selectedConnection.webhookUrl || ''}
                      onChange={(e) => setSelectedConnection({
                        ...selectedConnection,
                        webhookUrl: e.target.value
                      })}
                      placeholder="https://your-webhook-url.com"
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="isActive"
                      checked={selectedConnection.isActive}
                      onCheckedChange={(checked) => setSelectedConnection({
                        ...selectedConnection,
                        isActive: checked
                      })}
                    />
                    <Label htmlFor="isActive">Active</Label>
                  </div>
                </div>
                
                <DialogFooter>
                  <Button
                    variant="outline"
                    onClick={() => setSelectedConnection(null)}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => {
                      const { id, ...updates } = selectedConnection;
                      handleUpdateConnection(id, updates);
                    }}
                    disabled={updateConnectionMutation.isPending}
                  >
                    {updateConnectionMutation.isPending ? 'Saving...' : 'Save Changes'}
                  </Button>
                </DialogFooter>
              </TabsContent>
              
              <TabsContent value="databases" className="pt-4">
                <NotionDatabaseList
                  databases={selectedConnection.databases}
                  connectionId={selectedConnection.id}
                  defaultDatabase={selectedConnection.defaultDatabase}
                  onRemove={handleRemoveDatabase}
                  onSetDefault={handleSetDefaultDatabase}
                  isLoading={removeDatabaseMutation.isPending}
                />
                
                <div className="flex justify-end mt-4">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button>Add Database</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add Notion Database</DialogTitle>
                        <DialogDescription>
                          Add a Notion database to the connection. You'll be able to sync ideas with this database.
                        </DialogDescription>
                      </DialogHeader>
                      
                      <NotionDatabaseForm 
                        connectionId={selectedConnection.id}
                        databaseTypes={databaseTypes || []}
                        onSubmit={handleAddDatabase}
                        isLoading={addDatabaseMutation.isPending}
                      />
                    </DialogContent>
                  </Dialog>
                </div>
              </TabsContent>
            </Tabs>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
}