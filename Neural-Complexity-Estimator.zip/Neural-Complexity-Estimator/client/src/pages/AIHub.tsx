import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { MessageSquare, Image, FileText, Settings, Info } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { useQuery } from '@tanstack/react-query';
import ChatInterface from '@/components/ai/ChatInterface';
import ImageAnalyzer from '@/components/ai/ImageAnalyzer';
import TextEmbedder from '@/components/ai/TextEmbedder';
import { Link } from 'wouter';

export function AIHub() {
  const [activeTab, setActiveTab] = useState('chat');
  const { toast } = useToast();
  const { user, isLoading, isAuthenticated } = useAuth();
  
  // Fetch available AI models
  const { data: aiModels, isLoading: isLoadingModels } = useQuery({
    queryKey: ['/api/ai/models'],
    retry: false,
    enabled: isAuthenticated
  });
  
  if (isLoading) {
    return (
      <div className="container mx-auto py-10 space-y-6">
        <div className="flex justify-center items-center h-64">
          <p>Loading...</p>
        </div>
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return (
      <div className="container mx-auto py-10 space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>
              You need to be logged in to access AI features.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/api/login">
              <Button>Log in with Replit</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto py-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">AI Hub</h1>
        <p className="text-muted-foreground mt-2">
          Access powerful AI capabilities for your tasks
        </p>
      </div>
      
      <Separator />
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main content area - takes 3/4 of space on large screens */}
        <div className="lg:col-span-3 space-y-6">
          <Tabs 
            value={activeTab} 
            onValueChange={setActiveTab}
            className="w-full"
          >
            <TabsList className="mb-4">
              <TabsTrigger value="chat" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                Chat
              </TabsTrigger>
              <TabsTrigger value="vision" className="flex items-center gap-2">
                <Image className="h-4 w-4" />
                Vision
              </TabsTrigger>
              <TabsTrigger value="embeddings" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Embeddings
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="chat" className="mt-0">
              <ChatInterface 
                systemPrompt="You're an AI assistant for Pinky's AI OS, a personal productivity hub. Be helpful, concise, and focus on assisting with personal and business information management tasks."
                placeholder="How can I help with your information management today?"
              />
            </TabsContent>
            
            <TabsContent value="vision" className="mt-0">
              <ImageAnalyzer 
                title="AI Vision Analysis"
                defaultPrompt="Analyze this image in detail. What information can be extracted from it?"
              />
            </TabsContent>
            
            <TabsContent value="embeddings" className="mt-0">
              <TextEmbedder />
            </TabsContent>
          </Tabs>
        </div>
        
        {/* Sidebar - takes 1/4 of space on large screens */}
        <div className="space-y-6">
          {/* Available Models */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Available Models</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingModels ? (
                <p className="text-sm text-muted-foreground">Loading models...</p>
              ) : aiModels && aiModels.length > 0 ? (
                <div className="space-y-2">
                  {aiModels.map((model: any) => (
                    <div key={model.id} className="text-sm">
                      <p className="font-medium">{model.name}</p>
                      <p className="text-muted-foreground text-xs">{model.description}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No models available</p>
              )}
            </CardContent>
          </Card>
          
          {/* Quick Tips */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Info className="h-4 w-4" />
                Quick Tips
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-2">
              <p>
                <span className="font-medium">Chat:</span> Ask complex questions, request summaries, or get creative content.
              </p>
              <p>
                <span className="font-medium">Vision:</span> Analyze images for content, extract text, or identify objects.
              </p>
              <p>
                <span className="font-medium">Embeddings:</span> Generate vector representations of text for semantic search.
              </p>
            </CardContent>
          </Card>
          
          {/* Usage and Settings */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm">
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full"
                onClick={() => {
                  toast({
                    title: "Settings",
                    description: "AI settings will be available soon.",
                  });
                }}
              >
                Manage AI Settings
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default AIHub;