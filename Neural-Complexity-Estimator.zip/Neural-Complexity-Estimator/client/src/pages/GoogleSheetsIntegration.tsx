import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Download, PlusCircle, Trash2, RefreshCcw, Copy, Code } from 'lucide-react';

const GoogleSheetsIntegration: React.FC = () => {
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('configs');
  
  // Config states
  const [newConfig, setNewConfig] = useState({
    name: '',
    sheetId: '',
    tabName: 'Sheet1',
    events: [] as string[],
    active: true,
    mappingFunction: ''
  });
  
  const [editingConfig, setEditingConfig] = useState<string | null>(null);
  const [editingConfigData, setEditingConfigData] = useState({
    name: '',
    sheetId: '',
    tabName: '',
    events: [] as string[],
    active: true,
    mappingFunction: ''
  });
  
  const [isCreating, setIsCreating] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [showScriptTemplate, setShowScriptTemplate] = useState(false);
  const [scriptTemplate, setScriptTemplate] = useState('');
  const [scriptSheetId, setScriptSheetId] = useState('');
  const [scriptTabName, setScriptTabName] = useState('Sheet1');
  
  // Event trigger states
  const [triggerType, setTriggerType] = useState('file_sync');
  const [triggerData, setTriggerData] = useState(`{
  "filesProcessed": 10,
  "filesUpdated": 5,
  "success": true,
  "errors": []
}`);
  const [isTriggeringEvent, setIsTriggeringEvent] = useState(false);
  
  // Fetch configs
  const { data: configs = [], isLoading: isLoadingConfigs, refetch: refetchConfigs } = 
    useQuery<any[]>({
      queryKey: ['/api/google-sheets/configs'],
      enabled: isAuthenticated
    });
  
  // Fetch events
  const { data: events = [], isLoading: isLoadingEvents, refetch: refetchEvents } = 
    useQuery<any[]>({
      queryKey: ['/api/google-sheets/events'],
      enabled: isAuthenticated
    });
  
  // Event types
  const eventTypes = [
    { id: 'file_sync', label: 'File Synchronization' },
    { id: 'chat_extract', label: 'Chat Extraction' },
    { id: 'platform_connection', label: 'Platform Connection' },
    { id: 'document_upload', label: 'Document Upload' }
  ];
  
  // Create a new config
  const createConfig = async () => {
    try {
      if (!newConfig.name || !newConfig.sheetId) {
        toast({
          title: 'Error',
          description: 'Please enter a name and Google Sheet ID or URL',
          variant: 'destructive',
        });
        return;
      }
      
      if (newConfig.events.length === 0) {
        toast({
          title: 'Error',
          description: 'Please select at least one event type',
          variant: 'destructive',
        });
        return;
      }
      
      setIsCreating(true);
      
      const response = await fetch('/api/google-sheets/configs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newConfig),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to create config');
      }
      
      const result = await response.json();
      
      toast({
        title: 'Config Created',
        description: `Created "${result.name}" successfully`,
      });
      
      // Reset form
      setNewConfig({
        name: '',
        sheetId: '',
        tabName: 'Sheet1',
        events: [],
        active: true,
        mappingFunction: ''
      });
      
      refetchConfigs();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create config',
        variant: 'destructive',
      });
    } finally {
      setIsCreating(false);
    }
  };
  
  // Update a config
  const updateConfig = async () => {
    try {
      if (!editingConfig) return;
      
      if (!editingConfigData.name || !editingConfigData.sheetId) {
        toast({
          title: 'Error',
          description: 'Please enter a name and Google Sheet ID or URL',
          variant: 'destructive',
        });
        return;
      }
      
      if (editingConfigData.events.length === 0) {
        toast({
          title: 'Error',
          description: 'Please select at least one event type',
          variant: 'destructive',
        });
        return;
      }
      
      setIsEditing(true);
      
      const response = await fetch(`/api/google-sheets/configs/${editingConfig}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editingConfigData),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to update config');
      }
      
      const result = await response.json();
      
      toast({
        title: 'Config Updated',
        description: `Updated "${result.name}" successfully`,
      });
      
      setEditingConfig(null);
      refetchConfigs();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update config',
        variant: 'destructive',
      });
    } finally {
      setIsEditing(false);
    }
  };
  
  // Delete a config
  const deleteConfig = async (id: string) => {
    try {
      if (!confirm('Are you sure you want to delete this configuration?')) {
        return;
      }
      
      const response = await fetch(`/api/google-sheets/configs/${id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to delete config');
      }
      
      toast({
        title: 'Config Deleted',
        description: 'Configuration deleted successfully',
      });
      
      refetchConfigs();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to delete config',
        variant: 'destructive',
      });
    }
  };
  
  // Trigger an event
  const triggerEvent = async () => {
    try {
      let data;
      try {
        data = JSON.parse(triggerData);
      } catch (e) {
        toast({
          title: 'Error',
          description: 'Invalid JSON data',
          variant: 'destructive',
        });
        return;
      }
      
      setIsTriggeringEvent(true);
      
      const response = await fetch('/api/google-sheets/trigger', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          type: triggerType,
          data
        }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to trigger event');
      }
      
      const result = await response.json();
      
      toast({
        title: 'Event Triggered',
        description: `Triggered ${result.eventsTriggered} Google Sheets updates`,
      });
      
      refetchEvents();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to trigger event',
        variant: 'destructive',
      });
    } finally {
      setIsTriggeringEvent(false);
    }
  };
  
  // Get Apps Script template
  const getAppsScriptTemplate = async () => {
    try {
      if (!scriptSheetId) {
        toast({
          title: 'Error',
          description: 'Please enter a Google Sheet ID',
          variant: 'destructive',
        });
        return;
      }
      
      const response = await fetch(`/api/google-sheets/script-template?sheetId=${encodeURIComponent(scriptSheetId)}&tabName=${encodeURIComponent(scriptTabName)}`);
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to get script template');
      }
      
      const result = await response.json();
      setScriptTemplate(result.script);
      setShowScriptTemplate(true);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to get script template',
        variant: 'destructive',
      });
    }
  };
  
  // Copy script to clipboard
  const copyScriptToClipboard = () => {
    navigator.clipboard.writeText(scriptTemplate).then(() => {
      toast({
        title: 'Copied',
        description: 'Script copied to clipboard',
      });
    });
  };
  
  // Edit config
  const startEditing = (config: any) => {
    setEditingConfig(config.id);
    setEditingConfigData({
      name: config.name,
      sheetId: config.sheetId,
      tabName: config.tabName || 'Sheet1',
      events: config.events || [],
      active: config.active,
      mappingFunction: config.mappingFunction || ''
    });
  };
  
  // Toggle event in config
  const toggleEventInConfig = (event: string, isNew = true) => {
    if (isNew) {
      setNewConfig(prev => {
        const events = prev.events.includes(event)
          ? prev.events.filter(e => e !== event)
          : [...prev.events, event];
        
        return { ...prev, events };
      });
    } else {
      setEditingConfigData(prev => {
        const events = prev.events.includes(event)
          ? prev.events.filter(e => e !== event)
          : [...prev.events, event];
        
        return { ...prev, events };
      });
    }
  };
  
  // Get sample data for event type
  const getSampleDataForEventType = (type: string) => {
    switch (type) {
      case 'file_sync':
        return `{
  "filesProcessed": 10,
  "filesUpdated": 5,
  "success": true,
  "errors": []
}`;
      case 'chat_extract':
        return `{
  "totalExtracted": 25,
  "totalUploaded": 3,
  "platformType": "claude",
  "collectionName": "chat_history"
}`;
      case 'platform_connection':
        return `{
  "name": "My Dropbox",
  "type": "dropbox",
  "rootPath": "/documents",
  "active": true
}`;
      case 'document_upload':
        return `{
  "documentId": "doc-123",
  "name": "Important Document.pdf",
  "size": 2048576,
  "mimeType": "application/pdf",
  "tags": ["important", "legal"]
}`;
      default:
        return `{}`;
    }
  };
  
  // Update sample data when trigger type changes
  useEffect(() => {
    setTriggerData(getSampleDataForEventType(triggerType));
  }, [triggerType]);
  
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Google Sheets Integration</h1>
      
      {!isAuthenticated ? (
        <Card>
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>
              Please log in to access the Google Sheets integration.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => window.location.href = '/api/login'}>
              Log in with Replit
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="configs">Configurations</TabsTrigger>
              <TabsTrigger value="events">Event History</TabsTrigger>
              <TabsTrigger value="script">Apps Script Template</TabsTrigger>
            </TabsList>
            
            {/* Configurations Tab */}
            <TabsContent value="configs">
              <div className="space-y-6">
                {/* Create New Config */}
                <Card>
                  <CardHeader>
                    <CardTitle>Create New Configuration</CardTitle>
                    <CardDescription>
                      Create a new Google Sheets integration configuration to automatically update your sheets.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="config-name">Configuration Name</Label>
                        <Input
                          id="config-name"
                          value={newConfig.name}
                          onChange={(e) => setNewConfig({...newConfig, name: e.target.value})}
                          placeholder="e.g. File Sync Logs"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="sheet-id">
                          Google Sheet ID or Apps Script Web App URL
                          <span className="text-xs text-muted-foreground block mt-1">
                            For direct integration, use your Google Apps Script Web App URL
                          </span>
                        </Label>
                        <Input
                          id="sheet-id"
                          value={newConfig.sheetId}
                          onChange={(e) => setNewConfig({...newConfig, sheetId: e.target.value})}
                          placeholder="Google Sheet ID or Apps Script URL"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="tab-name">Sheet Tab Name</Label>
                      <Input
                        id="tab-name"
                        value={newConfig.tabName}
                        onChange={(e) => setNewConfig({...newConfig, tabName: e.target.value})}
                        placeholder="Sheet1"
                      />
                      <p className="text-xs text-muted-foreground">
                        The name of the tab/sheet within your Google Sheet.
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Event Types to Track</Label>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {eventTypes.map((event) => (
                          <div key={event.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={`event-${event.id}`}
                              checked={newConfig.events.includes(event.id)}
                              onCheckedChange={() => toggleEventInConfig(event.id)}
                            />
                            <Label htmlFor={`event-${event.id}`}>{event.label}</Label>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="config-active"
                        checked={newConfig.active}
                        onCheckedChange={(checked) => setNewConfig({...newConfig, active: !!checked})}
                      />
                      <Label htmlFor="config-active">Active</Label>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="mapping-function">
                        Custom Data Mapping Function (Optional)
                        <span className="text-xs text-muted-foreground block mt-1">
                          JavaScript function to transform data before sending to Google Sheets
                        </span>
                      </Label>
                      <Textarea
                        id="mapping-function"
                        value={newConfig.mappingFunction}
                        onChange={(e) => setNewConfig({...newConfig, mappingFunction: e.target.value})}
                        placeholder={`// Example: Transform data before sending to Google Sheets
function(data) {
  // Return the transformed data
  return {
    ...data,
    formattedTimestamp: new Date().toISOString()
  };
}`}
                        className="font-mono"
                        rows={6}
                      />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      onClick={createConfig} 
                      disabled={isCreating}
                      className="w-full"
                    >
                      {isCreating ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Creating...
                        </>
                      ) : (
                        <>
                          <PlusCircle className="mr-2 h-4 w-4" />
                          Create Configuration
                        </>
                      )}
                    </Button>
                  </CardFooter>
                </Card>
                
                {/* Existing Configs */}
                <Card>
                  <CardHeader>
                    <CardTitle>Existing Configurations</CardTitle>
                    <CardDescription>
                      Manage your Google Sheets integration configurations.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingConfigs ? (
                      <div className="flex justify-center py-8">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    ) : configs.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <p>No configurations found. Create your first one above.</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {configs.map((config) => (
                          <div key={config.id} className="border rounded-lg p-4">
                            {editingConfig === config.id ? (
                              <div className="space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div className="space-y-2">
                                    <Label htmlFor={`edit-name-${config.id}`}>Configuration Name</Label>
                                    <Input
                                      id={`edit-name-${config.id}`}
                                      value={editingConfigData.name}
                                      onChange={(e) => setEditingConfigData({...editingConfigData, name: e.target.value})}
                                    />
                                  </div>
                                  
                                  <div className="space-y-2">
                                    <Label htmlFor={`edit-sheet-id-${config.id}`}>Google Sheet ID or Apps Script URL</Label>
                                    <Input
                                      id={`edit-sheet-id-${config.id}`}
                                      value={editingConfigData.sheetId}
                                      onChange={(e) => setEditingConfigData({...editingConfigData, sheetId: e.target.value})}
                                    />
                                  </div>
                                </div>
                                
                                <div className="space-y-2">
                                  <Label htmlFor={`edit-tab-name-${config.id}`}>Sheet Tab Name</Label>
                                  <Input
                                    id={`edit-tab-name-${config.id}`}
                                    value={editingConfigData.tabName}
                                    onChange={(e) => setEditingConfigData({...editingConfigData, tabName: e.target.value})}
                                  />
                                </div>
                                
                                <div className="space-y-2">
                                  <Label>Event Types to Track</Label>
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                    {eventTypes.map((event) => (
                                      <div key={`edit-${config.id}-${event.id}`} className="flex items-center space-x-2">
                                        <Checkbox
                                          id={`edit-event-${config.id}-${event.id}`}
                                          checked={editingConfigData.events.includes(event.id)}
                                          onCheckedChange={() => toggleEventInConfig(event.id, false)}
                                        />
                                        <Label htmlFor={`edit-event-${config.id}-${event.id}`}>{event.label}</Label>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                                
                                <div className="flex items-center space-x-2">
                                  <Checkbox
                                    id={`edit-active-${config.id}`}
                                    checked={editingConfigData.active}
                                    onCheckedChange={(checked) => setEditingConfigData({...editingConfigData, active: !!checked})}
                                  />
                                  <Label htmlFor={`edit-active-${config.id}`}>Active</Label>
                                </div>
                                
                                <div className="space-y-2">
                                  <Label htmlFor={`edit-mapping-${config.id}`}>Custom Data Mapping Function</Label>
                                  <Textarea
                                    id={`edit-mapping-${config.id}`}
                                    value={editingConfigData.mappingFunction}
                                    onChange={(e) => setEditingConfigData({...editingConfigData, mappingFunction: e.target.value})}
                                    className="font-mono"
                                    rows={6}
                                  />
                                </div>
                                
                                <div className="flex space-x-2">
                                  <Button
                                    onClick={updateConfig}
                                    disabled={isEditing}
                                    className="flex-1"
                                  >
                                    {isEditing ? (
                                      <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Updating...
                                      </>
                                    ) : (
                                      'Save Changes'
                                    )}
                                  </Button>
                                  <Button
                                    variant="outline"
                                    onClick={() => setEditingConfig(null)}
                                    className="flex-1"
                                  >
                                    Cancel
                                  </Button>
                                </div>
                              </div>
                            ) : (
                              <div>
                                <div className="flex items-center justify-between">
                                  <div>
                                    <h3 className="text-lg font-semibold">{config.name}</h3>
                                    <p className="text-sm text-muted-foreground">{config.sheetId}</p>
                                  </div>
                                  <Badge variant={config.active ? 'default' : 'outline'}>
                                    {config.active ? 'Active' : 'Inactive'}
                                  </Badge>
                                </div>
                                
                                <div className="mt-4">
                                  <p className="text-sm font-medium">Events:</p>
                                  <div className="flex flex-wrap gap-2 mt-1">
                                    {config.events.map((event: string) => {
                                      const eventInfo = eventTypes.find(e => e.id === event);
                                      return (
                                        <Badge key={event} variant="secondary">
                                          {eventInfo ? eventInfo.label : event}
                                        </Badge>
                                      );
                                    })}
                                  </div>
                                </div>
                                
                                <div className="flex space-x-2 mt-4">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => startEditing(config)}
                                  >
                                    Edit
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => deleteConfig(config.id)}
                                    className="text-destructive"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                {/* Manual Trigger */}
                <Card>
                  <CardHeader>
                    <CardTitle>Manual Event Trigger</CardTitle>
                    <CardDescription>
                      Manually trigger an event to test your Google Sheets integration.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="trigger-type">Event Type</Label>
                      <select
                        id="trigger-type"
                        className="w-full p-2 border rounded"
                        value={triggerType}
                        onChange={(e) => setTriggerType(e.target.value)}
                      >
                        {eventTypes.map((event) => (
                          <option key={event.id} value={event.id}>
                            {event.label}
                          </option>
                        ))}
                      </select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="trigger-data">Event Data (JSON)</Label>
                      <Textarea
                        id="trigger-data"
                        value={triggerData}
                        onChange={(e) => setTriggerData(e.target.value)}
                        className="font-mono"
                        rows={8}
                      />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      onClick={triggerEvent} 
                      disabled={isTriggeringEvent || configs.length === 0}
                      className="w-full"
                    >
                      {isTriggeringEvent ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Triggering...
                        </>
                      ) : (
                        <>
                          <RefreshCcw className="mr-2 h-4 w-4" />
                          Trigger Event
                        </>
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
            
            {/* Events Tab */}
            <TabsContent value="events">
              <Card>
                <CardHeader>
                  <CardTitle>Event History</CardTitle>
                  <CardDescription>
                    Recent events that have been sent to Google Sheets.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingEvents ? (
                    <div className="flex justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : events.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <p>No events found. Trigger an event to see it here.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {events.map((event: any) => (
                        <div key={event.id} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h3 className="text-lg font-semibold">{event.type}</h3>
                              <p className="text-sm text-muted-foreground">
                                {new Date(event.timestamp).toLocaleString()}
                              </p>
                            </div>
                            <Badge>
                              Config: {configs.find((c: any) => c.id === event.configId)?.name || 'Unknown'}
                            </Badge>
                          </div>
                          
                          <div className="mt-4">
                            <Label>Data</Label>
                            <div className="mt-1 bg-secondary p-2 rounded-md">
                              <pre className="text-xs overflow-auto whitespace-pre-wrap">
                                {JSON.stringify(event.data, null, 2)}
                              </pre>
                            </div>
                          </div>
                          
                          {event.transformedData && (
                            <div className="mt-4">
                              <Label>Transformed Data</Label>
                              <div className="mt-1 bg-secondary p-2 rounded-md">
                                <pre className="text-xs overflow-auto whitespace-pre-wrap">
                                  {JSON.stringify(event.transformedData, null, 2)}
                                </pre>
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button 
                    variant="outline" 
                    onClick={() => refetchEvents()}
                    className="w-full"
                  >
                    <RefreshCcw className="mr-2 h-4 w-4" />
                    Refresh
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            {/* Apps Script Template Tab */}
            <TabsContent value="script">
              <Card>
                <CardHeader>
                  <CardTitle>Google Apps Script Template</CardTitle>
                  <CardDescription>
                    Generate a Google Apps Script template to create a webhook endpoint for your sheet.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm">
                    To integrate with Google Sheets, you need to create a Google Apps Script Web App that will accept
                    webhook requests and update your sheet. This script will help you get started quickly.
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="script-sheet-id">Google Sheet ID</Label>
                      <Input
                        id="script-sheet-id"
                        value={scriptSheetId}
                        onChange={(e) => setScriptSheetId(e.target.value)}
                        placeholder="e.g. 1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms"
                      />
                      <p className="text-xs text-muted-foreground">
                        The ID of your Google Sheet (from the URL)
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="script-tab-name">Sheet Tab Name</Label>
                      <Input
                        id="script-tab-name"
                        value={scriptTabName}
                        onChange={(e) => setScriptTabName(e.target.value)}
                        placeholder="Sheet1"
                      />
                      <p className="text-xs text-muted-foreground">
                        The name of the tab/sheet within your Google Sheet
                      </p>
                    </div>
                  </div>
                  
                  <Button onClick={getAppsScriptTemplate}>
                    <Code className="mr-2 h-4 w-4" />
                    Generate Script Template
                  </Button>
                  
                  {showScriptTemplate && (
                    <div className="mt-4">
                      <div className="flex justify-between items-center mb-2">
                        <Label>Google Apps Script Template</Label>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={copyScriptToClipboard}
                        >
                          <Copy className="mr-2 h-4 w-4" />
                          Copy
                        </Button>
                      </div>
                      
                      <ScrollArea className="h-[400px] rounded-md border">
                        <pre className="p-4 text-xs">{scriptTemplate}</pre>
                      </ScrollArea>
                      
                      <div className="mt-4 space-y-2">
                        <h3 className="font-semibold">How to use this script:</h3>
                        <ol className="list-decimal list-inside space-y-1 text-sm">
                          <li>Create a new Google Apps Script project from your Google Sheet (Extensions → Apps Script)</li>
                          <li>Replace the code with the generated script</li>
                          <li>Deploy as a web app (Deploy → New deployment → Web app)</li>
                          <li>Execute as: Me (your Google account)</li>
                          <li>Who has access: Anyone (if you want no authentication)</li>
                          <li>Copy the web app URL and paste it as the sheetId in your Google Sheets config</li>
                        </ol>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
};

export default GoogleSheetsIntegration;