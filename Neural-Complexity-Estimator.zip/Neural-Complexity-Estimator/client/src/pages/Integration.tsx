import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Upload, HardDrive, Inbox, FileText, RefreshCw } from 'lucide-react';

const Integration: React.FC = () => {
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('chat-extractor');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  
  // Chat extractor states
  const [chatPlatform, setChatPlatform] = useState<'claude' | 'chatgpt' | 'generic'>('claude');
  const [fileFormat, setFileFormat] = useState<'json' | 'csv' | 'txt'>('json');
  const [collectionName, setCollectionName] = useState('chat_history');
  const [tags, setTags] = useState('');
  const [namespace, setNamespace] = useState('default');
  const [chatFile, setChatFile] = useState<File | null>(null);
  const [chatStats, setChatStats] = useState<any>(null);
  
  // File sync states
  const [platforms, setPlatforms] = useState<any[]>([]);
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [syncDirection, setSyncDirection] = useState<'push' | 'pull' | 'bidirectional'>('push');
  const [includePaths, setIncludePaths] = useState('');
  const [excludePaths, setExcludePaths] = useState('');
  const [deleteOrphaned, setDeleteOrphaned] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  
  // Platform connection states
  const [newPlatform, setNewPlatform] = useState({
    name: '',
    type: 'local',
    rootPath: '',
    config: {} as Record<string, any>
  });
  
  // Fetch platform connections
  const { data: platformList = [], isLoading: isLoadingPlatforms, refetch: refetchPlatforms } = 
    useQuery<any[]>({
      queryKey: ['/api/integration/platforms'],
      enabled: isAuthenticated
    });
  
  useEffect(() => {
    if (platformList.length > 0) {
      setPlatforms(platformList);
    }
  }, [platformList]);
  
  // Handle chat file change
  const handleChatFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setChatFile(e.target.files[0]);
    }
  };
  
  // Upload and extract chat
  const uploadAndExtractChat = async () => {
    if (!chatFile || !collectionName) {
      toast({
        title: 'Error',
        description: 'Please select a file and enter a collection name',
        variant: 'destructive',
      });
      return;
    }
    
    setIsUploading(true);
    setUploadProgress(0);
    setChatStats(null);
    
    try {
      const formData = new FormData();
      formData.append('file', chatFile);
      formData.append('platformType', chatPlatform);
      formData.append('fileFormat', fileFormat);
      formData.append('collectionName', collectionName);
      
      if (tags) {
        formData.append('tags', JSON.stringify(tags.split(',').map(tag => tag.trim())));
      }
      
      if (namespace) {
        formData.append('namespace', namespace);
      }
      
      const response = await fetch('/api/integration/extract-chat', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to extract chat history');
      }
      
      const result = await response.json();
      
      toast({
        title: 'Chat Extraction Successful',
        description: `Extracted ${result.totalExtracted} messages and uploaded ${result.totalUploaded} conversations`,
      });
      
      setChatFile(null);
      if (document.getElementById('chat-file-upload') as HTMLInputElement) {
        (document.getElementById('chat-file-upload') as HTMLInputElement).value = '';
      }
      
      // Try to get chat stats
      await fetchChatStats(result.outputPath);
    } catch (error: any) {
      toast({
        title: 'Chat Extraction Failed',
        description: error.message || 'Failed to extract chat history',
        variant: 'destructive',
      });
    } finally {
      setIsUploading(false);
      setUploadProgress(100);
      
      // Reset progress after a delay
      setTimeout(() => {
        setUploadProgress(0);
      }, 1000);
    }
  };
  
  // Helper function to get filename from path
  const getFilenameFromPath = (filePath: string): string => {
    if (!filePath) return '';
    // Split by forward or back slashes and get the last part
    const parts = filePath.split(/[/\\]/);
    return parts[parts.length - 1];
  };
  
  // Fetch chat statistics
  const fetchChatStats = async (filePath: string) => {
    try {
      if (!filePath) return;
      
      const filename = getFilenameFromPath(filePath);
      const response = await fetch(`/api/integration/chat-stats/${filename}`);
      
      if (!response.ok) {
        throw new Error('Failed to get chat statistics');
      }
      
      const stats = await response.json();
      setChatStats(stats);
    } catch (error: any) {
      console.error('Error fetching chat stats:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to fetch chat statistics',
        variant: 'destructive',
      });
    }
  };
  
  // Add platform connection
  const addPlatform = async () => {
    try {
      if (!newPlatform.name || !newPlatform.rootPath) {
        toast({
          title: 'Error',
          description: 'Please enter platform name and root path',
          variant: 'destructive',
        });
        return;
      }
      
      const response = await fetch('/api/integration/platforms', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newPlatform,
          active: true,
        }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to add platform');
      }
      
      const result = await response.json();
      
      toast({
        title: 'Platform Added',
        description: `Added ${result.platform.name} successfully`,
      });
      
      // Reset form and refresh platforms
      setNewPlatform({
        name: '',
        type: 'local',
        rootPath: '',
        config: {}
      });
      
      refetchPlatforms();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to add platform',
        variant: 'destructive',
      });
    }
  };
  
  // Remove platform
  const removePlatform = async (id: string) => {
    try {
      const response = await fetch(`/api/integration/platforms/${id}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to remove platform');
      }
      
      toast({
        title: 'Platform Removed',
        description: 'Platform removed successfully',
      });
      
      refetchPlatforms();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to remove platform',
        variant: 'destructive',
      });
    }
  };
  
  // Sync files
  const syncFiles = async () => {
    try {
      if (selectedPlatforms.length < 1) {
        toast({
          title: 'Error',
          description: 'Please select at least one platform',
          variant: 'destructive',
        });
        return;
      }
      
      setIsSyncing(true);
      
      const response = await fetch('/api/integration/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          platforms: selectedPlatforms,
          direction: syncDirection,
          includePaths: includePaths ? includePaths.split(',').map(p => p.trim()) : [],
          excludePaths: excludePaths ? excludePaths.split(',').map(p => p.trim()) : [],
          deleteOrphaned,
        }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to sync files');
      }
      
      const result = await response.json();
      
      if (result.success) {
        toast({
          title: 'Sync Successful',
          description: `Processed ${result.filesProcessed} files, updated ${result.filesUpdated} files`,
        });
      } else {
        toast({
          title: 'Sync Issues',
          description: `Sync completed with issues: ${result.errors.join(', ')}`,
          variant: 'destructive',
        });
      }
    } catch (error: any) {
      toast({
        title: 'Sync Failed',
        description: error.message || 'Failed to sync files',
        variant: 'destructive',
      });
    } finally {
      setIsSyncing(false);
    }
  };
  
  // Handle platform config change
  const handleConfigChange = (key: string, value: string) => {
    setNewPlatform(prev => ({
      ...prev,
      config: {
        ...prev.config,
        [key]: value
      }
    }));
  };
  
  // Render platform config fields based on type
  const renderPlatformConfigFields = () => {
    switch (newPlatform.type) {
      case 'ubuntu':
      case 'windows':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="host">Host</Label>
              <Input
                id="host"
                value={newPlatform.config.host || ''}
                onChange={(e) => handleConfigChange('host', e.target.value)}
                placeholder="hostname or IP address"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="port">Port</Label>
              <Input
                id="port"
                type="number"
                value={newPlatform.config.port || '22'}
                onChange={(e) => handleConfigChange('port', e.target.value)}
                placeholder="22"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                value={newPlatform.config.username || ''}
                onChange={(e) => handleConfigChange('username', e.target.value)}
                placeholder="Username"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={newPlatform.config.password || ''}
                onChange={(e) => handleConfigChange('password', e.target.value)}
                placeholder="Password (if not using privateKey)"
              />
            </div>
          </>
        );
      
      case 'dropbox':
        return (
          <div className="space-y-2">
            <Label htmlFor="accessToken">Access Token</Label>
            <Input
              id="accessToken"
              type="password"
              value={newPlatform.config.accessToken || ''}
              onChange={(e) => handleConfigChange('accessToken', e.target.value)}
              placeholder="Dropbox Access Token"
            />
          </div>
        );
      
      case 'local':
        return (
          <p className="text-sm text-gray-500">
            No additional configuration needed for local filesystem.
          </p>
        );
      
      default:
        return null;
    }
  };
  
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Integration Tools</h1>
      
      {!isAuthenticated ? (
        <Card>
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>
              Please log in to access the integration tools.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => window.location.href = '/api/login'}>
              Log in with Replit
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="chat-extractor">Chat History Extractor</TabsTrigger>
              <TabsTrigger value="file-sync">File Synchronization</TabsTrigger>
              <TabsTrigger value="platforms">Platform Connections</TabsTrigger>
            </TabsList>
            
            {/* Chat Extractor Tab */}
            <TabsContent value="chat-extractor">
              <Card>
                <CardHeader>
                  <CardTitle>Chat History Extractor</CardTitle>
                  <CardDescription>
                    Extract conversations from Claude, ChatGPT, and other AI platforms.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="chat-platform">Platform</Label>
                      <select
                        id="chat-platform"
                        className="w-full p-2 border rounded"
                        value={chatPlatform}
                        onChange={(e) => setChatPlatform(e.target.value as any)}
                        disabled={isUploading}
                      >
                        <option value="claude">Claude</option>
                        <option value="chatgpt">ChatGPT</option>
                        <option value="generic">Generic</option>
                      </select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="file-format">File Format</Label>
                      <select
                        id="file-format"
                        className="w-full p-2 border rounded"
                        value={fileFormat}
                        onChange={(e) => setFileFormat(e.target.value as any)}
                        disabled={isUploading || chatPlatform !== 'generic'}
                      >
                        <option value="json">JSON</option>
                        <option value="csv">CSV</option>
                        <option value="txt">TXT</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="collection-name">Collection Name</Label>
                      <Input
                        id="collection-name"
                        value={collectionName}
                        onChange={(e) => setCollectionName(e.target.value)}
                        placeholder="Collection name in Astra DB"
                        disabled={isUploading}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="namespace">Namespace</Label>
                      <Input
                        id="namespace"
                        value={namespace}
                        onChange={(e) => setNamespace(e.target.value)}
                        placeholder="Namespace in Astra DB"
                        disabled={isUploading}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="tags">Tags (comma-separated)</Label>
                    <Input
                      id="tags"
                      value={tags}
                      onChange={(e) => setTags(e.target.value)}
                      placeholder="e.g. business, technical, requirements"
                      disabled={isUploading}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="chat-file-upload">Chat Export File</Label>
                    <Input
                      id="chat-file-upload"
                      type="file"
                      accept=".json,.csv,.txt"
                      onChange={handleChatFileChange}
                      disabled={isUploading}
                    />
                  </div>
                  
                  {uploadProgress > 0 && (
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div
                        className="bg-blue-600 h-2.5 rounded-full"
                        style={{ width: `${uploadProgress}%` }}
                      ></div>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button 
                    onClick={uploadAndExtractChat} 
                    disabled={!chatFile || !collectionName || isUploading}
                    className="w-full"
                  >
                    {isUploading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Extracting...
                      </>
                    ) : (
                      <>
                        <Upload className="mr-2 h-4 w-4" />
                        Extract and Upload
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
              
              {chatStats && (
                <Card className="mt-4">
                  <CardHeader>
                    <CardTitle>Chat Statistics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-gray-100 p-4 rounded">
                        <h3 className="text-lg font-medium mb-2">Overview</h3>
                        <p>Total Messages: {chatStats.totalMessages}</p>
                        <p>Conversations: {chatStats.conversations}</p>
                        <p>Avg. Message Length: {Math.round(chatStats.averageMessageLength)} chars</p>
                      </div>
                      
                      <div className="bg-gray-100 p-4 rounded">
                        <h3 className="text-lg font-medium mb-2">Top Topics</h3>
                        <ul className="space-y-1">
                          {Object.entries(chatStats.topicDistribution)
                            .slice(0, 5)
                            .map(([topic, count]) => (
                              <li key={topic} className="flex justify-between">
                                <span>{topic}</span>
                                <Badge variant="outline">{count}</Badge>
                              </li>
                            ))}
                        </ul>
                      </div>
                      
                      <div className="bg-gray-100 p-4 rounded">
                        <h3 className="text-lg font-medium mb-2">Requirements</h3>
                        <ul className="space-y-1 text-sm">
                          {chatStats.requirements.map((req: string, index: number) => (
                            <li key={index} className="flex items-start gap-2">
                              <span className="text-green-600">✓</span>
                              <span>{req}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
            
            {/* File Sync Tab */}
            <TabsContent value="file-sync">
              <Card>
                <CardHeader>
                  <CardTitle>File Synchronization</CardTitle>
                  <CardDescription>
                    Sync files between your devices and cloud storage.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {platforms.length === 0 ? (
                    <div className="text-center p-4 border rounded bg-gray-50">
                      <Inbox className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-sm font-semibold">No platforms configured</h3>
                      <p className="mt-1 text-sm text-gray-500">
                        Add platforms in the "Platform Connections" tab to start syncing files.
                      </p>
                    </div>
                  ) : (
                    <>
                      <div className="space-y-2">
                        <Label>Select Platforms</Label>
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                          {platforms.map((platform) => (
                            <div 
                              key={platform.id}
                              className={`p-3 border rounded cursor-pointer flex items-center gap-2 ${
                                selectedPlatforms.includes(platform.id) ? 'bg-blue-50 border-blue-300' : ''
                              }`}
                              onClick={() => {
                                if (selectedPlatforms.includes(platform.id)) {
                                  setSelectedPlatforms(selectedPlatforms.filter(id => id !== platform.id));
                                } else {
                                  setSelectedPlatforms([...selectedPlatforms, platform.id]);
                                }
                              }}
                            >
                              <div className="flex-grow">
                                <div className="font-medium">{platform.name}</div>
                                <div className="text-xs text-gray-500">{platform.type}</div>
                              </div>
                              <div>
                                {platform.type === 'local' && <HardDrive className="h-5 w-5" />}
                                {platform.type === 'dropbox' && <FileText className="h-5 w-5" />}
                                {(platform.type === 'ubuntu' || platform.type === 'windows') && (
                                  <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect>
                                    <rect x="9" y="9" width="6" height="6"></rect>
                                    <line x1="9" y1="1" x2="9" y2="4"></line>
                                    <line x1="15" y1="1" x2="15" y2="4"></line>
                                    <line x1="9" y1="20" x2="9" y2="23"></line>
                                    <line x1="15" y1="20" x2="15" y2="23"></line>
                                    <line x1="20" y1="9" x2="23" y2="9"></line>
                                    <line x1="20" y1="14" x2="23" y2="14"></line>
                                    <line x1="1" y1="9" x2="4" y2="9"></line>
                                    <line x1="1" y1="14" x2="4" y2="14"></line>
                                  </svg>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="sync-direction">Sync Direction</Label>
                        <select
                          id="sync-direction"
                          className="w-full p-2 border rounded"
                          value={syncDirection}
                          onChange={(e) => setSyncDirection(e.target.value as any)}
                          disabled={isSyncing}
                        >
                          <option value="push">Push (Local → Remote)</option>
                          <option value="pull">Pull (Remote → Local)</option>
                          <option value="bidirectional">Bidirectional (Experimental)</option>
                        </select>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="include-paths">Include Paths (comma-separated)</Label>
                          <Input
                            id="include-paths"
                            value={includePaths}
                            onChange={(e) => setIncludePaths(e.target.value)}
                            placeholder="Paths to include (optional)"
                            disabled={isSyncing}
                          />
                          <p className="text-xs text-gray-500">Leave empty to include all files</p>
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="exclude-paths">Exclude Paths (comma-separated)</Label>
                          <Input
                            id="exclude-paths"
                            value={excludePaths}
                            onChange={(e) => setExcludePaths(e.target.value)}
                            placeholder="Paths to exclude (optional)"
                            disabled={isSyncing}
                          />
                          <p className="text-xs text-gray-500">e.g. node_modules, .git</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id="delete-orphaned"
                          checked={deleteOrphaned}
                          onChange={(e) => setDeleteOrphaned(e.target.checked)}
                          disabled={isSyncing}
                          className="h-4 w-4"
                        />
                        <Label htmlFor="delete-orphaned">Delete orphaned files (use with caution)</Label>
                      </div>
                      
                      <Button 
                        onClick={syncFiles} 
                        disabled={selectedPlatforms.length < 1 || isSyncing}
                        className="w-full"
                      >
                        {isSyncing ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Syncing Files...
                          </>
                        ) : (
                          <>
                            <RefreshCw className="mr-2 h-4 w-4" />
                            Sync Files
                          </>
                        )}
                      </Button>
                    </>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Platforms Tab */}
            <TabsContent value="platforms">
              <Card>
                <CardHeader>
                  <CardTitle>Platform Connections</CardTitle>
                  <CardDescription>
                    Configure connections to your devices and cloud storage.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Add New Platform</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="platform-name">Platform Name</Label>
                        <Input
                          id="platform-name"
                          value={newPlatform.name}
                          onChange={(e) => setNewPlatform({...newPlatform, name: e.target.value})}
                          placeholder="e.g. My Ubuntu Server"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="platform-type">Platform Type</Label>
                        <select
                          id="platform-type"
                          className="w-full p-2 border rounded"
                          value={newPlatform.type}
                          onChange={(e) => setNewPlatform({...newPlatform, type: e.target.value as any})}
                        >
                          <option value="local">Local Filesystem</option>
                          <option value="ubuntu">Ubuntu (SFTP)</option>
                          <option value="windows">Windows (SFTP)</option>
                          <option value="dropbox">Dropbox</option>
                        </select>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="root-path">Root Path</Label>
                      <Input
                        id="root-path"
                        value={newPlatform.rootPath}
                        onChange={(e) => setNewPlatform({...newPlatform, rootPath: e.target.value})}
                        placeholder={
                          newPlatform.type === 'local' 
                            ? '/home/user/documents' 
                            : newPlatform.type === 'dropbox'
                              ? '/my_folder'
                              : '/home/user/sync'
                        }
                      />
                      <p className="text-xs text-gray-500">
                        Base path for file synchronization
                      </p>
                    </div>
                    
                    <div className="space-y-4">
                      <h4 className="text-sm font-medium">Connection Settings</h4>
                      {renderPlatformConfigFields()}
                    </div>
                    
                    <Button onClick={addPlatform}>
                      Add Platform
                    </Button>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Your Platforms</h3>
                    
                    {isLoadingPlatforms ? (
                      <div className="text-center p-4">
                        <Loader2 className="mx-auto h-8 w-8 animate-spin text-gray-400" />
                        <p className="mt-2 text-sm text-gray-500">Loading platforms...</p>
                      </div>
                    ) : platforms.length === 0 ? (
                      <p className="text-center p-4 text-gray-500">
                        No platforms configured yet.
                      </p>
                    ) : (
                      <div className="space-y-2">
                        {platforms.map((platform) => (
                          <div 
                            key={platform.id}
                            className="p-4 border rounded flex justify-between items-center"
                          >
                            <div>
                              <div className="font-medium">{platform.name}</div>
                              <div className="text-sm text-gray-500">
                                {platform.type} • {platform.rootPath}
                              </div>
                            </div>
                            <Button 
                              variant="destructive" 
                              size="sm"
                              onClick={() => removePlatform(platform.id)}
                            >
                              Remove
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
};

export default Integration;