import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'wouter';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { Eye, Plus, Trash2, Settings, ArrowRight, Power, Calendar, FileText } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Switch } from '@/components/ui/switch';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { apiRequest } from '@/lib/queryClient';

// Define validation schemas
const watchConfigSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters'),
  path: z.string().min(1, 'Path is required'),
  excludePaths: z.array(z.string()).default([]),
  isRecursive: z.boolean().default(true),
  watchForPatterns: z.array(z.string()).default(['*']),
  ignorePatterns: z.array(z.string()).default([]),
  active: z.boolean().default(true)
});

// Interface types based on the backend
interface WatchConfig {
  id: string;
  name: string;
  path: string;
  excludePaths: string[];
  isRecursive: boolean;
  watchForPatterns: string[];
  ignorePatterns: string[];
  active: boolean;
  createdAt: string;
  automationRules: AutomationRule[];
}

interface AutomationRule {
  id: string;
  name: string;
  description?: string;
  eventType: 'add' | 'change' | 'unlink' | 'addDir' | 'unlinkDir' | 'all';
  filePattern: string;
  actions: AutomationAction[];
  active: boolean;
}

interface AutomationAction {
  id: string;
  type: 'notify' | 'move' | 'copy' | 'delete' | 'rename' | 'sync' | 'extract' | 'execute' | 'googleSheets';
  config: Record<string, any>;
  active: boolean;
}

interface FileEvent {
  id: string;
  watchId: string;
  eventType: string;
  filePath: string;
  relativePath: string;
  timestamp: string;
  fileStats?: any;
  automationResults?: AutomationResult[];
}

interface AutomationResult {
  id: string;
  ruleId: string;
  ruleName: string;
  successful: boolean;
  actions: {
    id: string;
    type: string;
    successful: boolean;
    message?: string;
    details?: any;
  }[];
  timestamp: string;
}

// Add watch configuration form component
const AddConfigForm = ({ onClose }: { onClose: () => void }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<z.infer<typeof watchConfigSchema>>({
    resolver: zodResolver(watchConfigSchema),
    defaultValues: {
      name: '',
      path: '',
      excludePaths: [],
      isRecursive: true,
      watchForPatterns: ['*'],
      ignorePatterns: [],
      active: true
    }
  });
  
  const [excludePath, setExcludePath] = useState('');
  const [watchPattern, setWatchPattern] = useState('');
  const [ignorePattern, setIgnorePattern] = useState('');
  
  const { mutate: addConfig, isPending } = useMutation({
    mutationFn: (data: z.infer<typeof watchConfigSchema>) => 
      apiRequest('/api/file-watch/configs', {
        method: 'POST',
        data
      }),
    onSuccess: () => {
      toast({
        title: 'Configuration added',
        description: 'Watch configuration has been added successfully.'
      });
      queryClient.invalidateQueries({ queryKey: ['/api/file-watch/configs'] });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to add configuration',
        description: error.message || 'An error occurred while adding the configuration.',
        variant: 'destructive'
      });
    }
  });
  
  const addExcludePath = () => {
    if (excludePath.trim()) {
      const currentPaths = form.getValues().excludePaths || [];
      form.setValue('excludePaths', [...currentPaths, excludePath.trim()]);
      setExcludePath('');
    }
  };
  
  const removeExcludePath = (index: number) => {
    const currentPaths = form.getValues().excludePaths || [];
    form.setValue('excludePaths', currentPaths.filter((_, i) => i !== index));
  };
  
  const addWatchPattern = () => {
    if (watchPattern.trim()) {
      const currentPatterns = form.getValues().watchForPatterns || [];
      form.setValue('watchForPatterns', [...currentPatterns, watchPattern.trim()]);
      setWatchPattern('');
    }
  };
  
  const removeWatchPattern = (index: number) => {
    const currentPatterns = form.getValues().watchForPatterns || [];
    form.setValue('watchForPatterns', currentPatterns.filter((_, i) => i !== index));
  };
  
  const addIgnorePattern = () => {
    if (ignorePattern.trim()) {
      const currentPatterns = form.getValues().ignorePatterns || [];
      form.setValue('ignorePatterns', [...currentPatterns, ignorePattern.trim()]);
      setIgnorePattern('');
    }
  };
  
  const removeIgnorePattern = (index: number) => {
    const currentPatterns = form.getValues().ignorePatterns || [];
    form.setValue('ignorePatterns', currentPatterns.filter((_, i) => i !== index));
  };
  
  const onSubmit = (data: z.infer<typeof watchConfigSchema>) => {
    addConfig(data);
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Configuration Name</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Documents Folder Watch" />
              </FormControl>
              <FormDescription>
                A descriptive name for this watch configuration.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="path"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Watch Path</FormLabel>
              <FormControl>
                <Input {...field} placeholder="/path/to/watch" />
              </FormControl>
              <FormDescription>
                The directory path to monitor for changes.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="excludePaths"
          render={() => (
            <FormItem>
              <FormLabel>Exclude Paths</FormLabel>
              <div className="flex space-x-2">
                <Input 
                  value={excludePath} 
                  onChange={(e) => setExcludePath(e.target.value)}
                  placeholder="node_modules"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addExcludePath();
                    }
                  }}
                />
                <Button 
                  type="button" 
                  onClick={addExcludePath}
                  variant="outline"
                >
                  Add
                </Button>
              </div>
              <FormDescription>
                Paths to exclude from watching (relative to the watch path).
              </FormDescription>
              <div className="mt-2">
                {form.watch('excludePaths')?.map((path, index) => (
                  <Badge key={index} variant="secondary" className="m-1">
                    {path}
                    <button 
                      type="button" 
                      className="ml-1 text-muted-foreground hover:text-foreground"
                      onClick={() => removeExcludePath(index)}
                    >
                      ×
                    </button>
                  </Badge>
                ))}
              </div>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="watchForPatterns"
          render={() => (
            <FormItem>
              <FormLabel>Watch For Patterns</FormLabel>
              <div className="flex space-x-2">
                <Input 
                  value={watchPattern} 
                  onChange={(e) => setWatchPattern(e.target.value)}
                  placeholder="*.pdf"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addWatchPattern();
                    }
                  }}
                />
                <Button 
                  type="button" 
                  onClick={addWatchPattern}
                  variant="outline"
                >
                  Add
                </Button>
              </div>
              <FormDescription>
                File patterns to watch for (e.g., "*.pdf", "documents/*.docx").
              </FormDescription>
              <div className="mt-2">
                {form.watch('watchForPatterns')?.map((pattern, index) => (
                  <Badge key={index} variant="secondary" className="m-1">
                    {pattern}
                    <button 
                      type="button" 
                      className="ml-1 text-muted-foreground hover:text-foreground"
                      onClick={() => removeWatchPattern(index)}
                    >
                      ×
                    </button>
                  </Badge>
                ))}
              </div>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="ignorePatterns"
          render={() => (
            <FormItem>
              <FormLabel>Ignore Patterns</FormLabel>
              <div className="flex space-x-2">
                <Input 
                  value={ignorePattern} 
                  onChange={(e) => setIgnorePattern(e.target.value)}
                  placeholder=".git"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addIgnorePattern();
                    }
                  }}
                />
                <Button 
                  type="button" 
                  onClick={addIgnorePattern}
                  variant="outline"
                >
                  Add
                </Button>
              </div>
              <FormDescription>
                File patterns to ignore (e.g., ".git", "*.tmp").
              </FormDescription>
              <div className="mt-2">
                {form.watch('ignorePatterns')?.map((pattern, index) => (
                  <Badge key={index} variant="secondary" className="m-1">
                    {pattern}
                    <button 
                      type="button" 
                      className="ml-1 text-muted-foreground hover:text-foreground"
                      onClick={() => removeIgnorePattern(index)}
                    >
                      ×
                    </button>
                  </Badge>
                ))}
              </div>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="isRecursive"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <FormLabel className="text-base">Watch Recursively</FormLabel>
                <FormDescription>
                  Watch subdirectories recursively.
                </FormDescription>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="active"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <FormLabel className="text-base">Active</FormLabel>
                <FormDescription>
                  Whether this watch configuration is active.
                </FormDescription>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <DialogFooter>
          <Button 
            type="button" 
            variant="outline" 
            onClick={onClose}
            disabled={isPending}
          >
            Cancel
          </Button>
          <Button type="submit" disabled={isPending}>
            {isPending ? 'Adding...' : 'Add Configuration'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
};

// Configurations listing component
const ConfigurationsListing = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  
  const { data: configs, isLoading, error } = useQuery<WatchConfig[]>({
    queryKey: ['/api/file-watch/configs'],
  });
  
  const { data: recentEvents, isLoading: eventsLoading } = useQuery<FileEvent[]>({
    queryKey: ['/api/file-watch/events/recent'],
  });
  
  const { mutate: toggleConfigActive } = useMutation({
    mutationFn: ({ id, active }: { id: string, active: boolean }) => 
      apiRequest(`/api/file-watch/configs/${id}`, {
        method: 'PATCH',
        data: { active }
      }),
    onSuccess: () => {
      toast({
        title: 'Configuration updated',
        description: 'Watch configuration has been updated successfully.'
      });
      queryClient.invalidateQueries({ queryKey: ['/api/file-watch/configs'] });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to update configuration',
        description: error.message || 'An error occurred while updating the configuration.',
        variant: 'destructive'
      });
    }
  });
  
  const { mutate: deleteConfig } = useMutation({
    mutationFn: (id: string) => 
      apiRequest(`/api/file-watch/configs/${id}`, {
        method: 'DELETE'
      }),
    onSuccess: () => {
      toast({
        title: 'Configuration deleted',
        description: 'Watch configuration has been deleted successfully.'
      });
      queryClient.invalidateQueries({ queryKey: ['/api/file-watch/configs'] });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to delete configuration',
        description: error.message || 'An error occurred while deleting the configuration.',
        variant: 'destructive'
      });
    }
  });
  
  const handleToggleActive = (id: string, currentActive: boolean) => {
    toggleConfigActive({ id, active: !currentActive });
  };
  
  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this configuration?')) {
      deleteConfig(id);
    }
  };
  
  if (isLoading) {
    return <div className="text-center p-8">Loading configurations...</div>;
  }
  
  if (error) {
    return (
      <Alert variant="destructive" className="mb-4">
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          Failed to load file watch configurations. {(error as Error).message}
        </AlertDescription>
      </Alert>
    );
  }
  
  return (
    <div>
      <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">File Watch Configurations</h1>
          <p className="text-muted-foreground mt-1">
            Monitor file changes and trigger automated actions.
          </p>
        </div>
        
        <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" /> Add Configuration
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-xl">
            <DialogHeader>
              <DialogTitle>Add Watch Configuration</DialogTitle>
              <DialogDescription>
                Create a new file watch configuration to monitor changes and trigger automations.
              </DialogDescription>
            </DialogHeader>
            
            <AddConfigForm onClose={() => setAddDialogOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>
      
      <div className="space-y-6">
        {configs && configs?.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <Eye className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-4 text-lg font-medium">No watch configurations</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Create your first file watch configuration to start monitoring file changes.
              </p>
              <Button 
                className="mt-4" 
                onClick={() => setAddDialogOpen(true)}
              >
                <Plus className="mr-2 h-4 w-4" /> Add Configuration
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {configs?.map((config) => (
              <Card key={config.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>{config.name}</CardTitle>
                      <CardDescription className="mt-1">
                        {config.path}
                      </CardDescription>
                    </div>
                    <Badge variant={config.active ? "default" : "secondary"}>
                      {config.active ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-x-6 gap-y-2 mb-4">
                    <div className="flex items-center">
                      <span className="text-muted-foreground mr-2">Rules:</span>
                      <span className="font-medium">{config.automationRules?.length || 0}</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-muted-foreground mr-2">Recursive:</span>
                      <span>{config.isRecursive ? 'Yes' : 'No'}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    {config.watchForPatterns?.length > 0 && (
                      <div className="text-sm">
                        <span className="font-medium">Watch patterns:</span>{' '}
                        <div className="mt-1 flex flex-wrap gap-1">
                          {config.watchForPatterns.map((pattern, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {pattern}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {config.excludePaths?.length > 0 && (
                      <div className="text-sm mt-2">
                        <span className="font-medium">Excluded:</span>{' '}
                        <div className="mt-1 flex flex-wrap gap-1">
                          {config.excludePaths.map((path, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {path}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between pt-2">
                  <Button 
                    variant="outline" 
                    size="icon"
                    title={config.active ? "Deactivate" : "Activate"}
                    onClick={() => handleToggleActive(config.id, config.active)}
                  >
                    <Power className={`h-4 w-4 ${config.active ? 'text-green-500' : 'text-muted-foreground'}`} />
                  </Button>
                  
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="icon"
                      title="Delete"
                      onClick={() => handleDelete(config.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                    
                    <Button variant="outline" asChild title="Configure">
                      <Link href={`/file-watch/config/${config.id}`}>
                        <Settings className="h-4 w-4 mr-2" /> Configure
                      </Link>
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
      
      {recentEvents && recentEvents.length > 0 && (
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-4">Recent File Events</h2>
          <Card>
            <CardContent className="p-0 overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Config</TableHead>
                    <TableHead>Event Type</TableHead>
                    <TableHead className="hidden md:table-cell">Path</TableHead>
                    <TableHead className="hidden lg:table-cell">Time</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentEvents.map((event) => (
                    <TableRow key={event.id}>
                      <TableCell className="font-medium">
                        {configs?.find(c => c.id === event.watchId)?.name || event.watchId}
                      </TableCell>
                      <TableCell>
                        <Badge variant={event.eventType === 'unlink' ? 'destructive' : event.eventType === 'add' ? 'default' : 'secondary'}>
                          {event.eventType}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden md:table-cell font-mono text-xs truncate max-w-xs" title={event.relativePath}>
                        {event.relativePath}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        {new Date(event.timestamp).toLocaleString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/file-watch/config/${event.watchId}`}>
                            <ArrowRight className="h-4 w-4" />
                          </Link>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

// Main component
const FileWatchConfiguration = () => {
  return (
    <div className="container py-8">
      <ConfigurationsListing />
    </div>
  );
};

export default FileWatchConfiguration;