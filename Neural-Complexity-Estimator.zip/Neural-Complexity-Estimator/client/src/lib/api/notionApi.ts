/**
 * PinkSync - Notion API Client
 * Client-side API methods for interacting with the Notion integration
 */

import { apiRequest } from '../queryClient';

/**
 * Get all Notion connections
 */
export const getConnections = async () => {
  const response = await apiRequest('/api/notion/connections');
  return response;
};

/**
 * Get a specific Notion connection
 */
export const getConnection = async (id: string) => {
  const response = await apiRequest(`/api/notion/connections/${id}`);
  return response;
};

/**
 * Add a new Notion connection
 */
export const addConnection = async (connectionData: any) => {
  const response = await apiRequest('/api/notion/connections', {
    method: 'POST',
    body: JSON.stringify(connectionData),
  });
  return response;
};

/**
 * Update a Notion connection
 */
export const updateConnection = async ({ id, updates }: { id: string; updates: any }) => {
  const response = await apiRequest(`/api/notion/connections/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(updates),
  });
  return response;
};

/**
 * Remove a Notion connection
 */
export const removeConnection = async (id: string) => {
  const response = await apiRequest(`/api/notion/connections/${id}`, {
    method: 'DELETE',
  });
  return response;
};

/**
 * Get available databases for a connection
 */
export const getAvailableDatabases = async (connectionId: string) => {
  const response = await apiRequest(`/api/notion/connections/${connectionId}/databases`);
  return response;
};

/**
 * Add a database to a connection
 */
export const addDatabase = async ({ connectionId, database }: { connectionId: string; database: any }) => {
  const response = await apiRequest(`/api/notion/connections/${connectionId}/databases`, {
    method: 'POST',
    body: JSON.stringify(database),
  });
  return response;
};

/**
 * Update a database in a connection
 */
export const updateDatabase = async ({
  connectionId,
  databaseId,
  updates,
}: {
  connectionId: string;
  databaseId: string;
  updates: any;
}) => {
  const response = await apiRequest(`/api/notion/connections/${connectionId}/databases/${databaseId}`, {
    method: 'PATCH',
    body: JSON.stringify(updates),
  });
  return response;
};

/**
 * Remove a database from a connection
 */
export const removeDatabase = async ({
  connectionId,
  databaseId,
}: {
  connectionId: string;
  databaseId: string;
}) => {
  const response = await apiRequest(`/api/notion/connections/${connectionId}/databases/${databaseId}`, {
    method: 'DELETE',
  });
  return response;
};

/**
 * Create a new database in Notion
 */
export const createDatabase = async ({
  connectionId,
  title,
  parentPageId,
  type,
}: {
  connectionId: string;
  title: string;
  parentPageId: string;
  type?: string;
}) => {
  const response = await apiRequest(`/api/notion/connections/${connectionId}/create-database`, {
    method: 'POST',
    body: JSON.stringify({ title, parentPageId, type }),
  });
  return response;
};

/**
 * Sync an idea to Notion
 */
export const syncIdeaToNotion = async (options: {
  ideaId: number;
  connectionId: string;
  databaseId?: string;
  includeAnalysis?: boolean;
  includeValidation?: boolean;
  includeFiles?: boolean;
  asTemplate?: boolean;
  templateType?: string;
  templateProperties?: any;
}) => {
  const response = await apiRequest('/api/notion/sync-idea', {
    method: 'POST',
    body: JSON.stringify(options),
  });
  return response;
};

/**
 * Import content from Notion
 */
export const importFromNotion = async (options: {
  connectionId: string;
  databaseId: string;
  pageId?: string;
  asIdea?: boolean;
  categoryMapping?: Record<string, string>;
  statusMapping?: Record<string, string>;
  limit?: number;
}) => {
  const response = await apiRequest('/api/notion/import', {
    method: 'POST',
    body: JSON.stringify(options),
  });
  return response;
};

/**
 * Get database types
 */
export const getDatabaseTypes = async () => {
  const response = await apiRequest('/api/notion/database-types');
  return response;
};

export const notionApi = {
  getConnections,
  getConnection,
  addConnection,
  updateConnection,
  removeConnection,
  getAvailableDatabases,
  addDatabase,
  updateDatabase,
  removeDatabase,
  createDatabase,
  syncIdeaToNotion,
  importFromNotion,
  getDatabaseTypes,
};