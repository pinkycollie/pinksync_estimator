import { useQuery } from "@tanstack/react-query";

interface AccessControlPermissions {
  fileWatcher: boolean;
  fileAutomation: boolean;
  accessControl: boolean;
  [key: string]: boolean;
}

interface AccessControlRole {
  id: string;
  description: string;
}

interface AccessControlInfo {
  roles: AccessControlRole[];
  permissions: AccessControlPermissions;
}

export interface AuthUser {
  sub: string;
  email?: string;
  username?: string;
  first_name?: string | null;
  last_name?: string | null;
  profile_image_url?: string;
  accessControl?: AccessControlInfo;
}

export function useAuth() {
  // Fetch the current auth state from the server
  const { data: user, isLoading, error, refetch } = useQuery<AuthUser | null>({
    queryKey: ["/api/auth/user"],
    retry: false,
    refetchOnWindowFocus: true,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Helper function to redirect to login
  const login = () => {
    window.location.href = '/api/login';
  };

  // Helper function to log out
  const logout = () => {
    window.location.href = '/api/logout';
  };

  // Check if user has a specific permission
  const hasPermission = (permission: string): boolean => {
    if (!user?.accessControl?.permissions) {
      return false;
    }
    
    return !!user.accessControl.permissions[permission];
  };

  // Check if user has a specific role
  const hasRole = (roleId: string): boolean => {
    if (!user?.accessControl?.roles) {
      return false;
    }
    
    return user.accessControl.roles.some(role => role.id === roleId);
  };

  return {
    user,
    isLoading,
    error,
    isAuthenticated: !!user,
    login,
    logout,
    refetch,
    hasPermission,
    hasRole
  };
}