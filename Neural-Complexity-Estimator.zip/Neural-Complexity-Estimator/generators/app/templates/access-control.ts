/**
 * <%= description %>
 */
import { Permission, Role, UserAccessControl } from './accessControl';

/**
 * Class for managing <%= name %> access control
 */
export class <%= className %> {
  /**
   * Get the list of permissions for <%= name %>
   */
  public static getPermissions(): Permission[] {
    return [
      {
        key: '<%= name %>.read',
        name: 'Read <%= name %>',
        description: 'Permission to view <%= name %> information',
        resourceType: '<%= name %>',
        action: 'read'
      },
      {
        key: '<%= name %>.create',
        name: 'Create <%= name %>',
        description: 'Permission to create new <%= name %> entries',
        resourceType: '<%= name %>',
        action: 'create'
      },
      {
        key: '<%= name %>.update',
        name: 'Update <%= name %>',
        description: 'Permission to modify existing <%= name %> entries',
        resourceType: '<%= name %>',
        action: 'update'
      },
      {
        key: '<%= name %>.delete',
        name: 'Delete <%= name %>',
        description: 'Permission to remove <%= name %> entries',
        resourceType: '<%= name %>',
        action: 'delete'
      },
      {
        key: '<%= name %>.admin',
        name: 'Administer <%= name %>',
        description: 'Permission to administer <%= name %> system',
        resourceType: '<%= name %>',
        action: 'admin'
      }
    ];
  }
  
  /**
   * Get the list of roles for <%= name %>
   */
  public static getRoles(): Role[] {
    return [
      {
        id: '<%= name %>Viewer',
        name: '<%= name %> Viewer',
        description: 'Can view <%= name %> information but cannot modify',
        permissions: ['<%= name %>.read']
      },
      {
        id: '<%= name %>Editor',
        name: '<%= name %> Editor',
        description: 'Can view and modify <%= name %> information',
        permissions: ['<%= name %>.read', '<%= name %>.create', '<%= name %>.update']
      },
      {
        id: '<%= name %>Admin',
        name: '<%= name %> Administrator',
        description: 'Has full control over <%= name %> system',
        permissions: ['<%= name %>.read', '<%= name %>.create', '<%= name %>.update', '<%= name %>.delete', '<%= name %>.admin']
      }
    ];
  }
  
  /**
   * Check if a user has a specific <%= name %> permission
   */
  public static hasPermission(userAccessControl: UserAccessControl | undefined, permission: string): boolean {
    if (!userAccessControl) {
      return false;
    }
    
    // Check direct permissions
    if (userAccessControl.permissions[permission]) {
      return true;
    }
    
    // Get all roles for the user
    const roles = this.getRoles().filter(role => userAccessControl.roles.includes(role.id));
    
    // Check permissions from roles
    for (const role of roles) {
      if (role.permissions.includes(permission)) {
        return true;
      }
    }
    
    return false;
  }
}