const Generator = require('yeoman-generator');
const chalk = require('chalk');
const yosay = require('yosay');

module.exports = class extends Generator {
  prompting() {
    // Have Yeoman greet the user.
    this.log(
      yosay(`Welcome to the ${chalk.red('Pinky\'s AI OS')} generator!`)
    );

    const prompts = [
      {
        type: 'list',
        name: 'componentType',
        message: 'What type of component would you like to generate?',
        choices: [
          {
            name: 'API Endpoint',
            value: 'api'
          },
          {
            name: 'Service',
            value: 'service'
          },
          {
            name: 'Client Component',
            value: 'component'
          },
          {
            name: 'Access Control Entity',
            value: 'access'
          },
          {
            name: 'File Sync Module',
            value: 'sync'
          }
        ]
      },
      {
        type: 'input',
        name: 'name',
        message: 'What is the name of your component?',
        validate: input => input.length > 0 ? true : 'Component name is required'
      },
      {
        type: 'input',
        name: 'description',
        message: 'Provide a brief description of this component:',
        default: 'A component for Pinky\'s AI OS'
      }
    ];

    return this.prompt(prompts).then(props => {
      // To access props later use this.props.someAnswer;
      this.props = props;
    });
  }

  writing() {
    switch(this.props.componentType) {
      case 'api':
        this._writeApiEndpoint();
        break;
      case 'service':
        this._writeService();
        break;
      case 'component':
        this._writeClientComponent();
        break;
      case 'access':
        this._writeAccessControlComponent();
        break;
      case 'sync':
        this._writeSyncModule();
        break;
    }
  }

  _writeApiEndpoint() {
    const name = this.props.name.toLowerCase();
    
    this.fs.copyTpl(
      this.templatePath('api-endpoint.ts'),
      this.destinationPath(`server/api/${name}-routes.ts`),
      {
        name: name,
        description: this.props.description,
        className: this._capitalize(name) + 'Routes',
        fileName: name
      }
    );
  }

  _writeService() {
    const name = this.props.name.toLowerCase();
    
    this.fs.copyTpl(
      this.templatePath('service.ts'),
      this.destinationPath(`server/services/${name}/${name}Service.ts`),
      {
        name: name,
        description: this.props.description,
        className: this._capitalize(name) + 'Service'
      }
    );
  }

  _writeClientComponent() {
    const name = this.props.name;
    const componentName = this._capitalize(name);
    
    this.fs.copyTpl(
      this.templatePath('react-component.tsx'),
      this.destinationPath(`client/src/components/${componentName}.tsx`),
      {
        name: name,
        description: this.props.description,
        componentName: componentName
      }
    );
  }

  _writeAccessControlComponent() {
    const name = this.props.name.toLowerCase();
    
    this.fs.copyTpl(
      this.templatePath('access-control.ts'),
      this.destinationPath(`server/services/security/${name}.ts`),
      {
        name: name,
        description: this.props.description,
        className: this._capitalize(name)
      }
    );
  }

  _writeSyncModule() {
    const name = this.props.name.toLowerCase();
    
    this.fs.copyTpl(
      this.templatePath('sync-module.ts'),
      this.destinationPath(`server/services/integration/${name}Sync.ts`),
      {
        name: name,
        description: this.props.description,
        className: this._capitalize(name) + 'SyncService'
      }
    );
  }

  _capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  install() {
    this.log(chalk.green('Component generated successfully!'));
    this.log('Make sure to register your component in the appropriate files.');
  }
};