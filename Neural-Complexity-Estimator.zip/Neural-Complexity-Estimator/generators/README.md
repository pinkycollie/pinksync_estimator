# Pinky's AI OS - Yeoman Generator

This is a [Yeoman](https://yeoman.io/) generator for quickly scaffolding components for Pinky's AI OS.

## Available Generators

The following generator templates are available:

1. **API Endpoint** - Creates a new API endpoint with basic CRUD operations and access control.
2. **Service** - Creates a new service with data management and business logic.
3. **Client Component** - Creates a new React component for the client side.
4. **Access Control Entity** - Creates a new access control entity definition with permissions and roles.
5. **File Sync Module** - Creates a new file synchronization module for integrating with external systems.

## How to Use

Run the generator using the provided script:

```bash
node scripts/generate.js
```

Follow the prompts to select the type of component you want to generate and provide the necessary information.

## Templates

### API Endpoint

Creates a RESTful API endpoint with the following features:
- GET, POST, PATCH, DELETE operations
- Access control integration
- Error handling
- Proper TypeScript typing

### Service

Creates a service class with:
- Singleton pattern implementation
- Data management methods
- TypeScript interfaces
- Error handling

### Client Component

Creates a React component with:
- React Query integration
- Access control checks
- Loading states
- Form handling
- Error handling

### Access Control Entity

Creates an access control entity with:
- Permission definitions
- Role definitions
- Permission checking methods

### File Sync Module

Creates a file synchronization module with:
- Configuration management
- Timer-based sync capability
- Error handling
- Connection management

## Customizing Templates

Templates are located in the `generators/app/templates` directory. You can modify these templates to better suit your project needs.

## Adding New Templates

To add new templates:

1. Add your template file to `generators/app/templates/`
2. Update the `index.js` file to include your new template type
3. Create a method to handle the template generation